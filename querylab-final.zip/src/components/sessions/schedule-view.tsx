"use client";

import { CalendarDays, ChevronLeft, ChevronRight, List, Rows3 } from "lucide-react";
import { useEffect, useId, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  addDaysKey,
  addMonthsKey,
  labelDay,
  monthGrid,
  sameMonth,
  startOfWeekKey,
} from "@/lib/sessions/calendar";
import { localDateKey } from "@/lib/sessions/time";
import { cn } from "@/lib/utils";
import { type SessionListItem, SessionCard } from "./session-card";

type View = "list" | "week" | "month";
const TZ_KEY = "ql-viewer-tz";

export function ScheduleView({
  sessions,
  timezones,
  profileTimezone,
  myStatuses = {},
}: {
  sessions: SessionListItem[];
  timezones: string[];
  profileTimezone?: string;
  myStatuses?: Record<string, string>;
}) {
  const [tz, setTz] = useState(profileTimezone ?? "Africa/Accra");
  const [view, setView] = useState<View>("list");
  const tzId = useId();

  // Signed-out visitors: use their saved choice or the browser's timezone.
  useEffect(() => {
    if (profileTimezone) return;
    try {
      const saved = localStorage.getItem(TZ_KEY);
      setTz(saved || Intl.DateTimeFormat().resolvedOptions().timeZone || "Africa/Accra");
    } catch {
      setTz(Intl.DateTimeFormat().resolvedOptions().timeZone || "Africa/Accra");
    }
  }, [profileTimezone]);

  const today = useMemo(() => localDateKey(new Date(), tz), [tz]);
  const byDay = useMemo(() => {
    const m = new Map<string, SessionListItem[]>();
    for (const s of sessions) {
      const k = localDateKey(s.starts_at, tz);
      m.set(k, [...(m.get(k) ?? []), s]);
    }
    return m;
  }, [sessions, tz]);

  return (
    <div className="grid gap-6">
      <div className="bg-card flex flex-col gap-4 rounded-xl border p-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="grid gap-1.5">
          <label htmlFor={tzId} className="text-sm font-medium">
            Show times in
          </label>
          <select
            id={tzId}
            value={tz}
            onChange={(e) => {
              setTz(e.target.value);
              try {
                localStorage.setItem(TZ_KEY, e.target.value);
              } catch {
                /* storage unavailable */
              }
            }}
            className="border-input bg-background h-11 max-w-xs rounded-lg border px-3 text-base sm:text-sm"
          >
            {[...new Set([tz, ...timezones])].map((t) => (
              <option key={t} value={t}>
                {t.replaceAll("_", " ")}
              </option>
            ))}
          </select>
        </div>
        <div
          role="group"
          aria-label="Calendar view"
          className="inline-flex self-start rounded-lg border p-1 sm:self-auto"
        >
          {(
            [
              ["list", "List", List],
              ["week", "Week", Rows3],
              ["month", "Month", CalendarDays],
            ] as const
          ).map(([v, label, Icon]) => (
            <button
              key={v}
              type="button"
              aria-pressed={view === v}
              onClick={() => setView(v)}
              className={cn(
                "inline-flex min-h-10 items-center gap-1.5 rounded-md px-3 text-sm font-medium",
                view === v
                  ? "bg-secondary text-secondary-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              <Icon className="size-4" aria-hidden="true" /> {label}
            </button>
          ))}
        </div>
      </div>

      {view === "list" && <ListView byDay={byDay} tz={tz} myStatuses={myStatuses} />}
      {view === "week" && <WeekView byDay={byDay} tz={tz} today={today} myStatuses={myStatuses} />}
      {view === "month" && (
        <MonthView byDay={byDay} tz={tz} today={today} myStatuses={myStatuses} />
      )}
    </div>
  );
}

type ViewProps = {
  byDay: Map<string, SessionListItem[]>;
  tz: string;
  myStatuses: Record<string, string>;
};

function ListView({ byDay, tz, myStatuses }: ViewProps) {
  const days = [...byDay.keys()].sort();
  if (!days.length) return <Empty />;
  return (
    <div className="grid gap-8">
      {days.map((d) => (
        <section key={d} aria-labelledby={`day-${d}`}>
          <h2 id={`day-${d}`} className="mb-3 text-lg font-semibold">
            {labelDay(d)}
          </h2>
          <ul className="grid gap-3 md:grid-cols-2">
            {byDay.get(d)!.map((s) => (
              <li key={s.id}>
                <SessionCard s={s} timeZone={tz} myStatus={myStatuses[s.id]} />
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

function WeekView({ byDay, tz, today, myStatuses }: ViewProps & { today: string }) {
  const [start, setStart] = useState(() => startOfWeekKey(today));
  const days = Array.from({ length: 7 }, (_, i) => addDaysKey(start, i));
  const title = `${labelDay(days[0], { day: "numeric", month: "short" })} – ${labelDay(days[6], { day: "numeric", month: "short", year: "numeric" })}`;
  return (
    <section aria-labelledby="week-title" className="grid gap-4">
      <Nav
        title={title}
        titleId="week-title"
        onPrev={() => setStart(addDaysKey(start, -7))}
        onNext={() => setStart(addDaysKey(start, 7))}
        onToday={() => setStart(startOfWeekKey(today))}
        unit="week"
      />
      <ol className="grid gap-3 lg:grid-cols-7">
        {days.map((d) => {
          const items = byDay.get(d) ?? [];
          return (
            <li key={d} className={cn("rounded-xl border p-3", d === today && "border-primary")}>
              <h3 className="text-sm font-semibold">
                {labelDay(d, { weekday: "short", day: "numeric", month: "short" })}
                {d === today && (
                  <span className="text-primary ml-1.5 text-xs font-medium">Today</span>
                )}
              </h3>
              {items.length ? (
                <ul className="mt-3 grid gap-2">
                  {items.map((s) => (
                    <li key={s.id}>
                      <SessionCard
                        s={s}
                        timeZone={tz}
                        myStatus={myStatuses[s.id]}
                        headingLevel={4}
                      />
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-muted-foreground mt-2 text-sm">No sessions</p>
              )}
            </li>
          );
        })}
      </ol>
    </section>
  );
}

function MonthView({ byDay, tz, today, myStatuses }: ViewProps & { today: string }) {
  const [focusKey, setFocusKey] = useState(today);
  const [selected, setSelected] = useState(today);
  const grid = monthGrid(focusKey);
  const cells = useRef(new Map<string, HTMLButtonElement>());
  const moved = useRef(false);

  useEffect(() => {
    if (moved.current) cells.current.get(focusKey)?.focus();
  }, [focusKey]);

  function move(to: string) {
    moved.current = true;
    setFocusKey(to);
  }

  function onKeyDown(e: React.KeyboardEvent, key: string) {
    const map: Record<string, () => string> = {
      ArrowLeft: () => addDaysKey(key, -1),
      ArrowRight: () => addDaysKey(key, 1),
      ArrowUp: () => addDaysKey(key, -7),
      ArrowDown: () => addDaysKey(key, 7),
      Home: () => startOfWeekKey(key),
      End: () => addDaysKey(startOfWeekKey(key), 6),
      PageUp: () => addMonthsKey(key, -1),
      PageDown: () => addMonthsKey(key, 1),
    };
    if (map[e.key]) {
      e.preventDefault();
      move(map[e.key]());
    }
  }

  const monthTitle = labelDay(focusKey, { month: "long", year: "numeric" });
  const selectedItems = byDay.get(selected) ?? [];

  return (
    <section aria-labelledby="month-title" className="grid gap-4">
      <Nav
        title={monthTitle}
        titleId="month-title"
        onPrev={() => setFocusKey(addMonthsKey(focusKey, -1))}
        onNext={() => setFocusKey(addMonthsKey(focusKey, 1))}
        onToday={() => {
          setFocusKey(today);
          setSelected(today);
        }}
        unit="month"
      />
      <p id="grid-help" className="sr-only">
        Use the arrow keys to move between days, Page Up and Page Down to change month, and Enter to
        show a day&apos;s sessions.
      </p>
      <div className="bg-card overflow-hidden rounded-xl border">
        <table
          role="grid"
          aria-labelledby="month-title"
          aria-describedby="grid-help"
          className="w-full table-fixed border-collapse"
        >
          <thead>
            <tr>
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d, i) => (
                <th key={d} scope="col" className="text-muted-foreground py-2 text-xs font-medium">
                  <abbr
                    title={
                      [
                        "Monday",
                        "Tuesday",
                        "Wednesday",
                        "Thursday",
                        "Friday",
                        "Saturday",
                        "Sunday",
                      ][i]
                    }
                    className="no-underline"
                  >
                    {d}
                  </abbr>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {grid.map((week) => (
              <tr key={week[0]}>
                {week.map((d) => {
                  const count = byDay.get(d)?.length ?? 0;
                  const outside = !sameMonth(d, focusKey);
                  return (
                    <td
                      key={d}
                      role="gridcell"
                      aria-selected={d === selected}
                      className="border-t p-0.5"
                    >
                      <button
                        ref={(el) => {
                          if (el) cells.current.set(d, el);
                          else cells.current.delete(d);
                        }}
                        type="button"
                        tabIndex={d === focusKey ? 0 : -1}
                        onKeyDown={(e) => onKeyDown(e, d)}
                        onClick={() => {
                          setSelected(d);
                          setFocusKey(d);
                        }}
                        aria-label={`${labelDay(d)}${d === today ? ", today" : ""}: ${count ? `${count} ${count === 1 ? "session" : "sessions"}` : "no sessions"}`}
                        className={cn(
                          "flex h-14 w-full flex-col items-center justify-start gap-1 rounded-md pt-1.5 text-sm sm:h-20",
                          outside ? "text-muted-foreground" : "text-foreground",
                          d === selected
                            ? "bg-secondary text-secondary-foreground"
                            : "hover:bg-accent",
                          d === today && "ring-primary font-semibold ring-1 ring-inset",
                        )}
                      >
                        <span aria-hidden="true">{Number(d.slice(8))}</span>
                        {count > 0 && (
                          <span aria-hidden="true" className="flex gap-0.5">
                            {Array.from({ length: Math.min(count, 3) }, (_, i) => (
                              <span key={i} className="bg-highlight size-1.5 rounded-full" />
                            ))}
                          </span>
                        )}
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <section aria-live="polite" aria-labelledby="selected-day">
        <h3 id="selected-day" className="text-lg font-semibold">
          {labelDay(selected)}
        </h3>
        {selectedItems.length ? (
          <ul className="mt-3 grid gap-3 md:grid-cols-2">
            {selectedItems.map((s) => (
              <li key={s.id}>
                <SessionCard s={s} timeZone={tz} myStatus={myStatuses[s.id]} headingLevel={4} />
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-muted-foreground mt-2">No sessions on this day.</p>
        )}
      </section>
    </section>
  );
}

function Nav({
  title,
  titleId,
  onPrev,
  onNext,
  onToday,
  unit,
}: {
  title: string;
  titleId: string;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
  unit: string;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2">
      <h2 id={titleId} className="text-xl font-semibold" aria-live="polite">
        {title}
      </h2>
      <div className="flex gap-1">
        <Button
          variant="outline"
          size="icon-lg"
          className="size-10"
          onClick={onPrev}
          aria-label={`Previous ${unit}`}
        >
          <ChevronLeft aria-hidden="true" />
        </Button>
        <Button variant="outline" size="lg" className="h-10 px-3" onClick={onToday}>
          Today
        </Button>
        <Button
          variant="outline"
          size="icon-lg"
          className="size-10"
          onClick={onNext}
          aria-label={`Next ${unit}`}
        >
          <ChevronRight aria-hidden="true" />
        </Button>
      </div>
    </div>
  );
}

function Empty() {
  return (
    <div className="rounded-xl border border-dashed p-12 text-center">
      <CalendarDays className="text-muted-foreground mx-auto size-8" aria-hidden="true" />
      <h2 className="mt-3 text-lg font-semibold">No upcoming sessions</h2>
      <p className="text-muted-foreground mt-1">
        New live sessions will appear here as soon as they&apos;re scheduled.
      </p>
    </div>
  );
}
