import { Clock, Users } from "lucide-react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { availabilityLabel } from "@/lib/sessions/capacity";
import { formatSessionRange } from "@/lib/sessions/time";

export type SessionListItem = {
  id: string;
  title: string;
  starts_at: string;
  ends_at: string;
  status: string;
  capacity: number;
  registered: number;
  waitlisted: number;
  /** null = open session; undefined = hide the course badge (e.g. on the course page). */
  course?: { title: string; slug: string } | null;
};

export function SessionCard({
  s,
  timeZone,
  myStatus,
  headingLevel = 3,
}: {
  s: SessionListItem;
  timeZone: string;
  myStatus?: string;
  headingLevel?: 2 | 3 | 4;
}) {
  const H = `h${headingLevel}` as const;
  const cancelled = s.status === "cancelled";
  return (
    <article className="bg-card focus-within:ring-ring hover:border-primary/50 relative flex flex-col gap-2 rounded-xl border p-4 focus-within:ring-2">
      <div className="flex flex-wrap items-center gap-2">
        {s.course !== undefined && (
          <Badge
            variant={s.course ? "secondary" : "outline"}
            className={s.course ? "" : "border-highlight text-highlight-text"}
          >
            {s.course ? s.course.title : "Open to all · Free"}
          </Badge>
        )}
        {cancelled && <Badge variant="destructive">Cancelled</Badge>}
        {myStatus === "registered" && <Badge>You&apos;re registered</Badge>}
        {myStatus === "waitlist" && <Badge variant="outline">On waitlist</Badge>}
      </div>
      <H className={`leading-snug font-semibold ${cancelled ? "line-through decoration-1" : ""}`}>
        <Link
          href={`/schedule/${s.id}`}
          className="after:absolute after:inset-0 focus:outline-none"
        >
          {s.title}
        </Link>
      </H>
      <p className="text-muted-foreground flex items-center gap-1.5 text-sm">
        <Clock className="size-3.5 shrink-0" aria-hidden="true" />
        <time dateTime={s.starts_at}>{formatSessionRange(s.starts_at, s.ends_at, timeZone)}</time>
      </p>
      {!cancelled && (
        <p className="text-muted-foreground flex items-center gap-1.5 text-sm">
          <Users className="size-3.5 shrink-0" aria-hidden="true" />
          {availabilityLabel(s.capacity, s.registered, s.waitlisted)}
        </p>
      )}
    </article>
  );
}
