"use client";

import { useId, useState } from "react";

type Point = { week: string; value: number };

const fmtWeek = (
  iso: string,
  opts: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" },
) =>
  new Intl.DateTimeFormat("en-GB", { ...opts, timeZone: "UTC" }).format(
    new Date(`${iso}T00:00:00Z`),
  );

/** Single-series weekly bar chart: the title names the series (no legend), hover/focus tooltips, table view. */
export function WeeklyBarChart({
  title,
  unit,
  data,
}: {
  title: string;
  unit: string;
  data: Point[];
}) {
  const [active, setActive] = useState<number | null>(null);
  const id = useId();
  const max = Math.max(1, ...data.map((d) => d.value));
  const niceMax = Math.max(4, Math.ceil(max / 4) * 4);
  const ticks = [0, niceMax / 4, niceMax / 2, (3 * niceMax) / 4, niceMax];
  const W = 640,
    H = 220,
    padL = 32,
    padB = 26,
    padT = 8;
  const innerW = W - padL;
  const innerH = H - padB - padT;
  const slot = innerW / data.length;
  const barW = Math.max(6, slot - 2); // 2px surface gap between bars
  const y = (v: number) => padT + innerH - (v / niceMax) * innerH;
  const total = data.reduce((n, d) => n + d.value, 0);

  return (
    <figure aria-labelledby={`${id}-t`} className="bg-card rounded-xl border p-5">
      <figcaption>
        <h2 id={`${id}-t`} className="font-semibold">
          {title}
        </h2>
        <p className="text-muted-foreground text-sm">
          {total} {unit} in the last {data.length} weeks
        </p>
      </figcaption>
      <div className="relative mt-4">
        <svg
          viewBox={`0 0 ${W} ${H}`}
          className="w-full"
          role="group"
          aria-label={`${title}: bar chart, ${data.length} weeks. Each bar can be focused; the table below lists every value.`}
        >
          {ticks.map((t) => (
            <g key={t}>
              <line
                x1={padL}
                x2={W}
                y1={y(t)}
                y2={y(t)}
                className="stroke-border"
                strokeWidth="1"
              />
              <text
                x={padL - 6}
                y={y(t) + 4}
                textAnchor="end"
                className="fill-muted-foreground font-mono text-[11px]"
              >
                {t}
              </text>
            </g>
          ))}
          {data.map((d, i) => {
            const x = padL + i * slot + (slot - barW) / 2;
            const h = Math.max(0, padT + innerH - y(d.value));
            const r = Math.min(4, barW / 2, h);
            return (
              <g key={d.week}>
                {/* Bar: flat at the baseline, 4px rounded data end */}
                {h > 0 && (
                  <path
                    d={`M${x},${padT + innerH} V${y(d.value) + r} Q${x},${y(d.value)} ${x + r},${y(d.value)} H${x + barW - r} Q${x + barW},${y(d.value)} ${x + barW},${y(d.value) + r} V${padT + innerH} Z`}
                    className="fill-data-1"
                    opacity={active === null || active === i ? 1 : 0.55}
                  />
                )}
                {/* Larger invisible hit target, keyboard focusable */}
                <rect
                  x={padL + i * slot}
                  y={padT}
                  width={slot}
                  height={innerH}
                  fill="transparent"
                  tabIndex={0}
                  role="button"
                  aria-label={`Week of ${fmtWeek(d.week, { day: "numeric", month: "long", year: "numeric" })}: ${d.value} ${unit}`}
                  onMouseEnter={() => setActive(i)}
                  onMouseLeave={() => setActive(null)}
                  onFocus={() => setActive(i)}
                  onBlur={() => setActive(null)}
                  className="focus-visible:stroke-ring cursor-default outline-none focus-visible:stroke-2"
                />
                {(data.length - 1 - i) % Math.ceil(data.length / 6) === 0 && (
                  <text
                    x={padL + i * slot + slot / 2}
                    y={H - 8}
                    textAnchor="middle"
                    className="fill-muted-foreground text-[11px]"
                  >
                    {fmtWeek(d.week)}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
        {active !== null && (
          <div
            role="status"
            className="bg-popover pointer-events-none absolute top-0 rounded-md border px-3 py-2 text-sm shadow-md"
            style={{
              left: `clamp(0px, calc(${((padL + active * slot + slot / 2) / W) * 100}% - 4rem), calc(100% - 8rem))`,
            }}
          >
            <p className="text-muted-foreground text-xs">Week of {fmtWeek(data[active].week)}</p>
            <p className="tabular font-mono font-medium">
              {data[active].value} {unit}
            </p>
          </div>
        )}
      </div>
      <details className="mt-3 text-sm">
        <summary className="text-primary py-1 font-medium">Show data table</summary>
        <table className="mt-2 w-full text-left">
          <caption className="sr-only">{title} by week</caption>
          <thead>
            <tr>
              <th scope="col" className="py-1 font-medium">
                Week starting
              </th>
              <th scope="col" className="py-1 text-right font-medium">
                {unit}
              </th>
            </tr>
          </thead>
          <tbody>
            {data.map((d) => (
              <tr key={d.week} className="border-t">
                <td className="py-1">
                  {fmtWeek(d.week, { day: "numeric", month: "short", year: "numeric" })}
                </td>
                <td className="tabular py-1 text-right font-mono">{d.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </details>
    </figure>
  );
}
