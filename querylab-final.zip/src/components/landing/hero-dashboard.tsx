/**
 * Decorative, illustrative dashboard for the hero. All values are sample
 * data (labelled as such) — not product statistics. Pure SVG/CSS: no JS,
 * no layout shift, and animations are disabled under prefers-reduced-motion.
 */
const bars = [38, 52, 46, 64, 58, 72, 81];
const days = ["M", "T", "W", "T", "F", "S", "S"];
// y-values in SVG space (lower = higher on screen): accuracy rising over 10 weeks
const line = [62, 58, 60, 48, 50, 40, 34, 36, 26, 22];

function linePath(points: number[], w: number, h: number) {
  const step = w / (points.length - 1);
  return points
    .map((p, i) => `${i === 0 ? "M" : "L"}${(i * step).toFixed(1)},${((p / 70) * h).toFixed(1)}`)
    .join(" ");
}

export function HeroDashboard() {
  const path = linePath(line, 260, 90);
  return (
    <figure
      className="relative"
      role="img"
      aria-label="Illustration of a QueryLab learner dashboard with sample data: weekly study hours, a model accuracy trend and an upcoming live session."
    >
      <div
        aria-hidden="true"
        className="bg-grid absolute -inset-6 -z-10 rounded-[2rem] [mask-image:radial-gradient(closest-side,black,transparent)]"
      />
      <div
        aria-hidden="true"
        className="bg-card overflow-hidden rounded-xl border shadow-[0_24px_60px_-24px_color-mix(in_oklab,var(--ink)_35%,transparent)]"
      >
        {/* window chrome */}
        <div className="bg-surface flex items-center justify-between border-b px-4 py-2.5">
          <div className="flex gap-1.5">
            <span className="bg-border size-2.5 rounded-full" />
            <span className="bg-border size-2.5 rounded-full" />
            <span className="bg-border size-2.5 rounded-full" />
          </div>
          <span className="text-muted-foreground font-mono text-[11px]">
            querylab / my-learning
          </span>
          <span className="text-muted-foreground rounded border px-1.5 py-0.5 font-mono text-[10px] tracking-wider uppercase">
            Sample
          </span>
        </div>

        <div className="grid gap-3 p-4 sm:grid-cols-3">
          {[
            { k: "Course progress", v: "64%", sub: "Power BI Mastery" },
            { k: "Lessons done", v: "27", sub: "of 42" },
            { k: "Quiz average", v: "88%", sub: "last 5 quizzes" },
          ].map((s, i) => (
            <div
              key={s.k}
              className="ql-rise bg-background rounded-lg border p-3"
              style={{ animationDelay: `${150 + i * 90}ms` }}
            >
              <p className="text-muted-foreground text-[11px] font-medium">{s.k}</p>
              <p className="tabular text-foreground mt-1 font-mono text-xl font-medium">{s.v}</p>
              <p className="text-muted-foreground text-[11px]">{s.sub}</p>
            </div>
          ))}
        </div>

        <div className="grid gap-3 px-4 pb-4 sm:grid-cols-5">
          {/* bar chart */}
          <div className="bg-background rounded-lg border p-3 sm:col-span-2">
            <p className="text-muted-foreground text-[11px] font-medium">Study hours / week</p>
            <div className="mt-3 flex h-24 items-end gap-1.5">
              {bars.map((h, i) => (
                <div key={i} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
                  <div
                    className={`ql-bar w-full rounded-t-[3px] ${i === bars.length - 1 ? "bg-highlight" : "bg-primary/80"}`}
                    style={{ height: `${h}%`, animationDelay: `${300 + i * 70}ms` }}
                  />
                  <span className="text-muted-foreground font-mono text-[9px]">{days[i]}</span>
                </div>
              ))}
            </div>
          </div>
          {/* line chart */}
          <div className="bg-background rounded-lg border p-3 sm:col-span-3">
            <div className="flex items-baseline justify-between">
              <p className="text-muted-foreground text-[11px] font-medium">Model accuracy</p>
              <p className="text-primary font-mono text-[11px]">↑ improving</p>
            </div>
            <svg viewBox="0 0 260 100" className="mt-2 h-24 w-full overflow-visible">
              {[20, 45, 70, 95].map((y) => (
                <line
                  key={y}
                  x1="0"
                  x2="260"
                  y1={y}
                  y2={y}
                  className="stroke-border"
                  strokeWidth="1"
                />
              ))}
              <path
                d={path}
                fill="none"
                className="ql-line stroke-primary"
                strokeWidth="2.25"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ ["--len" as string]: 320 }}
              />
              <circle
                cx="260"
                cy={(22 / 70) * 90}
                r="4"
                className="fill-highlight ql-rise"
                style={{ animationDelay: "1500ms" }}
              />
            </svg>
          </div>
        </div>

        {/* live session + query */}
        <div className="bg-surface/60 grid gap-3 border-t p-4 sm:grid-cols-2">
          <div className="bg-background flex items-center gap-3 rounded-lg border p-3">
            <span className="relative flex size-2.5">
              <span className="ql-pulse bg-highlight absolute inline-flex size-full rounded-full" />
              <span className="bg-highlight relative inline-flex size-2.5 rounded-full" />
            </span>
            <div className="min-w-0">
              <p className="text-foreground truncate text-xs font-medium">
                Live: DAX time intelligence
              </p>
              <p className="text-muted-foreground font-mono text-[11px]">Thu 18:00 GMT · 90 min</p>
            </div>
          </div>
          <pre className="bg-background text-muted-foreground overflow-hidden rounded-lg border p-3 font-mono text-[11px] leading-5">
            <span className="text-primary">SELECT</span> track, AVG(score){"\n"}
            <span className="text-primary">FROM</span> quizzes{" "}
            <span className="text-primary">GROUP BY</span> 1;
          </pre>
        </div>
      </div>
    </figure>
  );
}
