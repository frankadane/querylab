import Link from "next/link";
import { cn } from "@/lib/utils";

/** Wordmark: a small bar-chart glyph + "QueryLab" in Plex Sans. */
export function Logo({ className }: { className?: string }) {
  return (
    <Link
      href="/"
      className={cn(
        "text-foreground inline-flex items-center gap-2 rounded-md font-semibold tracking-tight",
        className,
      )}
      aria-label="QueryLab home"
    >
      <svg viewBox="0 0 24 24" className="size-6" aria-hidden="true">
        <rect width="24" height="24" rx="6" className="fill-primary" />
        <rect x="6" y="12" width="3" height="6" rx="1" className="fill-primary-foreground" />
        <rect x="10.5" y="8" width="3" height="10" rx="1" className="fill-primary-foreground" />
        <rect x="15" y="5" width="3" height="13" rx="1" className="fill-highlight" />
      </svg>
      <span className="text-[17px]">
        Query<span className="text-primary">Lab</span>
      </span>
    </Link>
  );
}
