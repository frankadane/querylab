"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { SIGNED_IN_FLAG } from "@/lib/supabase/cookie-options";

export function useSignedIn() {
  const [signedIn, setSignedIn] = useState(false);
  useEffect(() => {
    setSignedIn(document.cookie.split("; ").some((c) => c.startsWith(`${SIGNED_IN_FLAG}=`)));
  }, []);
  return signedIn;
}

export function HeaderAuth() {
  const signedIn = useSignedIn();
  return signedIn ? (
    <Button asChild size="lg" className="hidden px-4 sm:inline-flex">
      <Link href="/dashboard">Dashboard</Link>
    </Button>
  ) : (
    <>
      <Button asChild variant="ghost" size="lg" className="hidden px-3 sm:inline-flex">
        <Link href="/login">Log in</Link>
      </Button>
      <Button asChild size="lg" className="hidden px-4 sm:inline-flex">
        <Link href="/register">Create account</Link>
      </Button>
    </>
  );
}
