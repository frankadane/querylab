"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

export function NavLink({
  href,
  children,
  className,
  onClick,
  exact,
}: {
  href: string;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  /** Match only this exact path (for tab bars whose first tab is a parent path). */
  exact?: boolean;
}) {
  const pathname = usePathname();
  const active = exact ? pathname === href : pathname === href || pathname.startsWith(`${href}/`);
  return (
    <Link
      href={href}
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "text-muted-foreground hover:bg-accent hover:text-foreground rounded-md px-3 py-2 text-sm font-medium transition-colors duration-150",
        active && "text-foreground",
        className,
      )}
    >
      {children}
    </Link>
  );
}
