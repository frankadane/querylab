"use client";

import { Award, CheckCircle2, RotateCcw, XCircle } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useRef, useState, useTransition } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { Button } from "@/components/ui/button";
import type { QuizResult } from "@/app/(app)/learn/actions";
import { submitQuiz } from "@/app/(app)/learn/actions";
import { cn } from "@/lib/utils";

type Question = { id: string; prompt: string; options: string[] };

export function QuizPlayer({
  lessonId,
  passMark,
  questions,
  bestScore,
  passed: alreadyPassed,
}: {
  lessonId: string;
  passMark: number;
  questions: Question[];
  bestScore: number | null;
  passed: boolean;
}) {
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [result, setResult] = useState<(QuizResult & { certificate: string | null }) | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const summary = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const unanswered = questions.filter((q) => answers[q.id] === undefined).length;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (unanswered) {
      setError(`Answer all questions first (${unanswered} left).`);
      return;
    }
    setError(null);
    start(async () => {
      const r = await submitQuiz(lessonId, answers);
      if (!r.ok) return setError(r.error);
      setResult(r.data!);
      router.refresh();
      requestAnimationFrame(() => summary.current?.focus());
    });
  }

  const byId = new Map(result?.results.map((r) => [r.question_id, r]));

  return (
    <div className="grid gap-6">
      <p className="text-muted-foreground">
        {questions.length} questions · pass mark {passMark}%
        {bestScore !== null && ` · your best so far: ${bestScore}%`}
        {alreadyPassed && " · passed"}
      </p>

      {result && (
        <div
          ref={summary}
          tabIndex={-1}
          role="status"
          className={cn(
            "rounded-xl border p-5 focus:outline-none",
            result.passed
              ? "border-primary/40 bg-secondary"
              : "border-destructive/40 bg-destructive/5",
          )}
        >
          <p className="flex items-center gap-2 text-lg font-semibold">
            {result.passed ? (
              <CheckCircle2 className="text-primary size-5" aria-hidden="true" />
            ) : (
              <XCircle className="text-destructive size-5" aria-hidden="true" />
            )}
            {result.passed ? "Passed" : "Not passed yet"}: {result.score}% ({result.correct} of{" "}
            {result.total} correct)
          </p>
          <p className="text-muted-foreground mt-1 text-sm">
            {result.passed
              ? "Correct answers and explanations are shown below."
              : `You need ${result.pass_mark}%. Incorrect answers are marked; review the lessons and try again.`}
          </p>
          {result.certificate && (
            <Button asChild size="lg" className="mt-4 h-11 px-5">
              <Link href={`/certificates/${result.certificate}/pdf`} target="_blank">
                <Award aria-hidden="true" /> Course complete: download your certificate
              </Link>
            </Button>
          )}
          {!result.passed && (
            <Button
              variant="outline"
              size="lg"
              className="mt-4 h-10 px-4"
              onClick={() => {
                setResult(null);
                setAnswers({});
              }}
            >
              <RotateCcw aria-hidden="true" /> Try again
            </Button>
          )}
        </div>
      )}

      <form onSubmit={submit} noValidate className="grid gap-5">
        <ol className="grid gap-5">
          {questions.map((q, qi) => {
            const r = byId.get(q.id);
            return (
              <li key={q.id}>
                <fieldset
                  className={cn(
                    "bg-card rounded-xl border p-5",
                    r && (r.correct ? "border-primary/50" : "border-destructive/50"),
                  )}
                  aria-describedby={r ? `fb-${q.id}` : undefined}
                >
                  <legend className="px-1 font-medium">
                    <span className="sr-only">Question {qi + 1}: </span>
                    {q.prompt}
                  </legend>
                  <div className="mt-3 grid gap-2">
                    {q.options.map((o, oi) => {
                      const chosen = answers[q.id] === oi;
                      const isCorrect = r?.correct_index === oi;
                      return (
                        <label
                          key={oi}
                          className={cn(
                            "hover:bg-accent flex min-h-11 items-center gap-3 rounded-lg border px-3 py-2",
                            chosen && "border-primary",
                            isCorrect && "border-primary bg-secondary",
                          )}
                        >
                          <input
                            type="radio"
                            name={q.id}
                            checked={chosen}
                            disabled={!!result}
                            onChange={() => setAnswers({ ...answers, [q.id]: oi })}
                            className="accent-primary size-5"
                          />
                          <span>{o}</span>
                          {isCorrect && (
                            <span className="text-primary ml-auto text-xs font-medium">
                              Correct answer
                            </span>
                          )}
                        </label>
                      );
                    })}
                  </div>
                  {r && (
                    <p
                      id={`fb-${q.id}`}
                      className={cn(
                        "mt-3 text-sm font-medium",
                        r.correct ? "text-primary" : "text-destructive",
                      )}
                    >
                      {r.correct ? "Correct." : "Incorrect."} {r.explanation}
                    </p>
                  )}
                </fieldset>
              </li>
            );
          })}
        </ol>
        {!result && (
          <div className="flex flex-wrap items-center gap-4">
            <Button type="submit" size="lg" className="h-11 px-6" disabled={pending}>
              {pending ? "Checking…" : "Submit answers"}
            </Button>
            <span className="text-muted-foreground text-sm">
              {questions.length - unanswered} of {questions.length} answered
            </span>
          </div>
        )}
        <div aria-live="assertive">{error && <FormAlert kind="error">{error}</FormAlert>}</div>
      </form>
    </div>
  );
}
