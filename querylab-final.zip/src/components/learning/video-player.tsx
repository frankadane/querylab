import { PlayCircle } from "lucide-react";
import { toVideoEmbed } from "@/lib/learning/video";

export function VideoPlayer({ url, title }: { url: string | null; title: string }) {
  const embed = toVideoEmbed(url);
  if (!url) return null;
  if (!embed || embed.provider === "placeholder") {
    return (
      <div className="bg-ink flex aspect-video flex-col items-center justify-center gap-2 rounded-xl border text-center text-sm text-white/80">
        <PlayCircle className="size-10 text-white/60" aria-hidden="true" />
        {embed?.provider === "placeholder"
          ? "Video coming soon (placeholder)"
          : "This video link can't be embedded. Ask your instructor for an updated link."}
      </div>
    );
  }
  return (
    <div className="bg-ink aspect-video overflow-hidden rounded-xl border">
      <iframe
        src={embed.src}
        title={`Video: ${title}`}
        className="size-full"
        loading="lazy"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
        allowFullScreen
        referrerPolicy="strict-origin-when-cross-origin"
      />
    </div>
  );
}
