"use client";

import { Check } from "lucide-react";
import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import type { ActionResult } from "@/lib/action-result";
import { setLessonComplete } from "@/app/(app)/learn/actions";

export function CompleteButton({
  lessonId,
  done,
  nextHref,
}: {
  lessonId: string;
  done: boolean;
  nextHref: string | null;
}) {
  const [pending, start] = useTransition();
  const [result, setResult] = useState<ActionResult<{ certificate: string | null }> | null>(null);
  const router = useRouter();
  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap gap-2">
        {done ? (
          <Button
            variant="outline"
            size="lg"
            className="h-11 px-4"
            disabled={pending}
            onClick={() =>
              start(async () => {
                setResult(await setLessonComplete(lessonId, false));
                router.refresh();
              })
            }
          >
            <Check aria-hidden="true" /> Completed · undo
          </Button>
        ) : (
          <Button
            size="lg"
            className="h-11 px-5"
            disabled={pending}
            onClick={() =>
              start(async () => {
                const r = await setLessonComplete(lessonId, true);
                setResult(r);
                if (r.ok && !r.data?.certificate && nextHref) router.push(nextHref);
                else router.refresh();
              })
            }
          >
            <Check aria-hidden="true" /> {nextHref ? "Mark complete and continue" : "Mark complete"}
          </Button>
        )}
      </div>
      <div aria-live="polite">
        {result && !result.ok && <FormAlert kind="error">{result.error}</FormAlert>}
      </div>
    </div>
  );
}
