import { Check, Circle } from "lucide-react";
import Link from "next/link";
import { LessonTypeIcon } from "@/components/courses/lesson-type-icon";
import type { LearningCourse } from "@/lib/learning/queries";
import { cn } from "@/lib/utils";

export function CourseOutline({ data, currentId }: { data: LearningCourse; currentId: string }) {
  return (
    <nav aria-label="Course outline">
      <ol className="grid gap-5">
        {data.course.sections.map((s, si) => (
          <li key={s.id}>
            <h2 className="text-muted-foreground px-2 text-xs font-semibold tracking-wide uppercase">
              {si + 1}. {s.title}
            </h2>
            <ol className="mt-1.5 grid gap-0.5">
              {s.lessons.map((l) => {
                const done = data.done.has(l.id);
                const current = l.id === currentId;
                return (
                  <li key={l.id}>
                    <Link
                      href={`/learn/${data.course.slug}/${l.id}`}
                      aria-current={current ? "page" : undefined}
                      className={cn(
                        "hover:bg-accent flex min-h-10 items-start gap-2.5 rounded-md px-2 py-2 text-sm",
                        current && "bg-secondary text-secondary-foreground font-medium",
                      )}
                    >
                      {done ? (
                        <Check className="text-primary mt-0.5 size-4 shrink-0" aria-hidden="true" />
                      ) : (
                        <Circle
                          className="text-muted-foreground mt-0.5 size-4 shrink-0"
                          aria-hidden="true"
                        />
                      )}
                      <span className="flex-1">
                        {l.title}
                        <span className="sr-only">
                          {done ? " (completed)" : " (not completed)"}
                        </span>
                      </span>
                      <LessonTypeIcon
                        type={l.type}
                        className="text-muted-foreground mt-0.5 size-3.5 shrink-0"
                      />
                    </Link>
                  </li>
                );
              })}
            </ol>
          </li>
        ))}
      </ol>
    </nav>
  );
}
