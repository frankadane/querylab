"use client";

import { FileDown } from "lucide-react";
import { FormAlert } from "@/components/forms/form-alert";
import { useAction } from "@/components/forms/use-action";
import { Button } from "@/components/ui/button";
import { getLessonFileUrl } from "@/app/(app)/learn/actions";

export function FileDownload({ lessonId, fileName }: { lessonId: string; fileName: string }) {
  const { pending, result, run } = useAction();
  return (
    <div className="bg-card flex flex-wrap items-center gap-3 rounded-xl border p-4">
      <FileDown className="text-primary size-5" aria-hidden="true" />
      <span className="min-w-0 flex-1 truncate font-medium">{fileName}</span>
      <Button
        variant="outline"
        size="lg"
        className="h-10 px-4"
        disabled={pending}
        onClick={() =>
          run(
            () => getLessonFileUrl(lessonId),
            (r) => {
              if (r.ok && r.data) window.location.assign(r.data.url);
            },
          )
        }
      >
        {pending ? "Preparing…" : "Download"}
      </Button>
      {result && !result.ok && (
        <FormAlert kind="error" className="w-full">
          {result.error}
        </FormAlert>
      )}
    </div>
  );
}
