import Link from "next/link";
import { CourseCover } from "@/components/courses/course-cover";
import type { Track } from "@/lib/courses/format";
import { ProgressBar } from "./progress-bar";

export function MyCourseCard({
  c,
}: {
  c: {
    slug: string;
    title: string;
    track: Track;
    thumbnail_url: string | null;
    progress: { percent: number; completed: number; total: number };
  };
}) {
  return (
    <article className="bg-card focus-within:ring-ring hover:border-primary/50 relative flex flex-col overflow-hidden rounded-xl border focus-within:ring-2">
      <CourseCover track={c.track} src={c.thumbnail_url} />
      <div className="grid gap-3 p-5">
        <h3 className="font-semibold">
          <Link
            href={`/learn/${c.slug}`}
            className="after:absolute after:inset-0 focus:outline-none"
          >
            {c.title}
          </Link>
        </h3>
        <ProgressBar
          percent={c.progress.percent}
          label={`${c.progress.completed} of ${c.progress.total} lessons`}
        />
        <p className="text-primary text-sm font-medium">
          {c.progress.percent === 0
            ? "Start course"
            : c.progress.percent === 100
              ? "Review course"
              : "Continue"}{" "}
          →
        </p>
      </div>
    </article>
  );
}
