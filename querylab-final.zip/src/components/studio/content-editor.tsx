"use client";

import { ImagePlus, Trash2 } from "lucide-react";
import Image from "next/image";
import { useRef, useState, useTransition } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { MarkdownField } from "@/components/forms/markdown-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { Button } from "@/components/ui/button";
import {
  deleteContent,
  saveContent,
  setPostCover,
  uploadContentImage,
} from "@/app/(app)/admin/content-actions";
import { type ContentInput, contentSchema } from "@/lib/validation/content";

export function ContentEditor({
  kind,
  id,
  defaults,
  coverUrl,
  publicPath,
}: {
  kind: "posts" | "pages";
  id: string;
  defaults: ContentInput;
  coverUrl?: string | null;
  publicPath: string;
}) {
  const { form, pending, result, onSubmit } = useActionForm(
    contentSchema,
    (v) => saveContent(kind, id, v),
    defaults,
  );
  const e = form.formState.errors;
  const r = form.register;
  const [uploading, startUpload] = useTransition();
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);
  const imgInput = useRef<HTMLInputElement>(null);
  const coverInput = useRef<HTMLInputElement>(null);
  const [cover, setCover] = useState(coverUrl ?? null);

  function upload(file: File, onUrl: (url: string) => void) {
    const fd = new FormData();
    fd.set("file", file);
    startUpload(async () => {
      const res = await uploadContentImage(fd);
      if (res.ok && res.data) onUrl(res.data.url);
      else setNotice({ ok: false, text: res.ok ? "Upload failed." : res.error });
    });
  }

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <FormField
          label="Title"
          registration={r("title")}
          error={e.title}
          className="sm:col-span-2"
        />
        <FormField
          label="URL slug"
          hint={`Public address: ${publicPath}${form.watch("slug") ?? ""}`}
          registration={r("slug")}
          error={e.slug}
        />
        <SelectField
          label="Status"
          registration={r("status")}
          options={{ draft: "Draft (hidden)", published: "Published" }}
        />
        {kind === "posts" && (
          <>
            <FormField
              label="Excerpt"
              hint="One or two sentences for the blog list and search results."
              registration={r("excerpt")}
              error={e.excerpt}
              className="sm:col-span-2"
            />
            <FormField
              label="Tags"
              hint="Comma separated, e.g. power-bi, dax"
              registration={r("tags")}
              error={e.tags}
            />
          </>
        )}
      </div>

      {kind === "posts" && (
        <section aria-labelledby="cover-h" className="bg-card grid gap-3 rounded-xl border p-5">
          <h2 id="cover-h" className="font-semibold">
            Cover image (optional)
          </h2>
          {cover && (
            <div className="relative aspect-[16/9] max-w-md overflow-hidden rounded-lg border">
              <Image src={cover} alt="" fill sizes="448px" className="object-cover" />
            </div>
          )}
          <FormField
            label="Cover image description (alt text)"
            hint="Describe the image for people who can't see it."
            registration={r("coverAlt")}
            error={e.coverAlt}
          />
          <div className="flex flex-wrap gap-2">
            <input
              ref={coverInput}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="sr-only"
              tabIndex={-1}
              aria-hidden="true"
              onChange={(ev) => {
                const f = ev.target.files?.[0];
                if (f)
                  upload(f, (url) =>
                    startUpload(async () => {
                      const res = await setPostCover(id, url);
                      if (res.ok) setCover(url);
                      setNotice({ ok: res.ok, text: res.ok ? res.message! : res.error });
                    }),
                  );
                ev.target.value = "";
              }}
            />
            <Button
              type="button"
              variant="outline"
              size="lg"
              className="h-10 px-4"
              disabled={uploading}
              onClick={() => coverInput.current?.click()}
            >
              <ImagePlus aria-hidden="true" /> {cover ? "Replace cover" : "Upload cover"}
            </Button>
            {cover && (
              <Button
                type="button"
                variant="ghost"
                size="lg"
                className="h-10 px-3"
                disabled={uploading}
                onClick={() =>
                  startUpload(async () => {
                    const res = await setPostCover(id, null);
                    if (res.ok) setCover(null);
                  })
                }
              >
                Remove
              </Button>
            )}
          </div>
        </section>
      )}

      <div className="grid gap-2">
        <MarkdownField
          label="Content"
          rows={20}
          registration={r("bodyMd")}
          value={form.watch("bodyMd") ?? ""}
          error={e.bodyMd}
        />
        <div>
          <input
            ref={imgInput}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="sr-only"
            tabIndex={-1}
            aria-hidden="true"
            onChange={(ev) => {
              const f = ev.target.files?.[0];
              ev.target.value = "";
              if (!f) return;
              const alt = window.prompt(
                "Describe this image for people who can't see it (alt text):",
                "",
              );
              if (alt === null) return;
              if (!alt.trim()) {
                setNotice({
                  ok: false,
                  text: "Alt text is required for accessibility. Image not inserted.",
                });
                return;
              }
              upload(f, (url) => {
                form.setValue(
                  "bodyMd",
                  `${form.getValues("bodyMd") ?? ""}\n\n![${alt.replace(/[[\]]/g, "")}](${url})\n`,
                  { shouldDirty: true },
                );
                setNotice({ ok: true, text: "Image inserted at the end of the content." });
              });
            }}
          />
          <Button
            type="button"
            variant="outline"
            size="lg"
            className="h-10 px-4"
            disabled={uploading}
            onClick={() => imgInput.current?.click()}
          >
            <ImagePlus aria-hidden="true" /> {uploading ? "Uploading…" : "Insert image"}
          </Button>
        </div>
      </div>

      <fieldset className="grid gap-5 border-t pt-8 sm:grid-cols-2">
        <legend className="mb-4 text-lg font-semibold">Search engines (optional)</legend>
        <FormField
          label="SEO title"
          hint="Up to 70 characters. Defaults to the title."
          registration={r("seoTitle")}
          error={e.seoTitle}
        />
        <FormField
          label="SEO description"
          hint="Up to 200 characters."
          registration={r("seoDescription")}
          error={e.seoDescription}
        />
      </fieldset>

      <div className="bg-background/95 sticky bottom-0 -mx-4 flex flex-wrap items-center gap-4 border-t px-4 py-4 backdrop-blur">
        <SubmitButton pending={pending} className="px-6">
          Save
        </SubmitButton>
        <Button
          type="button"
          variant="ghost"
          size="lg"
          className="text-destructive h-11"
          onClick={() => {
            if (confirm("Delete permanently?"))
              deleteContent(kind, id).then(
                (res) => res && !res.ok && setNotice({ ok: false, text: res.error }),
              );
          }}
        >
          <Trash2 aria-hidden="true" /> Delete
        </Button>
        <div aria-live="polite" className="min-w-0 flex-1">
          {result && (
            <FormAlert kind={result.ok ? "success" : "error"}>
              {result.ok ? result.message : result.error}
            </FormAlert>
          )}
          {notice && (
            <FormAlert kind={notice.ok ? "success" : "error"} className="mt-2">
              {notice.text}
            </FormAlert>
          )}
        </div>
      </div>
    </form>
  );
}
