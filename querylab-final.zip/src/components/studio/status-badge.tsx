import { Badge } from "@/components/ui/badge";
import { type CourseStatus, STATUSES } from "@/lib/courses/format";
import { cn } from "@/lib/utils";

export function StatusBadge({ status }: { status: CourseStatus }) {
  return (
    <Badge
      variant="outline"
      className={cn(
        status === "published" && "border-primary/40 bg-secondary text-secondary-foreground",
        status === "draft" && "border-highlight text-highlight-text",
        status === "archived" && "text-muted-foreground",
      )}
    >
      {STATUSES[status]}
    </Badge>
  );
}
