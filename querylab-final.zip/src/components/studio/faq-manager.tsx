"use client";

import { Pencil, Plus, Trash2 } from "lucide-react";
import { useState, useTransition } from "react";
import { Markdown } from "@/components/content/markdown";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { MarkdownField } from "@/components/forms/markdown-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { ActionResult } from "@/lib/action-result";
import { faqSchema } from "@/lib/validation/courses";

type Faq = { id: string; question: string; answer_md: string; is_published: boolean };

export function FaqManager({
  faqs,
  save,
  remove,
  description,
}: {
  faqs: Faq[];
  save: (id: string | null, input: unknown) => Promise<ActionResult>;
  remove: (id: string) => Promise<ActionResult>;
  description: string;
}) {
  const [editing, setEditing] = useState<string | "new" | null>(null);
  const [status, setStatus] = useState<ActionResult | null>(null);
  const [pending, start] = useTransition();

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="text-muted-foreground">{description}</p>
        <Button
          size="lg"
          className="h-10 px-4"
          onClick={() => setEditing("new")}
          disabled={editing === "new"}
        >
          <Plus aria-hidden="true" /> Add FAQ
        </Button>
      </div>
      <div aria-live="polite">
        {status && (
          <FormAlert kind={status.ok ? "success" : "error"}>
            {status.ok ? status.message : status.error}
          </FormAlert>
        )}
      </div>
      {editing === "new" && (
        <FaqForm
          onCancel={() => setEditing(null)}
          onSave={async (v) => {
            const r = await save(null, v);
            setStatus(r);
            if (r.ok) setEditing(null);
            return r;
          }}
        />
      )}
      <ol className="grid gap-3">
        {faqs.map((f) =>
          editing === f.id ? (
            <li key={f.id}>
              <FaqForm
                defaults={{
                  question: f.question,
                  answerMd: f.answer_md,
                  isPublished: f.is_published,
                }}
                onCancel={() => setEditing(null)}
                onSave={async (v) => {
                  const r = await save(f.id, v);
                  setStatus(r);
                  if (r.ok) setEditing(null);
                  return r;
                }}
              />
            </li>
          ) : (
            <li key={f.id} className="bg-card rounded-xl border p-5">
              <div className="flex items-start gap-3">
                <div className="min-w-0 flex-1">
                  <h3 className="font-semibold">{f.question}</h3>
                  {!f.is_published && (
                    <Badge variant="outline" className="mt-1">
                      Hidden
                    </Badge>
                  )}
                  <Markdown className="text-muted-foreground mt-2 text-sm">{f.answer_md}</Markdown>
                </div>
                <Button
                  variant="ghost"
                  size="icon-lg"
                  className="size-10"
                  aria-label={`Edit FAQ: ${f.question}`}
                  onClick={() => setEditing(f.id)}
                >
                  <Pencil className="size-4" aria-hidden="true" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon-lg"
                  className="text-destructive size-10"
                  aria-label={`Delete FAQ: ${f.question}`}
                  disabled={pending}
                  onClick={() => {
                    if (confirm("Delete this FAQ?"))
                      start(async () => setStatus(await remove(f.id)));
                  }}
                >
                  <Trash2 className="size-4" aria-hidden="true" />
                </Button>
              </div>
            </li>
          ),
        )}
      </ol>
      {faqs.length === 0 && editing !== "new" && (
        <p className="text-muted-foreground rounded-xl border border-dashed p-8 text-center">
          No FAQs yet.
        </p>
      )}
    </div>
  );
}

function FaqForm({
  defaults = { question: "", answerMd: "", isPublished: true },
  onSave,
  onCancel,
}: {
  defaults?: { question: string; answerMd: string; isPublished: boolean };
  onSave: (v: unknown) => Promise<ActionResult>;
  onCancel: () => void;
}) {
  const { form, pending, result, onSubmit } = useActionForm(faqSchema, onSave, defaults);
  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="border-primary/40 bg-card grid gap-4 rounded-xl border-2 p-5"
    >
      {result && !result.ok && <FormAlert kind="error">{result.error}</FormAlert>}
      <FormField
        label="Question"
        registration={form.register("question")}
        error={form.formState.errors.question}
      />
      <MarkdownField
        label="Answer"
        rows={5}
        registration={form.register("answerMd")}
        value={form.watch("answerMd") ?? ""}
        error={form.formState.errors.answerMd}
      />
      <label className="flex items-center gap-3 text-sm">
        <input
          type="checkbox"
          className="accent-primary size-5"
          {...form.register("isPublished")}
        />{" "}
        Visible on the site
      </label>
      <div className="flex gap-2">
        <SubmitButton pending={pending} className="px-5">
          Save FAQ
        </SubmitButton>
        <Button type="button" variant="ghost" size="lg" className="h-11" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
