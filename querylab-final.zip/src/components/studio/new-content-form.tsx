"use client";

import { Plus } from "lucide-react";
import { useState, useTransition } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createContent } from "@/app/(app)/admin/content-actions";

export function NewContentForm({ kind }: { kind: "posts" | "pages" }) {
  const [title, setTitle] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  return (
    <form
      className="flex flex-col gap-2 sm:flex-row sm:items-end"
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          const r = await createContent(kind, title);
          if (r && !r.ok) setError(r.error);
        });
      }}
    >
      <div className="grid flex-1 gap-1.5">
        <Label htmlFor="new-title">{kind === "posts" ? "New post title" : "New page title"}</Label>
        <Input
          id="new-title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={200}
          className="h-11"
        />
      </div>
      <Button type="submit" size="lg" className="h-11 px-4" disabled={pending || !title.trim()}>
        <Plus aria-hidden="true" /> Create draft
      </Button>
      {error && (
        <FormAlert kind="error" className="w-full">
          {error}
        </FormAlert>
      )}
    </form>
  );
}
