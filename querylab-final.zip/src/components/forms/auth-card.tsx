export function AuthCard({
  title,
  description,
  children,
  footer,
}: {
  title: string;
  description?: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
}) {
  return (
    <div className="bg-card rounded-xl border p-6 shadow-sm sm:p-8">
      <h1 className="text-2xl font-semibold">{title}</h1>
      {description && <p className="text-muted-foreground mt-2">{description}</p>}
      <div className="mt-6">{children}</div>
      {footer && <div className="text-muted-foreground mt-6 border-t pt-5 text-sm">{footer}</div>}
    </div>
  );
}
