"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useState, useTransition } from "react";
import { type DefaultValues, type FieldValues, type Path, useForm } from "react-hook-form";
import type { z } from "zod";
import type { ActionResult } from "@/lib/action-result";

/**
 * react-hook-form + zod on the client, then the same schema re-validated by
 * the server action. The server receives the RAW form input (not the
 * client-side transformed output) so schemas with non-idempotent transforms
 * (e.g. "one per line" → string[]) parse identically on both sides.
 * Server field errors are mapped back onto the form.
 */
export function useActionForm<S extends z.ZodType<FieldValues, FieldValues>>(
  schema: S,
  action: (values: z.input<S>) => Promise<ActionResult | undefined | void>,
  defaultValues?: DefaultValues<z.input<S>>,
) {
  const form = useForm<z.input<S>, unknown, z.infer<S>>({
    resolver: zodResolver(schema),
    defaultValues,
    mode: "onTouched",
  });
  const [pending, startTransition] = useTransition();
  const [result, setResult] = useState<ActionResult | null>(null);

  const onSubmit = form.handleSubmit(() => {
    setResult(null);
    const raw = form.getValues();
    startTransition(async () => {
      const res = await action(raw);
      if (!res) return; // redirected
      setResult(res);
      if (!res.ok && res.fieldErrors) {
        for (const [key, messages] of Object.entries(res.fieldErrors)) {
          if (messages?.[0] && key !== "_form") {
            form.setError(key as Path<z.input<S>>, { message: messages[0] });
          }
        }
      }
    });
  });

  return { form, pending, result, onSubmit, setResult };
}
