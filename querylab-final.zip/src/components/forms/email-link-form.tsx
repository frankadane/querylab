"use client";

import type { ActionResult } from "@/lib/action-result";
import { emailOnlySchema, type EmailOnlyValues } from "@/lib/validation/auth";
import { FormAlert } from "./form-alert";
import { FormField } from "./form-field";
import { SubmitButton } from "./submit-button";
import { useActionForm } from "./use-action-form";

export function EmailLinkForm({
  action,
  submitLabel,
}: {
  action: (v: EmailOnlyValues) => Promise<ActionResult>;
  submitLabel: string;
}) {
  const { form, pending, result, onSubmit } = useActionForm(emailOnlySchema, action, { email: "" });
  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5">
      {result && (
        <FormAlert kind={result.ok ? "success" : "error"}>
          {result.ok ? result.message : result.error}
        </FormAlert>
      )}
      <FormField
        label="Email"
        type="email"
        autoComplete="email"
        registration={form.register("email")}
        error={form.formState.errors.email}
      />
      <SubmitButton pending={pending}>{submitLabel}</SubmitButton>
    </form>
  );
}
