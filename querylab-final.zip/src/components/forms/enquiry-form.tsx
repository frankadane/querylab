"use client";

import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { submitEnquiry } from "@/app/(marketing)/enquiry-actions";
import { enquirySchema } from "@/lib/validation/enquiry";

export function EnquiryForm({ kind }: { kind: "contact" | "corporate" }) {
  const { form, pending, result, onSubmit } = useActionForm(enquirySchema, submitEnquiry, {
    kind,
    name: "",
    email: "",
    company: "",
    teamSize: "",
    topic: "",
    message: "",
    website: "",
  });
  const e = form.formState.errors;
  if (result?.ok) return <FormAlert kind="success">{result.message}</FormAlert>;
  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2">
      {result && !result.ok && (
        <FormAlert kind="error" className="sm:col-span-2">
          {result.error}
        </FormAlert>
      )}
      <FormField
        label="Your name"
        autoComplete="name"
        registration={form.register("name")}
        error={e.name}
      />
      <FormField
        label="Work email"
        type="email"
        autoComplete="email"
        registration={form.register("email")}
        error={e.email}
      />
      {kind === "corporate" ? (
        <>
          <FormField
            label="Company"
            autoComplete="organization"
            registration={form.register("company")}
            error={e.company}
          />
          <SelectField
            label="Team size"
            registration={form.register("teamSize")}
            options={[
              ["", "Choose…"],
              ["1-5", "1–5"],
              ["6-15", "6–15"],
              ["16-50", "16–50"],
              ["50+", "More than 50"],
            ]}
          />
          <SelectField
            label="Main interest"
            className="sm:col-span-2"
            registration={form.register("topic")}
            options={[
              ["", "Choose…"],
              ["Applied AI", "Applied AI"],
              ["Data Science", "Data Science with Python & SQL"],
              ["Power BI", "Power BI"],
              ["Mixed", "A mix / not sure yet"],
            ]}
          />
        </>
      ) : (
        <FormField
          label="Subject (optional)"
          className="sm:col-span-2"
          registration={form.register("topic")}
          error={e.topic}
        />
      )}
      <FormField
        label={kind === "corporate" ? "What does your team need?" : "Message"}
        multiline
        className="sm:col-span-2"
        hint={
          kind === "corporate"
            ? "Goals, current skill level, preferred dates and format (online/in person)."
            : undefined
        }
        registration={form.register("message")}
        error={e.message}
      />
      {/* Honeypot: hidden from people and assistive tech; bots tend to fill it. */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label>
          Website
          <input tabIndex={-1} autoComplete="off" {...form.register("website")} />
        </label>
      </div>
      <p className="text-muted-foreground text-sm sm:col-span-2">
        We use your details only to reply. See our{" "}
        <a href="/privacy" className="text-primary font-medium underline">
          privacy policy
        </a>
        .
      </p>
      <SubmitButton pending={pending} className="justify-self-start px-6">
        {kind === "corporate" ? "Send enquiry" : "Send message"}
      </SubmitButton>
    </form>
  );
}
