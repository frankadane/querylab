"use client";

import { useId } from "react";
import type { FieldError, UseFormRegisterReturn } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export function SelectField({
  label,
  registration,
  options,
  error,
  hint,
  className,
}: {
  label: string;
  registration: UseFormRegisterReturn;
  options: Record<string, string> | [string, string][];
  error?: FieldError | { message?: string };
  hint?: string;
  className?: string;
}) {
  const id = useId();
  const entries = Array.isArray(options) ? options : Object.entries(options);
  const describedBy =
    [hint && `${id}-hint`, error?.message && `${id}-err`].filter(Boolean).join(" ") || undefined;
  return (
    <div className={cn("grid min-w-0 gap-2", className)}>
      <Label htmlFor={id}>{label}</Label>
      <select
        id={id}
        {...registration}
        aria-invalid={error?.message ? true : undefined}
        aria-describedby={describedBy}
        className="border-input bg-background h-11 w-full min-w-0 rounded-lg border px-3 text-base sm:text-sm"
      >
        {entries.map(([v, l]) => (
          <option key={v} value={v}>
            {l}
          </option>
        ))}
      </select>
      {hint && (
        <p id={`${id}-hint`} className="text-muted-foreground text-sm">
          {hint}
        </p>
      )}
      {error?.message && (
        <p id={`${id}-err`} className="text-destructive text-sm font-medium">
          {error.message}
        </p>
      )}
    </div>
  );
}
