"use client";

import { useId } from "react";
import type { FieldError, UseFormRegisterReturn } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

type Base = {
  label: string;
  error?: FieldError | { message?: string };
  hint?: string;
  registration: UseFormRegisterReturn;
  className?: string;
};

/** Labelled input with hint + error wired to aria-describedby / aria-invalid. */
export function FormField({
  label,
  error,
  hint,
  registration,
  className,
  multiline,
  ...inputProps
}: Base &
  Omit<React.InputHTMLAttributes<HTMLInputElement>, "name" | "onChange" | "onBlur" | "ref"> & {
    multiline?: boolean;
  }) {
  const id = useId();
  const hintId = hint ? `${id}-hint` : undefined;
  const errorId = error?.message ? `${id}-error` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(" ") || undefined;
  const shared = {
    id,
    "aria-invalid": error?.message ? true : undefined,
    "aria-describedby": describedBy,
    className: "h-11 text-base sm:text-sm",
  };

  return (
    <div className={cn("grid min-w-0 gap-2", className)}>
      <Label htmlFor={id}>{label}</Label>
      {multiline ? (
        <Textarea
          {...registration}
          {...shared}
          className="min-h-28 text-base sm:text-sm"
          placeholder={inputProps.placeholder}
        />
      ) : (
        <Input {...registration} {...shared} {...inputProps} />
      )}
      {hint && (
        <p id={hintId} className="text-muted-foreground text-sm">
          {hint}
        </p>
      )}
      {error?.message && (
        <p id={errorId} className="text-destructive text-sm font-medium">
          {error.message}
        </p>
      )}
    </div>
  );
}
