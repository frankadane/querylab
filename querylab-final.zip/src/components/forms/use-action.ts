"use client";

import { useState, useTransition } from "react";
import type { ActionResult } from "@/lib/action-result";

/** For button-triggered server actions: pending state + last result for an aria-live region. */
export function useAction() {
  const [pending, start] = useTransition();
  const [result, setResult] = useState<ActionResult<unknown> | null>(null);
  function run<T>(
    fn: () => Promise<ActionResult<T> | undefined | void>,
    onOk?: (r: ActionResult<T>) => void,
  ) {
    start(async () => {
      const r = await fn();
      if (!r) return;
      setResult(r as ActionResult<unknown>);
      if (r.ok) onOk?.(r);
    });
  }
  return { pending, result, run, setResult };
}
