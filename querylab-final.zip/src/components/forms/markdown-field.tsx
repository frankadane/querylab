"use client";

import { useId, useState } from "react";
import type { FieldError, UseFormRegisterReturn } from "react-hook-form";
import { Markdown } from "@/components/content/markdown";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

/** Markdown textarea with an accessible Write / Preview toggle. */
export function MarkdownField({
  label,
  registration,
  value,
  error,
  rows = 12,
  hint = "Markdown supported: ## headings, **bold**, - lists, [links](https://…), `code`, tables.",
}: {
  label: string;
  registration: UseFormRegisterReturn;
  value: string;
  error?: FieldError;
  rows?: number;
  hint?: string;
}) {
  const id = useId();
  const [preview, setPreview] = useState(false);
  return (
    <div className="grid gap-2">
      <div className="flex items-center justify-between gap-2">
        <Label htmlFor={id}>{label}</Label>
        <div
          role="group"
          aria-label={`${label} view`}
          className="inline-flex rounded-lg border p-0.5 text-sm"
        >
          {(["Write", "Preview"] as const).map((m) => {
            const active = (m === "Preview") === preview;
            return (
              <button
                key={m}
                type="button"
                aria-pressed={active}
                onClick={() => setPreview(m === "Preview")}
                className={cn(
                  "rounded-md px-3 py-1.5 font-medium",
                  active
                    ? "bg-secondary text-secondary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {m}
              </button>
            );
          })}
        </div>
      </div>
      <textarea
        id={id}
        rows={rows}
        {...registration}
        hidden={preview}
        aria-invalid={error ? true : undefined}
        aria-describedby={`${id}-hint`}
        className="border-input bg-background rounded-lg border p-3 font-mono text-sm leading-6"
      />
      {preview && (
        <div className="bg-card min-h-40 rounded-lg border p-4">
          {value.trim() ? (
            <Markdown>{value}</Markdown>
          ) : (
            <p className="text-muted-foreground">Nothing to preview yet.</p>
          )}
        </div>
      )}
      <p id={`${id}-hint`} className="text-muted-foreground text-sm">
        {hint}
      </p>
      {error?.message && <p className="text-destructive text-sm font-medium">{error.message}</p>}
    </div>
  );
}
