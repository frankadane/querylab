import { CircleAlert, CircleCheck } from "lucide-react";
import { cn } from "@/lib/utils";

/** Announced form-level message. Errors use role=alert, success uses role=status. */
export function FormAlert({
  kind,
  children,
  className,
}: {
  kind: "error" | "success";
  children: React.ReactNode;
  className?: string;
}) {
  const Icon = kind === "error" ? CircleAlert : CircleCheck;
  return (
    <div
      role={kind === "error" ? "alert" : "status"}
      className={cn(
        "flex gap-2.5 rounded-lg border p-3 text-sm",
        kind === "error"
          ? "border-destructive/40 bg-destructive/5 text-destructive"
          : "border-primary/30 bg-secondary text-secondary-foreground",
        className,
      )}
    >
      <Icon className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
      <div>{children}</div>
    </div>
  );
}
