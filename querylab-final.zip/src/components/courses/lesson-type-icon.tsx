import { FileDown, FileText, ListChecks, PlayCircle, Video } from "lucide-react";
import type { LessonType } from "@/lib/courses/format";

const ICONS = {
  video: PlayCircle,
  article: FileText,
  file: FileDown,
  quiz: ListChecks,
  live_session: Video,
} as const;

export function LessonTypeIcon({ type, className }: { type: LessonType; className?: string }) {
  const Icon = ICONS[type];
  return <Icon className={className ?? "size-4"} aria-hidden="true" />;
}
