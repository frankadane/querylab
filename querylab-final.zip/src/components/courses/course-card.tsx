import { BookOpen, Clock } from "lucide-react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { FORMATS, TRACKS, formatPrice, levelLabel } from "@/lib/courses/format";
import type { CourseCardData } from "@/lib/courses/queries";
import { CourseCover } from "./course-cover";

export function CourseCard({
  course,
  headingLevel = 2,
}: {
  course: CourseCardData;
  headingLevel?: 2 | 3;
}) {
  const H = `h${headingLevel}` as const;
  return (
    <article className="group bg-card focus-within:ring-ring hover:border-primary/50 relative flex h-full flex-col overflow-hidden rounded-xl border transition-[border-color,box-shadow] duration-200 focus-within:ring-2 hover:shadow-[0_8px_30px_-12px_color-mix(in_oklab,var(--primary)_40%,transparent)]">
      <CourseCover track={course.track} src={course.thumbnail_url} />
      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="secondary">{TRACKS[course.track]}</Badge>
          <Badge variant="outline">{FORMATS[course.format]}</Badge>
          {course.is_demo && (
            <Badge variant="outline" className="border-highlight text-highlight-text">
              Demo
            </Badge>
          )}
        </div>
        <H className="mt-3 text-lg leading-snug font-semibold">
          <Link
            href={`/courses/${course.slug}`}
            className="after:absolute after:inset-0 focus:outline-none"
          >
            {course.title}
          </Link>
        </H>
        {course.subtitle && (
          <p className="text-muted-foreground mt-2 line-clamp-3 flex-1 text-sm leading-6">
            {course.subtitle}
          </p>
        )}
        <dl className="text-muted-foreground mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm">
          <div className="flex items-center gap-1.5">
            <dt className="sr-only">Level</dt>
            <dd>{levelLabel(course.level_min, course.level_max)}</dd>
          </div>
          {course.duration_weeks && (
            <div className="flex items-center gap-1.5">
              <Clock className="size-3.5" aria-hidden="true" />
              <dt className="sr-only">Duration</dt>
              <dd>{course.duration_weeks} weeks</dd>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <BookOpen className="size-3.5" aria-hidden="true" />
            <dt className="sr-only">Lessons</dt>
            <dd>{course.lessonCount} lessons</dd>
          </div>
        </dl>
        <p className="mt-4 border-t pt-4 font-mono text-base font-medium">
          <span className="sr-only">Price: </span>
          {formatPrice(course.price_minor, course.currency)}
        </p>
      </div>
    </article>
  );
}
