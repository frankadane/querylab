"use client";

import Link from "next/link";
import { useEffect, useState, useTransition } from "react";
import { enrolFree, getEnrolmentState } from "@/app/(app)/learn/actions";
import { FormAlert } from "@/components/forms/form-alert";
import { useSignedIn } from "@/components/site/header-auth";
import { Button } from "@/components/ui/button";

/** Public course pages are cached, so enrolment state is fetched for the viewer after load. */
export function EnrolCta({
  slug,
  courseId,
  free,
  priceLabel,
}: {
  slug: string;
  courseId: string;
  free: boolean;
  priceLabel?: string;
}) {
  const signedIn = useSignedIn();
  const [state, setState] = useState<{
    enrolled: boolean;
    revoked?: boolean;
    pendingOrder?: string | null;
  } | null>(null);
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (signedIn) getEnrolmentState(courseId).then((s) => setState(s));
  }, [signedIn, courseId]);

  if (!signedIn) {
    return (
      <div className="grid gap-2">
        <Button asChild size="lg" className="h-12 text-base">
          <Link href={`/register?next=/courses/${slug}`}>
            {free ? "Create a free account to start" : "Create an account to enrol"}
          </Link>
        </Button>
        <Button asChild variant="ghost" size="lg" className="h-11">
          <Link href={`/login?next=/courses/${slug}`}>I already have an account</Link>
        </Button>
      </div>
    );
  }
  if (!state) return <div className="bg-muted h-12 animate-pulse rounded-lg" aria-hidden="true" />;
  if (state.enrolled) {
    return (
      <Button asChild size="lg" className="h-12 w-full text-base">
        <Link href={`/learn/${slug}`}>Continue learning</Link>
      </Button>
    );
  }
  if (state.revoked) {
    return (
      <p className="text-muted-foreground text-sm">
        Your access to this course was removed. Contact us if you think this is a mistake.
      </p>
    );
  }
  if (!free) {
    return (
      <div className="grid gap-2">
        {state.pendingOrder ? (
          <>
            <Button asChild size="lg" className="h-12 w-full text-base">
              <Link href={`/orders/${state.pendingOrder}`}>Complete your payment</Link>
            </Button>
            <p className="text-muted-foreground text-sm">
              Order {state.pendingOrder} is awaiting payment.
            </p>
          </>
        ) : (
          <Button asChild size="lg" className="h-12 w-full text-base">
            <Link href={`/checkout/${slug}`}>Enrol{priceLabel ? ` · ${priceLabel}` : ""}</Link>
          </Button>
        )}
        <p className="text-muted-foreground text-sm">Pay by bank transfer. Coupons accepted.</p>
      </div>
    );
  }
  return (
    <div className="grid gap-2">
      <Button
        size="lg"
        className="h-12 w-full text-base"
        disabled={pending}
        onClick={() =>
          start(async () => {
            const r = await enrolFree(courseId);
            if (r && !r.ok) setError(r.error);
          })
        }
      >
        {pending ? "Enrolling…" : "Enrol for free"}
      </Button>
      <div aria-live="polite">{error && <FormAlert kind="error">{error}</FormAlert>}</div>
    </div>
  );
}
