import Image from "next/image";
import type { Track } from "@/lib/courses/format";
import { cn } from "@/lib/utils";

/**
 * Generated chart-motif cover used when a course has no thumbnail.
 * Decorative only (aria-hidden); the title is rendered as real text elsewhere.
 */
export function CourseCover({
  track,
  src,
  className,
}: {
  track: Track;
  src?: string | null;
  className?: string;
}) {
  if (src) {
    return (
      <div className={cn("bg-muted relative aspect-[16/9] w-full overflow-hidden", className)}>
        <Image
          src={src}
          alt=""
          fill
          sizes="(min-width: 1024px) 400px, 100vw"
          className="object-cover"
        />
      </div>
    );
  }
  return (
    <div
      aria-hidden="true"
      className={cn("bg-ink relative aspect-[16/9] w-full overflow-hidden", className)}
    >
      <div className="bg-grid absolute inset-0 opacity-40 [--foreground:#fff]" />
      <svg
        viewBox="0 0 320 180"
        className="absolute inset-0 size-full"
        preserveAspectRatio="xMidYMid slice"
      >
        {track === "power_bi" &&
          [40, 70, 55, 95, 80, 120, 105].map((h, i) => (
            <rect
              key={i}
              x={40 + i * 36}
              y={150 - h}
              width="22"
              height={h}
              rx="3"
              fill={i === 5 ? "#fbbf24" : "#818cf8"}
              opacity={i === 5 ? 1 : 0.85}
            />
          ))}
        {track === "data_science" && (
          <>
            {[
              [60, 120],
              [85, 105],
              [100, 112],
              [120, 90],
              [140, 95],
              [160, 75],
              [175, 82],
              [200, 60],
              [220, 66],
              [245, 45],
              [260, 50],
            ].map(([x, y], i) => (
              <circle key={i} cx={x} cy={y} r="5" fill="#818cf8" />
            ))}
            <line
              x1="50"
              y1="128"
              x2="275"
              y2="38"
              stroke="#fbbf24"
              strokeWidth="3"
              strokeLinecap="round"
            />
          </>
        )}
        {track === "ai" && (
          <>
            {[
              [70, 50],
              [70, 90],
              [70, 130],
              [160, 70],
              [160, 110],
              [250, 90],
            ].flatMap(([x1, y1], i, arr) =>
              arr
                .slice(i + 1)
                .filter(([x2]) => x2 > x1)
                .map(([x2, y2], j) => (
                  <line
                    key={`${i}-${j}`}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="#818cf8"
                    strokeOpacity="0.5"
                    strokeWidth="1.5"
                  />
                )),
            )}
            {[
              [70, 50],
              [70, 90],
              [70, 130],
              [160, 70],
              [160, 110],
            ].map(([x, y], i) => (
              <circle key={i} cx={x} cy={y} r="9" fill="#0a1022" stroke="#818cf8" strokeWidth="3" />
            ))}
            <circle cx="250" cy="90" r="12" fill="#fbbf24" />
          </>
        )}
      </svg>
    </div>
  );
}
