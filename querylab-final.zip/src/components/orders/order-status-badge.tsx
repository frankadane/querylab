import { Badge } from "@/components/ui/badge";

const LABELS = {
  pending: "Awaiting payment",
  paid: "Paid",
  cancelled: "Cancelled",
  refunded: "Refunded",
} as const;

export function OrderStatusBadge({ status }: { status: keyof typeof LABELS }) {
  return (
    <Badge
      variant={status === "paid" ? "secondary" : status === "pending" ? "outline" : "outline"}
      className={
        status === "pending"
          ? "border-highlight text-highlight-text"
          : status === "refunded" || status === "cancelled"
            ? "text-muted-foreground"
            : ""
      }
    >
      {LABELS[status]}
    </Badge>
  );
}
