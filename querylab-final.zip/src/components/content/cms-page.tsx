import { notFound } from "next/navigation";
import { getPage } from "@/lib/content/queries";
import { Markdown } from "./markdown";

/** Renders an admin-editable page (Admin → Pages). */
export async function CmsPage({ slug }: { slug: string }) {
  const page = await getPage(slug);
  if (!page) notFound();
  return (
    <article className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
      <h1 className="text-4xl font-semibold">{page.title}</h1>
      <Markdown className="mt-8">{page.body_md}</Markdown>
    </article>
  );
}

export async function cmsMetadata(slug: string) {
  const page = await getPage(slug);
  return page
    ? {
        title: page.seo_title || page.title,
        description: page.seo_description ?? undefined,
        alternates: { canonical: `/${slug}` },
      }
    : {};
}
