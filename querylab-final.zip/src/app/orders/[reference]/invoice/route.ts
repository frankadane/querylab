import { NextResponse } from "next/server";
import { getBillingSettings } from "@/lib/payments/bank";
import { renderInvoicePdf } from "@/lib/payments/invoice-pdf";
import { createClient } from "@/lib/supabase/server";

/** Owner or admin only (RLS). */
export async function GET(_req: Request, { params }: { params: Promise<{ reference: string }> }) {
  const { reference } = await params;
  if (!/^QL-[A-Z0-9]{8}$/.test(reference))
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  const supabase = await createClient();
  const { data: order } = await supabase
    .from("orders")
    .select("*")
    .eq("reference", reference)
    .maybeSingle();
  if (!order) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const { company, bank } = await getBillingSettings();
  const bytes = await renderInvoicePdf(order, company, bank);
  return new NextResponse(Buffer.from(bytes), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="${order.invoice_number ?? `proforma-${order.reference}`}.pdf"`,
      "Cache-Control": "private, no-store",
    },
  });
}
