import type { MetadataRoute } from "next";
import { listPosts } from "@/lib/content/queries";
import { listPublishedSlugs } from "@/lib/courses/queries";
import { listUpcomingSessions } from "@/lib/sessions/queries";
import { siteConfig } from "@/lib/site";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteConfig.url;
  const staticPaths = [
    "",
    "/courses",
    "/schedule",
    "/resources",
    "/instructors",
    "/about",
    "/corporate",
    "/contact",
    "/privacy",
    "/terms",
    "/cookies",
  ];
  const [courses, posts, sessions] = await Promise.all([
    listPublishedSlugs(),
    listPosts(),
    listUpcomingSessions({ days: 120 }),
  ]);
  return [
    ...staticPaths.map((p) => ({
      url: `${base}${p}`,
      changeFrequency: "weekly" as const,
      priority: p === "" ? 1 : 0.6,
    })),
    ...courses.map((c) => ({
      url: `${base}/courses/${c.slug}`,
      lastModified: c.updated_at,
      changeFrequency: "weekly" as const,
      priority: 0.9,
    })),
    ...posts.map((p) => ({
      url: `${base}/resources/${p.slug}`,
      lastModified: p.published_at ?? undefined,
      changeFrequency: "monthly" as const,
      priority: 0.5,
    })),
    ...sessions
      .filter((s) => s.status !== "cancelled")
      .map((s) => ({
        url: `${base}/schedule/${s.id}`,
        changeFrequency: "daily" as const,
        priority: 0.4,
      })),
  ];
}
