import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

/**
 * GDPR data export: everything we hold about the signed-in user as JSON.
 */
export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not signed in" }, { status: 401 });

  const own = <T extends string>(table: T) =>
    supabase
      .from(table as never)
      .select("*")
      .eq("user_id", user.id);
  const [
    { data: profile },
    enrolments,
    progress,
    quizAttempts,
    registrations,
    certificates,
    notifications,
  ] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).single(),
    own("enrolments"),
    own("lesson_progress"),
    own("quiz_attempts"),
    own("session_registrations"),
    own("certificates"),
    own("notifications"),
  ]);
  const { data: orders } = await supabase.from("orders").select("*").eq("user_id", user.id);

  const body = {
    exported_at: new Date().toISOString(),
    account: {
      id: user.id,
      email: user.email,
      email_confirmed_at: user.email_confirmed_at,
      created_at: user.created_at,
      last_sign_in_at: user.last_sign_in_at,
    },
    profile,
    enrolments: enrolments.data ?? [],
    lesson_progress: progress.data ?? [],
    quiz_attempts: quizAttempts.data ?? [],
    session_registrations: registrations.data ?? [],
    certificates: certificates.data ?? [],
    notifications: notifications.data ?? [],
    orders: orders ?? [],
  };

  return new NextResponse(JSON.stringify(body, null, 2), {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="querylab-data-${new Date().toISOString().slice(0, 10)}.json"`,
      "Cache-Control": "no-store",
    },
  });
}
