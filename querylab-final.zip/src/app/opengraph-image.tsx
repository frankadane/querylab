import { ImageResponse } from "next/og";

export const alt = "QueryLab: practical training in AI, Data Science and Power BI";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Default social preview image (pages can override with their own). */
export default function OgImage() {
  const bars = [40, 70, 55, 95, 80, 120, 150];
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        background: "#0a1022",
        color: "#e8ecf5",
        padding: 72,
        fontFamily: "sans-serif",
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          flex: 1,
        }}
      >
        <div
          style={{ display: "flex", alignItems: "center", gap: 16, fontSize: 40, fontWeight: 700 }}
        >
          <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 44 }}>
            <div style={{ width: 10, height: 20, background: "#818cf8", borderRadius: 3 }} />
            <div style={{ width: 10, height: 32, background: "#818cf8", borderRadius: 3 }} />
            <div style={{ width: 10, height: 44, background: "#fbbf24", borderRadius: 3 }} />
          </div>
          QueryLab
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div style={{ fontSize: 64, fontWeight: 700, lineHeight: 1.1, maxWidth: 700 }}>
            Data skills you will use at work on Monday.
          </div>
          <div style={{ fontSize: 30, color: "#a3aecb" }}>AI · Data Science · Power BI</div>
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 14, height: 470 }}>
        {bars.map((h, i) => (
          <div
            key={i}
            style={{
              width: 40,
              height: h * 2.6,
              background: i === bars.length - 1 ? "#fbbf24" : "#818cf8",
              borderRadius: "6px 6px 0 0",
            }}
          />
        ))}
      </div>
    </div>,
    size,
  );
}
