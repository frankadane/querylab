import { NextResponse } from "next/server";
import { getProvider } from "@/lib/payments/registry";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Shared webhook endpoint for card/PSP providers: /api/payments/<provider>/webhook.
 * The provider verifies the signature and extracts the order reference;
 * settlement is idempotent in the database.
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ provider: string }> },
) {
  const provider = getProvider((await params).provider);
  if (!provider?.handleWebhook)
    return NextResponse.json({ error: "Unknown provider" }, { status: 404 });

  let result;
  try {
    result = await provider.handleWebhook(request);
  } catch (err) {
    console.error(`[payments] ${provider.id} webhook rejected`, err);
    return NextResponse.json({ error: "Invalid webhook" }, { status: 400 });
  }
  if (!result) return NextResponse.json({ received: true });

  const { error } = await createAdminClient().rpc("confirm_order_payment", {
    p_reference: result.reference,
    p_provider: provider.id,
    p_provider_ref: result.providerRef,
  });
  if (error) {
    console.error(`[payments] confirm failed`, error.message);
    return NextResponse.json({ error: "Could not confirm" }, { status: 500 });
  }
  return NextResponse.json({ received: true });
}
