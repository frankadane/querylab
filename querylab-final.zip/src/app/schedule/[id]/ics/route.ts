import { createEvent } from "ics";
import { NextResponse } from "next/server";
import { getPublicSession } from "@/lib/sessions/queries";
import { siteConfig } from "@/lib/site";

const parts = (d: Date) =>
  [d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate(), d.getUTCHours(), d.getUTCMinutes()] as [
    number,
    number,
    number,
    number,
    number,
  ];

/** Calendar file for one session. Contains the session page URL, never the private join link. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const s = await getPublicSession((await params).id);
  if (!s) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const url = `${siteConfig.url}/schedule/${s.id}`;

  const { error, value } = createEvent({
    uid: `${s.id}@querylab`,
    title: s.title,
    description: `${s.course ? `${s.course.title}\n\n` : ""}Join link and details: ${url}`,
    url,
    location: url,
    start: parts(new Date(s.starts_at)),
    startInputType: "utc",
    startOutputType: "utc",
    end: parts(new Date(s.ends_at)),
    endInputType: "utc",
    endOutputType: "utc",
    status: s.status === "cancelled" ? "CANCELLED" : "CONFIRMED",
    organizer: { name: siteConfig.name, email: siteConfig.contactEmail },
    productId: "querylab/schedule",
  });
  if (error || !value)
    return NextResponse.json({ error: "Could not build calendar file" }, { status: 500 });

  return new NextResponse(value, {
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `attachment; filename="querylab-session-${s.id.slice(0, 8)}.ics"`,
      "Cache-Control": "public, max-age=300",
    },
  });
}
