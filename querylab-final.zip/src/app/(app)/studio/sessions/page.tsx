import { Plus } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { FormAlert } from "@/components/forms/form-alert";
import { PageHeader } from "@/components/site/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { requireRole } from "@/lib/auth";
import { formatSessionRange } from "@/lib/sessions/time";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Studio: live sessions", robots: { index: false } };

export default async function StudioSessionsPage({
  searchParams,
}: {
  searchParams: Promise<{ when?: string; deleted?: string }>;
}) {
  const { profile } = await requireRole(["instructor", "admin"], "/studio/sessions");
  const { when, deleted } = await searchParams;
  const past = when === "past";
  const supabase = await createClient();
  const now = new Date().toISOString();

  let q = supabase
    .from("live_sessions")
    .select(
      "id, title, starts_at, ends_at, status, capacity, course:courses(title), session_registrations(status)",
    )
    .order("starts_at", { ascending: !past })
    .limit(200);
  q = past ? q.lt("ends_at", now) : q.gte("ends_at", now);
  if (profile.role !== "admin") {
    // Public sessions are readable by everyone, so narrow to sessions this person runs.
    const { data: me } = await supabase.rpc("my_instructor_id");
    const { data: myCourses } = me
      ? await supabase.from("courses").select("id").eq("instructor_id", me)
      : { data: [] };
    const ids = (myCourses ?? []).map((c) => c.id);
    q = q.or(
      `instructor_id.eq.${profile.id}${ids.length ? `,course_id.in.(${ids.join(",")})` : ""}`,
    );
  }
  const { data: sessions } = await q;

  return (
    <>
      <PageHeader
        title="Live sessions"
        description={`Times shown in ${profile.timezone.replaceAll("_", " ")}.`}
      >
        <Button asChild size="lg" className="h-11 px-4">
          <Link href="/studio/sessions/new">
            <Plus aria-hidden="true" /> New session
          </Link>
        </Button>
      </PageHeader>
      {deleted && (
        <FormAlert kind="success" className="mt-6">
          Session deleted.
        </FormAlert>
      )}
      <nav aria-label="Session filter" className="mt-6 flex gap-2 text-sm">
        <Link
          href="/studio/sessions"
          aria-current={!past ? "page" : undefined}
          className="aria-[current=page]:bg-secondary aria-[current=page]:text-secondary-foreground rounded-md px-3 py-2 font-medium"
        >
          Upcoming
        </Link>
        <Link
          href="/studio/sessions?when=past"
          aria-current={past ? "page" : undefined}
          className="aria-[current=page]:bg-secondary aria-[current=page]:text-secondary-foreground rounded-md px-3 py-2 font-medium"
        >
          Past
        </Link>
      </nav>
      <div className="bg-card mt-4 overflow-x-auto rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Session</TableHead>
              <TableHead>When</TableHead>
              <TableHead className="text-right">Registered</TableHead>
              <TableHead className="text-right">Waitlist</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sessions?.map((s) => {
              const regs = s.session_registrations ?? [];
              const taken = regs.filter(
                (r) => r.status === "registered" || r.status === "attended",
              ).length;
              const wait = regs.filter((r) => r.status === "waitlist").length;
              return (
                <TableRow key={s.id}>
                  <TableCell className="max-w-80">
                    <Link
                      href={`/studio/sessions/${s.id}`}
                      className="text-primary font-medium underline-offset-4 hover:underline"
                    >
                      {s.title}
                    </Link>
                    <p className="text-muted-foreground truncate text-xs">
                      {s.course?.title ?? "Open to all"}
                    </p>
                  </TableCell>
                  <TableCell className="text-sm whitespace-nowrap">
                    {formatSessionRange(s.starts_at, s.ends_at, profile.timezone)}
                  </TableCell>
                  <TableCell className="tabular text-right font-mono">
                    {taken}/{s.capacity}
                  </TableCell>
                  <TableCell className="tabular text-right font-mono">{wait}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        s.status === "cancelled"
                          ? "destructive"
                          : s.status === "scheduled"
                            ? "secondary"
                            : "outline"
                      }
                      className="capitalize"
                    >
                      {s.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              );
            })}
            {!sessions?.length && (
              <TableRow>
                <TableCell colSpan={5} className="text-muted-foreground py-10 text-center">
                  No {past ? "past" : "upcoming"} sessions.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </>
  );
}
