"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { type ActionResult, GENERIC_ERROR, RATE_LIMITED, invalid } from "@/lib/action-result";
import { audit } from "@/lib/audit";
import { requireRole } from "@/lib/auth";
import { sendEmail } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";
import { notifySessionUsers } from "@/lib/sessions/notify";
import { weeklyOccurrences } from "@/lib/sessions/time";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import {
  afterSessionSchema,
  cancelSessionSchema,
  messageSchema,
  newSessionSchema,
  sessionSchema,
} from "@/lib/validation/sessions";

const uuid = z.string().uuid();
const NOT_ALLOWED: ActionResult = {
  ok: false,
  error: "You don't have permission to manage this session.",
};

async function staff() {
  const current = await requireRole(["instructor", "admin"], "/studio/sessions");
  return { ...current, supabase: await createClient() };
}

function refresh(id?: string) {
  revalidatePath("/studio/sessions");
  revalidatePath("/schedule", "layout");
  revalidatePath("/courses", "layout");
  revalidatePath("/dashboard");
  if (id) revalidatePath(`/studio/sessions/${id}`);
}

async function attendees(
  sessionId: string,
  statuses: ("registered" | "waitlist" | "attended" | "cancelled")[],
) {
  const { data } = await createAdminClient()
    .from("session_registrations")
    .select("user_id")
    .eq("session_id", sessionId)
    .in("status", statuses);
  return (data ?? []).map((r) => r.user_id);
}

export async function createSession(input: unknown): Promise<ActionResult> {
  const { supabase, profile } = await staff();
  const parsed = newSessionSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;
  const instructorId = profile.role === "admin" ? (v.instructorId ?? profile.id) : profile.id;

  const occurrences = weeklyOccurrences({
    date: v.date,
    time: v.time,
    timeZone: v.timezone,
    durationMinutes: v.durationMinutes,
    count: v.repeatWeeks,
  });
  if (occurrences[0].startsAt.getTime() < Date.now()) {
    return {
      ok: false,
      error: "The first session must be in the future.",
      fieldErrors: { date: ["Choose a future date and time"] },
    };
  }

  let seriesId: string | null = null;
  if (v.repeatWeeks > 1) {
    const { data, error } = await supabase
      .from("session_series")
      .insert({
        course_id: v.courseId,
        title: v.title,
        timezone: v.timezone,
        occurrences: v.repeatWeeks,
        created_by: profile.id,
      })
      .select("id")
      .single();
    if (error) return error.code === "42501" ? NOT_ALLOWED : { ok: false, error: GENERIC_ERROR };
    seriesId = data.id;
  }

  const rows = occurrences.map((o, i) => ({
    course_id: v.courseId,
    lesson_id: v.courseId ? (v.lessonId ?? null) : null,
    series_id: seriesId,
    title: v.repeatWeeks > 1 ? `${v.title} (${i + 1}/${v.repeatWeeks})` : v.title,
    description_md: v.descriptionMd,
    starts_at: o.startsAt.toISOString(),
    ends_at: o.endsAt.toISOString(),
    timezone: v.timezone,
    capacity: v.capacity,
    instructor_id: instructorId,
    created_by: profile.id,
  }));
  const { data: created, error } = await supabase.from("live_sessions").insert(rows).select("id");
  if (error?.code === "23514")
    return {
      ok: false,
      error: "Choose a live-session lesson from the same course.",
      fieldErrors: { lessonId: ["Not a live-session lesson of this course"] },
    };
  if (error || !created?.length) {
    console.error("[sessions] create", error?.message);
    return error?.code === "42501" ? NOT_ALLOWED : { ok: false, error: GENERIC_ERROR };
  }
  const { error: linkErr } = await supabase
    .from("live_session_links")
    .insert(created.map((c) => ({ session_id: c.id, join_url: v.joinUrl })));
  if (linkErr) console.error("[sessions] links", linkErr.message);

  await audit(
    supabase,
    "session.created",
    { type: "live_session", id: created[0].id },
    { count: created.length, series_id: seriesId },
  );
  refresh();
  redirect(`/studio/sessions/${created[0].id}?created=${created.length}`);
}

export async function updateSession(sessionId: string, input: unknown): Promise<ActionResult> {
  const { supabase, profile } = await staff();
  if (!uuid.safeParse(sessionId).success) return NOT_ALLOWED;
  const parsed = sessionSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;

  const { data: before } = await supabase
    .from("live_sessions")
    .select("starts_at, ends_at, capacity, status")
    .eq("id", sessionId)
    .maybeSingle();
  if (!before) return NOT_ALLOWED;
  const [occ] = weeklyOccurrences({
    date: v.date,
    time: v.time,
    timeZone: v.timezone,
    durationMinutes: v.durationMinutes,
    count: 1,
  });
  const rescheduled =
    occ.startsAt.toISOString() !== new Date(before.starts_at).toISOString() ||
    occ.endsAt.toISOString() !== new Date(before.ends_at).toISOString();
  if (rescheduled && occ.startsAt.getTime() < Date.now()) {
    return {
      ok: false,
      error: "Choose a future date and time.",
      fieldErrors: { date: ["Must be in the future"] },
    };
  }

  const { data, error } = await supabase
    .from("live_sessions")
    .update({
      course_id: v.courseId,
      lesson_id: v.courseId ? (v.lessonId ?? null) : null,
      title: v.title,
      description_md: v.descriptionMd,
      starts_at: occ.startsAt.toISOString(),
      ends_at: occ.endsAt.toISOString(),
      timezone: v.timezone,
      capacity: v.capacity,
      ...(profile.role === "admin" && v.instructorId ? { instructor_id: v.instructorId } : {}),
    })
    .eq("id", sessionId)
    .select("id, title, starts_at, ends_at");
  if (error?.code === "23514")
    return {
      ok: false,
      error: "Choose a live-session lesson from the same course.",
      fieldErrors: { lessonId: ["Not a live-session lesson of this course"] },
    };
  if (error || !data?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;
  await supabase.from("live_session_links").upsert({ session_id: sessionId, join_url: v.joinUrl });

  // More places → promote from the waitlist.
  let promotedCount = 0;
  if (v.capacity > before.capacity) {
    const { data: promoted } = await supabase.rpc("promote_waitlist", { p_session_id: sessionId });
    const ids = (promoted ?? []) as unknown as string[];
    promotedCount = ids.length;
    if (ids.length) {
      const { data: regs } = await createAdminClient()
        .from("session_registrations")
        .select("user_id")
        .in("id", ids);
      await notifySessionUsers(
        (regs ?? []).map((r) => r.user_id),
        data[0],
        {
          type: "waitlist_promoted",
          subject: `A place opened up: ${data[0].title}`,
          intro: "Good news: more places were added and you're now registered.",
        },
      );
    }
  }

  if (rescheduled) {
    await notifySessionUsers(
      await attendees(sessionId, ["registered", "attended", "waitlist"]),
      data[0],
      {
        type: "session_rescheduled",
        subject: `New time: ${data[0].title}`,
        intro:
          "This live session has been moved. Your place is kept at the new time below. If you can no longer attend, please cancel on the session page.",
      },
    );
  }

  await audit(supabase, rescheduled ? "session.rescheduled" : "session.updated", {
    type: "live_session",
    id: sessionId,
  });
  refresh(sessionId);
  return {
    ok: true,
    message: [
      rescheduled ? "Session rescheduled and attendees notified." : "Session saved.",
      promotedCount ? `${promotedCount} promoted from the waitlist.` : "",
    ]
      .filter(Boolean)
      .join(" "),
  };
}

export async function cancelSession(
  sessionId: string,
  input: unknown,
  wholeSeries = false,
): Promise<ActionResult> {
  const { supabase } = await staff();
  const parsed = cancelSessionSchema.safeParse(input);
  if (!parsed.success || !uuid.safeParse(sessionId).success)
    return { ok: false, error: "Invalid request." };

  const { data: s } = await supabase
    .from("live_sessions")
    .select("id, series_id, starts_at")
    .eq("id", sessionId)
    .maybeSingle();
  if (!s) return NOT_ALLOWED;
  let q = supabase
    .from("live_sessions")
    .update({ status: "cancelled", cancel_reason: parsed.data.reason || null })
    .neq("status", "completed");
  q =
    wholeSeries && s.series_id
      ? q.eq("series_id", s.series_id).gte("starts_at", s.starts_at)
      : q.eq("id", sessionId);
  const { data: cancelled, error } = await q.select("id, title, starts_at, ends_at");
  if (error || !cancelled?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;

  for (const c of cancelled) {
    await notifySessionUsers(await attendees(c.id, ["registered", "attended", "waitlist"]), c, {
      type: "session_cancelled",
      subject: `Cancelled: ${c.title}`,
      intro: `This live session has been cancelled.${parsed.data.reason ? ` Reason: ${parsed.data.reason}` : ""} We're sorry for the inconvenience.`,
    });
  }
  await audit(
    supabase,
    "session.cancelled",
    { type: "live_session", id: sessionId },
    { count: cancelled.length, reason: parsed.data.reason },
  );
  refresh(sessionId);
  return {
    ok: true,
    message: `${cancelled.length === 1 ? "Session" : `${cancelled.length} sessions`} cancelled and attendees notified.`,
  };
}

export async function setSessionStatus(
  sessionId: string,
  status: "live" | "completed" | "scheduled",
): Promise<ActionResult> {
  const { supabase } = await staff();
  if (!["live", "completed", "scheduled"].includes(status))
    return { ok: false, error: "Invalid status." };
  const { data, error } = await supabase
    .from("live_sessions")
    .update({ status, ...(status === "scheduled" ? { cancel_reason: null } : {}) })
    .eq("id", sessionId)
    .select("id");
  if (error || !data?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;
  await audit(supabase, `session.${status}`, { type: "live_session", id: sessionId });
  refresh(sessionId);
  return {
    ok: true,
    message: {
      live: "Marked as live.",
      completed: "Marked as completed.",
      scheduled: "Session restored.",
    }[status],
  };
}

export async function saveAfterSession(sessionId: string, input: unknown): Promise<ActionResult> {
  const { supabase } = await staff();
  const parsed = afterSessionSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { data, error } = await supabase
    .from("live_sessions")
    .update({ recording_url: parsed.data.recordingUrl, materials_md: parsed.data.materialsMd })
    .eq("id", sessionId)
    .select("id");
  if (error || !data?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;
  await audit(supabase, "session.materials_updated", { type: "live_session", id: sessionId });
  refresh(sessionId);
  return { ok: true, message: "Recording and materials saved." };
}

export async function saveAttendance(
  sessionId: string,
  attendedUserIds: string[],
  absentUserIds: string[],
): Promise<ActionResult> {
  const { supabase } = await staff();
  const ids = z.array(uuid).max(10000);
  if (!ids.safeParse(attendedUserIds).success || !ids.safeParse(absentUserIds).success)
    return { ok: false, error: "Invalid request." };
  const [a, b] = await Promise.all([
    attendedUserIds.length
      ? supabase.rpc("set_attendance", {
          p_session_id: sessionId,
          p_user_ids: attendedUserIds,
          p_attended: true,
        })
      : { data: 0, error: null },
    absentUserIds.length
      ? supabase.rpc("set_attendance", {
          p_session_id: sessionId,
          p_user_ids: absentUserIds,
          p_attended: false,
        })
      : { data: 0, error: null },
  ]);
  if (a.error || b.error)
    return a.error?.code === "42501" || b.error?.code === "42501"
      ? NOT_ALLOWED
      : { ok: false, error: GENERIC_ERROR };
  await audit(
    supabase,
    "session.attendance_saved",
    { type: "live_session", id: sessionId },
    { attended: attendedUserIds.length },
  );
  refresh(sessionId);
  return { ok: true, message: `Attendance saved: ${attendedUserIds.length} present.` };
}

/** CSV with an "email" column and optional "attended" column (yes/no/true/false/1/0; default yes). */
export async function importAttendance(
  sessionId: string,
  formData: FormData,
): Promise<ActionResult> {
  const { supabase } = await staff();
  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) return { ok: false, error: "Choose a CSV file." };
  if (file.size > 1024 * 1024) return { ok: false, error: "CSV files must be 1 MB or smaller." };

  const rows = (await file.text())
    .replace(/^﻿/, "")
    .split(/\r?\n/)
    .map((l) => l.split(",").map((c) => c.trim().replace(/^"|"$/g, "")));
  const header = rows.shift()?.map((h) => h.toLowerCase()) ?? [];
  const ei = header.indexOf("email");
  const ai = header.indexOf("attended");
  if (ei === -1) return { ok: false, error: "The CSV needs an “email” column." };

  const wanted = new Map<string, boolean>();
  for (const r of rows) {
    const email = r[ei]?.toLowerCase();
    if (!email) continue;
    const flag = ai === -1 ? "yes" : (r[ai] ?? "yes").toLowerCase();
    wanted.set(email, !["no", "false", "0", "absent"].includes(flag));
  }

  // Match emails to people registered for this session (staff can read these via RLS).
  const { data: regs } = await supabase
    .from("session_registrations")
    .select("user_id, status, profile:profiles(email)")
    .eq("session_id", sessionId)
    .in("status", ["registered", "attended"]);
  const attended: string[] = [];
  const absent: string[] = [];
  const matched = new Set<string>();
  for (const r of regs ?? []) {
    const email = r.profile?.email?.toLowerCase();
    if (email && wanted.has(email)) {
      matched.add(email);
      (wanted.get(email) ? attended : absent).push(r.user_id);
    }
  }
  const unmatched = [...wanted.keys()].filter((e) => !matched.has(e));
  const res = await saveAttendance(sessionId, attended, absent);
  if (!res.ok) return res;
  return {
    ok: true,
    message: `Imported ${matched.size} ${matched.size === 1 ? "row" : "rows"}: ${attended.length} present, ${absent.length} absent.${unmatched.length ? ` ${unmatched.length} not registered for this session: ${unmatched.slice(0, 5).join(", ")}${unmatched.length > 5 ? "…" : ""}` : ""}`,
  };
}

export async function messageAttendees(sessionId: string, input: unknown): Promise<ActionResult> {
  const { supabase, profile } = await staff();
  const parsed = messageSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  if (!(await rateLimit("sensitive", `message:${profile.id}`)))
    return { ok: false, error: RATE_LIMITED };

  const { data: allowed } = await supabase.rpc("is_session_staff", { p_session_id: sessionId });
  if (!allowed) return NOT_ALLOWED;
  const { data: session } = await supabase
    .from("live_sessions")
    .select("title")
    .eq("id", sessionId)
    .single();
  const ids = await attendees(
    sessionId,
    parsed.data.includeWaitlist
      ? ["registered", "attended", "waitlist"]
      : ["registered", "attended"],
  );
  if (!ids.length) return { ok: false, error: "Nobody is registered yet." };

  const { data: people } = await createAdminClient().from("profiles").select("email").in("id", ids);
  await Promise.all(
    (people ?? []).map((p) =>
      sendEmail({
        to: p.email,
        subject: `${parsed.data.subject} · ${session?.title ?? "QueryLab live session"}`,
        text: `${parsed.data.body}\n\n— ${profile.full_name || "Your instructor"}, QueryLab`,
      }),
    ),
  );
  await audit(
    supabase,
    "session.message_sent",
    { type: "live_session", id: sessionId },
    { recipients: ids.length, subject: parsed.data.subject },
  );
  return {
    ok: true,
    message: `Message sent to ${ids.length} ${ids.length === 1 ? "person" : "people"}.`,
  };
}

export async function deleteSession(sessionId: string): Promise<ActionResult> {
  const { supabase, profile } = await staff();
  if (profile.role !== "admin")
    return { ok: false, error: "Only admins can delete sessions. Cancel it instead." };
  const { count } = await supabase
    .from("session_registrations")
    .select("id", { count: "exact", head: true })
    .eq("session_id", sessionId)
    .neq("status", "cancelled");
  if (count)
    return {
      ok: false,
      error: "People are registered. Cancel the session instead so they're notified.",
    };
  const { error } = await supabase.from("live_sessions").delete().eq("id", sessionId);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, "session.deleted", { type: "live_session", id: sessionId });
  refresh();
  redirect("/studio/sessions?deleted=1");
}
