"use client";

import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { MarkdownField } from "@/components/forms/markdown-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import type { ActionResult } from "@/lib/action-result";
import { meetingProvider } from "@/lib/sessions/time";
import { type NewSessionInput, newSessionSchema, sessionSchema } from "@/lib/validation/sessions";

export function SessionForm({
  mode,
  defaults,
  courses,
  instructors,
  timezones,
  allowOpen,
  action,
  lessons = [],
}: {
  mode: "create" | "edit";
  defaults: NewSessionInput;
  courses: { id: string; title: string }[];
  instructors?: [string, string][];
  timezones: string[];
  allowOpen: boolean;
  action: (v: unknown) => Promise<ActionResult>;
  lessons?: { id: string; title: string; course_id: string }[];
}) {
  const schema =
    mode === "create"
      ? newSessionSchema
      : sessionSchema.extend({ repeatWeeks: newSessionSchema.shape.repeatWeeks.optional() });
  const { form, pending, result, onSubmit } = useActionForm(
    schema as typeof newSessionSchema,
    action,
    defaults,
  );
  const e = form.formState.errors;
  const r = form.register;
  const provider = meetingProvider(form.watch("joinUrl"));
  const repeat = Number(form.watch("repeatWeeks") ?? 1);
  const courseLessons = lessons.filter((l) => l.course_id === form.watch("courseId"));

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-8">
      <fieldset className="grid gap-5 sm:grid-cols-2">
        <legend className="mb-4 text-lg font-semibold">What</legend>
        <SelectField
          label="Who can attend"
          className="sm:col-span-2"
          registration={r("courseId")}
          options={[
            ...(allowOpen
              ? [["", "Anyone with an account (open session)"] as [string, string]]
              : []),
            ...courses.map((c) => [c.id, `Students enrolled in: ${c.title}`] as [string, string]),
          ]}
          error={e.courseId}
        />
        <FormField
          label="Title"
          registration={r("title")}
          error={e.title}
          className="sm:col-span-2"
        />
        {courseLessons.length > 0 && (
          <SelectField
            label="Counts towards lesson (optional)"
            className="sm:col-span-2"
            registration={r("lessonId")}
            options={[
              ["", "Not linked"],
              ...courseLessons.map((l) => [l.id, l.title] as [string, string]),
            ]}
            hint="Attending this session marks that live-session lesson complete in the student's progress."
          />
        )}
        <div className="sm:col-span-2">
          <MarkdownField
            label="Description"
            rows={5}
            registration={r("descriptionMd")}
            value={form.watch("descriptionMd") ?? ""}
            error={e.descriptionMd}
          />
        </div>
      </fieldset>

      <fieldset className="grid gap-5 border-t pt-8 sm:grid-cols-2 lg:grid-cols-4">
        <legend className="mb-4 text-lg font-semibold">When</legend>
        <FormField label="Date" type="date" registration={r("date")} error={e.date} />
        <FormField label="Start time" type="time" registration={r("time")} error={e.time} />
        <FormField
          label="Duration (minutes)"
          type="number"
          inputMode="numeric"
          min={15}
          max={720}
          step={15}
          registration={r("durationMinutes")}
          error={e.durationMinutes}
        />
        <SelectField
          label="Timezone"
          registration={r("timezone")}
          options={timezones.map((t) => [t, t.replaceAll("_", " ")] as [string, string])}
          error={e.timezone}
          hint="Date and time are in this zone."
        />
        {mode === "create" && (
          <FormField
            label="Repeat weekly"
            type="number"
            inputMode="numeric"
            min={1}
            max={26}
            registration={r("repeatWeeks")}
            error={e.repeatWeeks}
            hint={
              repeat > 1
                ? `Creates ${repeat} weekly sessions at the same local time.`
                : "1 = a single session."
            }
          />
        )}
      </fieldset>

      <fieldset className="grid gap-5 border-t pt-8 sm:grid-cols-2">
        <legend className="mb-4 text-lg font-semibold">Where &amp; who</legend>
        <FormField
          label="Meeting link"
          type="url"
          placeholder="https://zoom.us/j/… or https://meet.google.com/…"
          hint={
            provider
              ? `Detected: ${provider}. Only registered students see it, from 15 minutes before the start.`
              : "Zoom, Google Meet or Teams. Only registered students see it, from 15 minutes before the start."
          }
          registration={r("joinUrl")}
          error={e.joinUrl}
          className="sm:col-span-2"
        />
        <FormField
          label="Capacity"
          type="number"
          inputMode="numeric"
          min={1}
          registration={r("capacity")}
          error={e.capacity}
          hint="When full, new sign-ups join a waitlist."
        />
        {instructors && (
          <SelectField label="Instructor" registration={r("instructorId")} options={instructors} />
        )}
      </fieldset>

      <div className="bg-background/95 sticky bottom-0 -mx-4 flex flex-wrap items-center gap-4 border-t px-4 py-4 backdrop-blur">
        <SubmitButton pending={pending} className="px-6">
          {mode === "create"
            ? repeat > 1
              ? `Create ${repeat} sessions`
              : "Create session"
            : "Save changes"}
        </SubmitButton>
        {mode === "edit" && (
          <p className="text-muted-foreground text-sm">
            Changing the date or time emails everyone registered.
          </p>
        )}
        <div aria-live="polite" className="min-w-0 flex-1">
          {result && (
            <FormAlert kind={result.ok ? "success" : "error"}>
              {result.ok ? result.message : result.error}
            </FormAlert>
          )}
        </div>
      </div>
    </form>
  );
}
