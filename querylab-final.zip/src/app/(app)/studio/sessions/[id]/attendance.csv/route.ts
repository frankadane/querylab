import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

const esc = (v: string | null | undefined) => {
  const s = v ?? "";
  // Quote, double embedded quotes, and neutralise spreadsheet formula injection.
  const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
  return `"${safe.replace(/"/g, '""')}"`;
};

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success)
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  const supabase = await createClient();
  const { data: allowed } = await supabase.rpc("is_session_staff", { p_session_id: id });
  if (!allowed) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const [{ data: s }, { data: regs }] = await Promise.all([
    supabase.from("live_sessions").select("title, starts_at").eq("id", id).single(),
    supabase
      .from("session_registrations")
      .select("status, created_at, attended_at, profile:profiles(full_name, email)")
      .eq("session_id", id)
      .order("created_at"),
  ]);
  const lines = [
    ["name", "email", "status", "attended", "registered_at", "attended_at"].join(","),
    ...(regs ?? []).map((r) =>
      [
        esc(r.profile?.full_name),
        esc(r.profile?.email),
        esc(r.status),
        esc(r.status === "attended" ? "yes" : "no"),
        esc(r.created_at),
        esc(r.attended_at),
      ].join(","),
    ),
  ];
  const name = `attendance-${(s?.title ?? "session")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .slice(0, 50)}-${s?.starts_at.slice(0, 10) ?? ""}.csv`;
  return new NextResponse(`﻿${lines.join("\r\n")}\r\n`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}"`,
      "Cache-Control": "no-store",
    },
  });
}
