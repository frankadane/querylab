"use client";

import { Download, Mail, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { MarkdownField } from "@/components/forms/markdown-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useAction } from "@/components/forms/use-action";
import { useActionForm } from "@/components/forms/use-action-form";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { afterSessionSchema, messageSchema } from "@/lib/validation/sessions";
import {
  cancelSession,
  deleteSession,
  importAttendance,
  messageAttendees,
  saveAfterSession,
  saveAttendance,
  setSessionStatus,
} from "../actions";

export function StatusControls({
  sessionId,
  status,
  inSeries,
  canDelete,
}: {
  sessionId: string;
  status: string;
  inSeries: boolean;
  canDelete: boolean;
}) {
  const { pending, result, run } = useAction();
  const [reason, setReason] = useState("");
  const [whole, setWhole] = useState(false);
  return (
    <div className="grid gap-2 lg:justify-items-end">
      <div className="flex flex-wrap gap-2">
        {status === "scheduled" && (
          <Button
            variant="outline"
            size="lg"
            className="h-10 px-4"
            disabled={pending}
            onClick={() => run(() => setSessionStatus(sessionId, "live"))}
          >
            Mark as live
          </Button>
        )}
        {(status === "scheduled" || status === "live") && (
          <Button
            variant="outline"
            size="lg"
            className="h-10 px-4"
            disabled={pending}
            onClick={() => run(() => setSessionStatus(sessionId, "completed"))}
          >
            Mark completed
          </Button>
        )}
        {status === "cancelled" && (
          <Button
            variant="outline"
            size="lg"
            className="h-10 px-4"
            disabled={pending}
            onClick={() => run(() => setSessionStatus(sessionId, "scheduled"))}
          >
            Restore session
          </Button>
        )}
        {status !== "cancelled" && status !== "completed" && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="lg" className="h-10 px-4" disabled={pending}>
                Cancel session
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Cancel this session?</AlertDialogTitle>
                <AlertDialogDescription>
                  Everyone registered or on the waitlist gets an email.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="grid gap-3">
                <label htmlFor="cancel-reason" className="text-sm font-medium">
                  Reason (included in the email, optional)
                </label>
                <textarea
                  id="cancel-reason"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  maxLength={500}
                  rows={3}
                  className="border-input bg-background rounded-lg border p-3 text-sm"
                />
                {inSeries && (
                  <label className="flex items-center gap-3 text-sm">
                    <input
                      type="checkbox"
                      checked={whole}
                      onChange={(e) => setWhole(e.target.checked)}
                      className="accent-primary size-5"
                    />
                    Also cancel all later sessions in this series
                  </label>
                )}
              </div>
              <AlertDialogFooter>
                <AlertDialogCancel>Keep session</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => run(() => cancelSession(sessionId, { reason }, whole))}
                >
                  Cancel and notify
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
        {canDelete && (
          <Button
            variant="ghost"
            size="lg"
            className="text-destructive h-10 px-3"
            disabled={pending}
            onClick={() => {
              if (confirm("Delete this session permanently?")) run(() => deleteSession(sessionId));
            }}
          >
            Delete
          </Button>
        )}
      </div>
      <div aria-live="polite">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </div>
  );
}

type Person = {
  userId: string;
  name: string;
  email: string;
  status: "registered" | "waitlist" | "cancelled" | "attended";
  waitlistedAt: string | null;
};

export function Roster({
  sessionId,
  capacity,
  people,
}: {
  sessionId: string;
  capacity: number;
  people: Person[];
}) {
  const attending = people.filter((p) => p.status === "registered" || p.status === "attended");
  const waitlist = people
    .filter((p) => p.status === "waitlist")
    .sort((a, b) => (a.waitlistedAt ?? "").localeCompare(b.waitlistedAt ?? ""));
  const [present, setPresent] = useState(
    () => new Set(attending.filter((p) => p.status === "attended").map((p) => p.userId)),
  );
  const { pending, result, run } = useAction();
  const file = useRef<HTMLInputElement>(null);

  return (
    <section aria-labelledby="roster-h" className="grid gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 id="roster-h" className="text-2xl font-semibold">
            Roster &amp; attendance
          </h2>
          <p className="text-muted-foreground text-sm">
            {attending.length} of {capacity} places taken · {waitlist.length} on the waitlist
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline" size="lg" className="h-10 px-3">
            <a href={`/studio/sessions/${sessionId}/attendance.csv`} download>
              <Download aria-hidden="true" /> Export CSV
            </a>
          </Button>
          <input
            ref={file}
            type="file"
            accept=".csv,text/csv"
            className="sr-only"
            tabIndex={-1}
            aria-hidden="true"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const fd = new FormData();
              fd.set("file", f);
              run(() => importAttendance(sessionId, fd));
              e.target.value = "";
            }}
          />
          <Button
            variant="outline"
            size="lg"
            className="h-10 px-3"
            disabled={pending}
            onClick={() => file.current?.click()}
          >
            <Upload aria-hidden="true" /> Import CSV
          </Button>
        </div>
      </div>
      <p className="text-muted-foreground text-sm">
        Import format: a CSV with an <code className="font-mono">email</code> column and an optional{" "}
        <code className="font-mono">attended</code> column (yes/no). For example, a Zoom participant
        export.
      </p>
      <div aria-live="polite">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>

      {attending.length ? (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run(() =>
              saveAttendance(
                sessionId,
                [...present],
                attending.map((p) => p.userId).filter((id) => !present.has(id)),
              ),
            );
          }}
          className="bg-card overflow-x-auto rounded-xl border"
        >
          <Table>
            <caption className="sr-only">Registered people. Tick who attended.</caption>
            <TableHeader>
              <TableRow>
                <TableHead className="w-24">Attended</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {attending.map((p) => (
                <TableRow key={p.userId}>
                  <TableCell>
                    <input
                      type="checkbox"
                      aria-label={`${p.name} attended`}
                      className="accent-primary size-5"
                      checked={present.has(p.userId)}
                      onChange={(e) => {
                        const next = new Set(present);
                        if (e.target.checked) next.add(p.userId);
                        else next.delete(p.userId);
                        setPresent(next);
                      }}
                    />
                  </TableCell>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell className="text-muted-foreground">{p.email}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="flex flex-wrap gap-2 border-t p-3">
            <Button type="submit" size="lg" className="h-10 px-4" disabled={pending}>
              Save attendance
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="lg"
              className="h-10"
              onClick={() => setPresent(new Set(attending.map((p) => p.userId)))}
            >
              Mark everyone present
            </Button>
          </div>
        </form>
      ) : (
        <p className="text-muted-foreground rounded-xl border border-dashed p-6 text-center">
          Nobody has registered yet.
        </p>
      )}

      {waitlist.length > 0 && (
        <div>
          <h3 className="font-semibold">Waitlist (in order)</h3>
          <ol className="mt-2 list-decimal space-y-1 pl-6 text-sm">
            {waitlist.map((p) => (
              <li key={p.userId}>
                {p.name} <span className="text-muted-foreground">({p.email})</span>{" "}
                <Badge variant="outline" className="ml-1">
                  Waiting
                </Badge>
              </li>
            ))}
          </ol>
        </div>
      )}
    </section>
  );
}

export function MessageForm({ sessionId }: { sessionId: string }) {
  const { form, pending, result, onSubmit } = useActionForm(
    messageSchema,
    (v) => messageAttendees(sessionId, v),
    { subject: "", body: "", includeWaitlist: false },
  );
  return (
    <section aria-labelledby="msg-h" className="bg-card rounded-xl border p-5">
      <h2 id="msg-h" className="flex items-center gap-2 text-lg font-semibold">
        <Mail className="size-4" aria-hidden="true" /> Message attendees
      </h2>
      <form onSubmit={onSubmit} noValidate className="mt-4 grid gap-4">
        <FormField
          label="Subject"
          registration={form.register("subject")}
          error={form.formState.errors.subject}
        />
        <FormField
          label="Message"
          multiline
          registration={form.register("body")}
          error={form.formState.errors.body}
        />
        <label className="flex items-center gap-3 text-sm">
          <input
            type="checkbox"
            className="accent-primary size-5"
            {...form.register("includeWaitlist")}
          />{" "}
          Include people on the waitlist
        </label>
        <SubmitButton pending={pending} className="justify-self-start px-5">
          Send email
        </SubmitButton>
        <div aria-live="polite">
          {result && (
            <FormAlert kind={result.ok ? "success" : "error"}>
              {result.ok ? result.message : result.error}
            </FormAlert>
          )}
        </div>
      </form>
    </section>
  );
}

export function AfterSessionForm({
  sessionId,
  defaults,
}: {
  sessionId: string;
  defaults: { recordingUrl: string; materialsMd: string };
}) {
  const { form, pending, result, onSubmit } = useActionForm(
    afterSessionSchema,
    (v) => saveAfterSession(sessionId, v),
    defaults,
  );
  return (
    <section aria-labelledby="after-h" className="bg-card rounded-xl border p-5">
      <h2 id="after-h" className="text-lg font-semibold">
        Recording &amp; materials
      </h2>
      <p className="text-muted-foreground mt-1 text-sm">
        Shown to attendees on the session page once it&apos;s marked completed.
      </p>
      <form onSubmit={onSubmit} noValidate className="mt-4 grid gap-4">
        <FormField
          label="Recording URL"
          type="url"
          placeholder="https://"
          registration={form.register("recordingUrl")}
          error={form.formState.errors.recordingUrl}
        />
        <MarkdownField
          label="Materials"
          rows={5}
          registration={form.register("materialsMd")}
          value={form.watch("materialsMd") ?? ""}
          error={form.formState.errors.materialsMd}
          hint="Links to slides, notebooks or datasets (Markdown)."
        />
        <SubmitButton pending={pending} className="justify-self-start px-5">
          Save
        </SubmitButton>
        <div aria-live="polite">
          {result && (
            <FormAlert kind={result.ok ? "success" : "error"}>
              {result.ok ? result.message : result.error}
            </FormAlert>
          )}
        </div>
      </form>
    </section>
  );
}
