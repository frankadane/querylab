import { ArrowLeft, ExternalLink } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatInTimeZone } from "date-fns-tz";
import { z } from "zod";
import { FormAlert } from "@/components/forms/form-alert";
import { Badge } from "@/components/ui/badge";
import { requireRole } from "@/lib/auth";
import { formatSessionRange } from "@/lib/sessions/time";
import { liveLessons, manageableCourses, staffAccounts } from "@/lib/sessions/studio";
import { createClient } from "@/lib/supabase/server";
import { listTimezones } from "@/lib/timezones";
import { updateSession } from "../actions";
import { SessionForm } from "../session-form";
import { AfterSessionForm, MessageForm, Roster, StatusControls } from "./manage";

export const metadata: Metadata = { title: "Studio: manage session", robots: { index: false } };

export default async function ManageSessionPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ created?: string }>;
}) {
  const { id } = await params;
  const { created } = await searchParams;
  if (!z.string().uuid().safeParse(id).success) notFound();
  const { profile } = await requireRole(["instructor", "admin"], `/studio/sessions/${id}`);
  const supabase = await createClient();
  const { data: isStaff } = await supabase.rpc("is_session_staff", { p_session_id: id });
  if (!isStaff) notFound();

  const isAdmin = profile.role === "admin";
  const [{ data: s }, { data: link }, { data: regs }, courses, staff] = await Promise.all([
    supabase
      .from("live_sessions")
      .select("*, course:courses(title, slug), series:session_series(occurrences)")
      .eq("id", id)
      .single(),
    supabase.from("live_session_links").select("join_url").eq("session_id", id).maybeSingle(),
    supabase
      .from("session_registrations")
      .select(
        "user_id, status, waitlisted_at, attended_at, created_at, profile:profiles(full_name, email)",
      )
      .eq("session_id", id)
      .order("created_at"),
    manageableCourses(isAdmin),
    isAdmin ? staffAccounts() : Promise.resolve([]),
  ]);
  if (!s) notFound();

  // Make sure the current course appears in the selector even if the editor isn't its instructor.
  const courseOptions =
    s.course_id && !courses.some((c) => c.id === s.course_id) && s.course
      ? [{ id: s.course_id, title: s.course.title }, ...courses]
      : courses;
  const lessons = await liveLessons(courseOptions.map((c) => c.id));
  const minutes = Math.round(
    (new Date(s.ends_at).getTime() - new Date(s.starts_at).getTime()) / 60000,
  );
  const roster = (regs ?? []).map((r) => ({
    userId: r.user_id,
    name: r.profile?.full_name || "(no name)",
    email: r.profile?.email ?? "",
    status: r.status as "registered" | "waitlist" | "cancelled" | "attended",
    waitlistedAt: r.waitlisted_at,
  }));

  return (
    <div className="grid gap-10">
      <div>
        <Link
          href="/studio/sessions"
          className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5 text-sm font-medium"
        >
          <ArrowLeft className="size-4" aria-hidden="true" /> All sessions
        </Link>
        <div className="mt-4 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-3xl font-semibold">{s.title}</h1>
              <Badge
                variant={s.status === "cancelled" ? "destructive" : "secondary"}
                className="capitalize"
              >
                {s.status}
              </Badge>
            </div>
            <p className="text-muted-foreground mt-2">
              {formatSessionRange(s.starts_at, s.ends_at, profile.timezone)} ·{" "}
              {s.course?.title ?? "Open to all"}
            </p>
            <Link
              href={`/schedule/${s.id}`}
              className="text-primary mt-1 inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline"
            >
              View public page <ExternalLink className="size-3.5" aria-hidden="true" />
            </Link>
          </div>
          <StatusControls
            sessionId={s.id}
            status={s.status}
            inSeries={!!s.series_id}
            canDelete={isAdmin}
          />
        </div>
        {created && Number(created) > 0 && (
          <FormAlert kind="success" className="mt-6">
            {Number(created) === 1
              ? "Session created."
              : `${created} weekly sessions created. This is the first one.`}
          </FormAlert>
        )}
      </div>

      <Roster sessionId={s.id} capacity={s.capacity} people={roster} />

      <div className="grid gap-10 lg:grid-cols-2">
        <MessageForm sessionId={s.id} />
        <AfterSessionForm
          sessionId={s.id}
          defaults={{ recordingUrl: s.recording_url ?? "", materialsMd: s.materials_md ?? "" }}
        />
      </div>

      <section aria-labelledby="edit-h" className="border-t pt-10">
        <h2 id="edit-h" className="mb-6 text-2xl font-semibold">
          Edit session
        </h2>
        <SessionForm
          mode="edit"
          action={updateSession.bind(null, s.id)}
          courses={courseOptions}
          lessons={lessons}
          allowOpen={!s.course_id || isAdmin}
          timezones={listTimezones()}
          instructors={
            isAdmin
              ? staff.map((p) => [p.id, p.full_name || p.email] as [string, string])
              : undefined
          }
          defaults={{
            courseId: s.course_id ?? "",
            title: s.title,
            descriptionMd: s.description_md,
            date: formatInTimeZone(s.starts_at, s.timezone, "yyyy-MM-dd"),
            time: formatInTimeZone(s.starts_at, s.timezone, "HH:mm"),
            durationMinutes: minutes,
            timezone: s.timezone,
            joinUrl: link?.join_url ?? "",
            capacity: s.capacity,
            instructorId: s.instructor_id ?? "",
            repeatWeeks: 1,
            lessonId: s.lesson_id ?? "",
          }}
        />
      </section>
    </div>
  );
}
