import type { Metadata } from "next";
import { addDays, format } from "date-fns";
import { PageHeader } from "@/components/site/page-header";
import { requireRole } from "@/lib/auth";
import { liveLessons, manageableCourses, staffAccounts } from "@/lib/sessions/studio";
import { listTimezones } from "@/lib/timezones";
import { createSession } from "../actions";
import { SessionForm } from "../session-form";

export const metadata: Metadata = { title: "Studio: new session", robots: { index: false } };

export default async function NewSessionPage() {
  const { profile } = await requireRole(["instructor", "admin"], "/studio/sessions/new");
  const isAdmin = profile.role === "admin";
  const [courses, staff] = await Promise.all([
    manageableCourses(isAdmin),
    isAdmin ? staffAccounts() : Promise.resolve([]),
  ]);
  const lessons = await liveLessons(courses.map((c) => c.id));
  return (
    <>
      <PageHeader
        title="New live session"
        description="Students see it on the schedule straight away."
      />
      <div className="mt-8">
        <SessionForm
          mode="create"
          action={createSession}
          courses={courses}
          lessons={lessons}
          allowOpen
          timezones={listTimezones()}
          instructors={
            isAdmin
              ? staff.map((s) => [s.id, s.full_name || s.email] as [string, string])
              : undefined
          }
          defaults={{
            courseId: courses[0]?.id ?? "",
            title: "",
            descriptionMd: "",
            date: format(addDays(new Date(), 7), "yyyy-MM-dd"),
            time: "18:00",
            durationMinutes: 90,
            timezone: profile.timezone,
            joinUrl: "",
            capacity: 25,
            instructorId: profile.id,
            repeatWeeks: 1,
            lessonId: "",
          }}
        />
      </div>
    </>
  );
}
