import { NavLink } from "@/components/site/nav-link";
import { requireRole } from "@/lib/auth";

export default async function StudioLayout({ children }: { children: React.ReactNode }) {
  await requireRole(["instructor", "admin"], "/studio/courses");
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <nav aria-label="Studio" className="mb-8">
        <ul className="inline-flex gap-1 rounded-lg border p-1">
          <li>
            <NavLink
              href="/studio/courses"
              className="aria-[current=page]:bg-secondary aria-[current=page]:text-secondary-foreground block"
            >
              Courses
            </NavLink>
          </li>
          <li>
            <NavLink
              href="/studio/sessions"
              className="aria-[current=page]:bg-secondary aria-[current=page]:text-secondary-foreground block"
            >
              Live sessions
            </NavLink>
          </li>
        </ul>
      </nav>
      {children}
    </div>
  );
}
