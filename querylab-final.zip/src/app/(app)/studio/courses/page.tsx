import type { Metadata } from "next";
import Link from "next/link";
import { FormAlert } from "@/components/forms/form-alert";
import { PageHeader } from "@/components/site/page-header";
import { StatusBadge } from "@/components/studio/status-badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { requireRole } from "@/lib/auth";
import { TRACKS, formatPrice } from "@/lib/courses/format";
import { createClient } from "@/lib/supabase/server";
import { NewCourseDialog } from "./new-course-dialog";

export const metadata: Metadata = { title: "Studio: courses", robots: { index: false } };

export default async function StudioCoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ deleted?: string }>;
}) {
  const { profile } = await requireRole(["instructor", "admin"], "/studio/courses");
  const supabase = await createClient();
  // RLS lets everyone read published courses, so instructors are explicitly
  // narrowed to their own; admins see everything.
  let query = supabase
    .from("courses")
    .select(
      "id, title, slug, track, status, price_minor, currency, updated_at, is_demo, lessons(count), instructor:instructors(display_name)",
    )
    .order("updated_at", { ascending: false });
  if (profile.role !== "admin") {
    const { data: myInstructorId } = await supabase.rpc("my_instructor_id");
    query = myInstructorId
      ? query.eq("instructor_id", myInstructorId)
      : query.eq("id", "00000000-0000-0000-0000-000000000000");
  }
  const { data: courses } = await query;
  const { data: instructors } =
    profile.role === "admin"
      ? await supabase.from("instructors").select("id, display_name").order("display_name")
      : { data: null };
  const { deleted } = await searchParams;

  return (
    <>
      <PageHeader
        title="Courses"
        description={
          profile.role === "admin"
            ? "All courses. Instructors see only their own."
            : "Courses you teach."
        }
      >
        <NewCourseDialog instructors={instructors ?? undefined} />
      </PageHeader>
      {deleted && (
        <FormAlert kind="success" className="mt-6">
          Course deleted.
        </FormAlert>
      )}
      {courses?.length ? (
        <div className="bg-card mt-6 overflow-x-auto rounded-xl border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Course</TableHead>
                <TableHead>Track</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Lessons</TableHead>
                <TableHead className="text-right">Price</TableHead>
                <TableHead>Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {courses.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="max-w-80">
                    <Link
                      href={`/studio/courses/${c.id}`}
                      className="text-primary font-medium underline-offset-4 hover:underline"
                    >
                      {c.title}
                    </Link>
                    <p className="text-muted-foreground truncate text-xs">
                      {c.instructor?.display_name ?? "No instructor"}
                      {c.is_demo ? " · Demo" : ""}
                    </p>
                  </TableCell>
                  <TableCell>{TRACKS[c.track]}</TableCell>
                  <TableCell>
                    <StatusBadge status={c.status} />
                  </TableCell>
                  <TableCell className="tabular text-right font-mono">
                    {(c.lessons as unknown as { count: number }[])[0]?.count ?? 0}
                  </TableCell>
                  <TableCell className="tabular text-right font-mono">
                    {formatPrice(c.price_minor, c.currency)}
                  </TableCell>
                  <TableCell className="text-muted-foreground whitespace-nowrap">
                    <time dateTime={c.updated_at}>
                      {new Date(c.updated_at).toLocaleDateString("en-GB", {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                      })}
                    </time>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="mt-6 rounded-xl border border-dashed p-12 text-center">
          <h2 className="text-lg font-semibold">No courses yet</h2>
          <p className="text-muted-foreground mt-1">
            Create your first course to start building the curriculum.
          </p>
        </div>
      )}
    </>
  );
}
