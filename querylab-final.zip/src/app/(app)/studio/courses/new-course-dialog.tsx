"use client";

import { Plus } from "lucide-react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { TRACKS } from "@/lib/courses/format";
import { createCourseSchema } from "@/lib/validation/courses";
import { createCourse } from "../actions";

export function NewCourseDialog({
  instructors,
}: {
  instructors?: { id: string; display_name: string }[];
}) {
  const { form, pending, result, onSubmit } = useActionForm(createCourseSchema, createCourse, {
    title: "",
    track: "ai",
    instructorId: instructors?.[0]?.id ?? null,
  });
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button size="lg" className="h-11 px-4">
          <Plus aria-hidden="true" /> New course
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New course</DialogTitle>
          <DialogDescription>
            It starts as a draft. Nothing is public until you publish it.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} noValidate className="grid gap-5">
          {result && !result.ok && <FormAlert kind="error">{result.error}</FormAlert>}
          <FormField
            label="Title"
            registration={form.register("title")}
            error={form.formState.errors.title}
          />
          <SelectField label="Track" registration={form.register("track")} options={TRACKS} />
          {instructors && (
            <SelectField
              label="Instructor"
              registration={form.register("instructorId")}
              options={instructors.map((i) => [i.id, i.display_name] as [string, string])}
            />
          )}
          <SubmitButton pending={pending}>Create draft</SubmitButton>
        </form>
      </DialogContent>
    </Dialog>
  );
}
