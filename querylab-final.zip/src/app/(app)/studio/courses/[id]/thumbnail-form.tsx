"use client";

import { useRef } from "react";
import { CourseCover } from "@/components/courses/course-cover";
import { FormAlert } from "@/components/forms/form-alert";
import { useAction } from "@/components/forms/use-action";
import { Button } from "@/components/ui/button";
import type { Track } from "@/lib/courses/format";
import { uploadCourseThumbnail } from "../../actions";

export function ThumbnailForm({
  courseId,
  track,
  url,
}: {
  courseId: string;
  track: Track;
  url: string | null;
}) {
  const input = useRef<HTMLInputElement>(null);
  const { pending, result, run } = useAction();
  return (
    <section aria-labelledby="thumb-h" className="bg-card self-start rounded-xl border p-5">
      <h2 id="thumb-h" className="font-semibold">
        Thumbnail
      </h2>
      <p className="text-muted-foreground mt-1 text-sm">
        16:9, PNG/JPEG/WebP, up to 5 MB. Without one, a chart-style cover is generated.
      </p>
      <CourseCover track={track} src={url} className="mt-4 rounded-lg" />
      <input
        ref={input}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="sr-only"
        tabIndex={-1}
        aria-hidden="true"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const fd = new FormData();
          fd.set("file", f);
          run(() => uploadCourseThumbnail(courseId, fd));
          e.target.value = "";
        }}
      />
      <Button
        type="button"
        variant="outline"
        size="lg"
        className="mt-4 h-10 w-full"
        disabled={pending}
        onClick={() => input.current?.click()}
      >
        {pending ? "Uploading…" : "Upload thumbnail"}
      </Button>
      <div aria-live="polite" className="mt-3">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </section>
  );
}
