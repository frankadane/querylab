import type { Metadata } from "next";
import { requireRole } from "@/lib/auth";
import { getStudioCourse } from "@/lib/courses/studio";
import { createClient } from "@/lib/supabase/server";
import { CourseDetailsForm } from "./details-form";
import { ThumbnailForm } from "./thumbnail-form";

export const metadata: Metadata = { title: "Studio: course details", robots: { index: false } };

export default async function CourseDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { profile } = await requireRole(["instructor", "admin"]);
  const course = await getStudioCourse(id);
  const supabase = await createClient();
  const { data: instructors } =
    profile.role === "admin"
      ? await supabase.from("instructors").select("id, display_name").order("display_name")
      : { data: null };

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_20rem]">
      <CourseDetailsForm
        courseId={course.id}
        instructors={instructors ?? undefined}
        defaults={{
          title: course.title,
          slug: course.slug,
          subtitle: course.subtitle ?? "",
          descriptionMd: course.description_md,
          outcomes: course.outcomes.join("\n"),
          requirements: course.requirements.join("\n"),
          track: course.track,
          levelMin: course.level_min,
          levelMax: course.level_max,
          format: course.format,
          durationWeeks: course.duration_weeks ?? "",
          price: (course.price_minor / 100).toFixed(course.price_minor % 100 ? 2 : 0),
          currency: course.currency,
          instructorId: course.instructor_id ?? "",
        }}
      />
      <ThumbnailForm courseId={course.id} track={course.track} url={course.thumbnail_url} />
    </div>
  );
}
