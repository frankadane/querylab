"use client";

import { FileDown } from "lucide-react";
import { useRef } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { useAction } from "@/components/forms/use-action";
import { Button } from "@/components/ui/button";
import { uploadLessonFile } from "../../../../actions";

export function FileUpload({
  lessonId,
  currentPath,
}: {
  lessonId: string;
  currentPath: string | null;
}) {
  const input = useRef<HTMLInputElement>(null);
  const { pending, result, run } = useAction();
  const name = currentPath?.split("/").pop()?.replace(/^\d+-/, "");
  return (
    <section aria-labelledby="file-h" className="bg-card rounded-xl border p-5">
      <h2 id="file-h" className="text-lg font-semibold">
        Downloadable file
      </h2>
      <p className="text-muted-foreground mt-1 text-sm">
        Optional for videos and articles (worksheets, slides, datasets). Up to 50 MB, stored
        privately; only enrolled students can download it.
      </p>
      <p className="mt-4 flex items-center gap-2 text-sm">
        <FileDown className="text-muted-foreground size-4" aria-hidden="true" />
        {name ? (
          <span className="font-medium">{name}</span>
        ) : (
          <span className="text-muted-foreground">No file uploaded</span>
        )}
      </p>
      <input
        ref={input}
        type="file"
        className="sr-only"
        tabIndex={-1}
        aria-hidden="true"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const fd = new FormData();
          fd.set("file", f);
          run(() => uploadLessonFile(lessonId, fd));
          e.target.value = "";
        }}
      />
      <Button
        type="button"
        variant="outline"
        size="lg"
        className="mt-4 h-10 px-4"
        disabled={pending}
        onClick={() => input.current?.click()}
      >
        {pending ? "Uploading…" : name ? "Replace file" : "Upload file"}
      </Button>
      <div aria-live="polite" className="mt-3">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </section>
  );
}
