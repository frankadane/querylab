"use client";

import { useId } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { MarkdownField } from "@/components/forms/markdown-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { LESSON_TYPES } from "@/lib/courses/format";
import { type LessonInput, lessonSchema } from "@/lib/validation/courses";
import { updateLesson } from "../../../../actions";

export function LessonForm({
  lessonId,
  defaults,
  sections,
}: {
  lessonId: string;
  defaults: LessonInput;
  sections: [string, string][];
}) {
  const { form, pending, result, onSubmit } = useActionForm(
    lessonSchema,
    (v) => updateLesson(lessonId, v),
    defaults,
  );
  const { errors } = form.formState;
  const r = form.register;
  const type = form.watch("type");
  const previewId = useId();

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-6">
      <h2 className="text-2xl font-semibold">Edit lesson</h2>
      <div className="grid gap-5 sm:grid-cols-2">
        <FormField
          label="Title"
          registration={r("title")}
          error={errors.title}
          className="sm:col-span-2"
        />
        <FormField
          label="Summary"
          hint="Shown in the public syllabus."
          registration={r("summary")}
          error={errors.summary}
          className="sm:col-span-2"
        />
        <SelectField label="Type" registration={r("type")} options={LESSON_TYPES} />
        <SelectField
          label="Section"
          registration={r("sectionId")}
          options={sections}
          hint="Moving puts the lesson at the end of that section."
        />
        <FormField
          label="Duration (minutes)"
          type="number"
          inputMode="numeric"
          min={0}
          registration={r("durationMinutes")}
          error={errors.durationMinutes}
        />
        <div className="flex items-start gap-3 self-end pb-2">
          <input
            id={previewId}
            type="checkbox"
            className="accent-primary mt-0.5 size-5"
            {...r("isFreePreview")}
          />
          <label htmlFor={previewId} className="text-sm leading-6">
            <span className="font-medium">Free preview</span>
            <span className="text-muted-foreground block">
              Anyone can view this lesson without enrolling.
            </span>
          </label>
        </div>
      </div>
      {(type === "video" || type === "live_session") && (
        <FormField
          label="Video URL"
          type="url"
          hint="Vimeo, YouTube or Mux link (https). Leave empty if not ready yet."
          registration={r("videoUrl")}
          error={errors.videoUrl}
        />
      )}
      <MarkdownField
        label={type === "article" ? "Article" : "Lesson notes"}
        registration={r("bodyMd")}
        value={form.watch("bodyMd") ?? ""}
        error={errors.bodyMd}
        rows={16}
      />
      <div className="bg-background/95 sticky bottom-0 -mx-4 flex flex-wrap items-center gap-4 border-t px-4 py-4 backdrop-blur">
        <SubmitButton pending={pending} className="px-6">
          Save lesson
        </SubmitButton>
        <div aria-live="polite" className="min-w-0 flex-1">
          {result && (
            <FormAlert kind={result.ok ? "success" : "error"}>
              {result.ok ? result.message : result.error}
            </FormAlert>
          )}
        </div>
      </div>
    </form>
  );
}
