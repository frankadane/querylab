import { ArrowLeft } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getStudioCourse } from "@/lib/courses/studio";
import { createClient } from "@/lib/supabase/server";
import { FileUpload } from "./file-upload";
import { LessonForm } from "./lesson-form";
import { QuizEditor } from "./quiz-editor";

export const metadata: Metadata = { title: "Studio: lesson", robots: { index: false } };

export default async function LessonEditorPage({
  params,
}: {
  params: Promise<{ id: string; lessonId: string }>;
}) {
  const { id, lessonId } = await params;
  const course = await getStudioCourse(id);
  const section = course.sections.find((s) => s.lessons.some((l) => l.id === lessonId));
  if (!section) notFound();

  const supabase = await createClient();
  const [{ data: lesson }, { data: content }, { data: quiz }] = await Promise.all([
    supabase.from("lessons").select("*").eq("id", lessonId).single(),
    supabase.from("lesson_contents").select("*").eq("lesson_id", lessonId).maybeSingle(),
    supabase
      .from("quizzes")
      .select(
        "id, pass_mark, quiz_questions(prompt, options, correct_index, explanation, position)",
      )
      .eq("lesson_id", lessonId)
      .order("position", { referencedTable: "quiz_questions" })
      .maybeSingle(),
  ]);
  if (!lesson) notFound();

  return (
    <div className="grid gap-10">
      <Link
        href={`/studio/courses/${id}/curriculum`}
        className="text-primary inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> Back to curriculum
      </Link>
      <LessonForm
        lessonId={lessonId}
        sections={course.sections.map((s) => [s.id, s.title] as [string, string])}
        defaults={{
          title: lesson.title,
          summary: lesson.summary ?? "",
          type: lesson.type,
          sectionId: lesson.section_id,
          durationMinutes: lesson.duration_minutes ?? "",
          isFreePreview: lesson.is_free_preview,
          videoUrl: content?.video_url ?? "",
          bodyMd: content?.body_md ?? "",
        }}
      />
      {["file", "article", "video"].includes(lesson.type) && (
        <FileUpload lessonId={lessonId} currentPath={content?.file_path ?? null} />
      )}
      {lesson.type === "quiz" && (
        <QuizEditor
          lessonId={lessonId}
          defaults={{
            passMark: quiz?.pass_mark ?? 70,
            questions: (quiz?.quiz_questions ?? []).map((q) => ({
              prompt: q.prompt,
              options: q.options as string[],
              correctIndex: q.correct_index,
              explanation: q.explanation ?? "",
            })),
          }}
        />
      )}
      {lesson.type === "live_session" && (
        <p className="text-muted-foreground rounded-xl border border-dashed p-5">
          To link sessions to this lesson, open Studio → Live sessions, edit a session of this
          course and choose this lesson under “Counts towards lesson”. Attendance then marks it
          complete.
        </p>
      )}
    </div>
  );
}
