"use client";

import { Plus, Trash2, X } from "lucide-react";
import { useFieldArray } from "react-hook-form";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { type QuizInput, quizSchema } from "@/lib/validation/courses";
import { saveQuiz } from "../../../../actions";

export function QuizEditor({ lessonId, defaults }: { lessonId: string; defaults: QuizInput }) {
  const { form, pending, result, onSubmit } = useActionForm(
    quizSchema,
    (v) => saveQuiz(lessonId, v),
    defaults,
  );
  const questions = useFieldArray({ control: form.control, name: "questions" });
  const errors = form.formState.errors;

  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="bg-card grid gap-6 rounded-xl border p-5 sm:p-6"
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Quiz questions</h2>
          <p className="text-muted-foreground mt-1 text-sm">
            Multiple choice. Answers are never shown to students before they submit.
          </p>
        </div>
        <FormField
          label="Pass mark (%)"
          type="number"
          inputMode="numeric"
          min={0}
          max={100}
          registration={form.register("passMark")}
          error={errors.passMark}
          className="w-36"
        />
      </div>

      <ol className="grid gap-5">
        {questions.fields.map((q, qi) => (
          <QuestionEditor key={q.id} index={qi} form={form} onRemove={() => questions.remove(qi)} />
        ))}
      </ol>
      {questions.fields.length === 0 && (
        <p className="text-muted-foreground text-sm">No questions yet.</p>
      )}

      <Button
        type="button"
        variant="outline"
        size="lg"
        className="h-10 justify-self-start px-4"
        onClick={() =>
          questions.append({ prompt: "", options: ["", ""], correctIndex: 0, explanation: "" })
        }
      >
        <Plus aria-hidden="true" /> Add question
      </Button>

      <div className="flex flex-wrap items-center gap-4 border-t pt-5">
        <SubmitButton pending={pending} className="px-6">
          Save quiz
        </SubmitButton>
        <div aria-live="polite" className="min-w-0 flex-1">
          {result && (
            <FormAlert kind={result.ok ? "success" : "error"}>
              {result.ok ? result.message : result.error}
            </FormAlert>
          )}
        </div>
      </div>
    </form>
  );
}

function QuestionEditor({
  index,
  form,
  onRemove,
}: {
  index: number;
  form: ReturnType<typeof useActionForm<typeof quizSchema>>["form"];
  onRemove: () => void;
}) {
  const options = form.watch(`questions.${index}.options`) ?? [];
  const correct = Number(form.watch(`questions.${index}.correctIndex`));
  const qErrors = form.formState.errors.questions?.[index];
  const groupName = `q${index}-correct`;

  return (
    <li className="rounded-lg border p-4">
      <fieldset className="grid gap-4">
        <legend className="flex w-full items-center justify-between gap-2 font-medium">
          Question {index + 1}
          <Button
            type="button"
            variant="ghost"
            size="lg"
            className="text-destructive h-9 px-2"
            onClick={onRemove}
            aria-label={`Remove question ${index + 1}`}
          >
            <Trash2 aria-hidden="true" /> Remove
          </Button>
        </legend>
        <FormField
          label="Question"
          registration={form.register(`questions.${index}.prompt`)}
          error={qErrors?.prompt}
        />
        <div
          role="radiogroup"
          aria-label={`Options for question ${index + 1}. Select the correct answer.`}
          className="grid gap-2"
        >
          <p className="text-sm font-medium">
            Options{" "}
            <span className="text-muted-foreground font-normal">(select the correct one)</span>
          </p>
          {options.map((_, oi) => (
            <div key={oi} className="flex items-center gap-2">
              <input
                type="radio"
                name={groupName}
                checked={correct === oi}
                onChange={() =>
                  form.setValue(`questions.${index}.correctIndex`, oi, { shouldDirty: true })
                }
                aria-label={`Option ${oi + 1} is correct`}
                className="accent-primary size-5 shrink-0"
              />
              <Input
                {...form.register(`questions.${index}.options.${oi}`)}
                aria-label={`Option ${oi + 1}`}
                className="h-10"
                aria-invalid={qErrors?.options?.[oi] ? true : undefined}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon-lg"
                className="size-10 shrink-0"
                aria-label={`Remove option ${oi + 1}`}
                disabled={options.length <= 2}
                onClick={() => {
                  const next = options.filter((__, i) => i !== oi);
                  form.setValue(`questions.${index}.options`, next, { shouldDirty: true });
                  if (correct >= next.length) form.setValue(`questions.${index}.correctIndex`, 0);
                }}
              >
                <X className="size-4" aria-hidden="true" />
              </Button>
            </div>
          ))}
          {(qErrors?.options?.message || qErrors?.correctIndex?.message) && (
            <p className="text-destructive text-sm font-medium">
              {qErrors?.options?.message ?? qErrors?.correctIndex?.message}
            </p>
          )}
          {options.length < 6 && (
            <Button
              type="button"
              variant="ghost"
              size="lg"
              className="h-9 justify-self-start px-2"
              onClick={() =>
                form.setValue(`questions.${index}.options`, [...options, ""], { shouldDirty: true })
              }
            >
              <Plus aria-hidden="true" /> Add option
            </Button>
          )}
        </div>
        <FormField
          label="Explanation (optional)"
          hint="Shown after the student answers."
          registration={form.register(`questions.${index}.explanation`)}
          error={qErrors?.explanation}
        />
      </fieldset>
    </li>
  );
}
