"use client";

import { Archive, Eye, EyeOff, Trash2 } from "lucide-react";
import { FormAlert } from "@/components/forms/form-alert";
import { useAction } from "@/components/forms/use-action";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import type { CourseStatus } from "@/lib/courses/format";
import { deleteCourse, setCourseStatus } from "../../actions";

export function CourseStatusActions({
  courseId,
  status,
  canDelete,
}: {
  courseId: string;
  status: CourseStatus;
  canDelete: boolean;
}) {
  const { pending, result, run } = useAction();
  return (
    <div className="grid gap-2 lg:justify-items-end">
      <div className="flex flex-wrap gap-2">
        {status !== "published" && (
          <Button
            size="lg"
            className="h-10 px-4"
            disabled={pending}
            onClick={() => run(() => setCourseStatus(courseId, "published"))}
          >
            <Eye aria-hidden="true" /> Publish
          </Button>
        )}
        {status === "published" && (
          <Button
            variant="outline"
            size="lg"
            className="h-10 px-4"
            disabled={pending}
            onClick={() => run(() => setCourseStatus(courseId, "draft"))}
          >
            <EyeOff aria-hidden="true" /> Unpublish
          </Button>
        )}
        {status !== "archived" && (
          <Button
            variant="outline"
            size="lg"
            className="h-10 px-4"
            disabled={pending}
            onClick={() => run(() => setCourseStatus(courseId, "archived"))}
          >
            <Archive aria-hidden="true" /> Archive
          </Button>
        )}
        {canDelete && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="lg" className="h-10 px-4" disabled={pending}>
                <Trash2 aria-hidden="true" /> Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete this course?</AlertDialogTitle>
                <AlertDialogDescription>
                  All sections, lessons, quizzes and FAQs are deleted permanently. Courses with
                  enrolments can only be archived.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => run(() => deleteCourse(courseId))}>
                  Delete course
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>
      <div aria-live="polite">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </div>
  );
}
