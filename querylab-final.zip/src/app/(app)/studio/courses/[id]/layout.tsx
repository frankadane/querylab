import { ArrowLeft, ExternalLink } from "lucide-react";
import Link from "next/link";
import { NavLink } from "@/components/site/nav-link";
import { StatusBadge } from "@/components/studio/status-badge";
import { requireRole } from "@/lib/auth";
import { getStudioCourse } from "@/lib/courses/studio";
import { CourseStatusActions } from "./status-actions";

export default async function CourseStudioLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const { profile } = await requireRole(["instructor", "admin"], `/studio/courses/${id}`);
  const course = await getStudioCourse(id);
  const base = `/studio/courses/${id}`;

  return (
    <>
      <Link
        href="/studio/courses"
        className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5 text-sm font-medium"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> All courses
      </Link>
      <div className="mt-4 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-3xl font-semibold">{course.title}</h1>
            <StatusBadge status={course.status} />
          </div>
          {course.status === "published" && (
            <Link
              href={`/courses/${course.slug}`}
              className="text-primary mt-2 inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline"
            >
              View public page <ExternalLink className="size-3.5" aria-hidden="true" />
              <span className="sr-only">(opens course page)</span>
            </Link>
          )}
        </div>
        <CourseStatusActions
          courseId={course.id}
          status={course.status}
          canDelete={profile.role === "admin" && course.status !== "published"}
        />
      </div>
      <nav aria-label="Course editor" className="mt-6 border-b">
        <ul className="-mb-px flex gap-1 overflow-x-auto">
          {[
            { href: base, label: "Details" },
            { href: `${base}/curriculum`, label: "Curriculum" },
            { href: `${base}/faqs`, label: "FAQs" },
          ].map((t) => (
            <li key={t.href}>
              <NavLink
                href={t.href}
                exact
                className="aria-[current=page]:border-primary block rounded-none border-b-2 border-transparent whitespace-nowrap"
              >
                {t.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      <div className="mt-8">{children}</div>
    </>
  );
}
