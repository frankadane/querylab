import type { Metadata } from "next";
import { getStudioCourse } from "@/lib/courses/studio";
import { createClient } from "@/lib/supabase/server";
import { FaqManager } from "@/components/studio/faq-manager";
import { deleteCourseFaq, saveCourseFaq } from "../../../actions";

export const metadata: Metadata = { title: "Studio: FAQs", robots: { index: false } };

export default async function CourseFaqsPage({ params }: { params: Promise<{ id: string }> }) {
  const course = await getStudioCourse((await params).id);
  const supabase = await createClient();
  const { data: faqs } = await supabase
    .from("faqs")
    .select("id, question, answer_md, is_published")
    .eq("course_id", course.id)
    .order("position");
  return (
    <FaqManager
      faqs={faqs ?? []}
      save={saveCourseFaq.bind(null, course.id)}
      remove={deleteCourseFaq.bind(null, course.id)}
      description="Shown on the course page. Markdown is supported in answers."
    />
  );
}
