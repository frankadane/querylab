"use client";

import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { MarkdownField } from "@/components/forms/markdown-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { FORMATS, LEVELS, TRACKS } from "@/lib/courses/format";
import { type CourseDetailsInput, courseDetailsSchema } from "@/lib/validation/courses";
import { updateCourseDetails } from "../../actions";

export function CourseDetailsForm({
  courseId,
  defaults,
  instructors,
}: {
  courseId: string;
  defaults: CourseDetailsInput;
  instructors?: { id: string; display_name: string }[];
}) {
  const { form, pending, result, onSubmit } = useActionForm(
    courseDetailsSchema,
    (v) => updateCourseDetails(courseId, v),
    defaults,
  );
  const { errors } = form.formState;
  const r = form.register;

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-8">
      <fieldset className="grid gap-5">
        <legend className="mb-4 text-lg font-semibold">Basics</legend>
        <FormField label="Title" registration={r("title")} error={errors.title} />
        <FormField
          label="URL slug"
          hint="Appears in the course address: /courses/your-slug"
          registration={r("slug")}
          error={errors.slug}
        />
        <FormField
          label="Subtitle"
          hint="One sentence shown on course cards and in search results."
          registration={r("subtitle")}
          error={errors.subtitle}
        />
        <MarkdownField
          label="Description"
          registration={r("descriptionMd")}
          value={form.watch("descriptionMd") ?? ""}
          error={errors.descriptionMd}
        />
        <FormField
          label="Learning outcomes"
          multiline
          hint="One per line."
          registration={r("outcomes")}
          error={errors.outcomes}
        />
        <FormField
          label="Requirements"
          multiline
          hint="One per line."
          registration={r("requirements")}
          error={errors.requirements}
        />
      </fieldset>

      <fieldset className="grid gap-5 border-t pt-8 sm:grid-cols-2">
        <legend className="mb-4 text-lg font-semibold">Classification</legend>
        <SelectField label="Track" registration={r("track")} options={TRACKS} />
        <SelectField label="Format" registration={r("format")} options={FORMATS} />
        <SelectField label="Level from" registration={r("levelMin")} options={LEVELS} />
        <SelectField
          label="Level to"
          registration={r("levelMax")}
          options={LEVELS}
          error={errors.levelMax}
        />
        <FormField
          label="Duration (weeks)"
          type="number"
          inputMode="numeric"
          min={1}
          max={104}
          registration={r("durationWeeks")}
          error={errors.durationWeeks}
        />
        {instructors && (
          <SelectField
            label="Instructor"
            registration={r("instructorId")}
            options={[
              ["", "No instructor"],
              ...instructors.map((i) => [i.id, i.display_name] as [string, string]),
            ]}
          />
        )}
      </fieldset>

      <fieldset className="grid gap-5 border-t pt-8 sm:grid-cols-2">
        <legend className="mb-4 text-lg font-semibold">Price</legend>
        <FormField
          label="Price"
          inputMode="decimal"
          hint="0 makes the course free."
          registration={r("price")}
          error={errors.price}
        />
        <SelectField
          label="Currency"
          registration={r("currency")}
          options={{ GHS: "GHS (Ghana cedi)", USD: "USD (US dollar)" }}
        />
      </fieldset>

      <div className="bg-background/95 sticky bottom-0 -mx-4 flex flex-wrap items-center gap-4 border-t px-4 py-4 backdrop-blur">
        <SubmitButton pending={pending} className="px-6">
          Save changes
        </SubmitButton>
        <div aria-live="polite" className="min-w-0 flex-1">
          {result && (
            <FormAlert kind={result.ok ? "success" : "error"}>
              {result.ok ? result.message : result.error}
            </FormAlert>
          )}
        </div>
      </div>
    </form>
  );
}
