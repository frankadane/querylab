import type { Metadata } from "next";
import { getStudioCourse } from "@/lib/courses/studio";
import { CurriculumBuilder } from "./curriculum-builder";

export const metadata: Metadata = { title: "Studio: curriculum", robots: { index: false } };

export default async function CurriculumPage({ params }: { params: Promise<{ id: string }> }) {
  const course = await getStudioCourse((await params).id);
  return (
    <CurriculumBuilder
      courseId={course.id}
      sections={course.sections.map((s) => ({
        id: s.id,
        title: s.title,
        description: s.description,
        lessons: s.lessons.map((l) => ({
          id: l.id,
          title: l.title,
          type: l.type,
          durationMinutes: l.duration_minutes,
          isFreePreview: l.is_free_preview,
        })),
      }))}
    />
  );
}
