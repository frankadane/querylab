"use client";

import {
  type Announcements,
  DndContext,
  type DragEndEvent,
  KeyboardSensor,
  MeasuringStrategy,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { ArrowDown, ArrowUp, GripVertical, Pencil, Plus, Trash2 } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useId, useState, useTransition } from "react";
import { LessonTypeIcon } from "@/components/courses/lesson-type-icon";
import { FormAlert } from "@/components/forms/form-alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { ActionResult } from "@/lib/action-result";
import { LESSON_TYPES, type LessonType, formatDuration } from "@/lib/courses/format";
import {
  addLesson,
  addSection,
  deleteLesson,
  deleteSection,
  reorderLessons,
  reorderSections,
  updateSection,
} from "../../../actions";

/** Screen-reader announcements that use item titles and positions instead of internal IDs. */
function announcements(
  kind: "section" | "lesson",
  items: { id: string; title: string }[],
): Announcements {
  const title = (id: string | number) => items.find((i) => i.id === id)?.title ?? kind;
  const pos = (id: string | number) => items.findIndex((i) => i.id === id) + 1;
  return {
    onDragStart: ({ active }) =>
      `Picked up ${kind} “${title(active.id)}”, position ${pos(active.id)} of ${items.length}. Use the arrow keys to move, Space to drop, Escape to cancel.`,
    onDragOver: ({ active, over }) =>
      over
        ? `${kind === "section" ? "Section" : "Lesson"} “${title(active.id)}” is over position ${pos(over.id)} of ${items.length}.`
        : undefined,
    onDragEnd: ({ active, over }) =>
      over
        ? `Dropped “${title(active.id)}” at position ${pos(over.id)} of ${items.length}.`
        : `Dropped “${title(active.id)}”.`,
    onDragCancel: ({ active }) => `Moving “${title(active.id)}” was cancelled.`,
  };
}

const screenReaderInstructions = {
  draggable:
    "To reorder, press Space to pick up, use the arrow keys to move, then press Space again to drop. Press Escape to cancel. You can also use the Move up and Move down buttons.",
};

/** Measure drop targets up front so fast keyboard moves work immediately after pick-up. */
const measuring = { droppable: { strategy: MeasuringStrategy.Always } };

type Lesson = {
  id: string;
  title: string;
  type: LessonType;
  durationMinutes: number | null;
  isFreePreview: boolean;
};
type Section = { id: string; title: string; description: string | null; lessons: Lesson[] };

export function CurriculumBuilder({
  courseId,
  sections: initial,
}: {
  courseId: string;
  sections: Section[];
}) {
  const router = useRouter();
  const [sections, setSections] = useState(initial);
  const [status, setStatus] = useState<{ kind: "success" | "error"; text: string } | null>(null);
  const [, start] = useTransition();
  useEffect(() => setSections(initial), [initial]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  function report(r: ActionResult<unknown> | undefined, okText?: string, revert?: () => void) {
    if (!r) return;
    if (r.ok) {
      setStatus(okText || r.message ? { kind: "success", text: okText ?? r.message! } : null);
      router.refresh();
    } else {
      revert?.();
      setStatus({ kind: "error", text: r.error });
    }
  }

  function moveSection(from: number, to: number) {
    if (to < 0 || to >= sections.length) return;
    const prev = sections;
    const next = arrayMove(sections, from, to);
    setSections(next);
    start(async () =>
      report(
        await reorderSections({ parentId: courseId, ids: next.map((s) => s.id) }),
        `Moved “${prev[from].title}” to position ${to + 1}.`,
        () => setSections(prev),
      ),
    );
  }

  function moveLesson(sectionIndex: number, from: number, to: number) {
    const section = sections[sectionIndex];
    if (to < 0 || to >= section.lessons.length) return;
    const prev = sections;
    const lessons = arrayMove(section.lessons, from, to);
    setSections(sections.map((s, i) => (i === sectionIndex ? { ...s, lessons } : s)));
    start(async () =>
      report(
        await reorderLessons({ parentId: section.id, ids: lessons.map((l) => l.id) }),
        `Moved “${section.lessons[from].title}” to position ${to + 1}.`,
        () => setSections(prev),
      ),
    );
  }

  function onSectionDragEnd(e: DragEndEvent) {
    if (!e.over || e.active.id === e.over.id) return;
    moveSection(
      sections.findIndex((s) => s.id === e.active.id),
      sections.findIndex((s) => s.id === e.over!.id),
    );
  }

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="text-muted-foreground">
          Drag the handles to reorder, or use the arrow buttons. Click a lesson to edit its content.
        </p>
        <p className="text-muted-foreground text-sm">
          {sections.length} sections · {sections.reduce((n, s) => n + s.lessons.length, 0)} lessons
        </p>
      </div>
      <div aria-live="polite" aria-atomic="true">
        {status && <FormAlert kind={status.kind}>{status.text}</FormAlert>}
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={onSectionDragEnd}
        measuring={measuring}
        accessibility={{
          announcements: announcements("section", sections),
          screenReaderInstructions,
        }}
      >
        <SortableContext items={sections.map((s) => s.id)} strategy={verticalListSortingStrategy}>
          <ol className="grid gap-4">
            {sections.map((section, si) => (
              <SectionCard
                key={section.id}
                courseId={courseId}
                section={section}
                index={si}
                total={sections.length}
                sensors={sensors}
                onMove={(to) => moveSection(si, to)}
                onMoveLesson={(from, to) => moveLesson(si, from, to)}
                report={report}
              />
            ))}
          </ol>
        </SortableContext>
      </DndContext>

      <AddSectionForm courseId={courseId} report={report} />
    </div>
  );
}

function SectionCard({
  courseId,
  section,
  index,
  total,
  sensors,
  onMove,
  onMoveLesson,
  report,
}: {
  courseId: string;
  section: Section;
  index: number;
  total: number;
  sensors: ReturnType<typeof useSensors>;
  onMove: (to: number) => void;
  onMoveLesson: (from: number, to: number) => void;
  report: (r: ActionResult<unknown> | undefined, ok?: string, revert?: () => void) => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    setActivatorNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: section.id });
  const [pending, start] = useTransition();
  const headingId = useId();

  function onLessonDragEnd(e: DragEndEvent) {
    if (!e.over || e.active.id === e.over.id) return;
    onMoveLesson(
      section.lessons.findIndex((l) => l.id === e.active.id),
      section.lessons.findIndex((l) => l.id === e.over!.id),
    );
  }

  return (
    <li
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={`bg-card rounded-xl border ${isDragging ? "ring-ring relative z-10 shadow-lg ring-2" : ""}`}
      aria-labelledby={headingId}
    >
      <div className="flex items-center gap-2 border-b px-3 py-3 sm:px-4">
        <button
          ref={setActivatorNodeRef}
          {...attributes}
          {...listeners}
          aria-label={`Drag to reorder section: ${section.title}`}
          className="text-muted-foreground hover:bg-accent flex size-10 cursor-grab touch-none items-center justify-center rounded-md active:cursor-grabbing"
        >
          <GripVertical className="size-4" aria-hidden="true" />
        </button>
        <span className="text-muted-foreground tabular font-mono text-sm">
          {String(index + 1).padStart(2, "0")}
        </span>
        <h2 id={headingId} className="min-w-0 flex-1 truncate font-semibold">
          {section.title}
        </h2>
        <div className="flex items-center">
          <IconButton
            label={`Move section up: ${section.title}`}
            disabled={index === 0}
            onClick={() => onMove(index - 1)}
          >
            <ArrowUp />
          </IconButton>
          <IconButton
            label={`Move section down: ${section.title}`}
            disabled={index === total - 1}
            onClick={() => onMove(index + 1)}
          >
            <ArrowDown />
          </IconButton>
          <EditSectionDialog section={section} report={report} />
          <ConfirmDelete
            label={`Delete section: ${section.title}`}
            title="Delete this section?"
            description={`“${section.title}” and its ${section.lessons.length} lessons will be deleted permanently.`}
            onConfirm={() => start(async () => report(await deleteSection(section.id)))}
            disabled={pending}
          />
        </div>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={onLessonDragEnd}
        measuring={measuring}
        accessibility={{
          announcements: announcements("lesson", section.lessons),
          screenReaderInstructions,
        }}
      >
        <SortableContext
          items={section.lessons.map((l) => l.id)}
          strategy={verticalListSortingStrategy}
        >
          <ol className="divide-y">
            {section.lessons.map((lesson, li) => (
              <LessonRow
                key={lesson.id}
                courseId={courseId}
                lesson={lesson}
                index={li}
                total={section.lessons.length}
                onMove={(to) => onMoveLesson(li, to)}
                report={report}
              />
            ))}
          </ol>
        </SortableContext>
      </DndContext>
      {section.lessons.length === 0 && (
        <p className="text-muted-foreground px-4 py-4 text-sm">No lessons yet.</p>
      )}
      <AddLessonForm sectionId={section.id} sectionTitle={section.title} report={report} />
    </li>
  );
}

function LessonRow({
  courseId,
  lesson,
  index,
  total,
  onMove,
  report,
}: {
  courseId: string;
  lesson: Lesson;
  index: number;
  total: number;
  onMove: (to: number) => void;
  report: (r: ActionResult<unknown> | undefined) => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    setActivatorNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: lesson.id });
  const [pending, start] = useTransition();
  return (
    <li
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={`bg-card flex items-center gap-2 px-3 py-2 sm:px-4 ${isDragging ? "ring-ring relative z-10 shadow-lg ring-2" : ""}`}
    >
      <button
        ref={setActivatorNodeRef}
        {...attributes}
        {...listeners}
        aria-label={`Drag to reorder lesson: ${lesson.title}`}
        className="text-muted-foreground hover:bg-accent flex size-10 shrink-0 cursor-grab touch-none items-center justify-center rounded-md active:cursor-grabbing"
      >
        <GripVertical className="size-4" aria-hidden="true" />
      </button>
      <LessonTypeIcon type={lesson.type} className="text-muted-foreground size-4 shrink-0" />
      <div className="min-w-0 flex-1">
        <Link
          href={`/studio/courses/${courseId}/lessons/${lesson.id}`}
          className="text-primary block truncate font-medium underline-offset-4 hover:underline"
        >
          {lesson.title}
        </Link>
        <p className="text-muted-foreground text-xs">
          {LESSON_TYPES[lesson.type]}
          {lesson.durationMinutes ? ` · ${formatDuration(lesson.durationMinutes)}` : ""}
        </p>
      </div>
      {lesson.isFreePreview && (
        <Badge
          variant="outline"
          className="border-highlight text-highlight-text hidden sm:inline-flex"
        >
          Free preview
        </Badge>
      )}
      <div className="flex shrink-0 items-center">
        <IconButton
          label={`Move lesson up: ${lesson.title}`}
          disabled={index === 0}
          onClick={() => onMove(index - 1)}
        >
          <ArrowUp />
        </IconButton>
        <IconButton
          label={`Move lesson down: ${lesson.title}`}
          disabled={index === total - 1}
          onClick={() => onMove(index + 1)}
        >
          <ArrowDown />
        </IconButton>
        <ConfirmDelete
          label={`Delete lesson: ${lesson.title}`}
          title="Delete this lesson?"
          description={`“${lesson.title}” and its content will be deleted permanently.`}
          onConfirm={() => start(async () => report(await deleteLesson(lesson.id)))}
          disabled={pending}
        />
      </div>
    </li>
  );
}

function IconButton({
  label,
  onClick,
  disabled,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon-lg"
      className="size-10"
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
    >
      <span aria-hidden="true" className="[&_svg]:size-4">
        {children}
      </span>
    </Button>
  );
}

function ConfirmDelete({
  label,
  title,
  description,
  onConfirm,
  disabled,
}: {
  label: string;
  title: string;
  description: string;
  onConfirm: () => void;
  disabled?: boolean;
}) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="icon-lg"
          className="text-destructive size-10"
          aria-label={label}
          disabled={disabled}
        >
          <Trash2 className="size-4" aria-hidden="true" />
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm}>Delete</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function EditSectionDialog({
  section,
  report,
}: {
  section: Section;
  report: (r: ActionResult<unknown> | undefined) => void;
}) {
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const id = useId();
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="icon-lg"
          className="size-10"
          aria-label={`Edit section: ${section.title}`}
        >
          <Pencil className="size-4" aria-hidden="true" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit section</DialogTitle>
        </DialogHeader>
        <form
          className="grid gap-4"
          action={(fd) =>
            start(async () => {
              const r = await updateSection(section.id, {
                title: fd.get("title"),
                description: fd.get("description") ?? "",
              });
              if (r.ok) setOpen(false);
              else setError(r.fieldErrors?.title?.[0] ?? r.error);
              report(r);
            })
          }
        >
          {error && <FormAlert kind="error">{error}</FormAlert>}
          <div className="grid gap-2">
            <Label htmlFor={`${id}-t`}>Title</Label>
            <Input
              id={`${id}-t`}
              name="title"
              defaultValue={section.title}
              required
              maxLength={200}
              className="h-11"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor={`${id}-d`}>Description (optional)</Label>
            <textarea
              id={`${id}-d`}
              name="description"
              defaultValue={section.description ?? ""}
              maxLength={1000}
              rows={3}
              className="border-input bg-background rounded-lg border p-3 text-sm"
            />
          </div>
          <Button type="submit" size="lg" className="h-11" disabled={pending}>
            Save section
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function AddLessonForm({
  sectionId,
  sectionTitle,
  report,
}: {
  sectionId: string;
  sectionTitle: string;
  report: (r: ActionResult<unknown> | undefined) => void;
}) {
  const [pending, start] = useTransition();
  const [title, setTitle] = useState("");
  const [error, setError] = useState<string | null>(null);
  const id = useId();
  return (
    <form
      className="bg-surface/50 grid gap-2 border-t px-3 py-3 sm:grid-cols-[1fr_10rem_auto] sm:items-end sm:px-4"
      action={(fd) =>
        start(async () => {
          const r = await addLesson(sectionId, { title: fd.get("title"), type: fd.get("type") });
          if (r.ok) {
            setTitle("");
            setError(null);
          } else setError(r.fieldErrors?.title?.[0] ?? r.error);
          report(r);
        })
      }
    >
      <div className="grid gap-1.5">
        <Label htmlFor={`${id}-t`} className="text-xs">
          New lesson in “{sectionTitle}”
        </Label>
        <Input
          id={`${id}-t`}
          name="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Lesson title"
          maxLength={200}
          className="h-10"
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? `${id}-e` : undefined}
        />
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor={`${id}-type`} className="text-xs">
          Type
        </Label>
        <select
          id={`${id}-type`}
          name="type"
          className="border-input bg-background h-10 rounded-lg border px-2 text-sm"
        >
          {Object.entries(LESSON_TYPES).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
      </div>
      <Button
        type="submit"
        variant="outline"
        size="lg"
        className="h-10 px-3"
        disabled={pending || !title.trim()}
      >
        <Plus aria-hidden="true" /> Add lesson
      </Button>
      {error && (
        <p id={`${id}-e`} className="text-destructive text-sm font-medium sm:col-span-3">
          {error}
        </p>
      )}
    </form>
  );
}

function AddSectionForm({
  courseId,
  report,
}: {
  courseId: string;
  report: (r: ActionResult<unknown> | undefined) => void;
}) {
  const [pending, start] = useTransition();
  const [title, setTitle] = useState("");
  const id = useId();
  return (
    <form
      className="flex flex-col gap-2 rounded-xl border border-dashed p-4 sm:flex-row sm:items-end"
      action={(fd) =>
        start(async () => {
          const r = await addSection(courseId, { title: fd.get("title"), description: "" });
          if (r.ok) setTitle("");
          report(r);
        })
      }
    >
      <div className="grid flex-1 gap-1.5">
        <Label htmlFor={id}>New section</Label>
        <Input
          id={id}
          name="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g. Power Query transformations"
          maxLength={200}
          className="h-11"
        />
      </div>
      <Button type="submit" size="lg" className="h-11 px-4" disabled={pending || !title.trim()}>
        <Plus aria-hidden="true" /> Add section
      </Button>
    </form>
  );
}
