"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { type ActionResult, GENERIC_ERROR, invalid } from "@/lib/action-result";
import { audit } from "@/lib/audit";
import { requireRole } from "@/lib/auth";
import { slugify, toMinor } from "@/lib/courses/format";
import { createClient } from "@/lib/supabase/server";
import {
  STATUS,
  courseDetailsSchema,
  createCourseSchema,
  faqSchema,
  lessonSchema,
  newLessonSchema,
  quizSchema,
  reorderSchema,
  sectionSchema,
} from "@/lib/validation/courses";

const uuid = z.string().uuid();
const NOT_ALLOWED: ActionResult = {
  ok: false,
  error: "You don't have permission to change this course.",
};

async function staff() {
  const current = await requireRole(["instructor", "admin"], "/studio/courses");
  return { ...current, supabase: await createClient() };
}

async function courseSlug(supabase: Awaited<ReturnType<typeof createClient>>, courseId: string) {
  const { data } = await supabase.from("courses").select("slug").eq("id", courseId).maybeSingle();
  return data?.slug ?? null;
}

function revalidateCourse(courseId: string, slug?: string | null) {
  revalidatePath(`/studio/courses/${courseId}`, "layout");
  revalidatePath("/studio/courses");
  revalidatePath("/courses");
  revalidatePath("/");
  if (slug) revalidatePath(`/courses/${slug}`, "layout");
}

// --------------------------------------------------------------------------- courses

export async function createCourse(input: unknown): Promise<ActionResult> {
  const { supabase, profile } = await staff();
  const parsed = createCourseSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  let instructorId = parsed.data.instructorId ?? null;
  if (profile.role !== "admin") {
    const { data } = await supabase.rpc("my_instructor_id");
    if (!data)
      return {
        ok: false,
        error: "Your account isn't linked to an instructor profile yet. Ask an admin.",
      };
    instructorId = data;
  }

  const base = slugify(parsed.data.title) || "course";
  let slug = base;
  for (let i = 2; i < 50; i++) {
    const { data } = await supabase.from("courses").select("id").eq("slug", slug).maybeSingle();
    if (!data) break;
    slug = `${base}-${i}`;
  }

  const { data, error } = await supabase
    .from("courses")
    .insert({
      title: parsed.data.title,
      slug,
      track: parsed.data.track,
      instructor_id: instructorId,
      created_by: profile.id,
    })
    .select("id")
    .single();
  if (error) {
    console.error("[studio] createCourse", error.message);
    return error.code === "42501" ? NOT_ALLOWED : { ok: false, error: GENERIC_ERROR };
  }
  await audit(
    supabase,
    "course.created",
    { type: "course", id: data.id },
    { title: parsed.data.title },
  );
  redirect(`/studio/courses/${data.id}`);
}

export async function updateCourseDetails(courseId: string, input: unknown): Promise<ActionResult> {
  const { supabase, profile } = await staff();
  if (!uuid.safeParse(courseId).success) return NOT_ALLOWED;
  const parsed = courseDetailsSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;

  const oldSlug = await courseSlug(supabase, courseId);
  const update = {
    title: v.title,
    slug: v.slug,
    subtitle: v.subtitle,
    description_md: v.descriptionMd,
    outcomes: v.outcomes,
    requirements: v.requirements,
    track: v.track,
    level_min: v.levelMin,
    level_max: v.levelMax,
    format: v.format,
    duration_weeks: v.durationWeeks,
    price_minor: toMinor(v.price),
    currency: v.currency,
    ...(profile.role === "admin" ? { instructor_id: v.instructorId } : {}),
  };
  const { data, error } = await supabase
    .from("courses")
    .update(update)
    .eq("id", courseId)
    .select("id");
  if (error) {
    if (error.code === "23505")
      return {
        ok: false,
        error: "That URL slug is already used.",
        fieldErrors: { slug: ["Already used by another course"] },
      };
    console.error("[studio] updateCourse", error.message);
    return error.code === "42501" ? NOT_ALLOWED : { ok: false, error: GENERIC_ERROR };
  }
  if (!data.length) return NOT_ALLOWED;
  await audit(supabase, "course.updated", { type: "course", id: courseId });
  revalidateCourse(courseId, oldSlug);
  revalidateCourse(courseId, v.slug);
  return { ok: true, message: "Course saved." };
}

export async function setCourseStatus(courseId: string, status: unknown): Promise<ActionResult> {
  const { supabase } = await staff();
  const s = STATUS.safeParse(status);
  if (!s.success || !uuid.safeParse(courseId).success) return NOT_ALLOWED;

  if (s.data === "published") {
    const { count } = await supabase
      .from("lessons")
      .select("id", { count: "exact", head: true })
      .eq("course_id", courseId);
    if (!count) return { ok: false, error: "Add at least one lesson before publishing." };
  }
  const { data, error } = await supabase
    .from("courses")
    .update({ status: s.data })
    .eq("id", courseId)
    .select("slug");
  if (error || !data?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;
  await audit(supabase, `course.${s.data}`, { type: "course", id: courseId });
  revalidateCourse(courseId, data[0].slug);
  const label = { draft: "moved to draft", published: "published", archived: "archived" }[s.data];
  return { ok: true, message: `Course ${label}.` };
}

export async function deleteCourse(courseId: string): Promise<ActionResult> {
  const { supabase, profile } = await staff();
  if (profile.role !== "admin")
    return { ok: false, error: "Only admins can delete courses. Archive it instead." };
  const { count } = await supabase
    .from("enrolments")
    .select("id", { count: "exact", head: true })
    .eq("course_id", courseId);
  if (count)
    return { ok: false, error: "This course has enrolments. Archive it instead of deleting." };
  const { error } = await supabase.from("courses").delete().eq("id", courseId);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, "course.deleted", { type: "course", id: courseId });
  revalidatePath("/studio/courses");
  redirect("/studio/courses?deleted=1");
}

export async function uploadCourseThumbnail(
  courseId: string,
  formData: FormData,
): Promise<ActionResult> {
  const { supabase } = await staff();
  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) return { ok: false, error: "Choose an image." };
  const ext = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" }[file.type];
  if (!ext) return { ok: false, error: "Use a PNG, JPEG or WebP image." };
  if (file.size > 5 * 1024 * 1024) return { ok: false, error: "Images must be 5 MB or smaller." };

  const path = `courses/${courseId}/thumb-${Date.now()}.${ext}`;
  const { error: upErr } = await supabase.storage
    .from("course-media")
    .upload(path, file, { contentType: file.type });
  if (upErr) return { ok: false, error: GENERIC_ERROR };
  const url = supabase.storage.from("course-media").getPublicUrl(path).data.publicUrl;
  const { data } = await supabase
    .from("courses")
    .update({ thumbnail_url: url })
    .eq("id", courseId)
    .select("slug");
  if (!data?.length) return NOT_ALLOWED;
  await audit(supabase, "course.thumbnail_updated", { type: "course", id: courseId });
  revalidateCourse(courseId, data[0].slug);
  return { ok: true, message: "Thumbnail updated." };
}

// --------------------------------------------------------------------------- sections

export async function addSection(
  courseId: string,
  input: unknown,
): Promise<ActionResult<{ id: string }>> {
  const { supabase } = await staff();
  const parsed = sectionSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { count } = await supabase
    .from("sections")
    .select("id", { count: "exact", head: true })
    .eq("course_id", courseId);
  const { data, error } = await supabase
    .from("sections")
    .insert({
      course_id: courseId,
      title: parsed.data.title,
      description: parsed.data.description,
      position: (count ?? 0) + 1,
    })
    .select("id")
    .single();
  if (error) return error.code === "42501" ? NOT_ALLOWED : { ok: false, error: GENERIC_ERROR };
  revalidateCourse(courseId, await courseSlug(supabase, courseId));
  return { ok: true, message: "Section added.", data: { id: data.id } };
}

export async function updateSection(sectionId: string, input: unknown): Promise<ActionResult> {
  const { supabase } = await staff();
  const parsed = sectionSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { data, error } = await supabase
    .from("sections")
    .update(parsed.data)
    .eq("id", sectionId)
    .select("course_id");
  if (error || !data?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;
  revalidateCourse(data[0].course_id, await courseSlug(supabase, data[0].course_id));
  return { ok: true, message: "Section saved." };
}

export async function deleteSection(sectionId: string): Promise<ActionResult> {
  const { supabase } = await staff();
  const { data, error } = await supabase
    .from("sections")
    .delete()
    .eq("id", sectionId)
    .select("course_id");
  if (error || !data?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;
  await audit(
    supabase,
    "section.deleted",
    { type: "section", id: sectionId },
    { course_id: data[0].course_id },
  );
  revalidateCourse(data[0].course_id, await courseSlug(supabase, data[0].course_id));
  return { ok: true, message: "Section deleted." };
}

export async function reorderSections(input: unknown): Promise<ActionResult> {
  const { supabase } = await staff();
  const parsed = reorderSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { error } = await supabase.rpc("reorder_sections", {
    p_course_id: parsed.data.parentId,
    p_ids: parsed.data.ids,
  });
  if (error) return { ok: false, error: GENERIC_ERROR };
  revalidateCourse(parsed.data.parentId, await courseSlug(supabase, parsed.data.parentId));
  return { ok: true };
}

// --------------------------------------------------------------------------- lessons

export async function addLesson(
  sectionId: string,
  input: unknown,
): Promise<ActionResult<{ id: string }>> {
  const { supabase } = await staff();
  const parsed = newLessonSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { data: section } = await supabase
    .from("sections")
    .select("course_id")
    .eq("id", sectionId)
    .maybeSingle();
  if (!section) return NOT_ALLOWED;
  const { count } = await supabase
    .from("lessons")
    .select("id", { count: "exact", head: true })
    .eq("section_id", sectionId);

  const { data, error } = await supabase
    .from("lessons")
    .insert({
      section_id: sectionId,
      course_id: section.course_id,
      title: parsed.data.title,
      type: parsed.data.type,
      position: (count ?? 0) + 1,
    })
    .select("id")
    .single();
  if (error) return error.code === "42501" ? NOT_ALLOWED : { ok: false, error: GENERIC_ERROR };
  await supabase
    .from("lesson_contents")
    .insert({ lesson_id: data.id, course_id: section.course_id });
  if (parsed.data.type === "quiz")
    await supabase.from("quizzes").insert({ lesson_id: data.id, course_id: section.course_id });
  revalidateCourse(section.course_id, await courseSlug(supabase, section.course_id));
  return { ok: true, message: "Lesson added.", data: { id: data.id } };
}

export async function updateLesson(lessonId: string, input: unknown): Promise<ActionResult> {
  const { supabase } = await staff();
  const parsed = lessonSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;

  const { data: current } = await supabase
    .from("lessons")
    .select("section_id, course_id")
    .eq("id", lessonId)
    .maybeSingle();
  if (!current) return NOT_ALLOWED;
  // Moving to another section: append at the end, and only within the same course.
  let position: number | undefined;
  if (v.sectionId !== current.section_id) {
    const { data: target } = await supabase
      .from("sections")
      .select("course_id")
      .eq("id", v.sectionId)
      .maybeSingle();
    if (target?.course_id !== current.course_id)
      return { ok: false, error: "Choose a section in this course." };
    const { count } = await supabase
      .from("lessons")
      .select("id", { count: "exact", head: true })
      .eq("section_id", v.sectionId);
    position = (count ?? 0) + 1;
  }

  const { data, error } = await supabase
    .from("lessons")
    .update({
      title: v.title,
      summary: v.summary,
      type: v.type,
      section_id: v.sectionId,
      duration_minutes: v.durationMinutes,
      is_free_preview: v.isFreePreview,
      ...(position ? { position } : {}),
    })
    .eq("id", lessonId)
    .select("course_id");
  if (error || !data?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;

  const { error: cErr } = await supabase.from("lesson_contents").upsert({
    lesson_id: lessonId,
    course_id: current.course_id,
    body_md: v.bodyMd,
    video_url: v.videoUrl,
  });
  if (cErr) {
    console.error("[studio] lesson content", cErr.message);
    return { ok: false, error: GENERIC_ERROR };
  }
  if (v.type === "quiz") {
    await supabase
      .from("quizzes")
      .upsert(
        { lesson_id: lessonId, course_id: current.course_id },
        { onConflict: "lesson_id", ignoreDuplicates: true },
      );
  }
  revalidateCourse(current.course_id, await courseSlug(supabase, current.course_id));
  return { ok: true, message: "Lesson saved." };
}

export async function deleteLesson(lessonId: string): Promise<ActionResult> {
  const { supabase } = await staff();
  const { data, error } = await supabase
    .from("lessons")
    .delete()
    .eq("id", lessonId)
    .select("course_id");
  if (error || !data?.length) return error ? { ok: false, error: GENERIC_ERROR } : NOT_ALLOWED;
  await audit(
    supabase,
    "lesson.deleted",
    { type: "lesson", id: lessonId },
    { course_id: data[0].course_id },
  );
  revalidateCourse(data[0].course_id, await courseSlug(supabase, data[0].course_id));
  return { ok: true, message: "Lesson deleted." };
}

export async function reorderLessons(input: unknown): Promise<ActionResult> {
  const { supabase } = await staff();
  const parsed = reorderSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { error } = await supabase.rpc("reorder_lessons", {
    p_section_id: parsed.data.parentId,
    p_ids: parsed.data.ids,
  });
  if (error) return { ok: false, error: GENERIC_ERROR };
  const { data } = await supabase
    .from("sections")
    .select("course_id")
    .eq("id", parsed.data.parentId)
    .maybeSingle();
  if (data) revalidateCourse(data.course_id, await courseSlug(supabase, data.course_id));
  return { ok: true };
}

export async function uploadLessonFile(
  lessonId: string,
  formData: FormData,
): Promise<ActionResult> {
  const { supabase } = await staff();
  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) return { ok: false, error: "Choose a file." };
  if (file.size > 50 * 1024 * 1024) return { ok: false, error: "Files must be 50 MB or smaller." };
  const { data: lesson } = await supabase
    .from("lessons")
    .select("course_id")
    .eq("id", lessonId)
    .maybeSingle();
  if (!lesson) return NOT_ALLOWED;

  const safeName = file.name.replace(/[^A-Za-z0-9._-]+/g, "-").slice(-120) || "file";
  const path = `${lesson.course_id}/${lessonId}/${Date.now()}-${safeName}`;
  const { error } = await supabase.storage
    .from("lesson-files")
    .upload(path, file, { contentType: file.type || "application/octet-stream" });
  if (error)
    return error.message.includes("row-level") ? NOT_ALLOWED : { ok: false, error: GENERIC_ERROR };
  await supabase
    .from("lesson_contents")
    .upsert({ lesson_id: lessonId, course_id: lesson.course_id, file_path: path });
  revalidatePath(`/studio/courses/${lesson.course_id}`, "layout");
  return { ok: true, message: `Uploaded ${safeName}.` };
}

// --------------------------------------------------------------------------- quizzes

export async function saveQuiz(lessonId: string, input: unknown): Promise<ActionResult> {
  const { supabase } = await staff();
  const parsed = quizSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const { data: lesson } = await supabase
    .from("lessons")
    .select("course_id")
    .eq("id", lessonId)
    .maybeSingle();
  if (!lesson) return NOT_ALLOWED;
  const { data: quiz, error } = await supabase
    .from("quizzes")
    .upsert(
      { lesson_id: lessonId, course_id: lesson.course_id, pass_mark: parsed.data.passMark },
      { onConflict: "lesson_id" },
    )
    .select("id")
    .single();
  if (error) return error.code === "42501" ? NOT_ALLOWED : { ok: false, error: GENERIC_ERROR };

  // Replace the question set (quizzes are small; simpler and atomic enough for authoring).
  await supabase.from("quiz_questions").delete().eq("quiz_id", quiz.id);
  if (parsed.data.questions.length) {
    const { error: qErr } = await supabase.from("quiz_questions").insert(
      parsed.data.questions.map((q, i) => ({
        quiz_id: quiz.id,
        prompt: q.prompt,
        options: q.options,
        correct_index: q.correctIndex,
        explanation: q.explanation,
        position: i + 1,
      })),
    );
    if (qErr) {
      console.error("[studio] quiz questions", qErr.message);
      return { ok: false, error: GENERIC_ERROR };
    }
  }
  await audit(
    supabase,
    "quiz.saved",
    { type: "lesson", id: lessonId },
    { questions: parsed.data.questions.length },
  );
  revalidatePath(`/studio/courses/${lesson.course_id}`, "layout");
  return { ok: true, message: `Quiz saved (${parsed.data.questions.length} questions).` };
}

// --------------------------------------------------------------------------- course FAQs

export async function saveCourseFaq(
  courseId: string,
  faqId: string | null,
  input: unknown,
): Promise<ActionResult> {
  const { supabase } = await staff();
  const parsed = faqSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const row = {
    question: parsed.data.question,
    answer_md: parsed.data.answerMd,
    is_published: parsed.data.isPublished,
  };

  let res;
  if (faqId) {
    res = await supabase
      .from("faqs")
      .update(row)
      .eq("id", faqId)
      .eq("course_id", courseId)
      .select("id");
  } else {
    const { count } = await supabase
      .from("faqs")
      .select("id", { count: "exact", head: true })
      .eq("course_id", courseId);
    res = await supabase
      .from("faqs")
      .insert({ ...row, course_id: courseId, position: (count ?? 0) + 1 })
      .select("id");
  }
  if (res.error || !res.data?.length)
    return res.error?.code === "42501" || !res.data?.length
      ? NOT_ALLOWED
      : { ok: false, error: GENERIC_ERROR };
  revalidateCourse(courseId, await courseSlug(supabase, courseId));
  return { ok: true, message: "FAQ saved." };
}

export async function deleteCourseFaq(courseId: string, faqId: string): Promise<ActionResult> {
  const { supabase } = await staff();
  const { data } = await supabase
    .from("faqs")
    .delete()
    .eq("id", faqId)
    .eq("course_id", courseId)
    .select("id");
  if (!data?.length) return NOT_ALLOWED;
  revalidateCourse(courseId, await courseSlug(supabase, courseId));
  return { ok: true, message: "FAQ deleted." };
}
