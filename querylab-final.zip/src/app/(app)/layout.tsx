import { Logo } from "@/components/site/logo";
import { NavLink } from "@/components/site/nav-link";
import { ThemeToggle } from "@/components/site/theme-toggle";
import { UserMenu } from "@/components/site/user-menu";
import { requireUser } from "@/lib/auth";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, profile } = await requireUser();
  const links = [
    { href: "/dashboard", label: "Dashboard" },
    { href: "/my-courses", label: "My courses" },
    { href: "/courses", label: "Catalogue" },
    ...(profile.role === "instructor" || profile.role === "admin"
      ? [{ href: "/studio/courses", label: "Studio" }]
      : []),
    ...(profile.role === "admin" ? [{ href: "/admin", label: "Admin" }] : []),
  ];

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="bg-background/90 sticky top-0 z-50 border-b backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
          <Logo />
          <nav aria-label="App" className="-mx-1 overflow-x-auto">
            <ul className="flex items-center gap-0.5">
              {links.map((l) => (
                <li key={l.href}>
                  <NavLink href={l.href} className="whitespace-nowrap">
                    {l.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
          <div className="ml-auto flex items-center gap-1">
            <ThemeToggle />
            <UserMenu
              name={profile.full_name}
              email={user.email ?? profile.email}
              avatarUrl={profile.avatar_url}
            />
          </div>
        </div>
      </header>
      <main id="main" tabIndex={-1} className="flex-1 focus:outline-none">
        {children}
      </main>
    </div>
  );
}
