import type { Metadata } from "next";
import Link from "next/link";
import { MyCourseCard } from "@/components/learning/my-course-card";
import { PageHeader } from "@/components/site/page-header";
import { Button } from "@/components/ui/button";
import { requireUser } from "@/lib/auth";
import { myCourses } from "@/lib/learning/queries";

export const metadata: Metadata = { title: "My courses", robots: { index: false } };

export default async function MyCoursesPage() {
  const { user } = await requireUser("/my-courses");
  const courses = await myCourses(user.id);
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <PageHeader title="My courses" />
      {courses.length ? (
        <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((c) => (
            <li key={c.id}>
              <MyCourseCard c={c} />
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-8 rounded-xl border border-dashed p-12 text-center">
          <h2 className="text-lg font-semibold">You haven&apos;t enrolled in a course yet</h2>
          <Button asChild size="lg" className="mt-4 h-11 px-5">
            <Link href="/courses">Browse courses</Link>
          </Button>
        </div>
      )}
    </div>
  );
}
