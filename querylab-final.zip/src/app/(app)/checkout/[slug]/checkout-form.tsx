"use client";

import { useId, useState, useTransition } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { type Currency, formatPrice } from "@/lib/courses/format";
import { type Quote, placeOrder, quote } from "../actions";

export function CheckoutForm({
  course,
  providers,
  bankConfigured,
}: {
  course: { id: string; title: string; price: number; currency: Currency };
  providers: { id: string; label: string; description: string }[];
  bankConfigured: boolean;
}) {
  const [code, setCode] = useState("");
  const [q, setQ] = useState<Quote>({
    currency: course.currency,
    subtotal: course.price,
    discount: 0,
    total: course.price,
    coupon: null,
  });
  const [couponMsg, setCouponMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [provider, setProvider] = useState(providers[0]?.id ?? "");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const [checking, startCheck] = useTransition();
  const couponId = useId();
  const money = (m: number) =>
    m === 0 ? formatPrice(0, q.currency).replace("Free", "0") : formatPrice(m, q.currency);

  return (
    <div className="mt-8 grid gap-8">
      <section aria-labelledby="summary-h" className="bg-card rounded-xl border p-5">
        <h2 id="summary-h" className="font-semibold">
          Order summary
        </h2>
        <dl className="mt-4 grid gap-2 text-sm">
          <div className="flex justify-between gap-4">
            <dt>{course.title}</dt>
            <dd className="tabular font-mono">{money(q.subtotal)}</dd>
          </div>
          {q.discount > 0 && (
            <div className="text-muted-foreground flex justify-between gap-4">
              <dt>Discount ({q.coupon})</dt>
              <dd className="tabular font-mono">−{money(q.discount)}</dd>
            </div>
          )}
          <div className="flex justify-between gap-4 border-t pt-2 text-base font-semibold">
            <dt>Total</dt>
            <dd className="tabular font-mono" aria-live="polite">
              {money(q.total)}
            </dd>
          </div>
        </dl>
      </section>

      <section aria-labelledby="coupon-h" className="grid gap-2">
        <h2 id="coupon-h" className="sr-only">
          Coupon
        </h2>
        <Label htmlFor={couponId}>Coupon code (optional)</Label>
        <div className="flex gap-2">
          <Input
            id={couponId}
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            maxLength={32}
            className="h-11 max-w-xs font-mono uppercase"
            aria-describedby={couponMsg ? `${couponId}-msg` : undefined}
          />
          <Button
            type="button"
            variant="outline"
            size="lg"
            className="h-11 px-4"
            disabled={!code.trim() || checking}
            onClick={() =>
              startCheck(async () => {
                const r = await quote(course.id, code);
                if (r.ok && r.data) {
                  setQ(r.data);
                  setCouponMsg({ ok: true, text: r.message ?? "Coupon applied." });
                } else {
                  setQ({
                    currency: course.currency,
                    subtotal: course.price,
                    discount: 0,
                    total: course.price,
                    coupon: null,
                  });
                  setCouponMsg({ ok: false, text: r.ok ? "" : r.error });
                }
              })
            }
          >
            Apply
          </Button>
        </div>
        {couponMsg && (
          <p
            id={`${couponId}-msg`}
            role={couponMsg.ok ? "status" : "alert"}
            className={
              couponMsg.ok ? "text-primary text-sm" : "text-destructive text-sm font-medium"
            }
          >
            {couponMsg.text}
          </p>
        )}
      </section>

      {q.total > 0 && (
        <fieldset className="grid gap-3">
          <legend className="mb-2 font-semibold">Payment method</legend>
          {providers.map((p) => (
            <label
              key={p.id}
              className="bg-card has-[:checked]:border-primary flex items-start gap-3 rounded-xl border p-4"
            >
              <input
                type="radio"
                name="provider"
                value={p.id}
                checked={provider === p.id}
                onChange={() => setProvider(p.id)}
                className="accent-primary mt-1 size-5"
              />
              <span>
                <span className="block font-medium">{p.label}</span>
                <span className="text-muted-foreground block text-sm">{p.description}</span>
              </span>
            </label>
          ))}
          {provider === "bank_transfer" && !bankConfigured && (
            <p className="text-muted-foreground text-sm">
              Our bank details will be emailed to you with your order reference.
            </p>
          )}
        </fieldset>
      )}

      <div className="grid gap-3">
        <Button
          size="lg"
          className="h-12 text-base"
          disabled={pending}
          onClick={() =>
            start(async () => {
              setError(null);
              const r = await placeOrder({ courseId: course.id, provider, coupon: q.coupon ?? "" });
              if (r && !r.ok) setError(r.error);
            })
          }
        >
          {pending
            ? "Placing order…"
            : q.total === 0
              ? "Enrol now"
              : `Place order · ${money(q.total)}`}
        </Button>
        <p className="text-muted-foreground text-sm">
          {q.total === 0
            ? "No payment needed."
            : "You'll get a reference and a pro-forma invoice. Access starts once your payment is recorded."}
        </p>
        <div aria-live="assertive">{error && <FormAlert kind="error">{error}</FormAlert>}</div>
      </div>
    </div>
  );
}
