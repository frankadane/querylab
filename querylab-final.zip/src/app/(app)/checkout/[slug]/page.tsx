import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { FormAlert } from "@/components/forms/form-alert";
import { requireUser } from "@/lib/auth";
import { getPublishedCourse } from "@/lib/courses/queries";
import { getBillingSettings } from "@/lib/payments/bank";
import { checkoutProviders } from "@/lib/payments/registry";
import { createClient } from "@/lib/supabase/server";
import { CheckoutForm } from "./checkout-form";

export const metadata: Metadata = { title: "Checkout", robots: { index: false } };

export default async function CheckoutPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { user } = await requireUser(`/checkout/${slug}`);
  const course = await getPublishedCourse(slug);
  if (!course) notFound();

  const supabase = await createClient();
  const { data: enrolment } = await supabase
    .from("enrolments")
    .select("status")
    .eq("course_id", course.id)
    .eq("user_id", user.id)
    .maybeSingle();
  if (enrolment?.status === "active") redirect(`/learn/${slug}`);
  const { data: pending } = await supabase
    .from("orders")
    .select("reference")
    .eq("course_id", course.id)
    .eq("status", "pending")
    .maybeSingle();
  const { bankConfigured } = await getBillingSettings();

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <h1 className="text-3xl font-semibold">Checkout</h1>
      {pending && (
        <FormAlert kind="error" className="mt-6">
          You already have an unpaid order for this course ({pending.reference}).{" "}
          <Link href={`/orders/${pending.reference}`} className="font-medium underline">
            View payment instructions
          </Link>
          . Placing a new order replaces it.
        </FormAlert>
      )}
      <CheckoutForm
        course={{
          id: course.id,
          title: course.title,
          price: course.price_minor,
          currency: course.currency,
        }}
        providers={checkoutProviders().map((p) => ({
          id: p.id,
          label: p.label,
          description: p.description,
        }))}
        bankConfigured={bankConfigured}
      />
    </div>
  );
}
