"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { type ActionResult, GENERIC_ERROR, RATE_LIMITED } from "@/lib/action-result";
import { requireUser } from "@/lib/auth";
import { formatPrice } from "@/lib/courses/format";
import { sendEmail } from "@/lib/email";
import { publicEnv } from "@/lib/env";
import { checkoutProviders, getProvider } from "@/lib/payments/registry";
import type { Order } from "@/lib/payments/types";
import { rateLimit } from "@/lib/rate-limit";
import { createClient } from "@/lib/supabase/server";

const checkoutSchema = z.object({
  courseId: z.string().uuid(),
  provider: z.string().regex(/^[a-z_]{2,30}$/),
  coupon: z.string().trim().max(32).optional().default(""),
});

export type Quote = {
  currency: "GHS" | "USD";
  subtotal: number;
  discount: number;
  total: number;
  coupon: string | null;
};

export async function quote(courseId: string, coupon: string): Promise<ActionResult<Quote>> {
  const { user } = await requireUser();
  if (!z.string().uuid().safeParse(courseId).success)
    return { ok: false, error: "Course not found." };
  if (coupon && !(await rateLimit("sensitive", `coupon:${user.id}`)))
    return { ok: false, error: RATE_LIMITED };
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("quote_price", {
    p_course_id: courseId,
    p_coupon: coupon.trim() || undefined,
  });
  if (error) return { ok: false, error: error.code === "P0001" ? error.message : GENERIC_ERROR };
  const q = data[0];
  return {
    ok: true,
    data: {
      currency: q.currency,
      subtotal: q.subtotal_minor,
      discount: q.discount_minor,
      total: q.total_minor,
      coupon: q.coupon_code,
    },
    message: q.coupon_code
      ? `Coupon ${q.coupon_code} applied: ${formatPrice(q.discount_minor, q.currency)} off.`
      : undefined,
  };
}

export async function placeOrder(input: unknown): Promise<ActionResult> {
  const { user } = await requireUser();
  const parsed = checkoutSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "Choose a payment method." };
  const provider = getProvider(parsed.data.provider);
  if (!provider || !checkoutProviders().includes(provider))
    return { ok: false, error: "Choose a payment method." };
  if (!(await rateLimit("sensitive", `order:${user.id}`)))
    return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  const { data, error } = await supabase.rpc("create_order", {
    p_course_id: parsed.data.courseId,
    p_provider: provider.id,
    p_coupon: parsed.data.coupon || undefined,
  });
  if (error) {
    if (error.code === "P0001")
      return {
        ok: false,
        error: error.message,
        fieldErrors: error.message.includes("coupon") ? { coupon: [error.message] } : undefined,
      };
    console.error("[checkout] create_order", error.message);
    return { ok: false, error: GENERIC_ERROR };
  }
  const order = data as unknown as Order;
  const { data: course } = await supabase
    .from("courses")
    .select("slug")
    .eq("id", order.course_id)
    .single();
  revalidatePath("/dashboard");
  revalidatePath("/orders");

  if (order.status === "paid") {
    await sendEmail({
      to: order.billing_email,
      subject: `You're enrolled: ${order.course_title}`,
      text: `You're enrolled in ${order.course_title}${order.coupon_code ? ` (coupon ${order.coupon_code})` : ""}.\n\nStart learning: ${publicEnv.NEXT_PUBLIC_SITE_URL}/learn/${course?.slug}\n\nQueryLab`,
    });
    redirect(`/learn/${course?.slug}`);
  }

  const outcome = await provider.begin(order);
  if (outcome.type === "redirect") redirect(outcome.url);
  redirect(`/orders/${order.reference}?placed=1`);
}

export async function cancelMyOrder(orderId: string): Promise<ActionResult> {
  await requireUser();
  const supabase = await createClient();
  const { error } = await supabase.rpc("cancel_order", { p_order_id: orderId });
  if (error) return { ok: false, error: error.code === "P0001" ? error.message : GENERIC_ERROR };
  revalidatePath("/orders", "layout");
  return { ok: true, message: "Order cancelled." };
}
