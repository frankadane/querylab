import { ArrowLeft, FileText } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { FormAlert } from "@/components/forms/form-alert";
import { OrderStatusBadge } from "@/components/orders/order-status-badge";
import { Button } from "@/components/ui/button";
import { requireUser } from "@/lib/auth";
import { formatPrice } from "@/lib/courses/format";
import { getBillingSettings } from "@/lib/payments/bank";
import { providerLabel } from "@/lib/payments/registry";
import { createClient } from "@/lib/supabase/server";
import { CancelOrderButton, CopyReference } from "./order-controls";

export const metadata: Metadata = { title: "Order", robots: { index: false } };

export default async function OrderPage({
  params,
  searchParams,
}: {
  params: Promise<{ reference: string }>;
  searchParams: Promise<{ placed?: string }>;
}) {
  const { reference } = await params;
  const { placed } = await searchParams;
  await requireUser(`/orders/${reference}`);
  if (!/^QL-[A-Z0-9]{8}$/.test(reference)) notFound();
  const supabase = await createClient();
  const { data: o } = await supabase
    .from("orders")
    .select("*, course:courses(slug)")
    .eq("reference", reference)
    .maybeSingle();
  if (!o) notFound();
  const { bank, bankConfigured } = await getBillingSettings();
  const money = (m: number) => formatPrice(m, o.currency);

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <Link
        href="/orders"
        className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5 text-sm font-medium"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> Order history
      </Link>
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <h1 className="text-3xl font-semibold">
          Order <span className="font-mono">{o.reference}</span>
        </h1>
        <OrderStatusBadge status={o.status} />
      </div>
      {placed && o.status === "pending" && (
        <FormAlert kind="success" className="mt-6">
          Order placed. We&apos;ve emailed you these payment instructions.
        </FormAlert>
      )}

      <dl className="bg-card mt-8 grid gap-2 rounded-xl border p-5 text-sm">
        <div className="flex justify-between gap-4">
          <dt>{o.course_title}</dt>
          <dd className="tabular font-mono">{money(o.subtotal_minor)}</dd>
        </div>
        {o.discount_minor > 0 && (
          <div className="text-muted-foreground flex justify-between gap-4">
            <dt>Discount ({o.coupon_code})</dt>
            <dd className="tabular font-mono">−{money(o.discount_minor)}</dd>
          </div>
        )}
        <div className="flex justify-between gap-4 border-t pt-2 text-base font-semibold">
          <dt>Total</dt>
          <dd className="tabular font-mono">{money(o.total_minor)}</dd>
        </div>
        <div className="text-muted-foreground flex justify-between gap-4">
          <dt>Payment method</dt>
          <dd>{providerLabel(o.provider)}</dd>
        </div>
        {o.invoice_number && (
          <div className="text-muted-foreground flex justify-between gap-4">
            <dt>Invoice</dt>
            <dd className="font-mono">{o.invoice_number}</dd>
          </div>
        )}
      </dl>

      {o.status === "pending" && o.provider === "bank_transfer" && (
        <section
          aria-labelledby="pay-h"
          className="border-primary/40 bg-card mt-8 rounded-xl border-2 p-5"
        >
          <h2 id="pay-h" className="text-lg font-semibold">
            How to pay
          </h2>
          <ol className="mt-3 list-decimal space-y-2 pl-5">
            <li>
              Transfer <strong className="font-mono">{money(o.total_minor)}</strong> to the account
              below.
            </li>
            <li>
              Use your order reference <CopyReference reference={o.reference} /> as the payment
              reference.
            </li>
            <li>
              We&apos;ll email you as soon as the payment is recorded and your course unlocks.
            </li>
          </ol>
          {bankConfigured ? (
            <dl className="mt-4 grid gap-1 text-sm sm:grid-cols-[10rem_1fr]">
              {(
                [
                  ["Account name", bank.account_name],
                  ["Bank", bank.bank_name],
                  ["Account number", bank.account_number],
                  ["Branch", bank.branch],
                  ["SWIFT/BIC", bank.swift],
                  ["IBAN", bank.iban],
                ] as const
              )
                .filter(([, v]) => v)
                .map(([k, v]) => (
                  <div key={k} className="contents">
                    <dt className="text-muted-foreground">{k}</dt>
                    <dd className="font-mono font-medium">{v}</dd>
                  </div>
                ))}
            </dl>
          ) : (
            <p className="text-muted-foreground mt-4 text-sm">
              We&apos;ll email our bank details to you shortly.
            </p>
          )}
          {bank.instructions && <p className="mt-3 text-sm">{bank.instructions}</p>}
        </section>
      )}

      <div className="mt-8 flex flex-wrap gap-2">
        <Button asChild variant="outline" size="lg" className="h-10 px-4">
          <a href={`/orders/${o.reference}/invoice`} target="_blank" rel="noopener">
            <FileText aria-hidden="true" />{" "}
            {o.invoice_number ? "Download invoice" : "Download pro-forma invoice"}
          </a>
        </Button>
        {o.status === "paid" && o.course && (
          <Button asChild size="lg" className="h-10 px-4">
            <Link href={`/learn/${o.course.slug}`}>Go to course</Link>
          </Button>
        )}
        {o.status === "pending" && <CancelOrderButton orderId={o.id} />}
      </div>
    </div>
  );
}
