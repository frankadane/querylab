"use client";

import { Copy } from "lucide-react";
import { useState } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { useAction } from "@/components/forms/use-action";
import { Button } from "@/components/ui/button";
import { cancelMyOrder } from "../../checkout/actions";

export function CopyReference({ reference }: { reference: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <span className="inline-flex items-center gap-1.5">
      <strong className="font-mono">{reference}</strong>
      <button
        type="button"
        className="hover:bg-accent inline-flex size-8 items-center justify-center rounded-md"
        aria-label={copied ? "Reference copied" : "Copy reference"}
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(reference);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
          } catch {
            /* clipboard unavailable */
          }
        }}
      >
        <Copy className="size-4" aria-hidden="true" />
      </button>
      <span aria-live="polite" className="sr-only">
        {copied ? "Copied" : ""}
      </span>
    </span>
  );
}

export function CancelOrderButton({ orderId }: { orderId: string }) {
  const { pending, result, run } = useAction();
  return (
    <>
      <Button
        variant="ghost"
        size="lg"
        className="text-destructive h-10 px-4"
        disabled={pending}
        onClick={() => {
          if (confirm("Cancel this order?")) run(() => cancelMyOrder(orderId));
        }}
      >
        Cancel order
      </Button>
      <div aria-live="polite" className="w-full">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </>
  );
}
