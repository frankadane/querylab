import type { Metadata } from "next";
import Link from "next/link";
import { OrderStatusBadge } from "@/components/orders/order-status-badge";
import { PageHeader } from "@/components/site/page-header";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { requireUser } from "@/lib/auth";
import { formatPrice } from "@/lib/courses/format";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Order history", robots: { index: false } };

export default async function OrdersPage() {
  await requireUser("/orders");
  const supabase = await createClient();
  const { data: orders } = await supabase
    .from("orders")
    .select(
      "id, reference, course_title, total_minor, currency, status, created_at, invoice_number",
    )
    .order("created_at", { ascending: false });
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <PageHeader title="Order history" />
      {orders?.length ? (
        <div className="bg-card mt-6 overflow-x-auto rounded-xl border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order</TableHead>
                <TableHead>Course</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((o) => (
                <TableRow key={o.id}>
                  <TableCell>
                    <Link
                      href={`/orders/${o.reference}`}
                      className="text-primary font-mono font-medium underline-offset-4 hover:underline"
                    >
                      {o.reference}
                    </Link>
                  </TableCell>
                  <TableCell>{o.course_title}</TableCell>
                  <TableCell className="tabular text-right font-mono">
                    {formatPrice(o.total_minor, o.currency)}
                  </TableCell>
                  <TableCell>
                    <OrderStatusBadge status={o.status} />
                  </TableCell>
                  <TableCell className="text-muted-foreground whitespace-nowrap">
                    {new Date(o.created_at).toLocaleDateString("en-GB")}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <p className="text-muted-foreground mt-6 rounded-xl border border-dashed p-10 text-center">
          No orders yet.
        </p>
      )}
    </div>
  );
}
