"use client";

import { useId } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { Label } from "@/components/ui/label";
import { type ProfileValues, profileSchema } from "@/lib/validation/auth";
import { updateProfile } from "./actions";

export function ProfileForm({
  timezones,
  defaults,
}: {
  timezones: string[];
  defaults: ProfileValues;
}) {
  const { form, pending, result, onSubmit } = useActionForm(profileSchema, updateProfile, defaults);
  const { errors } = form.formState;
  const tzId = useId();
  return (
    <form onSubmit={onSubmit} noValidate className="grid max-w-xl gap-5">
      {result && (
        <FormAlert kind={result.ok ? "success" : "error"}>
          {result.ok ? result.message : result.error}
        </FormAlert>
      )}
      <FormField
        label="Full name"
        autoComplete="name"
        registration={form.register("fullName")}
        error={errors.fullName}
      />
      <FormField
        label="Bio"
        multiline
        hint="Optional. Shown to instructors in your course."
        registration={form.register("bio")}
        error={errors.bio}
      />
      <div className="grid gap-2">
        <Label htmlFor={tzId}>Timezone</Label>
        <select
          id={tzId}
          {...form.register("timezone")}
          aria-invalid={errors.timezone ? true : undefined}
          className="border-input bg-background h-11 rounded-lg border px-3 text-base sm:text-sm"
        >
          {timezones.map((tz) => (
            <option key={tz} value={tz}>
              {tz.replaceAll("_", " ")}
            </option>
          ))}
        </select>
        {errors.timezone && (
          <p className="text-destructive text-sm font-medium">{errors.timezone.message}</p>
        )}
      </div>
      <SubmitButton pending={pending} className="justify-self-start px-5">
        Save profile
      </SubmitButton>
    </form>
  );
}
