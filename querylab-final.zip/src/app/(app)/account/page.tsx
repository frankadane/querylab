import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { listTimezones } from "@/lib/timezones";
import { AvatarForm } from "./avatar-form";
import { ProfileForm } from "./profile-form";

export const metadata: Metadata = { title: "Profile", robots: { index: false } };

export default async function ProfilePage() {
  const { user, profile } = await requireUser("/account");
  return (
    <div className="grid gap-10">
      <section aria-labelledby="photo-heading" className="grid gap-4 md:grid-cols-[14rem_1fr]">
        <div>
          <h2 id="photo-heading" className="font-semibold">
            Photo
          </h2>
          <p className="text-muted-foreground mt-1 text-sm">PNG, JPEG or WebP, up to 2 MB.</p>
        </div>
        <AvatarForm
          name={profile.full_name}
          email={user.email ?? ""}
          avatarUrl={profile.avatar_url}
        />
      </section>
      <section
        aria-labelledby="details-heading"
        className="grid gap-4 border-t pt-10 md:grid-cols-[14rem_1fr]"
      >
        <div>
          <h2 id="details-heading" className="font-semibold">
            Details
          </h2>
          <p className="text-muted-foreground mt-1 text-sm">
            Your timezone controls how live session times are shown.
          </p>
        </div>
        <ProfileForm
          timezones={listTimezones()}
          defaults={{
            fullName: profile.full_name,
            bio: profile.bio ?? "",
            timezone: profile.timezone,
          }}
        />
      </section>
    </div>
  );
}
