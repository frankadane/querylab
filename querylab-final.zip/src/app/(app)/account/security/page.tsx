import { Download } from "lucide-react";
import type { Metadata } from "next";
import { FormAlert } from "@/components/forms/form-alert";
import { Button } from "@/components/ui/button";
import { requireUser } from "@/lib/auth";
import { ChangeEmailForm, ChangePasswordForm, DeleteAccountForm } from "./security-forms";

export const metadata: Metadata = { title: "Login & security", robots: { index: false } };

function Section({
  id,
  title,
  description,
  children,
  danger,
}: {
  id: string;
  title: string;
  description: string;
  children: React.ReactNode;
  danger?: boolean;
}) {
  return (
    <section
      aria-labelledby={id}
      className="grid gap-4 border-t pt-10 first:border-t-0 first:pt-0 md:grid-cols-[14rem_1fr]"
    >
      <div>
        <h2 id={id} className={danger ? "text-destructive font-semibold" : "font-semibold"}>
          {title}
        </h2>
        <p className="text-muted-foreground mt-1 text-sm">{description}</p>
      </div>
      <div className="max-w-xl">{children}</div>
    </section>
  );
}

export default async function SecurityPage({
  searchParams,
}: {
  searchParams: Promise<{ emailChanged?: string }>;
}) {
  const { user, profile } = await requireUser("/account/security");
  const { emailChanged } = await searchParams;
  return (
    <div className="grid gap-10">
      {emailChanged && (
        <FormAlert kind="success">
          Email change confirmed. If you confirmed only one address so far, check the other inbox
          too.
        </FormAlert>
      )}
      <Section id="email-h" title="Email" description={`Currently ${user.email}.`}>
        <ChangeEmailForm />
      </Section>
      <Section id="password-h" title="Password" description="You'll need your current password.">
        <ChangePasswordForm email={user.email ?? ""} />
      </Section>
      <Section
        id="export-h"
        title="Your data"
        description="Download a copy of the personal data we hold about you (JSON)."
      >
        <Button asChild variant="outline" size="lg" className="h-10 px-4">
          <a href="/account/export" download>
            <Download aria-hidden="true" /> Download my data
          </a>
        </Button>
      </Section>
      <Section
        id="delete-h"
        title="Delete account"
        description="Permanently erase your account and personal data. This can't be undone."
        danger
      >
        {profile.role === "admin" ? (
          <p className="text-muted-foreground text-sm">
            Admin accounts can only be removed by another admin.
          </p>
        ) : (
          <DeleteAccountForm email={user.email ?? ""} />
        )}
      </Section>
    </div>
  );
}
