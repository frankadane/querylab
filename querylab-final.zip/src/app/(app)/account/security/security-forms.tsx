"use client";

import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { changePasswordSchema, deleteAccountSchema, emailOnlySchema } from "@/lib/validation/auth";
import { changeEmail, changePassword, deleteAccount } from "../actions";

export function ChangeEmailForm() {
  const { form, pending, result, onSubmit } = useActionForm(emailOnlySchema, changeEmail, {
    email: "",
  });
  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5">
      {result && (
        <FormAlert kind={result.ok ? "success" : "error"}>
          {result.ok ? result.message : result.error}
        </FormAlert>
      )}
      <FormField
        label="New email"
        type="email"
        autoComplete="email"
        registration={form.register("email")}
        error={form.formState.errors.email}
      />
      <SubmitButton pending={pending} className="justify-self-start px-5">
        Change email
      </SubmitButton>
    </form>
  );
}

export function ChangePasswordForm({ email }: { email: string }) {
  const { form, pending, result, onSubmit } = useActionForm(changePasswordSchema, changePassword, {
    current: "",
    password: "",
    confirm: "",
  });
  const { errors } = form.formState;
  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5">
      {/* Helps password managers associate the change with the right account */}
      <input type="email" autoComplete="username" value={email} readOnly hidden />
      {result && (
        <FormAlert kind={result.ok ? "success" : "error"}>
          {result.ok ? result.message : result.error}
        </FormAlert>
      )}
      <FormField
        label="Current password"
        type="password"
        autoComplete="current-password"
        registration={form.register("current")}
        error={errors.current}
      />
      <FormField
        label="New password"
        type="password"
        autoComplete="new-password"
        hint="At least 10 characters, with a letter and a number."
        registration={form.register("password")}
        error={errors.password}
      />
      <FormField
        label="Confirm new password"
        type="password"
        autoComplete="new-password"
        registration={form.register("confirm")}
        error={errors.confirm}
      />
      <SubmitButton pending={pending} className="justify-self-start px-5">
        Change password
      </SubmitButton>
    </form>
  );
}

export function DeleteAccountForm({ email }: { email: string }) {
  const { form, pending, result, onSubmit } = useActionForm(deleteAccountSchema, deleteAccount, {
    confirmEmail: "",
  });
  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="border-destructive/40 grid gap-5 rounded-lg border p-4"
    >
      {result && !result.ok && <FormAlert kind="error">{result.error}</FormAlert>}
      <FormField
        label={`Type ${email} to confirm`}
        type="email"
        autoComplete="off"
        registration={form.register("confirmEmail")}
        error={form.formState.errors.confirmEmail}
      />
      <SubmitButton pending={pending} variant="destructive" className="justify-self-start px-5">
        Delete my account permanently
      </SubmitButton>
    </form>
  );
}
