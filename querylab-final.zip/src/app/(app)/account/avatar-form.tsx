"use client";

import { useRef, useState, useTransition } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { initials } from "@/components/site/user-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import type { ActionResult } from "@/lib/action-result";
import { removeAvatar, uploadAvatar } from "./actions";

export function AvatarForm({
  name,
  email,
  avatarUrl,
}: {
  name: string;
  email: string;
  avatarUrl: string | null;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [pending, start] = useTransition();
  const [result, setResult] = useState<ActionResult | null>(null);

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.set("avatar", file);
    start(async () => setResult(await uploadAvatar(fd)));
    e.target.value = "";
  }

  return (
    <div className="grid gap-4">
      <div className="flex items-center gap-4">
        <Avatar className="size-20">
          {avatarUrl && <AvatarImage src={avatarUrl} alt="Your profile photo" />}
          <AvatarFallback className="bg-secondary text-secondary-foreground text-xl font-semibold">
            {initials(name, email)}
          </AvatarFallback>
        </Avatar>
        <div className="flex flex-wrap gap-2">
          <input
            ref={input}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="sr-only"
            tabIndex={-1}
            aria-hidden="true"
            onChange={onFile}
          />
          <Button
            type="button"
            variant="outline"
            size="lg"
            className="h-10 px-4"
            disabled={pending}
            onClick={() => input.current?.click()}
          >
            {pending ? "Uploading…" : "Upload photo"}
          </Button>
          {avatarUrl && (
            <Button
              type="button"
              variant="ghost"
              size="lg"
              className="h-10 px-4"
              disabled={pending}
              onClick={() => start(async () => setResult(await removeAvatar()))}
            >
              Remove
            </Button>
          )}
        </div>
      </div>
      {result && (
        <FormAlert kind={result.ok ? "success" : "error"}>
          {result.ok ? result.message : result.error}
        </FormAlert>
      )}
    </div>
  );
}
