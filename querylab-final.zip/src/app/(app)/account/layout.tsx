import { NavLink } from "@/components/site/nav-link";

export default function AccountLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-semibold">Account settings</h1>
      <nav aria-label="Account" className="mt-6 border-b">
        <ul className="-mb-px flex gap-1">
          <li>
            <NavLink
              href="/account"
              className="aria-[current=page]:border-primary block rounded-none border-b-2 border-transparent"
            >
              Profile
            </NavLink>
          </li>
          <li>
            <NavLink
              href="/account/security"
              className="aria-[current=page]:border-primary block rounded-none border-b-2 border-transparent"
            >
              Login &amp; security
            </NavLink>
          </li>
        </ul>
      </nav>
      <div className="mt-8">{children}</div>
    </div>
  );
}
