"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { type ActionResult, GENERIC_ERROR, RATE_LIMITED, invalid } from "@/lib/action-result";
import { requireUser } from "@/lib/auth";
import { sendEmail } from "@/lib/email";
import { publicEnv } from "@/lib/env";
import { rateLimit } from "@/lib/rate-limit";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import {
  changePasswordSchema,
  deleteAccountSchema,
  emailOnlySchema,
  profileSchema,
} from "@/lib/validation/auth";

const AVATAR_TYPES = new Map([
  ["image/png", "png"],
  ["image/jpeg", "jpg"],
  ["image/webp", "webp"],
]);
const AVATAR_MAX_BYTES = 2 * 1024 * 1024;

export async function updateProfile(input: unknown): Promise<ActionResult> {
  const { user } = await requireUser("/account");
  const parsed = profileSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  const { error } = await supabase
    .from("profiles")
    .update({
      full_name: parsed.data.fullName,
      bio: parsed.data.bio || null,
      timezone: parsed.data.timezone,
    })
    .eq("id", user.id);
  if (error) {
    console.error("[account] updateProfile", error.message);
    return { ok: false, error: GENERIC_ERROR };
  }
  revalidatePath("/", "layout");
  return { ok: true, message: "Profile saved." };
}

export async function uploadAvatar(formData: FormData): Promise<ActionResult> {
  const { user } = await requireUser("/account");
  const file = formData.get("avatar");
  if (!(file instanceof File) || file.size === 0)
    return { ok: false, error: "Choose an image to upload." };
  const ext = AVATAR_TYPES.get(file.type);
  if (!ext) return { ok: false, error: "Use a PNG, JPEG or WebP image." };
  if (file.size > AVATAR_MAX_BYTES) return { ok: false, error: "Images must be 2 MB or smaller." };

  const supabase = await createClient();
  const path = `${user.id}/avatar-${Date.now()}.${ext}`;
  const { error: uploadError } = await supabase.storage
    .from("avatars")
    .upload(path, file, { contentType: file.type, upsert: false });
  if (uploadError) {
    console.error("[account] avatar upload", uploadError.message);
    return { ok: false, error: GENERIC_ERROR };
  }
  const { data } = supabase.storage.from("avatars").getPublicUrl(path);
  await supabase.from("profiles").update({ avatar_url: data.publicUrl }).eq("id", user.id);
  await removeOldAvatars(user.id, path);
  revalidatePath("/", "layout");
  return { ok: true, message: "Photo updated." };
}

export async function removeAvatar(): Promise<ActionResult> {
  const { user } = await requireUser("/account");
  const supabase = await createClient();
  await supabase.from("profiles").update({ avatar_url: null }).eq("id", user.id);
  await removeOldAvatars(user.id);
  revalidatePath("/", "layout");
  return { ok: true, message: "Photo removed." };
}

async function removeOldAvatars(userId: string, keep?: string) {
  const supabase = await createClient();
  const { data } = await supabase.storage.from("avatars").list(userId);
  const old = (data ?? []).map((f) => `${userId}/${f.name}`).filter((p) => p !== keep);
  if (old.length) await supabase.storage.from("avatars").remove(old);
}

export async function changeEmail(input: unknown): Promise<ActionResult> {
  const { user } = await requireUser("/account/security");
  const parsed = emailOnlySchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  if (parsed.data.email === user.email) return { ok: false, error: "That is already your email." };
  if (!(await rateLimit("sensitive", user.id))) return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser(
    { email: parsed.data.email },
    { emailRedirectTo: `${publicEnv.NEXT_PUBLIC_SITE_URL}/auth/confirm?next=/account/security` },
  );
  if (error && error.code !== "email_exists") {
    console.error("[account] changeEmail", error.code, error.message);
    return { ok: false, error: error.status === 429 ? RATE_LIMITED : GENERIC_ERROR };
  }
  return {
    ok: true,
    message:
      "We've sent confirmation links to your current and new addresses. Your email changes once both are confirmed.",
  };
}

export async function changePassword(input: unknown): Promise<ActionResult> {
  const { user } = await requireUser("/account/security");
  const parsed = changePasswordSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  if (!(await rateLimit("sensitive", user.id))) return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({
    password: parsed.data.password,
    current_password: parsed.data.current,
  });
  if (error) {
    if (
      error.code === "current_password_invalid" ||
      error.code === "current_password_mismatch" ||
      error.code === "current_password_required"
    ) {
      return {
        ok: false,
        error: "Current password is incorrect.",
        fieldErrors: { current: ["Current password is incorrect."] },
      };
    }
    if (error.code === "same_password")
      return { ok: false, error: "Choose a different password from your current one." };
    if (error.code === "weak_password") return { ok: false, error: "Choose a stronger password." };
    console.error("[account] changePassword", error.code, error.message);
    return { ok: false, error: GENERIC_ERROR };
  }
  return { ok: true, message: "Password changed. We've emailed you a confirmation." };
}

/** GDPR erasure: deletes the auth user (cascades to profile) and stored files. */
export async function deleteAccount(input: unknown): Promise<ActionResult> {
  const { user, profile } = await requireUser("/account/security");
  const parsed = deleteAccountSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  if (parsed.data.confirmEmail !== (user.email ?? "").toLowerCase()) {
    return {
      ok: false,
      error: "The email you typed doesn't match your account.",
      fieldErrors: { confirmEmail: ["Doesn't match your account email."] },
    };
  }
  if (profile.role === "admin") {
    return {
      ok: false,
      error: "Admins can't delete their own account. Ask another admin to remove it.",
    };
  }
  if (!(await rateLimit("sensitive", user.id))) return { ok: false, error: RATE_LIMITED };

  const admin = createAdminClient();
  const { data: files } = await admin.storage.from("avatars").list(user.id);
  if (files?.length)
    await admin.storage.from("avatars").remove(files.map((f) => `${user.id}/${f.name}`));

  const { error } = await admin.auth.admin.deleteUser(user.id);
  if (error) {
    console.error("[account] deleteAccount", error.message);
    return { ok: false, error: GENERIC_ERROR };
  }

  const supabase = await createClient();
  await supabase.auth.signOut();
  if (user.email) {
    await sendEmail({
      to: user.email,
      subject: "Your QueryLab account has been deleted",
      text: "Your QueryLab account and personal data have been deleted. If you didn't request this, reply to this email.",
    });
  }
  redirect("/?accountDeleted=1");
}
