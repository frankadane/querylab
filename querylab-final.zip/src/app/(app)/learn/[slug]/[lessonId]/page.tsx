import { ArrowLeft, ArrowRight, Award, CalendarClock, Menu } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { Markdown } from "@/components/content/markdown";
import { CompleteButton } from "@/components/learning/complete-button";
import { CourseOutline } from "@/components/learning/course-outline";
import { FileDownload } from "@/components/learning/file-download";
import { ProgressBar } from "@/components/learning/progress-bar";
import { QuizPlayer } from "@/components/learning/quiz-player";
import { VideoPlayer } from "@/components/learning/video-player";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireUser } from "@/lib/auth";
import { LESSON_TYPES, formatDuration } from "@/lib/courses/format";
import { getLearningCourse } from "@/lib/learning/queries";
import { formatSessionRange } from "@/lib/sessions/time";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { robots: { index: false } };

export default async function LessonPage({
  params,
}: {
  params: Promise<{ slug: string; lessonId: string }>;
}) {
  const { slug, lessonId } = await params;
  const { user, profile } = await requireUser(`/learn/${slug}/${lessonId}`);
  const data = await getLearningCourse(slug, user.id);
  if (!data) notFound();
  const idx = data.lessons.findIndex((l) => l.id === lessonId);
  if (idx === -1) notFound();
  const lesson = data.lessons[idx];
  if (!data.enrolled && !data.isStaff) {
    redirect(
      lesson.is_free_preview ? `/courses/${slug}/preview/${lessonId}` : `/courses/${slug}?enrol=1`,
    );
  }

  const supabase = await createClient();
  const [{ data: content }, quiz, sessions, attempts] = await Promise.all([
    supabase
      .from("lesson_contents")
      .select("body_md, video_url, file_path")
      .eq("lesson_id", lessonId)
      .maybeSingle(),
    lesson.type === "quiz"
      ? supabase.rpc("get_student_quiz", { p_lesson_id: lessonId })
      : Promise.resolve({ data: null }),
    lesson.type === "live_session"
      ? supabase
          .from("live_sessions")
          .select("id, title, starts_at, ends_at, status, session_registrations(status, user_id)")
          .eq("lesson_id", lessonId)
          .order("starts_at")
      : Promise.resolve({ data: null }),
    lesson.type === "quiz"
      ? supabase
          .from("quiz_attempts")
          .select("score, passed")
          .eq("lesson_id", lessonId)
          .eq("user_id", user.id)
          .order("score", { ascending: false })
          .limit(1)
      : Promise.resolve({ data: null }),
  ]);

  const prev = data.lessons[idx - 1];
  const next = data.lessons[idx + 1];
  const done = data.done.has(lessonId);
  const fileName = content?.file_path?.split("/").pop()?.replace(/^\d+-/, "");

  return (
    <div className="mx-auto grid max-w-7xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[18rem_1fr] lg:px-8">
      <aside className="lg:sticky lg:top-24 lg:max-h-[calc(100dvh-7rem)] lg:self-start lg:overflow-y-auto">
        <Link
          href={`/courses/${slug}`}
          className="text-muted-foreground hover:text-foreground text-sm font-medium"
        >
          {data.course.title}
        </Link>
        <ProgressBar percent={data.progress.percent} label="Course progress" className="mt-3" />
        {data.certificate && (
          <Button asChild size="lg" className="mt-4 h-10 w-full">
            <Link href={`/certificates/${data.certificate.serial}/pdf`} target="_blank">
              <Award aria-hidden="true" /> Download certificate
            </Link>
          </Button>
        )}
        <details className="group mt-4 lg:hidden">
          <summary className="flex min-h-11 items-center gap-2 rounded-lg border px-3 font-medium [&::-webkit-details-marker]:hidden">
            <Menu className="size-4" aria-hidden="true" /> Course outline
          </summary>
          <div className="mt-3">
            <CourseOutline data={data} currentId={lessonId} />
          </div>
        </details>
        <div className="mt-6 hidden lg:block">
          <CourseOutline data={data} currentId={lessonId} />
        </div>
      </aside>

      <article className="min-w-0">
        <p className="text-muted-foreground text-sm">{lesson.sectionTitle}</p>
        <h1 className="mt-1 text-3xl font-semibold">{lesson.title}</h1>
        <div className="mt-3 flex flex-wrap gap-2">
          <Badge variant="secondary">{LESSON_TYPES[lesson.type]}</Badge>
          {lesson.duration_minutes ? (
            <Badge variant="outline">{formatDuration(lesson.duration_minutes)}</Badge>
          ) : null}
          {done && <Badge>Completed</Badge>}
          {data.isStaff && !data.enrolled && <Badge variant="outline">Staff preview</Badge>}
        </div>

        <div className="mt-8 grid gap-8">
          {(lesson.type === "video" || lesson.type === "live_session") && content?.video_url && (
            <VideoPlayer url={content.video_url} title={lesson.title} />
          )}
          {content?.file_path && fileName && (
            <FileDownload lessonId={lessonId} fileName={fileName} />
          )}
          {content?.body_md && <Markdown>{content.body_md}</Markdown>}

          {lesson.type === "quiz" &&
            (quiz.data?.length ? (
              <QuizPlayer
                lessonId={lessonId}
                passMark={quiz.data[0].pass_mark}
                questions={quiz.data.map((q) => ({
                  id: q.question_id,
                  prompt: q.prompt,
                  options: q.options as string[],
                }))}
                bestScore={attempts.data?.[0]?.score ?? null}
                passed={done}
              />
            ) : (
              <p className="text-muted-foreground rounded-xl border border-dashed p-6">
                This quiz has no questions yet.
              </p>
            ))}

          {lesson.type === "live_session" && (
            <section aria-labelledby="live-h" className="bg-card rounded-xl border p-5">
              <h2 id="live-h" className="flex items-center gap-2 font-semibold">
                <CalendarClock className="size-4" aria-hidden="true" /> Live sessions for this
                lesson
              </h2>
              <p className="text-muted-foreground mt-1 text-sm">
                This lesson is marked complete when your attendance is recorded.
              </p>
              {sessions.data?.length ? (
                <ul className="mt-3 divide-y">
                  {sessions.data.map((s) => {
                    const mine = s.session_registrations.find((r) => r.user_id === user.id)?.status;
                    return (
                      <li
                        key={s.id}
                        className="flex flex-wrap items-center justify-between gap-2 py-3"
                      >
                        <div>
                          <Link
                            href={`/schedule/${s.id}`}
                            className="text-primary font-medium underline-offset-4 hover:underline"
                          >
                            {s.title}
                          </Link>
                          <p className="text-muted-foreground text-sm">
                            {formatSessionRange(s.starts_at, s.ends_at, profile.timezone)}
                          </p>
                        </div>
                        <span className="text-sm font-medium capitalize">
                          {mine === "attended"
                            ? "Attended"
                            : mine === "registered"
                              ? "Registered"
                              : mine === "waitlist"
                                ? "Waitlist"
                                : s.status === "cancelled"
                                  ? "Cancelled"
                                  : ""}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <p className="mt-3 text-sm">
                  No session is linked yet. See the{" "}
                  <Link href="/schedule" className="text-primary font-medium underline">
                    live schedule
                  </Link>
                  .
                </p>
              )}
            </section>
          )}

          {(lesson.type === "video" || lesson.type === "article" || lesson.type === "file") &&
            data.enrolled && (
              <CompleteButton
                lessonId={lessonId}
                done={done}
                nextHref={next ? `/learn/${slug}/${next.id}` : null}
              />
            )}

          {data.certificate &&
            data.progress.required_completed === data.progress.required_total && (
              <div role="status" className="border-primary/40 bg-secondary rounded-xl border p-5">
                <p className="flex items-center gap-2 font-semibold">
                  <Award className="size-5" aria-hidden="true" /> Course complete. Well done!
                </p>
                <p className="mt-1 text-sm">
                  Certificate {data.certificate.serial}.{" "}
                  <Link
                    href={`/verify/${data.certificate.serial}`}
                    className="font-medium underline"
                  >
                    Public verification page
                  </Link>
                  .
                </p>
              </div>
            )}
        </div>

        <nav
          aria-label="Lesson navigation"
          className="mt-12 flex flex-wrap justify-between gap-3 border-t pt-6"
        >
          {prev ? (
            <Button asChild variant="outline" size="lg" className="h-11 max-w-full px-4">
              <Link href={`/learn/${slug}/${prev.id}`}>
                <ArrowLeft aria-hidden="true" />
                <span className="truncate">Previous: {prev.title}</span>
              </Link>
            </Button>
          ) : (
            <span />
          )}
          {next && (
            <Button asChild variant="outline" size="lg" className="h-11 max-w-full px-4">
              <Link href={`/learn/${slug}/${next.id}`}>
                <span className="truncate">Next: {next.title}</span>
                <ArrowRight aria-hidden="true" />
              </Link>
            </Button>
          )}
        </nav>
      </article>
    </div>
  );
}
