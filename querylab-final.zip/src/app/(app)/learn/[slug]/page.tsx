import { notFound, redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { getLearningCourse } from "@/lib/learning/queries";

/** Sends the learner to their next unfinished lesson. */
export default async function LearnCoursePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { user } = await requireUser(`/learn/${slug}`);
  const data = await getLearningCourse(slug, user.id);
  if (!data) notFound();
  if (!data.enrolled && !data.isStaff) redirect(`/courses/${slug}?enrol=1`);
  const next = data.lessons.find((l) => !data.done.has(l.id)) ?? data.lessons[0];
  if (!next) notFound();
  redirect(`/learn/${slug}/${next.id}`);
}
