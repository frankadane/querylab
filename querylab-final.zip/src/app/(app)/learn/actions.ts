"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { type ActionResult, GENERIC_ERROR, RATE_LIMITED } from "@/lib/action-result";
import { requireUser } from "@/lib/auth";
import { sendEmail } from "@/lib/email";
import { publicEnv } from "@/lib/env";
import { rateLimit } from "@/lib/rate-limit";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";

const uuid = z.string().uuid();

export type QuizResult = {
  score: number;
  passed: boolean;
  pass_mark: number;
  correct: number;
  total: number;
  results: {
    question_id: string;
    correct: boolean;
    correct_index: number | null;
    explanation: string | null;
  }[];
};

async function maybeIssueCertificate(courseId: string, userEmail?: string | null) {
  const supabase = await createClient();
  const { data: before } = await supabase
    .from("certificates")
    .select("serial")
    .eq("course_id", courseId)
    .maybeSingle();
  const { data: serial } = await supabase.rpc("issue_certificate", { p_course_id: courseId });
  if (serial && !before && userEmail) {
    const { data: c } = await supabase.from("courses").select("title").eq("id", courseId).single();
    await sendEmail({
      to: userEmail,
      subject: `Your certificate: ${c?.title ?? "QueryLab course"}`,
      text: `Congratulations on completing ${c?.title}.\n\nDownload your certificate: ${publicEnv.NEXT_PUBLIC_SITE_URL}/certificates/${serial}/pdf\nAnyone can verify it at: ${publicEnv.NEXT_PUBLIC_SITE_URL}/verify/${serial}\n\nQueryLab`,
    });
  }
  return serial ?? null;
}

/** Status for the enrol button on public course pages (which are cached and user-agnostic). */
export async function getEnrolmentState(courseId: string) {
  if (!uuid.safeParse(courseId).success) return { signedIn: false, enrolled: false };
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { signedIn: false, enrolled: false };
  const [{ data }, { data: pending }] = await Promise.all([
    supabase
      .from("enrolments")
      .select("status")
      .eq("course_id", courseId)
      .eq("user_id", user.id)
      .maybeSingle(),
    supabase
      .from("orders")
      .select("reference")
      .eq("course_id", courseId)
      .eq("user_id", user.id)
      .eq("status", "pending")
      .maybeSingle(),
  ]);
  return {
    signedIn: true,
    enrolled: data?.status === "active",
    revoked: data?.status === "revoked",
    pendingOrder: pending?.reference ?? null,
  };
}

export async function enrolFree(courseId: string): Promise<ActionResult> {
  const { user } = await requireUser();
  if (!uuid.safeParse(courseId).success) return { ok: false, error: "Course not found." };
  if (!(await rateLimit("sensitive", `enrol:${user.id}`)))
    return { ok: false, error: RATE_LIMITED };
  const supabase = await createClient();
  const { error } = await supabase.rpc("enrol_free", { p_course_id: courseId });
  if (error) {
    if (error.code === "P0001")
      return { ok: false, error: "This course isn't free. Use the Enrol button to check out." };
    if (error.code === "42501") return { ok: false, error: error.message };
    return { ok: false, error: GENERIC_ERROR };
  }
  const { data: c } = await supabase
    .from("courses")
    .select("slug, title")
    .eq("id", courseId)
    .single();
  await sendEmail({
    to: user.email!,
    subject: `You're enrolled: ${c?.title}`,
    text: `You're enrolled in ${c?.title}. Start learning: ${publicEnv.NEXT_PUBLIC_SITE_URL}/learn/${c?.slug}\n\nQueryLab`,
  });
  revalidatePath("/dashboard");
  redirect(`/learn/${c?.slug}`);
}

export async function setLessonComplete(
  lessonId: string,
  completed: boolean,
): Promise<ActionResult<{ certificate: string | null }>> {
  const { user } = await requireUser();
  if (!uuid.safeParse(lessonId).success) return { ok: false, error: "Lesson not found." };
  const supabase = await createClient();
  const { error } = await supabase.rpc("complete_lesson", {
    p_lesson_id: lessonId,
    p_completed: completed,
  });
  if (error)
    return {
      ok: false,
      error:
        error.code === "42501"
          ? "Enrol in this course first."
          : error.code === "P0001"
            ? error.message
            : GENERIC_ERROR,
    };
  const { data: l } = await supabase
    .from("lessons")
    .select("course_id")
    .eq("id", lessonId)
    .single();
  const certificate = completed && l ? await maybeIssueCertificate(l.course_id, user.email) : null;
  revalidatePath("/learn", "layout");
  revalidatePath("/dashboard");
  return {
    ok: true,
    message: completed ? "Lesson marked as complete." : "Lesson marked as not complete.",
    data: { certificate },
  };
}

const answersSchema = z
  .record(z.string().uuid(), z.number().int().min(0).max(5))
  .refine((o) => Object.keys(o).length <= 50);

export async function submitQuiz(
  lessonId: string,
  answers: unknown,
): Promise<ActionResult<QuizResult & { certificate: string | null }>> {
  const { user } = await requireUser();
  const parsed = answersSchema.safeParse(answers);
  if (!uuid.safeParse(lessonId).success || !parsed.success)
    return { ok: false, error: "Answer every question before submitting." };
  if (!(await rateLimit("sensitive", `quiz:${user.id}:${lessonId}`)))
    return { ok: false, error: "You've made a lot of attempts. Take a break and try again later." };

  const supabase = await createClient();
  const { data, error } = await supabase.rpc("submit_quiz", {
    p_lesson_id: lessonId,
    p_answers: parsed.data,
  });
  if (error)
    return {
      ok: false,
      error: error.code === "42501" ? "Enrol in this course first." : GENERIC_ERROR,
    };
  const result = data as unknown as QuizResult;
  let certificate: string | null = null;
  if (result.passed) {
    const { data: l } = await supabase
      .from("lessons")
      .select("course_id")
      .eq("id", lessonId)
      .single();
    if (l) certificate = await maybeIssueCertificate(l.course_id, user.email);
  }
  revalidatePath("/learn", "layout");
  revalidatePath("/dashboard");
  return { ok: true, data: { ...result, certificate } };
}

/** Short-lived (2 min) download link for an enrolled student or course staff. */
export async function getLessonFileUrl(lessonId: string): Promise<ActionResult<{ url: string }>> {
  await requireUser();
  if (!uuid.safeParse(lessonId).success) return { ok: false, error: "File not found." };
  const supabase = await createClient();
  // RLS returns the content row only to enrolled students / staff of a published course.
  const { data: content } = await supabase
    .from("lesson_contents")
    .select("file_path")
    .eq("lesson_id", lessonId)
    .maybeSingle();
  if (!content?.file_path) return { ok: false, error: "No file is available for this lesson yet." };
  const { data, error } = await createAdminClient()
    .storage.from("lesson-files")
    .createSignedUrl(content.file_path, 120, { download: true });
  if (error || !data) return { ok: false, error: GENERIC_ERROR };
  return { ok: true, data: { url: data.signedUrl } };
}
