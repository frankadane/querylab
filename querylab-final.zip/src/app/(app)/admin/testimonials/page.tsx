import type { Metadata } from "next";
import { PageHeader } from "@/components/site/page-header";
import { createClient } from "@/lib/supabase/server";
import { TestimonialManager } from "./testimonial-manager";

export const metadata: Metadata = { title: "Admin: testimonials", robots: { index: false } };

export default async function TestimonialsPage() {
  const supabase = await createClient();
  const [{ data: items }, { data: courses }] = await Promise.all([
    supabase
      .from("testimonials")
      .select("*, course:courses(title)")
      .order("created_at", { ascending: false }),
    supabase.from("courses").select("id, title").order("title"),
  ]);
  return (
    <>
      <PageHeader
        title="Testimonials"
        description="Add only genuine quotes from real learners, with their permission. Nothing is shown publicly until published."
      />
      <div className="mt-6">
        <TestimonialManager
          items={items ?? []}
          courses={(courses ?? []).map((c) => [c.id, c.title] as [string, string])}
        />
      </div>
    </>
  );
}
