"use client";

import { Pencil, Plus, Quote, Trash2 } from "lucide-react";
import { useState } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useAction } from "@/components/forms/use-action";
import { useActionForm } from "@/components/forms/use-action-form";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { type TestimonialInput, testimonialSchema } from "@/lib/validation/admin";
import { deleteTestimonial, saveTestimonial } from "../actions";

type Item = {
  id: string;
  quote: string;
  author_name: string;
  author_title: string | null;
  course_id: string | null;
  is_published: boolean;
  course: { title: string } | null;
};

export function TestimonialManager({
  items,
  courses,
}: {
  items: Item[];
  courses: [string, string][];
}) {
  const [editing, setEditing] = useState<string | null>(null);
  const { pending, result, run } = useAction();
  const [notice, setNotice] = useState<string | null>(null);
  return (
    <div className="grid gap-4">
      <Button
        size="lg"
        className="h-10 justify-self-start px-4"
        onClick={() => setEditing("new")}
        disabled={editing === "new"}
      >
        <Plus aria-hidden="true" /> Add testimonial
      </Button>
      <div aria-live="polite">
        {notice && <FormAlert kind="success">{notice}</FormAlert>}
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
      {editing === "new" && (
        <TestimonialForm
          courses={courses}
          onDone={(m) => {
            setEditing(null);
            if (m) setNotice(m);
          }}
        />
      )}
      {items.length === 0 && editing !== "new" && (
        <div className="rounded-xl border border-dashed p-10 text-center">
          <Quote className="text-muted-foreground mx-auto size-6" aria-hidden="true" />
          <p className="mt-3 font-medium">No testimonials yet</p>
          <p className="text-muted-foreground mt-1 text-sm">
            Collect quotes from learners after your first cohort and add them here.
          </p>
        </div>
      )}
      <ul className="grid gap-3">
        {items.map((t) =>
          editing === t.id ? (
            <li key={t.id}>
              <TestimonialForm
                id={t.id}
                courses={courses}
                onDone={(m) => {
                  setEditing(null);
                  if (m) setNotice(m);
                }}
                defaults={{
                  quote: t.quote,
                  authorName: t.author_name,
                  authorTitle: t.author_title ?? "",
                  courseId: t.course_id ?? "",
                  isPublished: t.is_published,
                  consent: true,
                }}
              />
            </li>
          ) : (
            <li key={t.id} className="bg-card flex items-start gap-3 rounded-xl border p-4">
              <blockquote className="min-w-0 flex-1">
                <p>“{t.quote}”</p>
                <footer className="text-muted-foreground mt-2 text-sm">
                  {t.author_name}
                  {t.author_title ? `, ${t.author_title}` : ""}
                  {t.course ? ` · ${t.course.title}` : ""}
                </footer>
              </blockquote>
              {t.is_published ? (
                <Badge variant="secondary">Published</Badge>
              ) : (
                <Badge variant="outline">Hidden</Badge>
              )}
              <Button
                variant="ghost"
                size="icon-lg"
                className="size-10"
                aria-label={`Edit testimonial by ${t.author_name}`}
                onClick={() => setEditing(t.id)}
              >
                <Pencil className="size-4" aria-hidden="true" />
              </Button>
              <Button
                variant="ghost"
                size="icon-lg"
                className="text-destructive size-10"
                aria-label={`Delete testimonial by ${t.author_name}`}
                disabled={pending}
                onClick={() => {
                  if (confirm("Delete this testimonial?")) run(() => deleteTestimonial(t.id));
                }}
              >
                <Trash2 className="size-4" aria-hidden="true" />
              </Button>
            </li>
          ),
        )}
      </ul>
    </div>
  );
}

function TestimonialForm({
  id,
  courses,
  defaults,
  onDone,
}: {
  id?: string;
  courses: [string, string][];
  defaults?: TestimonialInput;
  onDone: (message?: string) => void;
}) {
  const { form, pending, result, onSubmit } = useActionForm(
    testimonialSchema,
    async (v) => {
      const r = await saveTestimonial(id ?? null, v);
      if (r.ok) onDone(r.message);
      return r;
    },
    defaults ?? { quote: "", authorName: "", authorTitle: "", courseId: "", isPublished: false },
  );
  const { errors } = form.formState;
  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="border-primary/40 bg-card grid gap-4 rounded-xl border-2 p-5 sm:grid-cols-2"
    >
      {result && !result.ok && (
        <FormAlert kind="error" className="sm:col-span-2">
          {result.error}
        </FormAlert>
      )}
      <FormField
        label="Quote"
        multiline
        registration={form.register("quote")}
        error={errors.quote}
        className="sm:col-span-2"
      />
      <FormField
        label="Author name"
        registration={form.register("authorName")}
        error={errors.authorName}
      />
      <FormField
        label="Author role / company"
        registration={form.register("authorTitle")}
        error={errors.authorTitle}
      />
      <SelectField
        label="Course (optional)"
        registration={form.register("courseId")}
        options={[["", "None"], ...courses]}
      />
      <label className="flex items-center gap-3 self-end pb-3 text-sm">
        <input
          type="checkbox"
          className="accent-primary size-5"
          {...form.register("isPublished")}
        />{" "}
        Publish on the site
      </label>
      <div className="grid gap-1 sm:col-span-2">
        <label className="flex items-start gap-3 text-sm">
          <input
            type="checkbox"
            className="accent-primary mt-0.5 size-5"
            {...form.register("consent")}
            aria-invalid={errors.consent ? true : undefined}
          />
          This is a genuine quote and the author agreed to it being published.
        </label>
        {errors.consent && (
          <p className="text-destructive text-sm font-medium">{errors.consent.message}</p>
        )}
      </div>
      <div className="flex gap-2 sm:col-span-2">
        <SubmitButton pending={pending} className="px-5">
          Save testimonial
        </SubmitButton>
        <Button type="button" variant="ghost" size="lg" className="h-11" onClick={() => onDone()}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
