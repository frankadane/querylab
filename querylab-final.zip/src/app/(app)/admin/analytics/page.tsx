import type { Metadata } from "next";
import { WeeklyBarChart } from "@/components/charts/weekly-bar-chart";
import { PageHeader } from "@/components/site/page-header";
import { type Currency, formatPrice } from "@/lib/courses/format";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Admin: analytics", robots: { index: false } };

type Analytics = {
  weeks: number;
  signups: { week: string; value: number }[];
  enrolments: { week: string; value: number }[];
  totals: {
    users: number;
    signups_period: number;
    active_enrolments: number;
    enrolments_period: number;
    pending_orders: number;
    certificates: number;
  };
  revenue: { currency: Currency; period_minor: number | null; all_minor: number; orders: number }[];
  attendance: { sessions: number; registered: number; attended: number };
  courses: { title: string; enrolled: number; completed: number }[];
};

function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="bg-card rounded-xl border p-5">
      <dt className="text-muted-foreground text-sm">{label}</dt>
      <dd className="tabular mt-1 font-mono text-3xl">{value}</dd>
      {sub && <dd className="text-muted-foreground mt-1 text-sm">{sub}</dd>}
    </div>
  );
}

export default async function AnalyticsPage() {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("admin_analytics", { p_weeks: 12 });
  if (error || !data) throw new Error("Could not load analytics");
  const a = data as unknown as Analytics;
  const att = a.attendance;
  const rate = att.registered ? Math.round((100 * att.attended) / att.registered) : null;

  return (
    <>
      <PageHeader
        title="Analytics"
        description={`Last ${a.weeks} weeks unless stated. Revenue counts only orders marked as paid.`}
      />

      <dl className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat
          label="New sign-ups"
          value={String(a.totals.signups_period)}
          sub={`${a.totals.users} users in total`}
        />
        <Stat
          label="New enrolments"
          value={String(a.totals.enrolments_period)}
          sub={`${a.totals.active_enrolments} active in total`}
        />
        <Stat
          label="Live attendance rate"
          value={rate === null ? "–" : `${rate}%`}
          sub={`${att.attended} of ${att.registered} registrations · ${att.sessions} past sessions`}
        />
        <Stat
          label="Certificates issued"
          value={String(a.totals.certificates)}
          sub={`${a.totals.pending_orders} ${a.totals.pending_orders === 1 ? "order" : "orders"} awaiting payment`}
        />
      </dl>

      <section aria-labelledby="rev-h" className="mt-8">
        <h2 id="rev-h" className="text-lg font-semibold">
          Revenue recorded
        </h2>
        {a.revenue.length ? (
          <dl className="mt-3 grid gap-4 sm:grid-cols-2">
            {a.revenue.map((r) => (
              <Stat
                key={r.currency}
                label={`${r.currency}, last ${a.weeks} weeks`}
                value={formatPrice(r.period_minor ?? 0, r.currency).replace("Free", "0")}
                sub={`${formatPrice(r.all_minor, r.currency)} all time · ${r.orders} paid orders`}
              />
            ))}
          </dl>
        ) : (
          <p className="text-muted-foreground mt-3">No paid orders yet.</p>
        )}
        <p className="text-muted-foreground mt-2 text-sm">
          GHS and USD are reported separately; they are never converted or added together.
        </p>
      </section>

      <div className="mt-8 grid gap-6 xl:grid-cols-2">
        <WeeklyBarChart title="Sign-ups per week" unit="sign-ups" data={a.signups} />
        <WeeklyBarChart title="Enrolments per week" unit="enrolments" data={a.enrolments} />
      </div>

      <section aria-labelledby="completion-h" className="bg-card mt-8 rounded-xl border p-5">
        <h2 id="completion-h" className="font-semibold">
          Completion rate by course
        </h2>
        <p className="text-muted-foreground text-sm">Certificates issued ÷ active enrolments.</p>
        <ul className="mt-4 grid gap-4">
          {a.courses.map((c) => {
            const pct = c.enrolled
              ? Math.round((100 * Math.min(c.completed, c.enrolled)) / c.enrolled)
              : 0;
            return (
              <li key={c.title} className="grid gap-1.5">
                <div className="flex flex-wrap justify-between gap-2 text-sm">
                  <span className="font-medium">{c.title}</span>
                  <span className="tabular text-muted-foreground font-mono">
                    {c.enrolled ? `${pct}% · ${c.completed} of ${c.enrolled}` : "No enrolments"}
                  </span>
                </div>
                <div aria-hidden="true" className="bg-muted h-2.5 overflow-hidden rounded-full">
                  <div className="bg-data-1 h-full rounded-r-[4px]" style={{ width: `${pct}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
      </section>
    </>
  );
}
