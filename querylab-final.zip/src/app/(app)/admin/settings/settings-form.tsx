"use client";

import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { type SettingsInput, settingsSchema } from "@/lib/validation/admin";
import { saveSettings } from "../actions";

export function SettingsForm({
  defaults,
  timezones,
}: {
  defaults: SettingsInput;
  timezones: string[];
}) {
  const { form, pending, result, onSubmit } = useActionForm(settingsSchema, saveSettings, defaults);
  const e = form.formState.errors;
  const r = form.register;
  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-10">
      <fieldset className="grid gap-5 sm:grid-cols-2">
        <legend className="mb-4 text-lg font-semibold">Brand &amp; contact</legend>
        <FormField label="Brand name" registration={r("brandName")} error={e.brandName} />
        <FormField
          label="Contact email"
          type="email"
          registration={r("contactEmail")}
          error={e.contactEmail}
        />
        <FormField
          label="Phone"
          type="tel"
          registration={r("contactPhone")}
          error={e.contactPhone}
        />
        <FormField label="Address" registration={r("address")} error={e.address} />
        <SelectField
          label="Default currency"
          registration={r("defaultCurrency")}
          options={{ GHS: "GHS (Ghana cedi)", USD: "USD (US dollar)" }}
        />
        <SelectField
          label="Default timezone"
          registration={r("defaultTimezone")}
          options={timezones.map((t) => [t, t.replaceAll("_", " ")] as [string, string])}
          error={e.defaultTimezone}
        />
      </fieldset>
      <fieldset className="grid gap-5 border-t pt-8 sm:grid-cols-2">
        <legend className="mb-1 text-lg font-semibold">Bank details for transfers</legend>
        <p className="text-muted-foreground text-sm sm:col-span-2">
          Shown to students who choose bank transfer at checkout, with their order reference.
        </p>
        <FormField
          label="Account name"
          registration={r("bank.accountName")}
          error={e.bank?.accountName}
        />
        <FormField label="Bank name" registration={r("bank.bankName")} error={e.bank?.bankName} />
        <FormField
          label="Account number"
          registration={r("bank.accountNumber")}
          error={e.bank?.accountNumber}
        />
        <FormField label="Branch" registration={r("bank.branch")} error={e.bank?.branch} />
        <FormField label="SWIFT / BIC" registration={r("bank.swift")} error={e.bank?.swift} />
        <FormField
          label="IBAN (international)"
          registration={r("bank.iban")}
          error={e.bank?.iban}
        />
        <FormField
          label="Payment instructions"
          multiline
          registration={r("bank.instructions")}
          error={e.bank?.instructions}
          className="sm:col-span-2"
        />
      </fieldset>
      <fieldset className="grid gap-5 border-t pt-8 sm:grid-cols-2">
        <legend className="mb-1 text-lg font-semibold">Invoice details</legend>
        <p className="text-muted-foreground text-sm sm:col-span-2">
          Printed on every invoice. Replace the placeholders before taking payments.
        </p>
        <FormField
          label="Company name"
          registration={r("invoice.companyName")}
          error={e.invoice?.companyName}
        />
        <FormField
          label="Tax ID / TIN (optional)"
          registration={r("invoice.taxId")}
          error={e.invoice?.taxId}
        />
        <FormField
          label="Company address"
          multiline
          registration={r("invoice.companyAddress")}
          error={e.invoice?.companyAddress}
          className="sm:col-span-2"
        />
        <FormField
          label="Invoice footer"
          registration={r("invoice.footer")}
          error={e.invoice?.footer}
          className="sm:col-span-2"
        />
      </fieldset>
      <fieldset className="grid gap-5 border-t pt-8 sm:grid-cols-2">
        <legend className="mb-4 text-lg font-semibold">Social links</legend>
        {(["linkedin", "x", "youtube", "instagram", "facebook"] as const).map((k) => (
          <FormField
            key={k}
            label={
              {
                linkedin: "LinkedIn",
                x: "X (Twitter)",
                youtube: "YouTube",
                instagram: "Instagram",
                facebook: "Facebook",
              }[k]
            }
            type="url"
            placeholder="https://"
            registration={r(`social.${k}`)}
            error={e.social?.[k]}
          />
        ))}
      </fieldset>
      <div className="bg-background/95 sticky bottom-0 -mx-4 flex flex-wrap items-center gap-4 border-t px-4 py-4 backdrop-blur">
        <SubmitButton pending={pending} className="px-6">
          Save settings
        </SubmitButton>
        <div aria-live="polite" className="min-w-0 flex-1">
          {result && (
            <FormAlert kind={result.ok ? "success" : "error"}>
              {result.ok ? result.message : result.error}
            </FormAlert>
          )}
        </div>
      </div>
    </form>
  );
}
