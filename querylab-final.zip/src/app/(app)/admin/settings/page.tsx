import type { Metadata } from "next";
import { PageHeader } from "@/components/site/page-header";
import { createClient } from "@/lib/supabase/server";
import { listTimezones } from "@/lib/timezones";
import { SettingsForm } from "./settings-form";

export const metadata: Metadata = { title: "Admin: settings", robots: { index: false } };

export default async function SettingsPage() {
  const supabase = await createClient();
  const { data: s } = await supabase.from("site_settings").select("*").eq("id", 1).single();
  const bank = (s?.bank_details ?? {}) as Record<string, string>;
  const social = (s?.social_links ?? {}) as Record<string, string | null>;
  return (
    <>
      <PageHeader
        title="Site settings"
        description="Brand, contact details and the bank details shown to buyers at bank-transfer checkout."
      />
      <div className="mt-6">
        <SettingsForm
          timezones={listTimezones()}
          defaults={{
            brandName: s?.brand_name ?? "QueryLab",
            contactEmail: s?.contact_email ?? "",
            contactPhone: s?.contact_phone ?? "",
            address: s?.address ?? "",
            defaultCurrency: s?.default_currency ?? "GHS",
            defaultTimezone: s?.default_timezone ?? "Africa/Accra",
            bank: {
              accountName: bank.account_name ?? "",
              bankName: bank.bank_name ?? "",
              accountNumber: bank.account_number ?? "",
              branch: bank.branch ?? "",
              swift: bank.swift ?? "",
              iban: bank.iban ?? "",
              instructions: bank.instructions ?? "",
            },
            invoice: {
              companyName: s?.invoice_company_name ?? "",
              companyAddress: s?.invoice_company_address ?? "",
              taxId: s?.invoice_tax_id ?? "",
              footer: s?.invoice_footer ?? "",
            },
            social: {
              linkedin: social.linkedin ?? "",
              x: social.x ?? "",
              youtube: social.youtube ?? "",
              instagram: social.instagram ?? "",
              facebook: social.facebook ?? "",
            },
          }}
        />
      </div>
    </>
  );
}
