import type { Metadata } from "next";
import { PageHeader } from "@/components/site/page-header";
import { createClient } from "@/lib/supabase/server";
import { CouponManager } from "./coupon-manager";

export const metadata: Metadata = { title: "Admin: coupons", robots: { index: false } };

export default async function CouponsPage() {
  const supabase = await createClient();
  const [{ data: coupons }, { data: courses }] = await Promise.all([
    supabase
      .from("coupons")
      .select("*, course:courses(title)")
      .order("created_at", { ascending: false }),
    supabase.from("courses").select("id, title").order("title"),
  ]);
  return (
    <>
      <PageHeader
        title="Coupons"
        description="Percentage or fixed discounts. A 100% coupon enrols the student immediately without payment."
      />
      <div className="mt-6">
        <CouponManager
          coupons={coupons ?? []}
          courses={(courses ?? []).map((c) => [c.id, c.title] as [string, string])}
        />
      </div>
    </>
  );
}
