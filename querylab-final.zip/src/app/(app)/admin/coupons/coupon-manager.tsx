"use client";

import { Pencil, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import type { z } from "zod";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useAction } from "@/components/forms/use-action";
import { useActionForm } from "@/components/forms/use-action-form";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatPrice } from "@/lib/courses/format";
import { couponSchema } from "@/lib/validation/payments";
import { deleteCoupon, saveCoupon } from "../orders/actions";

type Coupon = {
  id: string;
  code: string;
  kind: "percent" | "fixed";
  amount: number;
  currency: "GHS" | "USD" | null;
  course_id: string | null;
  expires_at: string | null;
  max_redemptions: number | null;
  redemptions: number;
  is_active: boolean;
  course: { title: string } | null;
};

export function CouponManager({
  coupons,
  courses,
}: {
  coupons: Coupon[];
  courses: [string, string][];
}) {
  const [editing, setEditing] = useState<string | null>(null);
  const { pending, result, run } = useAction();
  const [notice, setNotice] = useState<string | null>(null);
  const current = coupons.find((c) => c.id === editing);
  return (
    <div className="grid gap-4">
      <Button
        size="lg"
        className="h-10 justify-self-start px-4"
        onClick={() => setEditing("new")}
        disabled={editing === "new"}
      >
        <Plus aria-hidden="true" /> New coupon
      </Button>
      <div aria-live="polite">
        {notice && <FormAlert kind="success">{notice}</FormAlert>}
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
      {editing && (
        <CouponForm
          key={editing}
          id={editing === "new" ? null : editing}
          courses={courses}
          onDone={(m) => {
            setEditing(null);
            if (m) setNotice(m);
          }}
          defaults={
            current
              ? {
                  code: current.code,
                  kind: current.kind,
                  amount:
                    current.kind === "percent"
                      ? String(current.amount)
                      : (current.amount / 100).toFixed(2),
                  currency: current.currency ?? "",
                  courseId: current.course_id ?? "",
                  expiresAt: current.expires_at?.slice(0, 10) ?? "",
                  maxRedemptions: current.max_redemptions ? String(current.max_redemptions) : "",
                  isActive: current.is_active,
                }
              : undefined
          }
        />
      )}
      <div className="bg-card overflow-x-auto rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Discount</TableHead>
              <TableHead>Course</TableHead>
              <TableHead>Used</TableHead>
              <TableHead>Expires</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {coupons.map((c) => (
              <TableRow key={c.id}>
                <TableCell className="font-mono font-medium">{c.code}</TableCell>
                <TableCell>
                  {c.kind === "percent" ? `${c.amount}%` : formatPrice(c.amount, c.currency!)}
                </TableCell>
                <TableCell>{c.course?.title ?? "Any course"}</TableCell>
                <TableCell className="tabular font-mono">
                  {c.redemptions}
                  {c.max_redemptions ? ` / ${c.max_redemptions}` : ""}
                </TableCell>
                <TableCell className="whitespace-nowrap">
                  {c.expires_at ? new Date(c.expires_at).toLocaleDateString("en-GB") : "Never"}
                </TableCell>
                <TableCell>
                  {c.is_active ? (
                    <Badge variant="secondary">Active</Badge>
                  ) : (
                    <Badge variant="outline">Off</Badge>
                  )}
                </TableCell>
                <TableCell className="whitespace-nowrap">
                  <Button
                    variant="ghost"
                    size="icon-lg"
                    className="size-10"
                    aria-label={`Edit coupon ${c.code}`}
                    onClick={() => setEditing(c.id)}
                  >
                    <Pencil className="size-4" aria-hidden="true" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon-lg"
                    className="text-destructive size-10"
                    aria-label={`Delete coupon ${c.code}`}
                    disabled={pending}
                    onClick={() => {
                      if (confirm(`Delete ${c.code}?`)) run(() => deleteCoupon(c.id));
                    }}
                  >
                    <Trash2 className="size-4" aria-hidden="true" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {!coupons.length && (
              <TableRow>
                <TableCell colSpan={7} className="text-muted-foreground py-10 text-center">
                  No coupons yet.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function CouponForm({
  id,
  courses,
  defaults,
  onDone,
}: {
  id: string | null;
  courses: [string, string][];
  defaults?: z.input<typeof couponSchema>;
  onDone: (message?: string) => void;
}) {
  const { form, pending, result, onSubmit } = useActionForm(
    couponSchema,
    async (v) => {
      const r = await saveCoupon(id, v);
      if (r.ok) onDone(r.message);
      return r;
    },
    defaults ?? {
      code: "",
      kind: "percent",
      amount: "",
      currency: "",
      courseId: "",
      expiresAt: "",
      maxRedemptions: "",
      isActive: true,
    },
  );
  const e = form.formState.errors;
  const kind = form.watch("kind");
  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="border-primary/40 bg-card grid gap-4 rounded-xl border-2 p-5 sm:grid-cols-2 lg:grid-cols-4"
    >
      {result && !result.ok && (
        <FormAlert kind="error" className="sm:col-span-2 lg:col-span-4">
          {result.error}
        </FormAlert>
      )}
      <FormField
        label="Code"
        registration={form.register("code")}
        error={e.code}
        className="font-mono"
      />
      <SelectField
        label="Type"
        registration={form.register("kind")}
        options={{ percent: "Percentage off", fixed: "Fixed amount off" }}
      />
      <FormField
        label={kind === "percent" ? "Percent (1–100)" : "Amount"}
        inputMode="decimal"
        registration={form.register("amount")}
        error={e.amount}
      />
      {kind === "fixed" && (
        <SelectField
          label="Currency"
          registration={form.register("currency")}
          options={[
            ["", "Choose…"],
            ["GHS", "GHS"],
            ["USD", "USD"],
          ]}
          error={e.currency}
        />
      )}
      <SelectField
        label="Course"
        registration={form.register("courseId")}
        options={[["", "Any course"], ...courses]}
      />
      <FormField
        label="Expires on (optional)"
        type="date"
        registration={form.register("expiresAt")}
        error={e.expiresAt}
      />
      <FormField
        label="Max uses (optional)"
        inputMode="numeric"
        registration={form.register("maxRedemptions")}
        error={e.maxRedemptions}
      />
      <label className="flex items-center gap-3 self-end pb-3 text-sm">
        <input type="checkbox" className="accent-primary size-5" {...form.register("isActive")} />{" "}
        Active
      </label>
      <div className="flex gap-2 sm:col-span-2 lg:col-span-4">
        <SubmitButton pending={pending} className="px-5">
          Save coupon
        </SubmitButton>
        <Button type="button" variant="ghost" size="lg" className="h-11" onClick={() => onDone()}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
