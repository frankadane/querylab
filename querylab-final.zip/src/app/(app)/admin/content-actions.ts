"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { type ActionResult, GENERIC_ERROR, invalid } from "@/lib/action-result";
import { audit } from "@/lib/audit";
import { requireRole } from "@/lib/auth";
import { slugify } from "@/lib/courses/format";
import { createClient } from "@/lib/supabase/server";
import { contentSchema } from "@/lib/validation/content";

type Kind = "posts" | "pages";
const RESERVED_PAGE_SLUGS = ["about", "privacy", "terms", "cookies"];

async function admin() {
  const current = await requireRole(["admin"], "/admin");
  return { ...current, supabase: await createClient() };
}

function refresh(kind: Kind, slug?: string) {
  revalidatePath(`/admin/${kind}`, "layout");
  if (kind === "posts") {
    revalidatePath("/resources", "layout");
    // Purge this post's own entry too, so a 404 cached while it was a draft doesn't linger.
    if (slug) revalidatePath(`/resources/${slug}`);
  } else if (slug) {
    revalidatePath(`/${slug}`);
  }
  revalidatePath("/sitemap.xml");
}

export async function createContent(kind: Kind, title: string): Promise<ActionResult> {
  const { supabase, profile } = await admin();
  const clean = title.trim().slice(0, 200);
  if (!clean) return { ok: false, error: "Enter a title." };
  const slug = `${slugify(clean) || "untitled"}-${Date.now().toString(36).slice(-4)}`;
  const { data, error } =
    kind === "posts"
      ? await supabase
          .from("posts")
          .insert({ title: clean, slug, author_id: profile.id })
          .select("id")
          .single()
      : await supabase
          .from("pages")
          .insert({ title: clean, slug, updated_by: profile.id })
          .select("id")
          .single();
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, `${kind.slice(0, -1)}.created`, { type: kind.slice(0, -1), id: data.id });
  redirect(`/admin/${kind}/${data.id}`);
}

export async function saveContent(kind: Kind, id: string, input: unknown): Promise<ActionResult> {
  const { supabase, profile } = await admin();
  const parsed = contentSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;

  const { data: before } = await supabase.from(kind).select("slug").eq("id", id).single();
  if (
    kind === "pages" &&
    before &&
    RESERVED_PAGE_SLUGS.includes(before.slug) &&
    v.slug !== before.slug
  ) {
    return {
      ok: false,
      error: "This page's address is used by the site navigation and can't be changed.",
      fieldErrors: { slug: ["Fixed for this page"] },
    };
  }
  const common = {
    title: v.title,
    slug: v.slug,
    body_md: v.bodyMd,
    status: v.status,
    seo_title: v.seoTitle,
    seo_description: v.seoDescription,
  };
  const { error } =
    kind === "posts"
      ? await supabase
          .from("posts")
          .update({ ...common, excerpt: v.excerpt, tags: v.tags, cover_alt: v.coverAlt })
          .eq("id", id)
      : await supabase
          .from("pages")
          .update({ ...common, updated_by: profile.id })
          .eq("id", id);
  if (error) {
    if (error.code === "23505")
      return {
        ok: false,
        error: "That URL slug is already used.",
        fieldErrors: { slug: ["Already used"] },
      };
    return { ok: false, error: GENERIC_ERROR };
  }
  await audit(
    supabase,
    `${kind.slice(0, -1)}.saved`,
    { type: kind.slice(0, -1), id },
    { status: v.status },
  );
  refresh(kind, v.slug);
  if (before?.slug && before.slug !== v.slug) refresh(kind, before.slug);
  return { ok: true, message: v.status === "published" ? "Saved and published." : "Draft saved." };
}

export async function deleteContent(kind: Kind, id: string): Promise<ActionResult> {
  const { supabase } = await admin();
  const { data } = await supabase.from(kind).select("slug").eq("id", id).single();
  if (kind === "pages" && data && RESERVED_PAGE_SLUGS.includes(data.slug))
    return { ok: false, error: "Core pages can't be deleted. Set them to draft instead." };
  const { error } = await supabase.from(kind).delete().eq("id", id);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, `${kind.slice(0, -1)}.deleted`, { type: kind.slice(0, -1), id });
  refresh(kind, data?.slug);
  redirect(`/admin/${kind}`);
}

/** Uploads an image for use in content; returns its public URL. */
export async function uploadContentImage(
  formData: FormData,
): Promise<ActionResult<{ url: string }>> {
  const { supabase } = await admin();
  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) return { ok: false, error: "Choose an image." };
  const ext = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" }[file.type];
  if (!ext) return { ok: false, error: "Use a PNG, JPEG or WebP image." };
  if (file.size > 5 * 1024 * 1024) return { ok: false, error: "Images must be 5 MB or smaller." };
  const path = `content/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage
    .from("course-media")
    .upload(path, file, { contentType: file.type });
  if (error) return { ok: false, error: GENERIC_ERROR };
  return {
    ok: true,
    data: { url: supabase.storage.from("course-media").getPublicUrl(path).data.publicUrl },
  };
}

export async function setPostCover(id: string, url: string | null): Promise<ActionResult> {
  const { supabase } = await admin();
  if (url && !url.includes("/storage/v1/object/public/course-media/"))
    return { ok: false, error: "Invalid image." };
  const { error } = await supabase.from("posts").update({ cover_url: url }).eq("id", id);
  if (error) return { ok: false, error: GENERIC_ERROR };
  refresh("posts");
  return { ok: true, message: url ? "Cover image set." : "Cover image removed." };
}

export async function setEnquiryStatus(
  id: string,
  status: "new" | "in_progress" | "closed",
): Promise<ActionResult> {
  const { supabase } = await admin();
  if (!["new", "in_progress", "closed"].includes(status))
    return { ok: false, error: "Invalid status." };
  const { error } = await supabase.from("enquiries").update({ status }).eq("id", id);
  if (error) return { ok: false, error: GENERIC_ERROR };
  revalidatePath("/admin/enquiries");
  return { ok: true, message: "Status updated." };
}
