import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/site/page-header";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Admin", robots: { index: false } };

export default async function AdminOverview() {
  const supabase = await createClient();
  const count = async (table: "profiles" | "courses" | "enrolments", filter?: [string, string]) => {
    let q = supabase.from(table).select("id", { count: "exact", head: true });
    if (filter) q = q.eq(filter[0], filter[1]);
    return (await q).count ?? 0;
  };
  const [students, instructors, admins, published, drafts, enrolments] = await Promise.all([
    count("profiles", ["role", "student"]),
    count("profiles", ["role", "instructor"]),
    count("profiles", ["role", "admin"]),
    count("courses", ["status", "published"]),
    count("courses", ["status", "draft"]),
    count("enrolments", ["status", "active"]),
  ]);
  const stats = [
    { label: "Students", value: students, href: "/admin/users?role=student" },
    { label: "Instructors", value: instructors, href: "/admin/users?role=instructor" },
    { label: "Admins", value: admins, href: "/admin/users?role=admin" },
    { label: "Published courses", value: published, href: "/studio/courses" },
    { label: "Draft courses", value: drafts, href: "/studio/courses" },
    { label: "Active enrolments", value: enrolments, href: "/admin/users" },
  ];
  return (
    <>
      <PageHeader
        title="Admin"
        description="Revenue, attendance and completion analytics arrive with payments and live classes."
      />
      <dl className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {stats.map((s) => (
          <div
            key={s.label}
            className="bg-card hover:border-primary/50 relative rounded-xl border p-5"
          >
            <dt className="text-muted-foreground text-sm">
              <Link href={s.href} className="after:absolute after:inset-0">
                {s.label}
              </Link>
            </dt>
            <dd className="tabular mt-1 font-mono text-3xl">{s.value}</dd>
          </div>
        ))}
      </dl>
    </>
  );
}
