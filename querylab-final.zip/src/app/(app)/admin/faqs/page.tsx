import type { Metadata } from "next";
import { PageHeader } from "@/components/site/page-header";
import { FaqManager } from "@/components/studio/faq-manager";
import { createClient } from "@/lib/supabase/server";
import { deleteSiteFaq, saveSiteFaq } from "../actions";

export const metadata: Metadata = { title: "Admin: FAQs", robots: { index: false } };

export default async function SiteFaqsPage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("faqs")
    .select("id, question, answer_md, is_published")
    .is("course_id", null)
    .order("position");
  return (
    <>
      <PageHeader title="Site FAQs" />
      <div className="mt-6">
        <FaqManager
          faqs={data ?? []}
          save={saveSiteFaq}
          remove={deleteSiteFaq}
          description="Shown on the home page. Course FAQs are edited in each course."
        />
      </div>
    </>
  );
}
