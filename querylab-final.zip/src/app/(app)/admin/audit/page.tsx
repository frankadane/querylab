import type { Metadata } from "next";
import { PageHeader } from "@/components/site/page-header";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Admin: audit log", robots: { index: false } };

export default async function AuditPage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("audit_log")
    .select(
      "id, action, target_type, target_id, metadata, created_at, actor:profiles(full_name, email)",
    )
    .order("created_at", { ascending: false })
    .limit(200);
  return (
    <>
      <PageHeader
        title="Audit log"
        description="The latest 200 staff actions. Entries can't be edited or deleted from the app."
      />
      <div className="bg-card mt-6 overflow-x-auto rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>When</TableHead>
              <TableHead>Who</TableHead>
              <TableHead>Action</TableHead>
              <TableHead>Target</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data?.map((e) => (
              <TableRow key={e.id}>
                <TableCell className="text-muted-foreground whitespace-nowrap">
                  <time dateTime={e.created_at}>
                    {new Date(e.created_at).toLocaleString("en-GB")}
                  </time>
                </TableCell>
                <TableCell>{e.actor?.full_name || e.actor?.email || "(deleted user)"}</TableCell>
                <TableCell className="font-mono text-sm">{e.action}</TableCell>
                <TableCell className="text-muted-foreground font-mono text-xs">
                  {e.target_type ? `${e.target_type}:${e.target_id?.slice(0, 8)}` : "—"}
                </TableCell>
              </TableRow>
            ))}
            {!data?.length && (
              <TableRow>
                <TableCell colSpan={4} className="text-muted-foreground py-10 text-center">
                  No actions recorded yet.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </>
  );
}
