import { NavLink } from "@/components/site/nav-link";
import { requireRole } from "@/lib/auth";

const NAV = [
  { href: "/admin", label: "Overview", exact: true },
  { href: "/admin/analytics", label: "Analytics" },
  { href: "/studio/courses", label: "Courses" },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/coupons", label: "Coupons" },
  { href: "/admin/users", label: "Users" },
  { href: "/admin/instructors", label: "Instructors" },
  { href: "/admin/enquiries", label: "Enquiries" },
  { href: "/admin/posts", label: "Blog" },
  { href: "/admin/pages", label: "Pages" },
  { href: "/admin/faqs", label: "Site FAQs" },
  { href: "/admin/testimonials", label: "Testimonials" },
  { href: "/admin/settings", label: "Settings" },
  { href: "/admin/audit", label: "Audit log" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireRole(["admin"], "/admin");
  return (
    <div className="mx-auto grid max-w-7xl grid-cols-1 gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[12rem_minmax(0,1fr)] lg:px-8">
      <nav aria-label="Admin" className="min-w-0 lg:sticky lg:top-24 lg:self-start">
        <ul className="flex gap-1 overflow-x-auto pb-2 lg:flex-col lg:pb-0">
          {NAV.map((n) => (
            <li key={n.href}>
              <NavLink
                href={n.href}
                exact={n.exact}
                className="aria-[current=page]:bg-secondary aria-[current=page]:text-secondary-foreground block whitespace-nowrap"
              >
                {n.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      <div className="min-w-0">{children}</div>
    </div>
  );
}
