import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/site/page-header";
import { NewContentForm } from "@/components/studio/new-content-form";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Admin: Pages", robots: { index: false } };

export default async function Page() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("pages")
    .select("id, title, slug, status, updated_at")
    .order("updated_at", { ascending: false });
  return (
    <>
      <PageHeader title="Pages" />
      <div className="mt-6">
        <NewContentForm kind="pages" />
      </div>
      <div className="bg-card mt-6 overflow-x-auto rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Address</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Updated</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data?.map((p) => (
              <TableRow key={p.id}>
                <TableCell>
                  <Link
                    href={`/admin/pages/${p.id}`}
                    className="text-primary font-medium underline-offset-4 hover:underline"
                  >
                    {p.title}
                  </Link>
                </TableCell>
                <TableCell className="text-muted-foreground font-mono text-xs">/{p.slug}</TableCell>
                <TableCell>
                  {p.status === "published" ? (
                    <Badge variant="secondary">Published</Badge>
                  ) : (
                    <Badge variant="outline">Draft</Badge>
                  )}
                </TableCell>
                <TableCell className="text-muted-foreground whitespace-nowrap">
                  {new Date(p.updated_at).toLocaleDateString("en-GB")}
                </TableCell>
              </TableRow>
            ))}
            {!data?.length && (
              <TableRow>
                <TableCell colSpan={4} className="text-muted-foreground py-10 text-center">
                  Nothing yet.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </>
  );
}
