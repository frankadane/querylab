import { ArrowLeft } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { ContentEditor } from "@/components/studio/content-editor";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Admin: edit", robots: { index: false } };

export default async function EditPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) notFound();
  const supabase = await createClient();
  const { data: p } = await supabase.from("pages").select("*").eq("id", id).maybeSingle();
  if (!p) notFound();
  const row = p as Record<string, unknown> & {
    title: string;
    slug: string;
    body_md: string;
    status: "draft" | "published";
    seo_title: string | null;
    seo_description: string | null;
  };
  return (
    <div className="grid gap-6">
      <Link
        href="/admin/pages"
        className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5 text-sm font-medium"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> Pages
      </Link>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h1 className="text-3xl font-semibold">{row.title}</h1>
        {row.status === "published" && (
          <Link href={`/${row.slug}`} className="text-primary text-sm font-medium underline">
            View on site
          </Link>
        )}
      </div>
      <ContentEditor
        kind="pages"
        id={id}
        publicPath="/"
        coverUrl={(row.cover_url as string | null) ?? null}
        defaults={{
          title: row.title,
          slug: row.slug,
          excerpt: (row.excerpt as string | null) ?? "",
          bodyMd: row.body_md,
          tags: ((row.tags as string[] | undefined) ?? []).join(", "),
          status: row.status,
          seoTitle: row.seo_title ?? "",
          seoDescription: row.seo_description ?? "",
          coverAlt: (row.cover_alt as string | null) ?? "",
        }}
      />
    </div>
  );
}
