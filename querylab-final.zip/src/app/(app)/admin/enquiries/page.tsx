import type { Metadata } from "next";
import { PageHeader } from "@/components/site/page-header";
import { Badge } from "@/components/ui/badge";
import { createClient } from "@/lib/supabase/server";
import { EnquiryStatus } from "./enquiry-status";

export const metadata: Metadata = { title: "Admin: enquiries", robots: { index: false } };

export default async function EnquiriesPage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("enquiries")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(200);
  return (
    <>
      <PageHeader
        title="Enquiries"
        description="Messages from the contact and corporate training forms. Reply by email, then update the status."
      />
      <ul className="mt-6 grid gap-4">
        {data?.map((q) => (
          <li key={q.id} className="bg-card rounded-xl border p-5">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant={q.kind === "corporate" ? "secondary" : "outline"}>
                {q.kind === "corporate" ? "Corporate" : "Contact"}
              </Badge>
              <span className="font-semibold">{q.name}</span>
              <a
                href={`mailto:${q.email}?subject=${encodeURIComponent("Re: your QueryLab enquiry")}`}
                className="text-primary text-sm font-medium underline"
              >
                {q.email}
              </a>
              <time className="text-muted-foreground ml-auto text-sm" dateTime={q.created_at}>
                {new Date(q.created_at).toLocaleString("en-GB")}
              </time>
            </div>
            {(q.company || q.team_size || q.topic) && (
              <p className="text-muted-foreground mt-2 text-sm">
                {[q.company, q.team_size && `Team: ${q.team_size}`, q.topic]
                  .filter(Boolean)
                  .join(" · ")}
              </p>
            )}
            <p className="mt-3 whitespace-pre-line">{q.message}</p>
            <div className="mt-4">
              <EnquiryStatus id={q.id} status={q.status} />
            </div>
          </li>
        ))}
        {!data?.length && (
          <li className="text-muted-foreground rounded-xl border border-dashed p-10 text-center">
            No enquiries yet.
          </li>
        )}
      </ul>
    </>
  );
}
