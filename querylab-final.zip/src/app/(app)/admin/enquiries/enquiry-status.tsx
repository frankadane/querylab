"use client";

import { useId } from "react";
import { useAction } from "@/components/forms/use-action";
import { setEnquiryStatus } from "../content-actions";

export function EnquiryStatus({
  id,
  status,
}: {
  id: string;
  status: "new" | "in_progress" | "closed";
}) {
  const { pending, result, run } = useAction();
  const sid = useId();
  return (
    <div className="flex flex-wrap items-center gap-2 text-sm">
      <label htmlFor={sid} className="font-medium">
        Status
      </label>
      <select
        id={sid}
        defaultValue={status}
        disabled={pending}
        onChange={(e) => run(() => setEnquiryStatus(id, e.target.value as typeof status))}
        className="border-input bg-background h-9 rounded-lg border px-2"
      >
        <option value="new">New</option>
        <option value="in_progress">In progress</option>
        <option value="closed">Closed</option>
      </select>
      <span aria-live="polite" className="text-muted-foreground">
        {result ? (result.ok ? "Saved" : result.error) : ""}
      </span>
    </div>
  );
}
