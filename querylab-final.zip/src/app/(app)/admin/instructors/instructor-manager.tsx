"use client";

import { Pencil, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { MarkdownField } from "@/components/forms/markdown-field";
import { SelectField } from "@/components/forms/select-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useAction } from "@/components/forms/use-action";
import { useActionForm } from "@/components/forms/use-action-form";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { slugify } from "@/lib/courses/format";
import { type InstructorInput, instructorSchema } from "@/lib/validation/admin";
import { deleteInstructor, saveInstructor } from "../actions";

type Instructor = {
  id: string;
  display_name: string;
  slug: string;
  headline: string | null;
  bio_md: string | null;
  profile_id: string | null;
  is_published: boolean;
  is_placeholder: boolean;
  courseCount: number;
};

export function InstructorManager({
  instructors,
  accounts,
}: {
  instructors: Instructor[];
  accounts: [string, string][];
}) {
  const [editing, setEditing] = useState<string | null>(null);
  const { pending, result, run } = useAction();
  const [notice, setNotice] = useState<string | null>(null);
  return (
    <div className="grid gap-4">
      <Button
        size="lg"
        className="h-10 justify-self-start px-4"
        onClick={() => setEditing("new")}
        disabled={editing === "new"}
      >
        <Plus aria-hidden="true" /> Add instructor
      </Button>
      <div aria-live="polite">
        {notice && <FormAlert kind="success">{notice}</FormAlert>}
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
      {editing === "new" && (
        <InstructorForm
          accounts={accounts}
          onDone={(m) => {
            setEditing(null);
            if (m) setNotice(m);
          }}
        />
      )}
      <ul className="grid gap-3">
        {instructors.map((i) =>
          editing === i.id ? (
            <li key={i.id}>
              <InstructorForm
                id={i.id}
                accounts={accounts}
                onDone={(m) => {
                  setEditing(null);
                  if (m) setNotice(m);
                }}
                defaults={{
                  displayName: i.display_name,
                  slug: i.slug,
                  headline: i.headline ?? "",
                  bioMd: i.bio_md ?? "",
                  profileId: i.profile_id ?? "",
                  isPublished: i.is_published,
                  isPlaceholder: i.is_placeholder,
                }}
              />
            </li>
          ) : (
            <li
              key={i.id}
              className="bg-card flex flex-wrap items-center gap-3 rounded-xl border p-4"
            >
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{i.display_name}</p>
                <p className="text-muted-foreground text-sm">
                  {i.courseCount} {i.courseCount === 1 ? "course" : "courses"} ·{" "}
                  {i.profile_id ? "Linked to an account" : "No linked account"}
                </p>
              </div>
              {i.is_placeholder && (
                <Badge variant="outline" className="border-highlight text-highlight-text">
                  Placeholder
                </Badge>
              )}
              {!i.is_published && <Badge variant="outline">Hidden</Badge>}
              <Button
                variant="ghost"
                size="icon-lg"
                className="size-10"
                aria-label={`Edit ${i.display_name}`}
                onClick={() => setEditing(i.id)}
              >
                <Pencil className="size-4" aria-hidden="true" />
              </Button>
              <Button
                variant="ghost"
                size="icon-lg"
                className="text-destructive size-10"
                aria-label={`Delete ${i.display_name}`}
                disabled={pending}
                onClick={() => {
                  if (confirm(`Delete ${i.display_name}? Their courses will have no instructor.`))
                    run(() => deleteInstructor(i.id));
                }}
              >
                <Trash2 className="size-4" aria-hidden="true" />
              </Button>
            </li>
          ),
        )}
      </ul>
    </div>
  );
}

function InstructorForm({
  id,
  accounts,
  defaults,
  onDone,
}: {
  id?: string;
  accounts: [string, string][];
  defaults?: InstructorInput;
  onDone: (message?: string) => void;
}) {
  const { form, pending, result, onSubmit } = useActionForm(
    instructorSchema,
    async (v) => {
      const r = await saveInstructor(id ?? null, v);
      if (r.ok) onDone(r.message);
      return r;
    },
    defaults ?? {
      displayName: "",
      slug: "",
      headline: "",
      bioMd: "",
      profileId: "",
      isPublished: true,
      isPlaceholder: false,
    },
  );
  const { errors } = form.formState;
  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="border-primary/40 bg-card grid gap-4 rounded-xl border-2 p-5 sm:grid-cols-2"
    >
      {result && !result.ok && (
        <FormAlert kind="error" className="sm:col-span-2">
          {result.error}
        </FormAlert>
      )}
      <FormField
        label="Display name"
        registration={form.register("displayName", {
          onBlur: (e) => {
            if (!form.getValues("slug")) form.setValue("slug", slugify(e.target.value));
          },
        })}
        error={errors.displayName}
      />
      <FormField label="URL slug" registration={form.register("slug")} error={errors.slug} />
      <FormField
        label="Headline"
        hint="e.g. Senior data analyst, 10 years in retail analytics"
        registration={form.register("headline")}
        error={errors.headline}
        className="sm:col-span-2"
      />
      <div className="sm:col-span-2">
        <MarkdownField
          label="Bio"
          rows={6}
          registration={form.register("bioMd")}
          value={form.watch("bioMd") ?? ""}
          error={errors.bioMd}
          hint="Use only real, verified information."
        />
      </div>
      <SelectField
        label="Linked user account"
        registration={form.register("profileId")}
        options={[["", "Not linked"], ...accounts]}
        error={errors.profileId}
        hint="Only instructor/admin accounts are listed."
      />
      <div className="grid content-end gap-3 text-sm">
        <label className="flex items-center gap-3">
          <input
            type="checkbox"
            className="accent-primary size-5"
            {...form.register("isPublished")}
          />{" "}
          Show on the public site
        </label>
        <label className="flex items-center gap-3">
          <input
            type="checkbox"
            className="accent-primary size-5"
            {...form.register("isPlaceholder")}
          />{" "}
          Mark as placeholder
        </label>
      </div>
      <div className="flex gap-2 sm:col-span-2">
        <SubmitButton pending={pending} className="px-5">
          Save instructor
        </SubmitButton>
        <Button type="button" variant="ghost" size="lg" className="h-11" onClick={() => onDone()}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
