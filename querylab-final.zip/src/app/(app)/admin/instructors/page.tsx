import type { Metadata } from "next";
import { PageHeader } from "@/components/site/page-header";
import { createClient } from "@/lib/supabase/server";
import { InstructorManager } from "./instructor-manager";

export const metadata: Metadata = { title: "Admin: instructors", robots: { index: false } };

export default async function InstructorsAdminPage() {
  const supabase = await createClient();
  const [{ data: instructors }, { data: staff }] = await Promise.all([
    supabase.from("instructors").select("*, courses(id)").order("display_name"),
    supabase
      .from("profiles")
      .select("id, full_name, email")
      .in("role", ["instructor", "admin"])
      .order("full_name"),
  ]);
  return (
    <>
      <PageHeader
        title="Instructors"
        description="Public instructor profiles. Link one to a user account so that person can edit their own courses."
      />
      <div className="mt-6">
        <InstructorManager
          instructors={(instructors ?? []).map((i) => ({ ...i, courseCount: i.courses.length }))}
          accounts={(staff ?? []).map(
            (s) => [s.id, `${s.full_name || s.email} (${s.email})`] as [string, string],
          )}
        />
      </div>
    </>
  );
}
