"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { type ActionResult, GENERIC_ERROR, invalid } from "@/lib/action-result";
import { audit } from "@/lib/audit";
import { requireRole } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { ROLE, instructorSchema, settingsSchema, testimonialSchema } from "@/lib/validation/admin";
import { faqSchema } from "@/lib/validation/courses";

const uuid = z.string().uuid();

async function admin() {
  const current = await requireRole(["admin"], "/admin");
  return { ...current, supabase: await createClient() };
}

// --------------------------------------------------------------------------- users

export async function setUserRole(userId: string, role: unknown): Promise<ActionResult> {
  const { supabase, profile } = await admin();
  const r = ROLE.safeParse(role);
  if (!r.success || !uuid.safeParse(userId).success)
    return { ok: false, error: "Invalid request." };
  if (userId === profile.id) return { ok: false, error: "You can't change your own role." };

  const { data: before } = await supabase.from("profiles").select("role").eq("id", userId).single();
  const { error } = await supabase.from("profiles").update({ role: r.data }).eq("id", userId);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(
    supabase,
    "user.role_changed",
    { type: "profile", id: userId },
    { from: before?.role, to: r.data },
  );
  revalidatePath(`/admin/users/${userId}`);
  revalidatePath("/admin/users");
  return { ok: true, message: `Role changed to ${r.data}.` };
}

/** Suspension blocks sign-in at the auth server (ban) and removes elevated access via RLS. */
export async function setUserSuspended(userId: string, suspended: boolean): Promise<ActionResult> {
  const { supabase, profile } = await admin();
  if (!uuid.safeParse(userId).success) return { ok: false, error: "Invalid request." };
  if (userId === profile.id) return { ok: false, error: "You can't suspend yourself." };

  const { error } = await supabase
    .from("profiles")
    .update({ suspended_at: suspended ? new Date().toISOString() : null })
    .eq("id", userId);
  if (error) return { ok: false, error: GENERIC_ERROR };

  const { error: banError } = await createAdminClient().auth.admin.updateUserById(userId, {
    ban_duration: suspended ? "876000h" : "none",
  });
  if (banError) console.error("[admin] ban", banError.message);

  await audit(supabase, suspended ? "user.suspended" : "user.unsuspended", {
    type: "profile",
    id: userId,
  });
  revalidatePath(`/admin/users/${userId}`);
  revalidatePath("/admin/users");
  return {
    ok: true,
    message: suspended ? "User suspended. They can no longer sign in." : "Suspension lifted.",
  };
}

export async function enrolUser(userId: string, courseId: string): Promise<ActionResult> {
  const { supabase } = await admin();
  if (!uuid.safeParse(userId).success || !uuid.safeParse(courseId).success)
    return { ok: false, error: "Choose a course." };
  const { error } = await supabase
    .from("enrolments")
    .upsert(
      { user_id: userId, course_id: courseId, source: "manual", status: "active" },
      { onConflict: "user_id,course_id" },
    );
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(
    supabase,
    "enrolment.manual_added",
    { type: "profile", id: userId },
    { course_id: courseId },
  );
  revalidatePath(`/admin/users/${userId}`);
  return { ok: true, message: "User enrolled." };
}

export async function setEnrolmentStatus(
  enrolmentId: string,
  status: "active" | "revoked",
): Promise<ActionResult> {
  const { supabase } = await admin();
  if (!uuid.safeParse(enrolmentId).success || !["active", "revoked"].includes(status))
    return { ok: false, error: "Invalid request." };
  const { data, error } = await supabase
    .from("enrolments")
    .update({ status })
    .eq("id", enrolmentId)
    .select("user_id, course_id");
  if (error || !data?.length) return { ok: false, error: GENERIC_ERROR };
  await audit(
    supabase,
    status === "revoked" ? "enrolment.revoked" : "enrolment.restored",
    { type: "enrolment", id: enrolmentId },
    data[0],
  );
  revalidatePath(`/admin/users/${data[0].user_id}`);
  return { ok: true, message: status === "revoked" ? "Access removed." : "Access restored." };
}

// --------------------------------------------------------------------------- instructors

export async function saveInstructor(id: string | null, input: unknown): Promise<ActionResult> {
  const { supabase } = await admin();
  const parsed = instructorSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;
  const row = {
    display_name: v.displayName,
    slug: v.slug,
    headline: v.headline,
    bio_md: v.bioMd || null,
    profile_id: v.profileId,
    is_published: v.isPublished,
    is_placeholder: v.isPlaceholder,
  };
  const res = id
    ? await supabase.from("instructors").update(row).eq("id", id).select("id")
    : await supabase.from("instructors").insert(row).select("id");
  if (res.error) {
    if (res.error.code === "23505") {
      const field = res.error.message.includes("profile_id") ? "profileId" : "slug";
      return {
        ok: false,
        error: "That value is already used.",
        fieldErrors: { [field]: ["Already used by another instructor"] },
      };
    }
    return { ok: false, error: GENERIC_ERROR };
  }
  await audit(supabase, id ? "instructor.updated" : "instructor.created", {
    type: "instructor",
    id: res.data[0].id,
  });
  revalidatePath("/admin/instructors");
  revalidatePath("/instructors");
  revalidatePath("/courses", "layout");
  return { ok: true, message: "Instructor saved." };
}

export async function deleteInstructor(id: string): Promise<ActionResult> {
  const { supabase } = await admin();
  const { error } = await supabase.from("instructors").delete().eq("id", id);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, "instructor.deleted", { type: "instructor", id });
  revalidatePath("/admin/instructors");
  revalidatePath("/instructors");
  return { ok: true, message: "Instructor deleted. Their courses now have no instructor." };
}

// --------------------------------------------------------------------------- site FAQs

export async function saveSiteFaq(id: string | null, input: unknown): Promise<ActionResult> {
  const { supabase } = await admin();
  const parsed = faqSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const row = {
    question: parsed.data.question,
    answer_md: parsed.data.answerMd,
    is_published: parsed.data.isPublished,
  };
  let error;
  if (id) ({ error } = await supabase.from("faqs").update(row).eq("id", id).is("course_id", null));
  else {
    const { count } = await supabase
      .from("faqs")
      .select("id", { count: "exact", head: true })
      .is("course_id", null);
    ({ error } = await supabase
      .from("faqs")
      .insert({ ...row, course_id: null, position: (count ?? 0) + 1 }));
  }
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, id ? "faq.updated" : "faq.created", id ? { type: "faq", id } : undefined);
  revalidatePath("/admin/faqs");
  revalidatePath("/");
  return { ok: true, message: "FAQ saved." };
}

export async function deleteSiteFaq(id: string): Promise<ActionResult> {
  const { supabase } = await admin();
  const { error } = await supabase.from("faqs").delete().eq("id", id).is("course_id", null);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, "faq.deleted", { type: "faq", id });
  revalidatePath("/admin/faqs");
  revalidatePath("/");
  return { ok: true, message: "FAQ deleted." };
}

// --------------------------------------------------------------------------- testimonials

export async function saveTestimonial(id: string | null, input: unknown): Promise<ActionResult> {
  const { supabase } = await admin();
  const parsed = testimonialSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;
  const row = {
    quote: v.quote,
    author_name: v.authorName,
    author_title: v.authorTitle,
    course_id: v.courseId,
    is_published: v.isPublished,
  };
  const res = id
    ? await supabase.from("testimonials").update(row).eq("id", id).select("id")
    : await supabase.from("testimonials").insert(row).select("id");
  if (res.error || !res.data?.length) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, id ? "testimonial.updated" : "testimonial.created", {
    type: "testimonial",
    id: res.data[0].id,
  });
  revalidatePath("/admin/testimonials");
  revalidatePath("/");
  return { ok: true, message: "Testimonial saved." };
}

export async function deleteTestimonial(id: string): Promise<ActionResult> {
  const { supabase } = await admin();
  const { error } = await supabase.from("testimonials").delete().eq("id", id);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, "testimonial.deleted", { type: "testimonial", id });
  revalidatePath("/admin/testimonials");
  return { ok: true, message: "Testimonial deleted." };
}

// --------------------------------------------------------------------------- settings

export async function saveSettings(input: unknown): Promise<ActionResult> {
  const { supabase } = await admin();
  const parsed = settingsSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;
  const { error } = await supabase
    .from("site_settings")
    .update({
      brand_name: v.brandName,
      contact_email: v.contactEmail,
      contact_phone: v.contactPhone,
      address: v.address,
      default_currency: v.defaultCurrency,
      default_timezone: v.defaultTimezone,
      bank_details: {
        account_name: v.bank.accountName,
        bank_name: v.bank.bankName,
        account_number: v.bank.accountNumber,
        branch: v.bank.branch,
        swift: v.bank.swift,
        iban: v.bank.iban,
        instructions: v.bank.instructions,
      },
      social_links: v.social,
      invoice_company_name: v.invoice.companyName,
      invoice_company_address: v.invoice.companyAddress,
      invoice_tax_id: v.invoice.taxId || null,
      invoice_footer: v.invoice.footer,
    })
    .eq("id", 1);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, "settings.updated", { type: "site_settings", id: "1" });
  revalidatePath("/", "layout");
  return { ok: true, message: "Settings saved." };
}
