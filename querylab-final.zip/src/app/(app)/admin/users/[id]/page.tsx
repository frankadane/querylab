import { ArrowLeft } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { EnrolmentManager, RoleAndStatus } from "./user-controls";

export const metadata: Metadata = { title: "Admin: user", robots: { index: false } };

export default async function UserDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) notFound();
  const { profile: me } = await requireRole(["admin"]);
  const supabase = await createClient();
  const [{ data: user }, { data: enrolments }, { data: courses }, { data: log }] =
    await Promise.all([
      supabase.from("profiles").select("*").eq("id", id).maybeSingle(),
      supabase
        .from("enrolments")
        .select("id, status, source, created_at, course:courses(id, title)")
        .eq("user_id", id)
        .order("created_at", { ascending: false }),
      supabase.from("courses").select("id, title").neq("status", "archived").order("title"),
      supabase
        .from("audit_log")
        .select("id, action, created_at, metadata")
        .eq("target_id", id)
        .order("created_at", { ascending: false })
        .limit(20),
    ]);
  if (!user) notFound();

  return (
    <div className="grid gap-10">
      <Link
        href="/admin/users"
        className="text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5 text-sm font-medium"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> All users
      </Link>
      <header>
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="text-3xl font-semibold">{user.full_name || "(no name)"}</h1>
          {user.suspended_at && <Badge variant="destructive">Suspended</Badge>}
          {user.is_demo && <Badge variant="outline">Demo</Badge>}
        </div>
        <dl className="text-muted-foreground mt-3 grid gap-x-8 gap-y-1 text-sm sm:grid-cols-[auto_1fr]">
          <dt>Email</dt>
          <dd className="text-foreground">{user.email}</dd>
          <dt>Timezone</dt>
          <dd className="text-foreground font-mono">{user.timezone}</dd>
          <dt>Joined</dt>
          <dd className="text-foreground">{new Date(user.created_at).toLocaleString("en-GB")}</dd>
        </dl>
      </header>

      <RoleAndStatus
        userId={user.id}
        role={user.role}
        suspended={!!user.suspended_at}
        isSelf={user.id === me.id}
      />

      <EnrolmentManager
        userId={user.id}
        courses={courses ?? []}
        enrolments={(enrolments ?? []).map((e) => ({
          id: e.id,
          status: e.status,
          source: e.source,
          createdAt: e.created_at,
          courseTitle: e.course?.title ?? "(deleted course)",
        }))}
      />

      <section aria-labelledby="history-h">
        <h2 id="history-h" className="text-lg font-semibold">
          Admin history
        </h2>
        {log?.length ? (
          <ol className="bg-card mt-3 divide-y rounded-xl border text-sm">
            {log.map((l) => (
              <li key={l.id} className="flex flex-wrap justify-between gap-2 px-4 py-3">
                <span className="font-mono">{l.action}</span>
                <time className="text-muted-foreground" dateTime={l.created_at}>
                  {new Date(l.created_at).toLocaleString("en-GB")}
                </time>
              </li>
            ))}
          </ol>
        ) : (
          <p className="text-muted-foreground mt-3 text-sm">
            No admin actions recorded for this user.
          </p>
        )}
      </section>
    </div>
  );
}
