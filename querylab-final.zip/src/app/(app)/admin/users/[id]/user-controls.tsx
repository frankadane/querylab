"use client";

import { useId, useState } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { useAction } from "@/components/forms/use-action";
import { Button } from "@/components/ui/button";
import { enrolUser, setEnrolmentStatus, setUserRole, setUserSuspended } from "../../actions";

export function RoleAndStatus({
  userId,
  role,
  suspended,
  isSelf,
}: {
  userId: string;
  role: string;
  suspended: boolean;
  isSelf: boolean;
}) {
  const { pending, result, run } = useAction();
  const [value, setValue] = useState(role);
  const id = useId();
  return (
    <section aria-labelledby={`${id}-h`} className="bg-card grid gap-4 rounded-xl border p-5">
      <h2 id={`${id}-h`} className="text-lg font-semibold">
        Role &amp; access
      </h2>
      {isSelf && (
        <p className="text-muted-foreground text-sm">
          You can&apos;t change your own role or suspend yourself.
        </p>
      )}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
        <div className="grid gap-1.5">
          <label htmlFor={`${id}-role`} className="text-sm font-medium">
            Role
          </label>
          <select
            id={`${id}-role`}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            disabled={isSelf}
            className="border-input bg-background h-11 rounded-lg border px-3"
          >
            <option value="student">Student</option>
            <option value="instructor">Instructor</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <Button
          size="lg"
          className="h-11 px-4"
          disabled={isSelf || pending || value === role}
          onClick={() => run(() => setUserRole(userId, value))}
        >
          Save role
        </Button>
        <div className="sm:ml-auto">
          <Button
            variant={suspended ? "outline" : "destructive"}
            size="lg"
            className="h-11 px-4"
            disabled={isSelf || pending}
            onClick={() => {
              if (
                suspended ||
                confirm("Suspend this user? They will be signed out and unable to log in.")
              )
                run(() => setUserSuspended(userId, !suspended));
            }}
          >
            {suspended ? "Lift suspension" : "Suspend user"}
          </Button>
        </div>
      </div>
      <div aria-live="polite">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </section>
  );
}

type Enrolment = {
  id: string;
  status: "active" | "revoked";
  source: string;
  createdAt: string;
  courseTitle: string;
};

export function EnrolmentManager({
  userId,
  courses,
  enrolments,
}: {
  userId: string;
  courses: { id: string; title: string }[];
  enrolments: Enrolment[];
}) {
  const { pending, result, run } = useAction();
  const [courseId, setCourseId] = useState("");
  const id = useId();
  return (
    <section aria-labelledby={`${id}-h`} className="grid gap-4">
      <h2 id={`${id}-h`} className="text-lg font-semibold">
        Enrolments
      </h2>
      {enrolments.length ? (
        <ul className="bg-card divide-y rounded-xl border">
          {enrolments.map((e) => (
            <li key={e.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
              <div className="min-w-0 flex-1">
                <p className="font-medium">{e.courseTitle}</p>
                <p className="text-muted-foreground text-xs">
                  {e.status === "active" ? "Active" : "Revoked"} · via {e.source} ·{" "}
                  {new Date(e.createdAt).toLocaleDateString("en-GB")}
                </p>
              </div>
              <Button
                variant="outline"
                size="lg"
                className="h-9 px-3"
                disabled={pending}
                onClick={() =>
                  run(() => setEnrolmentStatus(e.id, e.status === "active" ? "revoked" : "active"))
                }
              >
                {e.status === "active" ? "Remove access" : "Restore access"}
                <span className="sr-only"> to {e.courseTitle}</span>
              </Button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-muted-foreground text-sm">Not enrolled in any course.</p>
      )}
      <div className="flex flex-col gap-3 rounded-xl border border-dashed p-4 sm:flex-row sm:items-end">
        <div className="grid flex-1 gap-1.5">
          <label htmlFor={`${id}-course`} className="text-sm font-medium">
            Enrol in a course (manual)
          </label>
          <select
            id={`${id}-course`}
            value={courseId}
            onChange={(e) => setCourseId(e.target.value)}
            className="border-input bg-background h-11 rounded-lg border px-3"
          >
            <option value="">Choose a course…</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title}
              </option>
            ))}
          </select>
        </div>
        <Button
          size="lg"
          className="h-11 px-4"
          disabled={!courseId || pending}
          onClick={() =>
            run(
              () => enrolUser(userId, courseId),
              () => setCourseId(""),
            )
          }
        >
          Enrol user
        </Button>
      </div>
      <div aria-live="polite">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </section>
  );
}
