import type { Metadata } from "next";
import Link from "next/link";
import { z } from "zod";
import { PageHeader } from "@/components/site/page-header";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Admin: users", robots: { index: false } };
const PAGE_SIZE = 25;

const params = z.object({
  q: z.string().trim().max(100).optional().catch(undefined),
  role: z.enum(["student", "instructor", "admin"]).optional().catch(undefined),
  page: z.coerce.number().int().min(1).max(1000).catch(1).default(1),
});

export default async function UsersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string>>;
}) {
  const sp = await searchParams;
  const { q, role, page } = params.parse(
    Object.fromEntries(Object.entries(sp).filter(([, v]) => v !== "")),
  );
  const supabase = await createClient();

  let query = supabase
    .from("profiles")
    .select("id, full_name, email, role, suspended_at, created_at, is_demo", { count: "exact" })
    .order("created_at", { ascending: false })
    .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);
  if (role) query = query.eq("role", role);
  if (q) {
    // Escape PostgREST filter syntax and LIKE wildcards in user input.
    const safe = q.replace(/[%_\\]/g, (m) => `\\${m}`).replace(/[,()]/g, " ");
    query = query.or(`full_name.ilike.%${safe}%,email.ilike.%${safe}%`);
  }
  const { data: users, count } = await query;
  const pages = Math.max(1, Math.ceil((count ?? 0) / PAGE_SIZE));
  const qs = (p: number) =>
    `?${new URLSearchParams({ ...(q ? { q } : {}), ...(role ? { role } : {}), page: String(p) })}`;

  return (
    <>
      <PageHeader
        title="Users"
        description={`${count ?? 0} ${role ? `${role}s` : "users"}${q ? ` matching “${q}”` : ""}`}
      />
      <form
        role="search"
        aria-label="Filter users"
        className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-end"
      >
        <div className="grid flex-1 gap-1.5">
          <label htmlFor="q" className="text-sm font-medium">
            Search name or email
          </label>
          <input
            id="q"
            name="q"
            type="search"
            defaultValue={q}
            className="border-input bg-background h-11 rounded-lg border px-3"
          />
        </div>
        <div className="grid gap-1.5">
          <label htmlFor="role" className="text-sm font-medium">
            Role
          </label>
          <select
            id="role"
            name="role"
            defaultValue={role ?? ""}
            className="border-input bg-background h-11 rounded-lg border px-3"
          >
            <option value="">All roles</option>
            <option value="student">Student</option>
            <option value="instructor">Instructor</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <Button type="submit" size="lg" className="h-11 px-5">
          Search
        </Button>
      </form>

      <div className="bg-card mt-6 overflow-x-auto rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Joined</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users?.map((u) => (
              <TableRow key={u.id}>
                <TableCell>
                  <Link
                    href={`/admin/users/${u.id}`}
                    className="text-primary font-medium underline-offset-4 hover:underline"
                  >
                    {u.full_name || "(no name)"}
                  </Link>
                  {u.is_demo && (
                    <Badge variant="outline" className="ml-2">
                      Demo
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-muted-foreground">{u.email}</TableCell>
                <TableCell className="capitalize">{u.role}</TableCell>
                <TableCell>
                  {u.suspended_at ? (
                    <Badge variant="destructive">Suspended</Badge>
                  ) : (
                    <span className="text-muted-foreground">Active</span>
                  )}
                </TableCell>
                <TableCell className="text-muted-foreground whitespace-nowrap">
                  {new Date(u.created_at).toLocaleDateString("en-GB", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                  })}
                </TableCell>
              </TableRow>
            ))}
            {!users?.length && (
              <TableRow>
                <TableCell colSpan={5} className="text-muted-foreground py-10 text-center">
                  No users found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      {pages > 1 && (
        <nav aria-label="Pagination" className="mt-4 flex items-center justify-between text-sm">
          <span className="text-muted-foreground">
            Page {page} of {pages}
          </span>
          <div className="flex gap-2">
            {page > 1 && (
              <Button asChild variant="outline" size="lg" className="h-10">
                <Link href={qs(page - 1)}>Previous</Link>
              </Button>
            )}
            {page < pages && (
              <Button asChild variant="outline" size="lg" className="h-10">
                <Link href={qs(page + 1)}>Next</Link>
              </Button>
            )}
          </div>
        </nav>
      )}
    </>
  );
}
