"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { type ActionResult, GENERIC_ERROR, invalid } from "@/lib/action-result";
import { audit } from "@/lib/audit";
import { requireRole } from "@/lib/auth";
import { formatPrice } from "@/lib/courses/format";
import { sendEmail } from "@/lib/email";
import { publicEnv } from "@/lib/env";
import type { Order } from "@/lib/payments/types";
import { createClient } from "@/lib/supabase/server";
import { couponSchema } from "@/lib/validation/payments";

const uuid = z.string().uuid();
const note = z.string().trim().max(1000).optional();

async function admin() {
  await requireRole(["admin"], "/admin/orders");
  return createClient();
}

function refresh() {
  revalidatePath("/admin/orders");
  revalidatePath("/orders", "layout");
  revalidatePath("/admin/analytics");
}

export async function markOrderPaid(orderId: string, adminNote?: string): Promise<ActionResult> {
  const supabase = await admin();
  if (!uuid.safeParse(orderId).success || !note.safeParse(adminNote).success)
    return { ok: false, error: "Invalid request." };
  const { data, error } = await supabase.rpc("mark_order_paid", {
    p_order_id: orderId,
    p_note: adminNote || undefined,
  });
  if (error) return { ok: false, error: error.code === "P0001" ? error.message : GENERIC_ERROR };
  const o = data as unknown as Order;
  const { data: c } = await supabase.from("courses").select("slug").eq("id", o.course_id).single();
  await sendEmail({
    to: o.billing_email,
    subject: `Payment received: ${o.course_title}`,
    text: [
      `We've received your payment of ${formatPrice(o.total_minor, o.currency)} for ${o.course_title}. Thank you!`,
      "",
      `Invoice ${o.invoice_number}: ${publicEnv.NEXT_PUBLIC_SITE_URL}/orders/${o.reference}/invoice`,
      `Start learning: ${publicEnv.NEXT_PUBLIC_SITE_URL}/learn/${c?.slug}`,
      "",
      "QueryLab",
    ].join("\n"),
  });
  await audit(
    supabase,
    "order.marked_paid",
    { type: "order", id: orderId },
    { reference: o.reference, invoice: o.invoice_number },
  );
  refresh();
  return {
    ok: true,
    message: `${o.reference} marked as paid. Invoice ${o.invoice_number} emailed and access granted.`,
  };
}

export async function adminCancelOrder(orderId: string): Promise<ActionResult> {
  const supabase = await admin();
  const { data, error } = await supabase.rpc("cancel_order", { p_order_id: orderId });
  if (error) return { ok: false, error: error.code === "P0001" ? error.message : GENERIC_ERROR };
  await audit(
    supabase,
    "order.cancelled",
    { type: "order", id: orderId },
    { reference: (data as unknown as Order).reference },
  );
  refresh();
  return { ok: true, message: "Order cancelled." };
}

export async function refundOrder(orderId: string, adminNote?: string): Promise<ActionResult> {
  const supabase = await admin();
  if (!uuid.safeParse(orderId).success || !note.safeParse(adminNote).success)
    return { ok: false, error: "Invalid request." };
  const { data, error } = await supabase.rpc("refund_order", {
    p_order_id: orderId,
    p_note: adminNote || undefined,
  });
  if (error) return { ok: false, error: error.code === "P0001" ? error.message : GENERIC_ERROR };
  const o = data as unknown as Order;
  await sendEmail({
    to: o.billing_email,
    subject: `Refund processed: ${o.course_title}`,
    text: `Your order ${o.reference} for ${o.course_title} has been refunded (${formatPrice(o.total_minor, o.currency)}). Your access to the course has ended.\n\nQueryLab`,
  });
  await audit(
    supabase,
    "order.refunded",
    { type: "order", id: orderId },
    { reference: o.reference },
  );
  refresh();
  return { ok: true, message: `${o.reference} refunded and access removed.` };
}

// --------------------------------------------------------------------------- coupons

export async function saveCoupon(id: string | null, input: unknown): Promise<ActionResult> {
  const supabase = await admin();
  const parsed = couponSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;
  const row = {
    code: v.code,
    kind: v.kind,
    amount: v.kind === "percent" ? Number(v.amount) : Math.round(Number(v.amount) * 100),
    currency: v.kind === "fixed" ? (v.currency as "GHS" | "USD") : null,
    course_id: v.courseId || null,
    expires_at: v.expiresAt ? new Date(`${v.expiresAt}T23:59:59Z`).toISOString() : null,
    max_redemptions: v.maxRedemptions ? Number(v.maxRedemptions) : null,
    is_active: v.isActive,
  };
  const res = id
    ? await supabase.from("coupons").update(row).eq("id", id).select("id")
    : await supabase.from("coupons").insert(row).select("id");
  if (res.error) {
    if (res.error.code === "23505")
      return {
        ok: false,
        error: "That code already exists.",
        fieldErrors: { code: ["Already exists"] },
      };
    return { ok: false, error: GENERIC_ERROR };
  }
  await audit(
    supabase,
    id ? "coupon.updated" : "coupon.created",
    { type: "coupon", id: res.data![0].id },
    { code: v.code },
  );
  revalidatePath("/admin/coupons");
  return { ok: true, message: `Coupon ${v.code} saved.` };
}

export async function deleteCoupon(id: string): Promise<ActionResult> {
  const supabase = await admin();
  const { error } = await supabase.from("coupons").delete().eq("id", id);
  if (error) return { ok: false, error: GENERIC_ERROR };
  await audit(supabase, "coupon.deleted", { type: "coupon", id });
  revalidatePath("/admin/coupons");
  return { ok: true, message: "Coupon deleted." };
}
