import type { Metadata } from "next";
import Link from "next/link";
import { z } from "zod";
import { OrderStatusBadge } from "@/components/orders/order-status-badge";
import { PageHeader } from "@/components/site/page-header";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatPrice } from "@/lib/courses/format";
import { providerLabel } from "@/lib/payments/registry";
import { createClient } from "@/lib/supabase/server";
import { OrderActions } from "./order-actions";

export const metadata: Metadata = { title: "Admin: orders", robots: { index: false } };

const params = z.object({
  status: z.enum(["pending", "paid", "cancelled", "refunded"]).optional().catch(undefined),
  q: z.string().trim().max(100).optional().catch(undefined),
});

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string>>;
}) {
  const sp = await searchParams;
  const { status, q } = params.parse(Object.fromEntries(Object.entries(sp).filter(([, v]) => v)));
  const supabase = await createClient();
  let query = supabase
    .from("orders")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(200);
  if (status) query = query.eq("status", status);
  if (q) {
    const safe = q.replace(/[%_\\]/g, (m) => `\\${m}`).replace(/[,()]/g, " ");
    query = query.or(
      `reference.ilike.%${safe}%,billing_email.ilike.%${safe}%,billing_name.ilike.%${safe}%,invoice_number.ilike.%${safe}%`,
    );
  }
  const { data: orders } = await query;

  return (
    <>
      <PageHeader
        title="Orders"
        description="Bank transfers: match the reference on your bank statement, then mark the order as paid. That grants access and emails the invoice."
      />
      <form
        role="search"
        aria-label="Filter orders"
        className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-end"
      >
        <div className="grid flex-1 gap-1.5">
          <label htmlFor="q" className="text-sm font-medium">
            Reference, name, email or invoice no.
          </label>
          <input
            id="q"
            name="q"
            type="search"
            defaultValue={q}
            className="border-input bg-background h-11 rounded-lg border px-3"
          />
        </div>
        <div className="grid gap-1.5">
          <label htmlFor="status" className="text-sm font-medium">
            Status
          </label>
          <select
            id="status"
            name="status"
            defaultValue={status ?? ""}
            className="border-input bg-background h-11 rounded-lg border px-3"
          >
            <option value="">All</option>
            <option value="pending">Awaiting payment</option>
            <option value="paid">Paid</option>
            <option value="cancelled">Cancelled</option>
            <option value="refunded">Refunded</option>
          </select>
        </div>
        <Button type="submit" size="lg" className="h-11 px-5">
          Filter
        </Button>
      </form>
      <div className="bg-card mt-6 overflow-x-auto rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Course</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders?.map((o) => (
              <TableRow key={o.id}>
                <TableCell className="align-top">
                  <a
                    href={`/orders/${o.reference}/invoice`}
                    target="_blank"
                    rel="noopener"
                    className="text-primary font-mono font-medium underline-offset-4 hover:underline"
                  >
                    {o.reference}
                  </a>
                  <p className="text-muted-foreground text-xs">
                    {new Date(o.created_at).toLocaleDateString("en-GB")} ·{" "}
                    {providerLabel(o.provider)}
                  </p>
                  {o.invoice_number && (
                    <p className="text-muted-foreground font-mono text-xs">{o.invoice_number}</p>
                  )}
                </TableCell>
                <TableCell className="align-top">
                  <Link
                    href={`/admin/users/${o.user_id}`}
                    className="text-primary font-medium underline-offset-4 hover:underline"
                  >
                    {o.billing_name}
                  </Link>
                  <p className="text-muted-foreground text-xs">{o.billing_email}</p>
                </TableCell>
                <TableCell className="align-top">
                  {o.course_title}
                  {o.coupon_code && (
                    <p className="text-muted-foreground font-mono text-xs">{o.coupon_code}</p>
                  )}
                </TableCell>
                <TableCell className="tabular text-right align-top font-mono">
                  {formatPrice(o.total_minor, o.currency)}
                </TableCell>
                <TableCell className="align-top">
                  <OrderStatusBadge status={o.status} />
                </TableCell>
                <TableCell className="align-top">
                  <OrderActions orderId={o.id} reference={o.reference} status={o.status} />
                </TableCell>
              </TableRow>
            ))}
            {!orders?.length && (
              <TableRow>
                <TableCell colSpan={6} className="text-muted-foreground py-10 text-center">
                  No orders found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </>
  );
}
