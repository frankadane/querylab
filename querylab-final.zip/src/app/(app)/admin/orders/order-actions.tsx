"use client";

import { useState } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { useAction } from "@/components/forms/use-action";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { adminCancelOrder, markOrderPaid, refundOrder } from "./actions";

export function OrderActions({
  orderId,
  reference,
  status,
}: {
  orderId: string;
  reference: string;
  status: string;
}) {
  const { pending, result, run } = useAction();
  const [note, setNote] = useState("");
  return (
    <div className="grid min-w-44 gap-2">
      {status === "pending" && (
        <>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="lg" className="h-9 px-3" disabled={pending}>
                Mark paid<span className="sr-only"> {reference}</span>
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Mark {reference} as paid?</AlertDialogTitle>
                <AlertDialogDescription>
                  Only do this once the money is in your account. The student gets access and an
                  invoice by email.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <label className="grid gap-1.5 text-sm">
                <span className="font-medium">Note (optional, e.g. bank transaction ID)</span>
                <input
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  maxLength={1000}
                  className="border-input bg-background h-10 rounded-lg border px-3"
                />
              </label>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => run(() => markOrderPaid(orderId, note))}>
                  Confirm payment received
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <Button
            variant="ghost"
            size="lg"
            className="h-9 px-3"
            disabled={pending}
            onClick={() => {
              if (confirm(`Cancel ${reference}?`)) run(() => adminCancelOrder(orderId));
            }}
          >
            Cancel<span className="sr-only"> {reference}</span>
          </Button>
        </>
      )}
      {status === "paid" && (
        <Button
          variant="outline"
          size="lg"
          className="text-destructive h-9 px-3"
          disabled={pending}
          onClick={() => {
            const reason = prompt(
              `Refund ${reference}? This removes course access. Optional note:`,
            );
            if (reason !== null) run(() => refundOrder(orderId, reason));
          }}
        >
          Refund<span className="sr-only"> {reference}</span>
        </Button>
      )}
      <div aria-live="polite">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </div>
  );
}
