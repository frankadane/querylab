import { Award, BookOpen, CalendarClock, ShieldAlert } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { FormAlert } from "@/components/forms/form-alert";
import { PageHeader } from "@/components/site/page-header";
import { Button } from "@/components/ui/button";
import { requireUser } from "@/lib/auth";
import { myUpcomingSessions } from "@/lib/sessions/queries";
import { MyCourseCard } from "@/components/learning/my-course-card";
import { myCourses } from "@/lib/learning/queries";
import { formatSessionRange } from "@/lib/sessions/time";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Dashboard", robots: { index: false } };

const roleLabel = { student: "Student", instructor: "Instructor", admin: "Admin" } as const;

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ denied?: string; passwordReset?: string }>;
}) {
  const { profile } = await requireUser();
  const sp = await searchParams;
  const supabase = await createClient();
  const [upcoming, { data: notifications }, courses, { data: certificates }] = await Promise.all([
    myUpcomingSessions(profile.id),
    supabase
      .from("notifications")
      .select("id, title, body, link, created_at, read_at")
      .order("created_at", { ascending: false })
      .limit(5),
    myCourses(profile.id),
    supabase
      .from("certificates")
      .select("serial, course_title, issued_at")
      .eq("user_id", profile.id)
      .order("issued_at", { ascending: false }),
  ]);
  const firstName = profile.full_name.split(" ")[0] || "there";

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <PageHeader
        title={`Welcome, ${firstName}`}
        description={
          <>
            Signed in as{" "}
            <span className="text-foreground font-medium">{roleLabel[profile.role]}</span> · times
            shown in <span className="font-mono text-sm">{profile.timezone}</span>
          </>
        }
      />
      <div className="mt-6 grid gap-3" aria-live="polite">
        {sp.denied && (
          <FormAlert kind="error">
            <span className="inline-flex items-center gap-1.5">
              <ShieldAlert className="size-4" aria-hidden="true" />
              You don&apos;t have access to that page.
            </span>
          </FormAlert>
        )}
        {sp.passwordReset && <FormAlert kind="success">Your password has been changed.</FormAlert>}
      </div>
      <section aria-labelledby="upcoming-h" className="bg-card mt-8 rounded-xl border p-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 id="upcoming-h" className="flex items-center gap-2 text-lg font-semibold">
            <CalendarClock className="text-primary size-5" aria-hidden="true" /> Upcoming live
            sessions
          </h2>
          <Link
            href="/schedule"
            className="text-primary text-sm font-medium underline-offset-4 hover:underline"
          >
            Live schedule
          </Link>
        </div>
        {upcoming.length ? (
          <ul className="mt-4 divide-y">
            {upcoming.map((r) => (
              <li
                key={r.session!.id}
                className="flex flex-wrap items-center justify-between gap-2 py-3"
              >
                <div className="min-w-0">
                  <Link
                    href={`/schedule/${r.session!.id}`}
                    className="text-primary font-medium underline-offset-4 hover:underline"
                  >
                    {r.session!.title}
                  </Link>
                  <p className="text-muted-foreground text-sm">
                    <time dateTime={r.session!.starts_at}>
                      {formatSessionRange(
                        r.session!.starts_at,
                        r.session!.ends_at,
                        profile.timezone,
                      )}
                    </time>
                  </p>
                </div>
                <span className="text-sm font-medium">
                  {r.status === "waitlist"
                    ? "On waitlist"
                    : r.session!.status === "cancelled"
                      ? "Cancelled"
                      : "Registered"}
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-muted-foreground mt-3">
            You haven&apos;t registered for any sessions. The free “Intro to Data &amp; AI” session
            is open to everyone.
          </p>
        )}
      </section>

      {notifications && notifications.length > 0 && (
        <section aria-labelledby="notif-h" className="mt-6">
          <h2 id="notif-h" className="text-lg font-semibold">
            Recent updates
          </h2>
          <ul className="bg-card mt-3 divide-y rounded-xl border">
            {notifications.map((n) => (
              <li key={n.id} className="px-4 py-3">
                {n.link ? (
                  <Link
                    href={n.link}
                    className="text-primary font-medium underline-offset-4 hover:underline"
                  >
                    {n.title}
                  </Link>
                ) : (
                  <p className="font-medium">{n.title}</p>
                )}
                {n.body && <p className="text-muted-foreground text-sm">{n.body}</p>}
              </li>
            ))}
          </ul>
        </section>
      )}

      <section aria-labelledby="learning-h" className="mt-8">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 id="learning-h" className="flex items-center gap-2 text-lg font-semibold">
            <BookOpen className="text-primary size-5" aria-hidden="true" /> Continue learning
          </h2>
          <Link
            href="/my-courses"
            className="text-primary text-sm font-medium underline-offset-4 hover:underline"
          >
            All my courses
          </Link>
        </div>
        {courses.length ? (
          <ul className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {courses.slice(0, 3).map((c) => (
              <li key={c.id}>
                <MyCourseCard c={c} />
              </li>
            ))}
          </ul>
        ) : (
          <div className="mt-4 rounded-xl border border-dashed p-8 text-center">
            <p className="text-muted-foreground">You haven&apos;t enrolled in a course yet.</p>
            <Button asChild size="lg" className="mt-4 h-10 px-4">
              <Link href="/courses">Browse courses</Link>
            </Button>
          </div>
        )}
      </section>

      <section aria-labelledby="certs-h" className="bg-card mt-8 rounded-xl border p-6">
        <h2 id="certs-h" className="flex items-center gap-2 text-lg font-semibold">
          <Award className="text-primary size-5" aria-hidden="true" /> Certificates
        </h2>
        {certificates?.length ? (
          <ul className="mt-3 divide-y">
            {certificates.map((c) => (
              <li key={c.serial} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <div>
                  <p className="font-medium">{c.course_title}</p>
                  <p className="text-muted-foreground font-mono text-xs">{c.serial}</p>
                </div>
                <Button asChild variant="outline" size="lg" className="h-9 px-3">
                  <a href={`/certificates/${c.serial}/pdf`} target="_blank" rel="noopener">
                    Download PDF<span className="sr-only"> for {c.course_title}</span>
                  </a>
                </Button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-muted-foreground mt-3">
            Complete all lessons and pass the quizzes in a course to earn a certificate.
          </p>
        )}
      </section>
    </div>
  );
}
