import type { Metadata } from "next";
import Link from "next/link";
import { Logo } from "@/components/site/logo";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = { title: "Link problem", robots: { index: false } };

export default async function AuthErrorPage({
  searchParams,
}: {
  searchParams: Promise<{ reason?: string }>;
}) {
  const { reason } = await searchParams;
  return (
    <main id="main" className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-4">
      <Logo />
      <h1 className="mt-8 text-2xl font-semibold">This link doesn&apos;t work</h1>
      <p className="text-muted-foreground mt-3">
        {reason === "expired"
          ? "It has expired or has already been used. Links are valid for 1 hour and can be used once."
          : "The link is incomplete. Try copying the full link from the email."}
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Button asChild size="lg" className="h-11 px-5">
          <Link href="/login">Log in</Link>
        </Button>
        <Button asChild size="lg" variant="outline" className="h-11 px-5">
          <Link href="/forgot-password">Reset password</Link>
        </Button>
      </div>
    </main>
  );
}
