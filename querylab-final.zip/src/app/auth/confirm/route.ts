import type { EmailOtpType } from "@supabase/supabase-js";
import { type NextRequest, NextResponse } from "next/server";
import { safeNext } from "@/lib/safe-redirect";
import { createClient } from "@/lib/supabase/server";

const TYPES: EmailOtpType[] = [
  "signup",
  "email",
  "recovery",
  "email_change",
  "magiclink",
  "invite",
];

/** Handles every email link (confirm, magic link, recovery, email change). */
export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const tokenHash = searchParams.get("token_hash");
  const type = searchParams.get("type") as EmailOtpType | null;
  const next = safeNext(searchParams.get("next"));

  const fail = (reason: string) => {
    const url = request.nextUrl.clone();
    url.pathname = "/auth/error";
    url.search = `?reason=${reason}`;
    return NextResponse.redirect(url);
  };

  if (!tokenHash || !type || !TYPES.includes(type)) return fail("invalid");

  const supabase = await createClient();
  const { error } = await supabase.auth.verifyOtp({ type, token_hash: tokenHash });
  if (error) return fail("expired");

  const url = request.nextUrl.clone();
  const [pathname, search = ""] = next.split("?");
  url.pathname = pathname;
  url.search = search ? `?${search}` : "";
  if (type === "email_change") url.searchParams.set("emailChanged", "1");
  return NextResponse.redirect(url);
}
