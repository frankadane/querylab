import { NextResponse } from "next/server";
import { renderCertificatePdf } from "@/lib/learning/certificate-pdf";
import { siteConfig } from "@/lib/site";
import { createClient } from "@/lib/supabase/server";

/** The holder (or an admin) downloads the PDF; anyone can verify the serial at /verify/:serial. */
export async function GET(_req: Request, { params }: { params: Promise<{ serial: string }> }) {
  const { serial } = await params;
  if (!/^QL-\d{4}-[A-Z0-9]{8}$/.test(serial))
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  const supabase = await createClient();
  const { data: c } = await supabase
    .from("certificates")
    .select("serial, holder_name, course_title, issued_at")
    .eq("serial", serial)
    .maybeSingle();
  if (!c) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const bytes = await renderCertificatePdf({
    serial: c.serial,
    holderName: c.holder_name,
    courseTitle: c.course_title,
    issuedAt: c.issued_at,
    verifyUrl: `${siteConfig.url.replace(/^https?:\/\//, "")}/verify/${c.serial}`,
  });
  return new NextResponse(Buffer.from(bytes), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="QueryLab-certificate-${c.serial}.pdf"`,
      "Cache-Control": "private, no-store",
    },
  });
}
