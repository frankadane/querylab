import type { Metadata } from "next";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { listPosts } from "@/lib/content/queries";

export const metadata: Metadata = {
  title: "Blog & resources",
  description: "Practical articles on AI, data science and Power BI from the QueryLab team.",
  alternates: { canonical: "/resources" },
};
export const revalidate = 300;

const date = (d: string | null) =>
  d
    ? new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric" }).format(
        new Date(d),
      )
    : "";

export default async function ResourcesPage({
  searchParams,
}: {
  searchParams: Promise<{ tag?: string }>;
}) {
  const { tag } = await searchParams;
  const safeTag = tag && /^[a-z0-9-]{1,30}$/.test(tag) ? tag : undefined;
  const posts = await listPosts(safeTag);
  return (
    <div className="mx-auto max-w-5xl px-4 py-14 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-semibold">Blog &amp; resources</h1>
      <p className="text-muted-foreground mt-3 text-lg">Practical guides from the QueryLab team.</p>
      {safeTag && (
        <p className="mt-6 text-sm">
          Showing posts tagged <Badge variant="secondary">{safeTag}</Badge> ·{" "}
          <Link href="/resources" className="text-primary font-medium underline">
            Show all
          </Link>
        </p>
      )}
      {posts.length ? (
        <ul className="mt-10 grid gap-6 md:grid-cols-2">
          {posts.map((p) => (
            <li key={p.slug}>
              <article className="bg-card focus-within:ring-ring hover:border-primary/50 relative flex h-full flex-col rounded-xl border p-6 focus-within:ring-2">
                <p className="text-muted-foreground text-sm">
                  <time dateTime={p.published_at ?? undefined}>{date(p.published_at)}</time>
                  {p.is_demo ? " · Demo" : ""}
                </p>
                <h2 className="mt-2 text-xl font-semibold">
                  <Link
                    href={`/resources/${p.slug}`}
                    className="after:absolute after:inset-0 focus:outline-none"
                  >
                    {p.title}
                  </Link>
                </h2>
                {p.excerpt && <p className="text-muted-foreground mt-2 flex-1">{p.excerpt}</p>}
                {p.tags.length > 0 && (
                  <ul className="mt-4 flex flex-wrap gap-2" aria-label="Tags">
                    {p.tags.map((t) => (
                      <li key={t}>
                        <Badge variant="outline">{t}</Badge>
                      </li>
                    ))}
                  </ul>
                )}
              </article>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-muted-foreground mt-10 rounded-xl border border-dashed p-10 text-center">
          No posts yet.
        </p>
      )}
    </div>
  );
}
