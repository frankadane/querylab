import { ArrowLeft } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Markdown } from "@/components/content/markdown";
import { Badge } from "@/components/ui/badge";
import { getPost, listPosts } from "@/lib/content/queries";
import { siteConfig } from "@/lib/site";

export const revalidate = 300;

export async function generateStaticParams() {
  return (await listPosts()).map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const p = await getPost((await params).slug);
  if (!p) return {};
  return {
    title: p.seo_title || p.title,
    description: p.seo_description || p.excerpt || undefined,
    alternates: { canonical: `/resources/${p.slug}` },
    openGraph: {
      type: "article",
      title: p.title,
      description: p.excerpt ?? undefined,
      publishedTime: p.published_at ?? undefined,
      images: p.cover_url ? [p.cover_url] : undefined,
    },
  };
}

export default async function PostPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = await getPost((await params).slug);
  if (!p) notFound();
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: p.title,
    description: p.excerpt ?? undefined,
    datePublished: p.published_at,
    dateModified: p.updated_at,
    author: { "@type": "Person", name: p.author?.full_name || siteConfig.name },
    publisher: { "@type": "Organization", name: siteConfig.name, url: siteConfig.url },
    mainEntityOfPage: `${siteConfig.url}/resources/${p.slug}`,
    image: p.cover_url ?? undefined,
  };
  return (
    <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
      />
      <Link
        href="/resources"
        className="text-primary inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> Blog &amp; resources
      </Link>
      <h1 className="mt-6 text-4xl leading-tight font-semibold">{p.title}</h1>
      <p className="text-muted-foreground mt-3 text-sm">
        {p.author?.full_name && <>By {p.author.full_name} · </>}
        <time dateTime={p.published_at ?? undefined}>
          {p.published_at &&
            new Intl.DateTimeFormat("en-GB", {
              day: "numeric",
              month: "long",
              year: "numeric",
            }).format(new Date(p.published_at))}
        </time>
      </p>
      {p.tags.length > 0 && (
        <ul className="mt-4 flex flex-wrap gap-2" aria-label="Tags">
          {p.tags.map((t) => (
            <li key={t}>
              <Badge variant="outline" asChild>
                <Link href={`/resources?tag=${t}`}>{t}</Link>
              </Badge>
            </li>
          ))}
        </ul>
      )}
      {p.cover_url && (
        <div className="relative mt-8 aspect-[16/9] overflow-hidden rounded-xl border">
          <Image
            src={p.cover_url}
            alt={p.cover_alt ?? ""}
            fill
            sizes="(min-width: 768px) 768px, 100vw"
            className="object-cover"
            priority
          />
        </div>
      )}
      <Markdown className="mt-8 text-base">{p.body_md}</Markdown>
    </article>
  );
}
