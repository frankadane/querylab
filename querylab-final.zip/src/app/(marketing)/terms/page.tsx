import type { Metadata } from "next";
import { CmsPage, cmsMetadata } from "@/components/content/cms-page";

export const revalidate = 300;
export const generateMetadata = (): Promise<Metadata> => cmsMetadata("terms");

export default function Page() {
  return <CmsPage slug="terms" />;
}
