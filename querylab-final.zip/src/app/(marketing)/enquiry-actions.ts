"use server";

import { type ActionResult, GENERIC_ERROR, RATE_LIMITED, invalid } from "@/lib/action-result";
import { getCurrentUser } from "@/lib/auth";
import { sendEmail } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";
import { siteConfig } from "@/lib/site";
import { createAdminClient } from "@/lib/supabase/admin";
import { enquirySchema } from "@/lib/validation/enquiry";

export async function submitEnquiry(input: unknown): Promise<ActionResult> {
  const parsed = enquirySchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const v = parsed.data;
  // Bots that fill the hidden honeypot field get the normal success message and nothing is stored.
  if (v.website) return { ok: true, message: "Thanks! We've received your message." };
  if (!(await rateLimit("emailLink", `enquiry:${v.email}`)))
    return { ok: false, error: RATE_LIMITED };

  const current = await getCurrentUser();
  const admin = createAdminClient();
  const { error } = await admin.from("enquiries").insert({
    kind: v.kind,
    name: v.name,
    email: v.email,
    company: v.company || null,
    team_size: v.teamSize || null,
    topic: v.topic || null,
    message: v.message,
    user_id: current?.user.id ?? null,
  });
  if (error) {
    console.error("[enquiry]", error.message);
    return { ok: false, error: GENERIC_ERROR };
  }
  const { data: settings } = await admin
    .from("site_settings")
    .select("contact_email")
    .eq("id", 1)
    .single();
  const label = v.kind === "corporate" ? "Corporate training enquiry" : "Contact form";
  await Promise.all([
    sendEmail({
      to: settings?.contact_email ?? siteConfig.contactEmail,
      subject: `${label}: ${v.company || v.name}`,
      text: [
        `From: ${v.name} <${v.email}>`,
        v.company && `Company: ${v.company}`,
        v.teamSize && `Team size: ${v.teamSize}`,
        v.topic && `Topic: ${v.topic}`,
        "",
        v.message,
      ]
        .filter(Boolean)
        .join("\n"),
    }),
    sendEmail({
      to: v.email,
      subject: "We've received your message",
      text: `Hi ${v.name.split(" ")[0]},\n\nThanks for getting in touch with QueryLab. We'll reply by email, usually within 2 working days.\n\nYour message:\n${v.message}\n\nQueryLab`,
    }),
  ]);
  return {
    ok: true,
    message:
      "Thanks! We've received your message and emailed you a copy. We usually reply within 2 working days.",
  };
}
