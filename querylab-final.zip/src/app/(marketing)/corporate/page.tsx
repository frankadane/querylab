import { Building2, CalendarClock, LineChart, Wrench } from "lucide-react";
import type { Metadata } from "next";
import { EnquiryForm } from "@/components/forms/enquiry-form";

export const metadata: Metadata = {
  title: "Training for teams",
  description:
    "Private QueryLab cohorts in AI, Data Science and Power BI for companies and public-sector teams.",
  alternates: { canonical: "/corporate" },
};

const points = [
  {
    icon: Wrench,
    title: "Built around your data",
    body: "Exercises and capstones use your tools and, where possible, anonymised examples from your own work.",
  },
  {
    icon: CalendarClock,
    title: "Scheduled for your team",
    body: "Live sessions at times that suit you, online, with recordings for anyone who misses one.",
  },
  {
    icon: LineChart,
    title: "Progress you can see",
    body: "Attendance, completion and quiz results for your cohort, so you know the training is landing.",
  },
  {
    icon: Building2,
    title: "Invoiced to your company",
    body: "Pay by bank transfer against an invoice. No individual sign-ups or card payments needed.",
  },
];

export default function CorporatePage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-14 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-semibold">Training for teams</h1>
      <p className="text-muted-foreground mt-3 max-w-2xl text-lg">
        Private cohorts in Applied AI, Data Science with Python &amp; SQL, and Power BI for analysts
        and business teams.
      </p>
      <ul className="mt-10 grid gap-6 sm:grid-cols-2">
        {points.map((p) => (
          <li key={p.title} className="bg-card rounded-xl border p-6">
            <p.icon className="text-primary size-5" aria-hidden="true" />
            <h2 className="mt-3 font-semibold">{p.title}</h2>
            <p className="text-muted-foreground mt-1">{p.body}</p>
          </li>
        ))}
      </ul>
      <section
        aria-labelledby="enquire-h"
        className="bg-surface mt-14 rounded-xl border p-6 sm:p-8"
      >
        <h2 id="enquire-h" className="text-2xl font-semibold">
          Tell us about your team
        </h2>
        <p className="text-muted-foreground mt-2">
          We&apos;ll reply by email with options and a quote.
        </p>
        <div className="mt-8">
          <EnquiryForm kind="corporate" />
        </div>
      </section>
    </div>
  );
}
