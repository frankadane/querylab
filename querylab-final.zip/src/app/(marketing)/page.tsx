import {
  ArrowRight,
  BarChart3,
  BrainCircuit,
  Building2,
  CalendarClock,
  Code2,
  GraduationCap,
  Layers,
  PlayCircle,
  UserRound,
  Video,
} from "lucide-react";
import Link from "next/link";
import { HeroDashboard } from "@/components/landing/hero-dashboard";
import { Button } from "@/components/ui/button";
import { listSiteFaqs } from "@/lib/courses/queries";
import { siteConfig, tracks } from "@/lib/site";

export const revalidate = 300;

const trackIcons = { ai: BrainCircuit, "data-science": Code2, "power-bi": BarChart3 } as const;

const formats = [
  {
    icon: PlayCircle,
    title: "Self-paced",
    body: "Short video lessons, readings, downloadable files and quizzes. Start any time and track your progress lesson by lesson.",
  },
  {
    icon: Video,
    title: "Live cohort",
    body: "Weekly 90-minute sessions with an instructor on Zoom, Meet or Teams. Shown in your own timezone, with recordings afterwards.",
  },
  {
    icon: Layers,
    title: "Hybrid",
    body: "Work through the material at your own pace, then bring questions and project work to live sessions.",
  },
];

export default async function HomePage() {
  const faqs = await listSiteFaqs();
  const orgLd = {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    name: siteConfig.name,
    url: siteConfig.url,
    email: siteConfig.contactEmail,
    description: siteConfig.description,
    logo: `${siteConfig.url}/icon.svg`,
  };
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(orgLd).replace(/</g, "\\u003c") }}
      />
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 pt-14 pb-20 sm:px-6 md:pt-20 lg:grid-cols-[1fr_1.05fr] lg:gap-12 lg:px-8 lg:pt-24 lg:pb-28">
          <div>
            <p className="text-highlight-text font-mono text-xs font-medium tracking-[0.14em] uppercase">
              AI · Data Science · Power BI
            </p>
            <h1 className="mt-5 text-4xl leading-[1.08] font-semibold sm:text-5xl lg:text-[3.5rem]">
              Data skills you will use at work on Monday.
            </h1>
            <p className="text-muted-foreground mt-6 max-w-xl text-lg leading-8">
              QueryLab teaches working professionals and teams to analyse data, build models and
              report clearly, through self-paced courses and live classes with instructors.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg" className="h-12 px-5 text-base">
                <Link href="/courses">
                  Browse courses <ArrowRight aria-hidden="true" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-12 px-5 text-base">
                <Link href="/schedule">
                  <CalendarClock aria-hidden="true" /> See the live schedule
                </Link>
              </Button>
            </div>
            <ul className="text-muted-foreground mt-10 grid gap-3 text-sm sm:grid-cols-3">
              {[
                "Self-paced and live",
                "Schedule in your timezone",
                "Certificate on completion",
              ].map((t) => (
                <li key={t} className="flex items-center gap-2">
                  <span aria-hidden="true" className="bg-highlight h-3 w-0.5 rounded-full" />
                  {t}
                </li>
              ))}
            </ul>
          </div>
          <HeroDashboard />
        </div>
      </section>

      {/* Tracks */}
      <section aria-labelledby="tracks-heading" className="bg-surface border-t">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h2 id="tracks-heading" className="text-3xl font-semibold sm:text-4xl">
              Three tracks, one practical approach
            </h2>
            <p className="text-muted-foreground mt-4 text-lg">
              Every course ends with a capstone built on a problem from your own job.
            </p>
          </div>
          <ul className="mt-12 grid gap-5 md:grid-cols-3">
            {tracks.map((t) => {
              const Icon = trackIcons[t.slug];
              return (
                <li key={t.slug}>
                  <Link
                    href={`/courses/${t.courseSlug}`}
                    className="group bg-card hover:border-primary/50 flex h-full flex-col rounded-xl border p-6 transition-[border-color,box-shadow] duration-200 hover:shadow-[0_8px_30px_-12px_color-mix(in_oklab,var(--primary)_40%,transparent)]"
                  >
                    <span className="bg-secondary text-secondary-foreground inline-flex size-10 items-center justify-center rounded-lg">
                      <Icon className="size-5" aria-hidden="true" />
                    </span>
                    <h3 className="mt-5 text-xl font-semibold">{t.name}</h3>
                    <p className="text-muted-foreground mt-2 flex-1 leading-7">{t.summary}</p>
                    <span className="text-primary mt-6 inline-flex items-center gap-1.5 text-sm font-medium">
                      View course
                      <ArrowRight
                        className="size-4 transition-transform duration-200 group-hover:translate-x-0.5"
                        aria-hidden="true"
                      />
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      </section>

      {/* Formats */}
      <section aria-labelledby="formats-heading">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <h2 id="formats-heading" className="max-w-2xl text-3xl font-semibold sm:text-4xl">
            Learn the way your week allows
          </h2>
          <dl className="mt-12 grid gap-10 md:grid-cols-3">
            {formats.map((f) => (
              <div key={f.title} className="border-primary border-t-2 pt-6">
                <dt className="flex items-center gap-2.5 text-lg font-semibold">
                  <f.icon className="text-primary size-5" aria-hidden="true" />
                  {f.title}
                </dt>
                <dd className="text-muted-foreground mt-3 leading-7">{f.body}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* Path selection */}
      <section aria-labelledby="paths-heading" className="bg-surface border-t">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <h2 id="paths-heading" className="text-3xl font-semibold sm:text-4xl">
            Where are you starting from?
          </h2>
          <div className="mt-10 grid gap-5 md:grid-cols-2">
            <div className="bg-card flex flex-col rounded-xl border p-8">
              <UserRound className="text-primary size-6" aria-hidden="true" />
              <h3 className="mt-4 text-xl font-semibold">I&apos;m learning for myself</h3>
              <p className="text-muted-foreground mt-2 flex-1 leading-7">
                Pick a course, start with the free intro lesson, and join live sessions when they
                suit you.
              </p>
              <Button asChild size="lg" className="mt-6 h-11 self-start px-5">
                <Link href="/courses">Find a course</Link>
              </Button>
            </div>
            <div className="bg-card flex flex-col rounded-xl border p-8">
              <Building2 className="text-primary size-6" aria-hidden="true" />
              <h3 className="mt-4 text-xl font-semibold">I&apos;m training a team</h3>
              <p className="text-muted-foreground mt-2 flex-1 leading-7">
                Private cohorts for analysts and business teams, scheduled around your calendar and
                invoiced to your company.
              </p>
              <Button asChild size="lg" variant="outline" className="mt-6 h-11 self-start px-5">
                <Link href="/corporate">Enquire about team training</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section aria-labelledby="faq-heading">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-20 sm:px-6 lg:grid-cols-[1fr_1.6fr] lg:px-8">
          <div>
            <h2 id="faq-heading" className="text-3xl font-semibold sm:text-4xl">
              Common questions
            </h2>
            <p className="text-muted-foreground mt-4">
              Something else?{" "}
              <Link
                href="/contact"
                className="text-primary font-medium underline-offset-4 hover:underline"
              >
                Contact us
              </Link>
              .
            </p>
          </div>
          <div className="divide-y border-y">
            {faqs.map((f) => (
              <details key={f.id} className="group py-1">
                <summary className="flex min-h-12 items-center justify-between gap-4 py-3 font-medium [&::-webkit-details-marker]:hidden">
                  {f.question}
                  <span
                    aria-hidden="true"
                    className="text-muted-foreground font-mono text-lg transition-transform duration-200 group-open:rotate-45"
                  >
                    +
                  </span>
                </summary>
                <p className="text-muted-foreground pb-5 leading-7">{f.answer_md}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA band */}
      <section className="dark bg-background text-foreground border-t">
        <div className="mx-auto flex max-w-7xl flex-col items-start gap-6 px-4 py-16 sm:px-6 md:flex-row md:items-center md:justify-between lg:px-8">
          <div className="flex items-start gap-4">
            <GraduationCap className="text-highlight mt-1 size-7 shrink-0" aria-hidden="true" />
            <div>
              <h2 className="text-2xl font-semibold">Start with a free intro session</h2>
              <p className="text-muted-foreground mt-2">
                “Intro to Data &amp; AI” is open to everyone with a free account.
              </p>
            </div>
          </div>
          <Button
            asChild
            size="lg"
            className="bg-highlight text-highlight-foreground hover:bg-highlight/90 h-12 px-5 text-base"
          >
            <Link href="/schedule">
              View upcoming sessions <ArrowRight aria-hidden="true" />
            </Link>
          </Button>
        </div>
      </section>
    </>
  );
}
