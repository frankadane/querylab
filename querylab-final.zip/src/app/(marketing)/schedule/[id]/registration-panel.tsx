"use client";

import Link from "next/link";
import { FormAlert } from "@/components/forms/form-alert";
import { useAction } from "@/components/forms/use-action";
import { Button } from "@/components/ui/button";
import { cancelRegistration, registerForSession } from "../actions";

export function RegistrationPanel({
  sessionId,
  signedIn,
  status,
  canRegister,
  open,
  courseSlug,
}: {
  sessionId: string;
  signedIn: boolean;
  status: string | null;
  canRegister: boolean;
  open: boolean;
  courseSlug: string | null;
}) {
  const { pending, result, run } = useAction();
  const active = status === "registered" || status === "waitlist" || status === "attended";

  let body: React.ReactNode;
  if (!signedIn) {
    body = (
      <>
        <p className="text-muted-foreground text-sm">
          {courseSlug
            ? "Enrolled students can register."
            : "Free for anyone with a QueryLab account."}
        </p>
        <Button asChild size="lg" className="mt-3 h-11 w-full">
          <Link href={`/login?next=/schedule/${sessionId}`}>Log in to register</Link>
        </Button>
        <Button asChild variant="ghost" size="lg" className="mt-1 h-10 w-full">
          <Link href={`/register?next=/schedule/${sessionId}`}>Create a free account</Link>
        </Button>
      </>
    );
  } else if (status === "attended") {
    body = <p className="text-sm">You attended this session.</p>;
  } else if (active) {
    body = (
      <>
        <p className="font-medium">
          {status === "registered" ? "You're registered." : "You're on the waitlist."}
        </p>
        <p className="text-muted-foreground mt-1 text-sm">
          {status === "registered"
            ? "We'll email you 24 hours and 1 hour before it starts."
            : "We'll email you if a place opens up."}
        </p>
        {open && (
          <Button
            variant="outline"
            size="lg"
            className="mt-3 h-10 w-full"
            disabled={pending}
            onClick={() => run(() => cancelRegistration(sessionId))}
          >
            {status === "registered" ? "Cancel my place" : "Leave the waitlist"}
          </Button>
        )}
      </>
    );
  } else if (!open) {
    body = <p className="text-muted-foreground text-sm">Registration is closed.</p>;
  } else if (!canRegister) {
    body = (
      <>
        <p className="text-muted-foreground text-sm">
          This session is for students enrolled in the course.
        </p>
        {courseSlug && (
          <Button asChild variant="outline" size="lg" className="mt-3 h-10 w-full">
            <Link href={`/courses/${courseSlug}`}>View the course</Link>
          </Button>
        )}
      </>
    );
  } else {
    body = (
      <Button
        size="lg"
        className="h-12 w-full text-base"
        disabled={pending}
        onClick={() => run(() => registerForSession(sessionId))}
      >
        {pending ? "Registering…" : "Register for this session"}
      </Button>
    );
  }

  return (
    <div>
      <h2 className="mb-3 font-semibold">Your place</h2>
      {body}
      <div aria-live="polite" className="mt-3">
        {result && (
          <FormAlert kind={result.ok ? "success" : "error"}>
            {result.ok ? result.message : result.error}
          </FormAlert>
        )}
      </div>
    </div>
  );
}
