import { ArrowLeft, CalendarPlus, Clock, Download, PlayCircle, Users, Video } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Markdown } from "@/components/content/markdown";
import { FormAlert } from "@/components/forms/form-alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getCurrentUser } from "@/lib/auth";
import { availabilityLabel } from "@/lib/sessions/capacity";
import { getPublicSession } from "@/lib/sessions/queries";
import {
  JOIN_OPENS_MINUTES,
  formatSessionRange,
  googleCalendarUrl,
  joinState,
  meetingProvider,
} from "@/lib/sessions/time";
import { siteConfig } from "@/lib/site";
import { createClient } from "@/lib/supabase/server";
import { RegistrationPanel } from "./registration-panel";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const s = await getPublicSession((await params).id);
  return s
    ? { title: s.title, description: `Live session${s.course ? ` for ${s.course.title}` : ""}.` }
    : {};
}

export default async function SessionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [s, current] = await Promise.all([getPublicSession(id), getCurrentUser()]);
  if (!s) notFound();

  const tz = current?.profile.timezone ?? s.timezone;
  const startsAt = new Date(s.starts_at);
  const endsAt = new Date(s.ends_at);
  const now = new Date();
  const state = joinState(now, startsAt, endsAt, s.status);

  let myStatus: string | null = null;
  let joinUrl: string | null = null;
  let canRegister = false;
  let isStaff = false;
  if (current) {
    const supabase = await createClient();
    const [{ data: reg }, { data: url }, { data: eligible }, { data: staff }] = await Promise.all([
      supabase.from("session_registrations").select("status").eq("session_id", id).maybeSingle(),
      supabase.rpc("get_join_url", { p_session_id: id }),
      supabase.rpc("can_register", { p_session_id: id }),
      supabase.rpc("is_session_staff", { p_session_id: id }),
    ]);
    myStatus = reg?.status ?? null;
    joinUrl = url ?? null;
    canRegister = !!eligible;
    isStaff = !!staff;
  }
  const attending = myStatus === "registered" || myStatus === "attended";
  const showAfter =
    s.status === "completed" && (attending || isStaff) && (s.recording_url || s.materials_md);
  const sessionUrl = `${siteConfig.url}/schedule/${s.id}`;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Event",
    name: s.title,
    startDate: s.starts_at,
    endDate: s.ends_at,
    eventStatus:
      s.status === "cancelled"
        ? "https://schema.org/EventCancelled"
        : "https://schema.org/EventScheduled",
    eventAttendanceMode: "https://schema.org/OnlineEventAttendanceMode",
    location: { "@type": "VirtualLocation", url: sessionUrl },
    organizer: { "@type": "Organization", name: siteConfig.name, url: siteConfig.url },
    maximumAttendeeCapacity: s.capacity,
    isAccessibleForFree: !s.course,
  };

  return (
    <article className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
      />
      <Link
        href="/schedule"
        className="text-primary inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> Live schedule
      </Link>

      <div className="mt-6 grid gap-10 lg:grid-cols-[1fr_20rem]">
        <div className="min-w-0">
          <div className="flex flex-wrap gap-2">
            {s.course ? (
              <Badge variant="secondary" asChild>
                <Link href={`/courses/${s.course.slug}`}>{s.course.title}</Link>
              </Badge>
            ) : (
              <Badge variant="outline" className="border-highlight text-highlight-text">
                Open to all · Free
              </Badge>
            )}
            {s.status === "cancelled" && <Badge variant="destructive">Cancelled</Badge>}
            {s.status === "completed" && <Badge variant="outline">Completed</Badge>}
            {s.is_demo && <Badge variant="outline">Demo</Badge>}
          </div>
          <h1 className="mt-4 text-3xl font-semibold sm:text-4xl">{s.title}</h1>
          <dl className="mt-6 grid gap-3 text-sm">
            <div className="flex items-start gap-2">
              <Clock className="text-muted-foreground mt-0.5 size-4 shrink-0" aria-hidden="true" />
              <dt className="sr-only">When</dt>
              <dd>
                <time dateTime={s.starts_at} className="font-medium">
                  {formatSessionRange(startsAt, endsAt, tz)}
                </time>
                <span className="text-muted-foreground block">
                  Shown in {tz.replaceAll("_", " ")}
                  {current ? "" : " (sign in to use your own timezone)"}.
                </span>
              </dd>
            </div>
            {s.instructor?.full_name && (
              <div className="flex items-center gap-2">
                <Users className="text-muted-foreground size-4" aria-hidden="true" />
                <dt className="sr-only">Instructor</dt>
                <dd>With {s.instructor.full_name}</dd>
              </div>
            )}
            {s.status !== "cancelled" && (
              <div className="flex items-center gap-2">
                <Users className="text-muted-foreground size-4" aria-hidden="true" />
                <dt className="sr-only">Places</dt>
                <dd>{availabilityLabel(s.capacity, s.registered, s.waitlisted)}</dd>
              </div>
            )}
          </dl>

          {s.status === "cancelled" && (
            <FormAlert kind="error" className="mt-6">
              This session was cancelled.{s.cancel_reason ? ` ${s.cancel_reason}` : ""}
            </FormAlert>
          )}

          {s.description_md && <Markdown className="mt-8">{s.description_md}</Markdown>}

          {showAfter && (
            <section aria-labelledby="after-h" className="bg-card mt-10 rounded-xl border p-5">
              <h2 id="after-h" className="text-lg font-semibold">
                Recording &amp; materials
              </h2>
              {s.recording_url && (
                <Button asChild variant="outline" size="lg" className="mt-4 h-10 px-4">
                  <a href={s.recording_url} target="_blank" rel="noopener noreferrer">
                    <PlayCircle aria-hidden="true" /> Watch the recording
                    <span className="sr-only"> (opens in a new tab)</span>
                  </a>
                </Button>
              )}
              {s.materials_md && <Markdown className="mt-4">{s.materials_md}</Markdown>}
            </section>
          )}
        </div>

        <aside aria-label="Registration" className="grid gap-4 self-start lg:sticky lg:top-24">
          <div className="bg-card rounded-xl border p-5">
            <RegistrationPanel
              sessionId={s.id}
              signedIn={!!current}
              status={myStatus}
              canRegister={canRegister}
              open={s.status === "scheduled" && startsAt > now}
              courseSlug={s.course?.slug ?? null}
            />
          </div>

          {attending && s.status !== "cancelled" && state !== "ended" && (
            <div className="bg-card rounded-xl border p-5">
              <h2 className="font-semibold">Join</h2>
              {joinUrl && state === "open" ? (
                <Button asChild size="lg" className="mt-3 h-12 w-full text-base">
                  <a href={joinUrl} target="_blank" rel="noopener noreferrer">
                    <Video aria-hidden="true" /> Join on{" "}
                    {meetingProvider(joinUrl) ?? "the meeting link"}
                    <span className="sr-only"> (opens in a new tab)</span>
                  </a>
                </Button>
              ) : (
                <p className="text-muted-foreground mt-2 text-sm">
                  The join link appears here {JOIN_OPENS_MINUTES} minutes before the session starts.
                  Refresh this page then.
                </p>
              )}
            </div>
          )}
          {isStaff && joinUrl && (
            <p className="text-muted-foreground rounded-lg border border-dashed p-3 text-sm">
              Staff view:{" "}
              <a
                href={joinUrl}
                className="text-primary font-medium underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                host link
              </a>{" "}
              ·{" "}
              <Link
                href={`/studio/sessions/${s.id}`}
                className="text-primary font-medium underline"
              >
                Manage session
              </Link>
            </p>
          )}

          {s.status !== "cancelled" && state !== "ended" && (
            <div className="bg-card rounded-xl border p-5">
              <h2 className="flex items-center gap-2 font-semibold">
                <CalendarPlus className="size-4" aria-hidden="true" /> Add to calendar
              </h2>
              <div className="mt-3 grid gap-2">
                <Button asChild variant="outline" size="lg" className="h-10">
                  <a href={`/schedule/${s.id}/ics`} download>
                    <Download aria-hidden="true" /> Download .ics (Outlook, Apple)
                  </a>
                </Button>
                <Button asChild variant="outline" size="lg" className="h-10">
                  <a
                    href={googleCalendarUrl({
                      title: s.title,
                      startsAt,
                      endsAt,
                      details: `Join details: ${sessionUrl}`,
                      location: sessionUrl,
                    })}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Google Calendar<span className="sr-only"> (opens in a new tab)</span>
                  </a>
                </Button>
              </div>
            </div>
          )}
        </aside>
      </div>
    </article>
  );
}
