"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { type ActionResult, GENERIC_ERROR, RATE_LIMITED } from "@/lib/action-result";
import { requireUser } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { notifySessionUsers } from "@/lib/sessions/notify";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";

const id = z.string().uuid();

export async function registerForSession(
  sessionId: string,
): Promise<ActionResult<{ status: string }>> {
  const { user } = await requireUser(`/schedule/${sessionId}`);
  if (!id.safeParse(sessionId).success) return { ok: false, error: "Session not found." };
  if (!(await rateLimit("sensitive", user.id))) return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  const { data: status, error } = await supabase.rpc("register_for_session", {
    p_session_id: sessionId,
  });
  if (error) {
    if (error.code === "42501")
      return { ok: false, error: "Enrol in this course to register for its live sessions." };
    if (error.code === "P0001")
      return { ok: false, error: "Registration has closed for this session." };
    if (error.code === "P0002") return { ok: false, error: "Session not found." };
    console.error("[sessions] register", error.message);
    return { ok: false, error: GENERIC_ERROR };
  }

  const { data: session } = await supabase
    .from("live_sessions")
    .select("id, title, starts_at, ends_at")
    .eq("id", sessionId)
    .single();
  if (session) {
    await notifySessionUsers(
      [user.id],
      session,
      status === "registered"
        ? {
            type: "session_registered",
            subject: `You're registered: ${session.title}`,
            intro:
              "Your place is confirmed. The join link appears on the session page 15 minutes before the start.",
          }
        : {
            type: "session_waitlisted",
            subject: `You're on the waitlist: ${session.title}`,
            intro:
              "This session is full, so you're on the waitlist. We'll email you if a place opens up.",
          },
    );
  }
  revalidatePath(`/schedule/${sessionId}`);
  revalidatePath("/dashboard");
  return {
    ok: true,
    data: { status: status as string },
    message:
      status === "registered"
        ? "You're registered. We've emailed you a confirmation."
        : "This session is full. You're on the waitlist and we'll email you if a place opens.",
  };
}

export async function cancelRegistration(sessionId: string): Promise<ActionResult> {
  await requireUser(`/schedule/${sessionId}`);
  if (!id.safeParse(sessionId).success) return { ok: false, error: "Session not found." };

  const supabase = await createClient();
  const { data: promoted, error } = await supabase.rpc("cancel_registration", {
    p_session_id: sessionId,
  });
  if (error) {
    console.error("[sessions] cancel", error.message);
    return { ok: false, error: GENERIC_ERROR };
  }

  const { data: session } = await supabase
    .from("live_sessions")
    .select("id, title, starts_at, ends_at")
    .eq("id", sessionId)
    .single();
  if (session && promoted?.length) {
    const { data: regs } = await createAdminClient()
      .from("session_registrations")
      .select("user_id")
      .in("id", promoted as unknown as string[]);
    await notifySessionUsers(
      (regs ?? []).map((r) => r.user_id),
      session,
      {
        type: "waitlist_promoted",
        subject: `A place opened up: ${session.title}`,
        intro: "Good news: a place became available and you're now registered.",
        outro: "Can't make it any more? Cancel on the session page so someone else can join.",
      },
    );
  }
  revalidatePath(`/schedule/${sessionId}`);
  revalidatePath("/dashboard");
  return { ok: true, message: "Your registration has been cancelled." };
}
