import type { Metadata } from "next";
import { ScheduleView } from "@/components/sessions/schedule-view";
import { getCurrentUser } from "@/lib/auth";
import { listUpcomingSessions, myRegistrations } from "@/lib/sessions/queries";
import { listTimezones } from "@/lib/timezones";

export const metadata: Metadata = {
  title: "Live schedule",
  description:
    "Upcoming live QueryLab sessions in AI, Data Science and Power BI, shown in your own timezone.",
  alternates: { canonical: "/schedule" },
};

export default async function SchedulePage() {
  const [sessions, current] = await Promise.all([listUpcomingSessions(), getCurrentUser()]);
  const mine = current ? await myRegistrations(sessions.map((s) => s.id)) : new Map();

  return (
    <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-semibold">Live schedule</h1>
      <p className="text-muted-foreground mt-3 max-w-2xl text-lg">
        Weekly live sessions for each course, plus free sessions open to everyone with an account.
      </p>
      <div className="mt-10">
        <ScheduleView
          sessions={sessions.map((s) => ({
            id: s.id,
            title: s.title,
            starts_at: s.starts_at,
            ends_at: s.ends_at,
            status: s.status,
            capacity: s.capacity,
            registered: s.registered,
            waitlisted: s.waitlisted,
            course: s.course ? { title: s.course.title, slug: s.course.slug } : null,
          }))}
          timezones={listTimezones()}
          profileTimezone={current?.profile.timezone}
          myStatuses={Object.fromEntries(mine)}
        />
      </div>
    </div>
  );
}
