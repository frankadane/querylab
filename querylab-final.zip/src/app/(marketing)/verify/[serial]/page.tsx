import { BadgeCheck, SearchX } from "lucide-react";
import type { Metadata } from "next";
import { createPublicClient } from "@/lib/supabase/public";

export const metadata: Metadata = { title: "Verify a certificate", robots: { index: false } };

export default async function VerifyPage({ params }: { params: Promise<{ serial: string }> }) {
  const { serial } = await params;
  const valid = /^QL-\d{4}-[A-Z0-9]{8}$/i.test(serial);
  const { data } = valid
    ? await createPublicClient().rpc("verify_certificate", { p_serial: serial })
    : { data: null };
  const cert = data?.[0];

  return (
    <div className="mx-auto max-w-2xl px-4 py-20 sm:px-6">
      {cert ? (
        <div className="bg-card rounded-xl border p-8">
          <p className="text-primary flex items-center gap-2 font-semibold">
            <BadgeCheck className="size-5" aria-hidden="true" /> Valid certificate
          </p>
          <h1 className="mt-4 text-3xl font-semibold">{cert.holder_name}</h1>
          <p className="mt-2 text-lg">
            completed <strong>{cert.course_title}</strong>
          </p>
          <dl className="text-muted-foreground mt-6 grid gap-1 text-sm sm:grid-cols-[auto_1fr] sm:gap-x-6">
            <dt>Issued</dt>
            <dd className="text-foreground">
              {new Intl.DateTimeFormat("en-GB", {
                day: "numeric",
                month: "long",
                year: "numeric",
                timeZone: "UTC",
              }).format(new Date(cert.issued_at))}
            </dd>
            <dt>Certificate ID</dt>
            <dd className="text-foreground font-mono">{cert.serial}</dd>
          </dl>
        </div>
      ) : (
        <div className="rounded-xl border border-dashed p-8 text-center">
          <SearchX className="text-muted-foreground mx-auto size-8" aria-hidden="true" />
          <h1 className="mt-4 text-2xl font-semibold">Certificate not found</h1>
          <p className="text-muted-foreground mt-2">
            Check the ID on the certificate. It looks like QL-2026-ABCD1234.
          </p>
        </div>
      )}
    </div>
  );
}
