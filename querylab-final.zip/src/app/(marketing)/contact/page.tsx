import { Mail } from "lucide-react";
import type { Metadata } from "next";
import { EnquiryForm } from "@/components/forms/enquiry-form";
import { createPublicClient } from "@/lib/supabase/public";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with QueryLab.",
  alternates: { canonical: "/contact" },
};
export const revalidate = 300;

export default async function ContactPage() {
  const { data: s } = await createPublicClient()
    .from("site_settings")
    .select("contact_email, contact_phone, address")
    .eq("id", 1)
    .single();
  return (
    <div className="mx-auto grid max-w-5xl gap-12 px-4 py-14 sm:px-6 lg:grid-cols-[1fr_18rem] lg:px-8">
      <div>
        <h1 className="text-4xl font-semibold">Contact us</h1>
        <p className="text-muted-foreground mt-3 text-lg">
          Questions about a course, payment or live session? Send us a message.
        </p>
        <div className="mt-10">
          <EnquiryForm kind="contact" />
        </div>
      </div>
      <aside
        aria-label="Contact details"
        className="bg-card self-start rounded-xl border p-6 text-sm"
      >
        <h2 className="font-semibold">Other ways to reach us</h2>
        <p className="mt-3 flex items-center gap-2">
          <Mail className="text-muted-foreground size-4" aria-hidden="true" />
          <a href={`mailto:${s?.contact_email}`} className="text-primary font-medium underline">
            {s?.contact_email}
          </a>
        </p>
        {s?.contact_phone && <p className="mt-2">{s.contact_phone}</p>}
        {s?.address && (
          <p className="text-muted-foreground mt-2 whitespace-pre-line">{s.address}</p>
        )}
      </aside>
    </div>
  );
}
