import { CalendarClock, Check, ChevronDown, Clock, Layers, ListOrdered } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Markdown } from "@/components/content/markdown";
import { CourseCover } from "@/components/courses/course-cover";
import { EnrolCta } from "@/components/courses/enrol-cta";
import { LessonTypeIcon } from "@/components/courses/lesson-type-icon";
import { Badge } from "@/components/ui/badge";
import {
  FORMATS,
  LESSON_TYPES,
  TRACKS,
  formatDuration,
  formatPrice,
  levelLabel,
} from "@/lib/courses/format";
import { getPublishedCourse, listPublishedSlugs } from "@/lib/courses/queries";
import { SessionCard } from "@/components/sessions/session-card";
import { listUpcomingSessions } from "@/lib/sessions/queries";
import { siteConfig } from "@/lib/site";

export const revalidate = 300;

export async function generateStaticParams() {
  return (await listPublishedSlugs()).map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const course = await getPublishedCourse((await params).slug);
  if (!course) return {};
  return {
    title: course.title,
    description: course.subtitle ?? undefined,
    alternates: { canonical: `/courses/${course.slug}` },
    openGraph: { title: course.title, description: course.subtitle ?? undefined, type: "website" },
  };
}

export default async function CoursePage({ params }: { params: Promise<{ slug: string }> }) {
  const course = await getPublishedCourse((await params).slug);
  if (!course) notFound();

  const price = formatPrice(course.price_minor, course.currency);
  const sessions = await listUpcomingSessions({ courseId: course.id, limit: 6 });
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Course",
    name: course.title,
    description: course.subtitle ?? course.title,
    url: `${siteConfig.url}/courses/${course.slug}`,
    provider: { "@type": "Organization", name: siteConfig.name, sameAs: siteConfig.url },
    educationalLevel: levelLabel(course.level_min, course.level_max),
    teaches: course.outcomes,
    offers: {
      "@type": "Offer",
      category: course.price_minor === 0 ? "Free" : "Paid",
      price: (course.price_minor / 100).toFixed(2),
      priceCurrency: course.currency,
      availability: "https://schema.org/InStock",
    },
    hasCourseInstance: {
      "@type": "CourseInstance",
      courseMode: course.format === "self_paced" ? "Online" : "Blended",
      courseWorkload: course.duration_weeks ? `P${course.duration_weeks}W` : undefined,
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
      />

      <div className="bg-surface border-b">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1fr_22rem] lg:px-8 lg:py-16">
          <div>
            <nav aria-label="Breadcrumb" className="text-muted-foreground text-sm">
              <ol className="flex items-center gap-1.5">
                <li>
                  <Link href="/courses" className="hover:text-foreground">
                    Courses
                  </Link>
                </li>
                <li aria-hidden="true">/</li>
                <li aria-current="page" className="text-foreground truncate">
                  {course.title}
                </li>
              </ol>
            </nav>
            <div className="mt-6 flex flex-wrap gap-2">
              <Badge variant="secondary">{TRACKS[course.track]}</Badge>
              <Badge variant="outline">{FORMATS[course.format]}</Badge>
              {course.is_demo && (
                <Badge variant="outline" className="border-highlight text-highlight-text">
                  Demo course
                </Badge>
              )}
            </div>
            <h1 className="mt-4 text-4xl leading-tight font-semibold sm:text-5xl">
              {course.title}
            </h1>
            {course.subtitle && (
              <p className="text-muted-foreground mt-4 max-w-2xl text-lg leading-8">
                {course.subtitle}
              </p>
            )}
            <dl className="mt-8 grid max-w-2xl grid-cols-2 gap-4 sm:grid-cols-4">
              <Fact
                icon={<Layers className="size-4" aria-hidden="true" />}
                label="Level"
                value={levelLabel(course.level_min, course.level_max)}
              />
              <Fact
                icon={<Clock className="size-4" aria-hidden="true" />}
                label="Duration"
                value={course.duration_weeks ? `${course.duration_weeks} weeks` : "Self-paced"}
              />
              <Fact
                icon={<ListOrdered className="size-4" aria-hidden="true" />}
                label="Lessons"
                value={`${course.lessonCount}`}
              />
              <Fact
                icon={<CalendarClock className="size-4" aria-hidden="true" />}
                label="Content"
                value={formatDuration(course.totalMinutes)}
              />
            </dl>
          </div>

          <aside
            aria-label="Enrolment"
            className="bg-card self-start overflow-hidden rounded-xl border lg:sticky lg:top-24"
          >
            <CourseCover track={course.track} src={course.thumbnail_url} />
            <div className="p-5">
              <p className="font-mono text-3xl font-medium">
                <span className="sr-only">Price: </span>
                {price}
              </p>
              <div className="mt-4">
                <EnrolCta
                  slug={course.slug}
                  courseId={course.id}
                  free={course.price_minor === 0}
                  priceLabel={price}
                />
              </div>
            </div>
          </aside>
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-14 px-4 py-14 sm:px-6 lg:grid-cols-[1fr_22rem] lg:px-8">
        <div className="grid min-w-0 gap-14">
          {course.outcomes.length > 0 && (
            <section aria-labelledby="outcomes-h">
              <h2 id="outcomes-h" className="text-2xl font-semibold">
                What you&apos;ll learn
              </h2>
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {course.outcomes.map((o) => (
                  <li key={o} className="flex gap-3">
                    <Check className="text-primary mt-1 size-4 shrink-0" aria-hidden="true" />
                    <span>{o}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section aria-labelledby="about-h">
            <h2 id="about-h" className="text-2xl font-semibold">
              About this course
            </h2>
            <Markdown className="mt-4">{course.description_md}</Markdown>
            {course.requirements.length > 0 && (
              <>
                <h3 className="mt-8 font-semibold">Before you start</h3>
                <ul className="text-muted-foreground mt-3 list-disc space-y-1 pl-6">
                  {course.requirements.map((r) => (
                    <li key={r}>{r}</li>
                  ))}
                </ul>
              </>
            )}
          </section>

          <section aria-labelledby="syllabus-h">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 id="syllabus-h" className="text-2xl font-semibold">
                Syllabus
              </h2>
              <p className="text-muted-foreground text-sm">
                {course.sections.length} sections · {course.lessonCount} lessons ·{" "}
                {formatDuration(course.totalMinutes)}
              </p>
            </div>
            <ol className="bg-card mt-6 divide-y rounded-xl border">
              {course.sections.map((s, i) => (
                <li key={s.id}>
                  <details className="group" open={i === 0}>
                    <summary className="flex min-h-14 items-center gap-4 px-5 py-4 [&::-webkit-details-marker]:hidden">
                      <span className="text-muted-foreground tabular font-mono text-sm">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="flex-1 font-medium">{s.title}</span>
                      <span className="text-muted-foreground hidden text-sm sm:inline">
                        {s.lessons.length} lessons
                      </span>
                      <ChevronDown
                        className="text-muted-foreground size-4 transition-transform duration-200 group-open:rotate-180"
                        aria-hidden="true"
                      />
                    </summary>
                    <ul className="bg-background/50 border-t px-5 py-2">
                      {s.lessons.map((l) => (
                        <li key={l.id} className="flex items-start gap-3 py-3">
                          <LessonTypeIcon
                            type={l.type}
                            className="text-muted-foreground mt-0.5 size-4 shrink-0"
                          />
                          <div className="min-w-0 flex-1">
                            <p className="font-medium">
                              {l.is_free_preview ? (
                                <Link
                                  href={`/courses/${course.slug}/preview/${l.id}`}
                                  className="text-primary underline-offset-4 hover:underline"
                                >
                                  {l.title}
                                </Link>
                              ) : (
                                l.title
                              )}
                              <span className="sr-only"> ({LESSON_TYPES[l.type]})</span>
                            </p>
                            {l.summary && (
                              <p className="text-muted-foreground mt-0.5 text-sm">{l.summary}</p>
                            )}
                          </div>
                          <div className="flex shrink-0 items-center gap-2">
                            {l.is_free_preview && (
                              <Badge
                                variant="outline"
                                className="border-highlight text-highlight-text"
                              >
                                Free preview
                              </Badge>
                            )}
                            {l.duration_minutes ? (
                              <span className="text-muted-foreground tabular font-mono text-xs">
                                {formatDuration(l.duration_minutes)}
                              </span>
                            ) : null}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </details>
                </li>
              ))}
            </ol>
          </section>

          <section aria-labelledby="sessions-h">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 id="sessions-h" className="text-2xl font-semibold">
                Upcoming live sessions
              </h2>
              <Link
                href="/schedule"
                className="text-primary text-sm font-medium underline-offset-4 hover:underline"
              >
                Full schedule
              </Link>
            </div>
            {sessions.length ? (
              <>
                <p className="text-muted-foreground mt-2 text-sm">
                  Times shown in Africa/Accra (GMT). Session pages show times in your own timezone
                  once you sign in.
                </p>
                <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                  {sessions.map((s) => (
                    <li key={s.id}>
                      <SessionCard s={{ ...s, course: undefined }} timeZone="Africa/Accra" />
                    </li>
                  ))}
                </ul>
              </>
            ) : (
              <p className="text-muted-foreground mt-4 rounded-xl border border-dashed p-6">
                No live sessions are scheduled yet. Check the{" "}
                <Link href="/schedule" className="text-primary font-medium underline">
                  live schedule
                </Link>{" "}
                for updates.
              </p>
            )}
          </section>

          {course.faqs.length > 0 && (
            <section aria-labelledby="faq-h">
              <h2 id="faq-h" className="text-2xl font-semibold">
                Frequently asked questions
              </h2>
              <div className="mt-6 divide-y border-y">
                {course.faqs.map((f) => (
                  <details key={f.id} className="group">
                    <summary className="flex min-h-12 items-center justify-between gap-4 py-3 font-medium [&::-webkit-details-marker]:hidden">
                      {f.question}
                      <ChevronDown
                        className="text-muted-foreground size-4 shrink-0 transition-transform group-open:rotate-180"
                        aria-hidden="true"
                      />
                    </summary>
                    <Markdown className="text-muted-foreground pb-5">{f.answer_md}</Markdown>
                  </details>
                ))}
              </div>
            </section>
          )}
        </div>

        {course.instructor && (
          <aside
            aria-labelledby="instructor-h"
            className="bg-card self-start rounded-xl border p-6"
          >
            <h2
              id="instructor-h"
              className="text-muted-foreground text-sm font-semibold tracking-wide uppercase"
            >
              Instructor
            </h2>
            <p className="mt-3 text-lg font-semibold">{course.instructor.display_name}</p>
            {course.instructor.headline && (
              <p className="text-muted-foreground mt-1 text-sm">{course.instructor.headline}</p>
            )}
            {course.instructor.bio_md && (
              <Markdown className="mt-4 text-sm">{course.instructor.bio_md}</Markdown>
            )}
            <Link
              href="/instructors"
              className="text-primary mt-4 inline-block text-sm font-medium underline-offset-4 hover:underline"
            >
              All instructors
            </Link>
          </aside>
        )}
      </div>
    </>
  );
}

function Fact({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div>
      <dt className="text-muted-foreground flex items-center gap-1.5 text-xs font-medium">
        {icon}
        {label}
      </dt>
      <dd className="mt-1 font-medium">{value}</dd>
    </div>
  );
}
