import { ArrowLeft } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Markdown } from "@/components/content/markdown";
import { VideoPlayer } from "@/components/learning/video-player";
import { Badge } from "@/components/ui/badge";
import { getPublishedCourse } from "@/lib/courses/queries";
import { createPublicClient } from "@/lib/supabase/public";

export const revalidate = 300;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string; lessonId: string }>;
}): Promise<Metadata> {
  const { slug, lessonId } = await params;
  const course = await getPublishedCourse(slug);
  const lesson = course?.sections.flatMap((s) => s.lessons).find((l) => l.id === lessonId);
  return lesson ? { title: `${lesson.title} (free preview)` } : {};
}

export default async function PreviewPage({
  params,
}: {
  params: Promise<{ slug: string; lessonId: string }>;
}) {
  const { slug, lessonId } = await params;
  if (!/^[0-9a-f-]{36}$/.test(lessonId)) notFound();
  const course = await getPublishedCourse(slug);
  const lesson = course?.sections
    .flatMap((s) => s.lessons)
    .find((l) => l.id === lessonId && l.is_free_preview);
  if (!course || !lesson) notFound();

  // RLS only returns content for free-preview lessons of published courses.
  const { data: content } = await createPublicClient()
    .from("lesson_contents")
    .select("body_md, video_url")
    .eq("lesson_id", lesson.id)
    .maybeSingle();
  if (!content) notFound();

  return (
    <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <Link
        href={`/courses/${course.slug}`}
        className="text-primary inline-flex items-center gap-1.5 text-sm font-medium underline-offset-4 hover:underline"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> {course.title}
      </Link>
      <div className="mt-6">
        <Badge variant="outline" className="border-highlight text-highlight-text">
          Free preview
        </Badge>
      </div>
      <h1 className="mt-3 text-3xl font-semibold">{lesson.title}</h1>
      {content.video_url && (
        <div className="mt-8">
          <VideoPlayer url={content.video_url} title={lesson.title} />
        </div>
      )}
      <Markdown className="mt-8">{content.body_md}</Markdown>
    </article>
  );
}
