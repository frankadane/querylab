import { SearchX } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { z } from "zod";
import { CourseCard } from "@/components/courses/course-card";
import { Button } from "@/components/ui/button";
import { FORMATS, LEVELS, TRACKS } from "@/lib/courses/format";
import { listPublishedCourses } from "@/lib/courses/queries";

export const metadata: Metadata = {
  title: "Courses",
  description:
    "Search QueryLab courses in Applied AI, Data Science with Python & SQL, and Power BI. Filter by track, level, format and price.",
  alternates: { canonical: "/courses" },
};

const filtersSchema = z.object({
  q: z.string().trim().max(100).optional().catch(undefined),
  track: z.enum(["ai", "data_science", "power_bi"]).optional().catch(undefined),
  level: z.enum(["beginner", "intermediate", "advanced"]).optional().catch(undefined),
  format: z.enum(["self_paced", "live_cohort", "hybrid"]).optional().catch(undefined),
  price: z.enum(["free", "paid"]).optional().catch(undefined),
});

const selectClass =
  "h-11 w-full rounded-lg border border-input bg-background px-3 text-base sm:text-sm";

export default async function CoursesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string>>;
}) {
  const raw = await searchParams;
  const filters = filtersSchema.parse(
    Object.fromEntries(Object.entries(raw).filter(([, v]) => v !== "")),
  );
  const courses = await listPublishedCourses(filters);
  const active = Object.values(filters).some(Boolean);

  return (
    <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-semibold">Courses</h1>
      <p className="text-muted-foreground mt-3 max-w-2xl text-lg">
        Self-paced and live courses in Applied AI, Data Science and Power BI.
      </p>

      <form
        role="search"
        aria-label="Filter courses"
        className="bg-card mt-10 grid gap-4 rounded-xl border p-4 sm:grid-cols-2 lg:grid-cols-[2fr_repeat(4,1fr)_auto] lg:items-end"
      >
        <div className="grid gap-2 sm:col-span-2 lg:col-span-1">
          <label htmlFor="q" className="text-sm font-medium">
            Search
          </label>
          <input
            id="q"
            name="q"
            type="search"
            defaultValue={filters.q}
            placeholder="e.g. DAX, pandas, prompting"
            className={selectClass}
          />
        </div>
        <Filter id="track" label="Track" value={filters.track} options={TRACKS} />
        <Filter id="level" label="Level" value={filters.level} options={LEVELS} />
        <Filter id="format" label="Format" value={filters.format} options={FORMATS} />
        <Filter
          id="price"
          label="Price"
          value={filters.price}
          options={{ free: "Free", paid: "Paid" }}
        />
        <div className="flex gap-2 sm:col-span-2 lg:col-span-1">
          <Button type="submit" size="lg" className="h-11 flex-1 px-5">
            Apply
          </Button>
          {active && (
            <Button asChild variant="ghost" size="lg" className="h-11 px-3">
              <Link href="/courses">Clear</Link>
            </Button>
          )}
        </div>
      </form>

      <p className="text-muted-foreground mt-8 text-sm" role="status">
        {courses.length} {courses.length === 1 ? "course" : "courses"}
        {active ? " match your filters" : ""}
      </p>

      {courses.length ? (
        <ul className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((c) => (
            <li key={c.id}>
              <CourseCard course={c} />
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-4 flex flex-col items-center rounded-xl border border-dashed px-6 py-16 text-center">
          <SearchX className="text-muted-foreground size-8" aria-hidden="true" />
          <h2 className="mt-4 text-lg font-semibold">No courses match</h2>
          <p className="text-muted-foreground mt-1">
            Try a different search term or remove a filter.
          </p>
          <Button asChild variant="outline" size="lg" className="mt-6 h-11 px-5">
            <Link href="/courses">Show all courses</Link>
          </Button>
        </div>
      )}
    </div>
  );
}

function Filter({
  id,
  label,
  value,
  options,
}: {
  id: string;
  label: string;
  value?: string;
  options: Record<string, string>;
}) {
  return (
    <div className="grid gap-2">
      <label htmlFor={id} className="text-sm font-medium">
        {label}
      </label>
      <select id={id} name={id} defaultValue={value ?? ""} className={selectClass}>
        <option value="">All</option>
        {Object.entries(options).map(([k, v]) => (
          <option key={k} value={k}>
            {v}
          </option>
        ))}
      </select>
    </div>
  );
}
