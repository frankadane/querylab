import type { Metadata } from "next";
import Link from "next/link";
import { Markdown } from "@/components/content/markdown";
import { Badge } from "@/components/ui/badge";
import { listInstructors } from "@/lib/courses/queries";

export const metadata: Metadata = {
  title: "Instructors",
  description: "The people who teach QueryLab courses.",
};
export const revalidate = 300;

export default async function InstructorsPage() {
  const instructors = await listInstructors();
  return (
    <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-semibold">Instructors</h1>
      <p className="text-muted-foreground mt-3 max-w-2xl text-lg">
        Practitioners who use these tools at work.
      </p>
      <ul className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {instructors.map((i) => (
          <li key={i.id} className="bg-card flex flex-col rounded-xl border p-6">
            <div className="flex items-center gap-4">
              <div
                aria-hidden="true"
                className="bg-secondary text-secondary-foreground flex size-14 items-center justify-center rounded-full text-lg font-semibold"
              >
                {i.display_name
                  .replace(/^Placeholder:\s*/, "")
                  .split(" ")
                  .map((p) => p[0])
                  .slice(0, 2)
                  .join("")}
              </div>
              <div>
                <h2 className="font-semibold">{i.display_name}</h2>
                {i.headline && <p className="text-muted-foreground text-sm">{i.headline}</p>}
              </div>
            </div>
            {i.is_placeholder && (
              <Badge
                variant="outline"
                className="border-highlight text-highlight-text mt-4 self-start"
              >
                Placeholder profile
              </Badge>
            )}
            {i.bio_md && (
              <Markdown className="text-muted-foreground mt-4 flex-1 text-sm">{i.bio_md}</Markdown>
            )}
            {i.courses.length > 0 && (
              <div className="mt-5 border-t pt-4">
                <h3 className="text-muted-foreground text-xs font-semibold tracking-wide uppercase">
                  Teaches
                </h3>
                <ul className="mt-2 space-y-1">
                  {i.courses.map((c) => (
                    <li key={c.slug}>
                      <Link
                        href={`/courses/${c.slug}`}
                        className="text-primary text-sm font-medium underline-offset-4 hover:underline"
                      >
                        {c.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
