"use client";

import Link from "next/link";
import { useEffect, useId } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { signUpSchema } from "@/lib/validation/auth";
import { signUp } from "../actions";

export function RegisterForm() {
  const { form, pending, result, onSubmit } = useActionForm(signUpSchema, signUp, {
    fullName: "",
    email: "",
    password: "",
    timezone: "Africa/Accra",
  });
  const { errors } = form.formState;
  const termsId = useId();

  // Default the timezone to the browser's; users can change it later in their profile.
  useEffect(() => {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (tz) form.setValue("timezone", tz);
  }, [form]);

  if (result?.ok) {
    return (
      <FormAlert kind="success">
        <p className="font-medium">Check your email</p>
        <p className="mt-1">{result.message} The link expires in 1 hour.</p>
        <p className="mt-3">
          Didn&apos;t get it?{" "}
          <Link href="/verify-email" className="font-medium underline">
            Resend the email
          </Link>
        </p>
      </FormAlert>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5">
      {result && !result.ok && <FormAlert kind="error">{result.error}</FormAlert>}
      <FormField
        label="Full name"
        autoComplete="name"
        registration={form.register("fullName")}
        error={errors.fullName}
      />
      <FormField
        label="Email"
        type="email"
        autoComplete="email"
        registration={form.register("email")}
        error={errors.email}
      />
      <FormField
        label="Password"
        type="password"
        autoComplete="new-password"
        hint="At least 10 characters, with a letter and a number."
        registration={form.register("password")}
        error={errors.password}
      />
      <input type="hidden" {...form.register("timezone")} />
      <div className="grid gap-1.5">
        <div className="flex items-start gap-3">
          <input
            id={termsId}
            type="checkbox"
            className="accent-primary mt-0.5 size-5 shrink-0"
            aria-invalid={errors.acceptTerms ? true : undefined}
            aria-describedby={errors.acceptTerms ? `${termsId}-error` : undefined}
            {...form.register("acceptTerms")}
          />
          <label htmlFor={termsId} className="text-sm leading-6">
            I agree to the{" "}
            <Link href="/terms" className="text-primary font-medium underline">
              terms of service
            </Link>{" "}
            and{" "}
            <Link href="/privacy" className="text-primary font-medium underline">
              privacy policy
            </Link>
            .
          </label>
        </div>
        {errors.acceptTerms && (
          <p id={`${termsId}-error`} className="text-destructive text-sm font-medium">
            {errors.acceptTerms.message}
          </p>
        )}
      </div>
      <SubmitButton pending={pending}>Create account</SubmitButton>
    </form>
  );
}
