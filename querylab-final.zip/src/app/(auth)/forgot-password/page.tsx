import type { Metadata } from "next";
import Link from "next/link";
import { AuthCard } from "@/components/forms/auth-card";
import { EmailLinkForm } from "@/components/forms/email-link-form";
import { requestPasswordReset } from "../actions";

export const metadata: Metadata = { title: "Reset your password" };

export default function ForgotPasswordPage() {
  return (
    <AuthCard
      title="Reset your password"
      description="Enter your account email and we'll send you a link to choose a new password."
      footer={
        <Link href="/login" className="text-primary font-medium underline-offset-4 hover:underline">
          Back to log in
        </Link>
      }
    >
      <EmailLinkForm action={requestPasswordReset} submitLabel="Send reset link" />
    </AuthCard>
  );
}
