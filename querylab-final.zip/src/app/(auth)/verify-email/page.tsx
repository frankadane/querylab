import type { Metadata } from "next";
import Link from "next/link";
import { AuthCard } from "@/components/forms/auth-card";
import { EmailLinkForm } from "@/components/forms/email-link-form";
import { resendConfirmation } from "../actions";

export const metadata: Metadata = { title: "Confirm your email" };

export default function VerifyEmailPage() {
  return (
    <AuthCard
      title="Resend confirmation email"
      description="Didn't receive the confirmation link, or did it expire? We'll send a new one."
      footer={
        <Link href="/login" className="text-primary font-medium underline-offset-4 hover:underline">
          Back to log in
        </Link>
      }
    >
      <EmailLinkForm action={resendConfirmation} submitLabel="Resend email" />
    </AuthCard>
  );
}
