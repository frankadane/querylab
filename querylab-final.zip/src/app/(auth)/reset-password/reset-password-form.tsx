"use client";

import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { resetPasswordSchema } from "@/lib/validation/auth";
import { updatePasswordAfterReset } from "../actions";

export function ResetPasswordForm() {
  const { form, pending, result, onSubmit } = useActionForm(
    resetPasswordSchema,
    updatePasswordAfterReset,
    {
      password: "",
      confirm: "",
    },
  );
  const { errors } = form.formState;
  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5">
      {result && !result.ok && <FormAlert kind="error">{result.error}</FormAlert>}
      <FormField
        label="New password"
        type="password"
        autoComplete="new-password"
        hint="At least 10 characters, with a letter and a number."
        registration={form.register("password")}
        error={errors.password}
      />
      <FormField
        label="Confirm new password"
        type="password"
        autoComplete="new-password"
        registration={form.register("confirm")}
        error={errors.confirm}
      />
      <SubmitButton pending={pending}>Save new password</SubmitButton>
    </form>
  );
}
