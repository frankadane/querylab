"use server";

import { redirect } from "next/navigation";
import { type ActionResult, GENERIC_ERROR, RATE_LIMITED, invalid } from "@/lib/action-result";
import { publicEnv } from "@/lib/env";
import { rateLimit } from "@/lib/rate-limit";
import { safeNext } from "@/lib/safe-redirect";
import { createClient } from "@/lib/supabase/server";
import {
  emailOnlySchema,
  resetPasswordSchema,
  signInSchema,
  signUpSchema,
} from "@/lib/validation/auth";

const site = publicEnv.NEXT_PUBLIC_SITE_URL;

/** Generic copy so responses never reveal whether an email is registered. */
const CHECK_INBOX =
  "If that email can be used, we've sent a link to it. Check your inbox (and spam folder).";

export async function signUp(input: unknown): Promise<ActionResult> {
  const parsed = signUpSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { email, password, fullName, timezone } = parsed.data;

  if (!(await rateLimit("signUp", email))) return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${site}/auth/confirm?next=/dashboard`,
      // Only display data. Role is never read from metadata.
      data: { full_name: fullName, timezone },
    },
  });

  if (error) {
    if (error.code === "weak_password") {
      return {
        ok: false,
        error: "Choose a stronger password.",
        fieldErrors: { password: [error.message] },
      };
    }
    if (error.status === 429) return { ok: false, error: RATE_LIMITED };
    // "User already registered" etc. are hidden behind the generic message.
    if (error.code !== "user_already_exists")
      console.error("[auth] signUp", error.code, error.message);
  }
  return { ok: true, message: "Account created. We've sent you an email to confirm your address." };
}

export async function signIn(input: unknown, next?: string): Promise<ActionResult> {
  const parsed = signInSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { email, password } = parsed.data;

  if (!(await rateLimit("signIn", email))) return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    if (error.code === "email_not_confirmed") {
      return {
        ok: false,
        error:
          "Please confirm your email first. Check your inbox for the link, or request a new one.",
      };
    }
    if (error.status === 429) return { ok: false, error: RATE_LIMITED };
    return { ok: false, error: "Email or password is incorrect." };
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("suspended_at")
    .eq("id", data.user.id)
    .single();
  if (profile?.suspended_at) {
    await supabase.auth.signOut();
    return {
      ok: false,
      error: "This account is suspended. Contact us if you think this is a mistake.",
    };
  }

  redirect(safeNext(next));
}

export async function sendMagicLink(input: unknown): Promise<ActionResult> {
  const parsed = emailOnlySchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { email } = parsed.data;

  if (!(await rateLimit("emailLink", email))) return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: { shouldCreateUser: false, emailRedirectTo: `${site}/auth/confirm?next=/dashboard` },
  });
  if (error && error.status === 429) return { ok: false, error: RATE_LIMITED };
  return { ok: true, message: CHECK_INBOX };
}

export async function requestPasswordReset(input: unknown): Promise<ActionResult> {
  const parsed = emailOnlySchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  const { email } = parsed.data;

  if (!(await rateLimit("emailLink", email))) return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${site}/auth/confirm?next=/reset-password`,
  });
  if (error && error.status === 429) return { ok: false, error: RATE_LIMITED };
  return { ok: true, message: CHECK_INBOX };
}

export async function resendConfirmation(input: unknown): Promise<ActionResult> {
  const parsed = emailOnlySchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);
  if (!(await rateLimit("emailLink", parsed.data.email))) return { ok: false, error: RATE_LIMITED };

  const supabase = await createClient();
  await supabase.auth.resend({
    type: "signup",
    email: parsed.data.email,
    options: { emailRedirectTo: `${site}/auth/confirm?next=/dashboard` },
  });
  return { ok: true, message: CHECK_INBOX };
}

/** Sets a new password after arriving from a recovery link (session already established). */
export async function updatePasswordAfterReset(input: unknown): Promise<ActionResult> {
  const parsed = resetPasswordSchema.safeParse(input);
  if (!parsed.success) return invalid(parsed.error);

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false, error: "Your reset link has expired. Request a new one." };

  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) {
    if (error.code === "same_password") {
      return { ok: false, error: "Choose a password you haven't used here before." };
    }
    if (error.code === "weak_password") return { ok: false, error: "Choose a stronger password." };
    console.error("[auth] reset", error.code, error.message);
    return { ok: false, error: GENERIC_ERROR };
  }
  redirect("/dashboard?passwordReset=1");
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}
