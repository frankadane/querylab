import type { Metadata } from "next";
import { AuthCard } from "@/components/forms/auth-card";
import { siteConfig } from "@/lib/site";
import { signOut } from "../actions";

export const metadata: Metadata = { title: "Account suspended", robots: { index: false } };

export default function SuspendedPage() {
  return (
    <AuthCard
      title="Account suspended"
      description={
        <>
          Your account has been suspended. If you think this is a mistake, email{" "}
          <a
            className="text-primary font-medium underline"
            href={`mailto:${siteConfig.contactEmail}`}
          >
            {siteConfig.contactEmail}
          </a>
          .
        </>
      }
    >
      <form action={signOut}>
        <button type="submit" className="text-primary font-medium underline">
          Log out
        </button>
      </form>
    </AuthCard>
  );
}
