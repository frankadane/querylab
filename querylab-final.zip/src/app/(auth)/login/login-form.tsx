"use client";

import Link from "next/link";
import { useState } from "react";
import { FormAlert } from "@/components/forms/form-alert";
import { FormField } from "@/components/forms/form-field";
import { SubmitButton } from "@/components/forms/submit-button";
import { useActionForm } from "@/components/forms/use-action-form";
import { Button } from "@/components/ui/button";
import { emailOnlySchema, signInSchema } from "@/lib/validation/auth";
import { sendMagicLink, signIn } from "../actions";

export function LoginForm({ next }: { next?: string }) {
  const [mode, setMode] = useState<"password" | "magic">("password");
  return mode === "password" ? (
    <PasswordForm next={next} onMagic={() => setMode("magic")} />
  ) : (
    <MagicForm onPassword={() => setMode("password")} />
  );
}

function PasswordForm({ next, onMagic }: { next?: string; onMagic: () => void }) {
  const { form, pending, result, onSubmit } = useActionForm(signInSchema, (v) => signIn(v, next), {
    email: "",
    password: "",
  });
  const { errors } = form.formState;
  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5">
      {result && !result.ok && <FormAlert kind="error">{result.error}</FormAlert>}
      <FormField
        label="Email"
        type="email"
        autoComplete="email"
        registration={form.register("email")}
        error={errors.email}
      />
      <div className="grid gap-2">
        <FormField
          label="Password"
          type="password"
          autoComplete="current-password"
          registration={form.register("password")}
          error={errors.password}
        />
        <Link
          href="/forgot-password"
          className="text-primary justify-self-end py-1 text-sm font-medium underline-offset-4 hover:underline"
        >
          Forgot password?
        </Link>
      </div>
      <SubmitButton pending={pending}>Log in</SubmitButton>
      <Button type="button" variant="outline" size="lg" className="h-11" onClick={onMagic}>
        Email me a sign-in link instead
      </Button>
    </form>
  );
}

function MagicForm({ onPassword }: { onPassword: () => void }) {
  const { form, pending, result, onSubmit } = useActionForm(emailOnlySchema, sendMagicLink, {
    email: "",
  });
  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5">
      <p className="text-muted-foreground">
        We&apos;ll email you a link that signs you in without a password.
      </p>
      {result && (
        <FormAlert kind={result.ok ? "success" : "error"}>
          {result.ok ? result.message : result.error}
        </FormAlert>
      )}
      <FormField
        label="Email"
        type="email"
        autoComplete="email"
        registration={form.register("email")}
        error={form.formState.errors.email}
      />
      <SubmitButton pending={pending}>Send sign-in link</SubmitButton>
      <Button type="button" variant="ghost" size="lg" className="h-11" onClick={onPassword}>
        Use my password instead
      </Button>
    </form>
  );
}
