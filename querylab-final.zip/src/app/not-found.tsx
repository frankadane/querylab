import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <main id="main" className="mx-auto flex min-h-dvh max-w-xl flex-col justify-center px-4">
      <p className="text-highlight-text font-mono text-sm">404</p>
      <h1 className="mt-3 text-3xl font-semibold">Page not found</h1>
      <p className="text-muted-foreground mt-3">
        The page you asked for does not exist or has moved.
      </p>
      <Button asChild size="lg" className="mt-8 h-11 self-start px-5">
        <Link href="/">Go to home</Link>
      </Button>
    </main>
  );
}
