import "server-only";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

const INK = rgb(11 / 255, 21 / 255, 48 / 255);
const INDIGO = rgb(67 / 255, 56 / 255, 202 / 255);
const AMBER = rgb(245 / 255, 158 / 255, 11 / 255);
const MUTED = rgb(74 / 255, 84 / 255, 112 / 255);

/** A4 landscape certificate. Text is real (selectable, screen-reader friendly), not an image. */
export async function renderCertificatePdf(c: {
  serial: string;
  holderName: string;
  courseTitle: string;
  issuedAt: string;
  verifyUrl: string;
}) {
  const pdf = await PDFDocument.create();
  pdf.setTitle(`QueryLab certificate: ${c.courseTitle}`);
  pdf.setAuthor("QueryLab");
  pdf.setSubject(`Certificate of completion for ${c.holderName}`);
  pdf.setLanguage("en-GB");
  const page = pdf.addPage([841.89, 595.28]);
  const { width, height } = page.getSize();
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

  page.drawRectangle({
    x: 24,
    y: 24,
    width: width - 48,
    height: height - 48,
    borderColor: INK,
    borderWidth: 1.5,
  });
  page.drawRectangle({ x: 24, y: height - 32, width: width - 48, height: 8, color: INDIGO });

  // Logo bars
  [
    [0, 14],
    [9, 22],
    [18, 30],
  ].forEach(([dx, h], i) =>
    page.drawRectangle({
      x: 64 + dx,
      y: height - 104,
      width: 6,
      height: h,
      color: i === 2 ? AMBER : INDIGO,
    }),
  );
  page.drawText("QueryLab", { x: 96, y: height - 100, size: 20, font: bold, color: INK });

  const center = (text: string, y: number, size: number, font = regular, color = INK) => {
    const w = font.widthOfTextAtSize(text, size);
    page.drawText(text, { x: (width - w) / 2, y, size, font, color });
  };
  const fit = (text: string, max: number, size: number, font = bold) => {
    let s = size;
    while (font.widthOfTextAtSize(text, s) > max && s > 14) s -= 1;
    return s;
  };

  center("CERTIFICATE OF COMPLETION", height - 190, 14, bold, MUTED);
  center("This certifies that", height - 240, 14, regular, MUTED);
  center(c.holderName, height - 290, fit(c.holderName, width - 160, 36), bold, INK);
  page.drawLine({
    start: { x: width / 2 - 180, y: height - 305 },
    end: { x: width / 2 + 180, y: height - 305 },
    thickness: 1,
    color: AMBER,
  });
  center("has successfully completed", height - 345, 14, regular, MUTED);
  center(c.courseTitle, height - 385, fit(c.courseTitle, width - 160, 26), bold, INDIGO);

  const issued = new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(c.issuedAt));
  page.drawText(`Issued ${issued}`, { x: 64, y: 72, size: 11, font: regular, color: MUTED });
  page.drawText(`Certificate ID ${c.serial}`, { x: 64, y: 56, size: 11, font: bold, color: INK });
  const v = `Verify at ${c.verifyUrl}`;
  page.drawText(v, {
    x: width - 64 - regular.widthOfTextAtSize(v, 10),
    y: 56,
    size: 10,
    font: regular,
    color: MUTED,
  });

  return pdf.save();
}
