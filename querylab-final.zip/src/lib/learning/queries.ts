import "server-only";
import { cache } from "react";
import { createClient } from "@/lib/supabase/server";

/** Course structure + the viewer's progress, through RLS (enrolled students and staff only). */
export const getLearningCourse = cache(async (slug: string, userId: string) => {
  const supabase = await createClient();
  const { data: course } = await supabase
    .from("courses")
    .select(
      "id, slug, title, status, price_minor, sections(id, title, position, lessons(id, title, type, duration_minutes, is_free_preview, position))",
    )
    .eq("slug", slug)
    .order("position", { referencedTable: "sections" })
    .order("position", { referencedTable: "sections.lessons" })
    .maybeSingle();
  if (!course) return null;

  const [
    { data: enrolment },
    { data: staff },
    { data: progressRows },
    { data: prog },
    { data: cert },
  ] = await Promise.all([
    supabase
      .from("enrolments")
      .select("status")
      .eq("course_id", course.id)
      .eq("user_id", userId)
      .maybeSingle(),
    supabase.rpc("is_course_staff", { p_course_id: course.id }),
    supabase
      .from("lesson_progress")
      .select("lesson_id, source")
      .eq("course_id", course.id)
      .eq("user_id", userId),
    supabase.rpc("course_progress", { p_course_id: course.id }),
    supabase
      .from("certificates")
      .select("serial, issued_at")
      .eq("course_id", course.id)
      .eq("user_id", userId)
      .maybeSingle(),
  ]);

  const lessons = course.sections.flatMap((s) =>
    s.lessons.map((l) => ({ ...l, sectionTitle: s.title })),
  );
  return {
    course,
    lessons,
    enrolled: enrolment?.status === "active",
    isStaff: !!staff,
    done: new Set((progressRows ?? []).map((p) => p.lesson_id)),
    progress: prog?.[0] ?? {
      completed: 0,
      total: lessons.length,
      percent: 0,
      required_completed: 0,
      required_total: 0,
    },
    certificate: cert,
  };
});

export type LearningCourse = NonNullable<Awaited<ReturnType<typeof getLearningCourse>>>;

/** Enrolled courses with progress for the dashboard. */
export async function myCourses(userId: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("enrolments")
    .select("course:courses(id, slug, title, track, thumbnail_url, status)")
    .eq("user_id", userId)
    .eq("status", "active")
    .order("created_at", { ascending: false });
  const courses = (data ?? [])
    .map((e) => e.course)
    .filter((c): c is NonNullable<typeof c> => !!c && c.status !== "draft");
  return Promise.all(
    courses.map(async (c) => {
      const { data: p } = await supabase.rpc("course_progress", { p_course_id: c.id });
      return {
        ...c,
        progress: p?.[0] ?? {
          completed: 0,
          total: 0,
          percent: 0,
          required_completed: 0,
          required_total: 0,
        },
      };
    }),
  );
}
