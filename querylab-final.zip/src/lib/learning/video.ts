export type VideoEmbed =
  { provider: "YouTube" | "Vimeo" | "Mux"; src: string } | { provider: "placeholder" } | null;

/**
 * Converts a pasted video page URL into a privacy-friendly embed URL.
 * Only these three hosts are ever embedded; anything else returns null.
 */
export function toVideoEmbed(url: string | null | undefined): VideoEmbed {
  if (!url) return null;
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    return null;
  }
  if (u.protocol !== "https:") return null;
  const host = u.hostname.replace(/^www\./, "").replace(/^m\./, "");
  if (host === "example.com") return { provider: "placeholder" };

  const id = (re: RegExp, s: string) => s.match(re)?.[1];
  const ytId = /^[\w-]{11}$/;

  if (host === "youtube.com" || host === "youtube-nocookie.com") {
    const v = u.searchParams.get("v") ?? id(/^\/(?:embed|shorts|live)\/([\w-]{11})/, u.pathname);
    if (v && ytId.test(v))
      return { provider: "YouTube", src: `https://www.youtube-nocookie.com/embed/${v}?rel=0` };
  }
  if (host === "youtu.be") {
    const v = u.pathname.slice(1);
    if (ytId.test(v))
      return { provider: "YouTube", src: `https://www.youtube-nocookie.com/embed/${v}?rel=0` };
  }
  if (host === "vimeo.com" || host === "player.vimeo.com") {
    const v = id(/(?:\/video)?\/(\d{5,12})(?:\/([0-9a-f]{6,20}))?/, u.pathname);
    const hash = u.pathname.match(/\/\d{5,12}\/([0-9a-f]{6,20})/)?.[1] ?? u.searchParams.get("h");
    if (v)
      return {
        provider: "Vimeo",
        src: `https://player.vimeo.com/video/${v}?dnt=1${hash ? `&h=${hash}` : ""}`,
      };
  }
  if (host === "stream.mux.com" || host === "player.mux.com") {
    const v = id(/^\/([A-Za-z0-9]{10,64})/, u.pathname);
    if (v) return { provider: "Mux", src: `https://player.mux.com/${v}` };
  }
  return null;
}
