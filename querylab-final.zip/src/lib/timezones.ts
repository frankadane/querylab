/** IANA timezones supported by the runtime, with Africa/Accra first. */
export function listTimezones(): string[] {
  const all =
    typeof Intl.supportedValuesOf === "function" ? Intl.supportedValuesOf("timeZone") : [];
  const set = new Set(["Africa/Accra", "UTC", ...all]);
  return Array.from(set);
}

export function isValidTimezone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat("en", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}
