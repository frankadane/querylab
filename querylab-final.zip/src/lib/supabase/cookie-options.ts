import type { CookieOptionsWithName } from "@supabase/ssr";

/**
 * Session cookies are httpOnly (unreadable by page JS) and Secure in
 * production. All Supabase calls happen on the server, so the browser
 * never needs the token.
 */
export const authCookieOptions: CookieOptionsWithName = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax",
  path: "/",
};

/** Non-sensitive flag so static pages can show "Dashboard" instead of "Log in". */
export const SIGNED_IN_FLAG = "ql-signed-in";
