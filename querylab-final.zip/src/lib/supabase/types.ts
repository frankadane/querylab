export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  graphql_public: {
    Tables: {
      [_ in never]: never;
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      graphql: {
        Args: { extensions?: Json; operationName?: string; query?: string; variables?: Json };
        Returns: Json;
      };
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
  public: {
    Tables: {
      audit_log: {
        Row: {
          action: string;
          actor_id: string | null;
          created_at: string;
          id: number;
          metadata: NonNullable<Json>;
          target_id: string | null;
          target_type: string | null;
        };
        ComputedFields: never;
        Insert: {
          action: string;
          actor_id?: string | null;
          created_at?: string;
          id?: never;
          metadata?: NonNullable<Json>;
          target_id?: string | null;
          target_type?: string | null;
        };
        Update: {
          action?: string;
          actor_id?: string | null;
          created_at?: string;
          id?: never;
          metadata?: NonNullable<Json>;
          target_id?: string | null;
          target_type?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "audit_log_actor_id_fkey";
            columns: ["actor_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      certificates: {
        Row: {
          course_id: string;
          course_title: string;
          holder_name: string;
          id: string;
          issued_at: string;
          serial: string;
          user_id: string;
        };
        ComputedFields: never;
        Insert: {
          course_id: string;
          course_title: string;
          holder_name: string;
          id?: string;
          issued_at?: string;
          serial: string;
          user_id: string;
        };
        Update: {
          course_id?: string;
          course_title?: string;
          holder_name?: string;
          id?: string;
          issued_at?: string;
          serial?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "certificates_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "certificates_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      coupons: {
        Row: {
          amount: number;
          code: string;
          course_id: string | null;
          created_at: string;
          created_by: string | null;
          currency: Database["public"]["Enums"]["currency_code"] | null;
          expires_at: string | null;
          id: string;
          is_active: boolean;
          kind: Database["public"]["Enums"]["coupon_kind"];
          max_redemptions: number | null;
          redemptions: number;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          amount: number;
          code: string;
          course_id?: string | null;
          created_at?: string;
          created_by?: string | null;
          currency?: Database["public"]["Enums"]["currency_code"] | null;
          expires_at?: string | null;
          id?: string;
          is_active?: boolean;
          kind: Database["public"]["Enums"]["coupon_kind"];
          max_redemptions?: number | null;
          redemptions?: number;
          updated_at?: string;
        };
        Update: {
          amount?: number;
          code?: string;
          course_id?: string | null;
          created_at?: string;
          created_by?: string | null;
          currency?: Database["public"]["Enums"]["currency_code"] | null;
          expires_at?: string | null;
          id?: string;
          is_active?: boolean;
          kind?: Database["public"]["Enums"]["coupon_kind"];
          max_redemptions?: number | null;
          redemptions?: number;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "coupons_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "coupons_created_by_fkey";
            columns: ["created_by"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      courses: {
        Row: {
          created_at: string;
          created_by: string | null;
          currency: Database["public"]["Enums"]["currency_code"];
          description_md: string;
          duration_weeks: number | null;
          format: Database["public"]["Enums"]["course_format"];
          id: string;
          instructor_id: string | null;
          is_demo: boolean;
          level_max: Database["public"]["Enums"]["course_level"];
          level_min: Database["public"]["Enums"]["course_level"];
          outcomes: string[];
          price_minor: number;
          published_at: string | null;
          requirements: string[];
          search: unknown;
          slug: string;
          status: Database["public"]["Enums"]["course_status"];
          subtitle: string | null;
          thumbnail_url: string | null;
          title: string;
          track: Database["public"]["Enums"]["course_track"];
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          created_at?: string;
          created_by?: string | null;
          currency?: Database["public"]["Enums"]["currency_code"];
          description_md?: string;
          duration_weeks?: number | null;
          format?: Database["public"]["Enums"]["course_format"];
          id?: string;
          instructor_id?: string | null;
          is_demo?: boolean;
          level_max?: Database["public"]["Enums"]["course_level"];
          level_min?: Database["public"]["Enums"]["course_level"];
          outcomes?: string[];
          price_minor?: number;
          published_at?: string | null;
          requirements?: string[];
          search?: never;
          slug: string;
          status?: Database["public"]["Enums"]["course_status"];
          subtitle?: string | null;
          thumbnail_url?: string | null;
          title: string;
          track: Database["public"]["Enums"]["course_track"];
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          created_by?: string | null;
          currency?: Database["public"]["Enums"]["currency_code"];
          description_md?: string;
          duration_weeks?: number | null;
          format?: Database["public"]["Enums"]["course_format"];
          id?: string;
          instructor_id?: string | null;
          is_demo?: boolean;
          level_max?: Database["public"]["Enums"]["course_level"];
          level_min?: Database["public"]["Enums"]["course_level"];
          outcomes?: string[];
          price_minor?: number;
          published_at?: string | null;
          requirements?: string[];
          search?: never;
          slug?: string;
          status?: Database["public"]["Enums"]["course_status"];
          subtitle?: string | null;
          thumbnail_url?: string | null;
          title?: string;
          track?: Database["public"]["Enums"]["course_track"];
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "courses_created_by_fkey";
            columns: ["created_by"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "courses_instructor_id_fkey";
            columns: ["instructor_id"];
            isOneToOne: false;
            referencedRelation: "instructors";
            referencedColumns: ["id"];
          },
        ];
      };
      enquiries: {
        Row: {
          company: string | null;
          created_at: string;
          email: string;
          id: string;
          kind: Database["public"]["Enums"]["enquiry_kind"];
          message: string;
          name: string;
          status: Database["public"]["Enums"]["enquiry_status"];
          team_size: string | null;
          topic: string | null;
          updated_at: string;
          user_id: string | null;
        };
        ComputedFields: never;
        Insert: {
          company?: string | null;
          created_at?: string;
          email: string;
          id?: string;
          kind: Database["public"]["Enums"]["enquiry_kind"];
          message: string;
          name: string;
          status?: Database["public"]["Enums"]["enquiry_status"];
          team_size?: string | null;
          topic?: string | null;
          updated_at?: string;
          user_id?: string | null;
        };
        Update: {
          company?: string | null;
          created_at?: string;
          email?: string;
          id?: string;
          kind?: Database["public"]["Enums"]["enquiry_kind"];
          message?: string;
          name?: string;
          status?: Database["public"]["Enums"]["enquiry_status"];
          team_size?: string | null;
          topic?: string | null;
          updated_at?: string;
          user_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "enquiries_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      enrolments: {
        Row: {
          course_id: string;
          created_at: string;
          id: string;
          order_id: string | null;
          source: Database["public"]["Enums"]["enrolment_source"];
          status: Database["public"]["Enums"]["enrolment_status"];
          updated_at: string;
          user_id: string;
        };
        ComputedFields: never;
        Insert: {
          course_id: string;
          created_at?: string;
          id?: string;
          order_id?: string | null;
          source: Database["public"]["Enums"]["enrolment_source"];
          status?: Database["public"]["Enums"]["enrolment_status"];
          updated_at?: string;
          user_id: string;
        };
        Update: {
          course_id?: string;
          created_at?: string;
          id?: string;
          order_id?: string | null;
          source?: Database["public"]["Enums"]["enrolment_source"];
          status?: Database["public"]["Enums"]["enrolment_status"];
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "enrolments_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "enrolments_order_id_fkey";
            columns: ["order_id"];
            isOneToOne: false;
            referencedRelation: "orders";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "enrolments_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      faqs: {
        Row: {
          answer_md: string;
          course_id: string | null;
          created_at: string;
          id: string;
          is_published: boolean;
          position: number;
          question: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          answer_md: string;
          course_id?: string | null;
          created_at?: string;
          id?: string;
          is_published?: boolean;
          position?: number;
          question: string;
          updated_at?: string;
        };
        Update: {
          answer_md?: string;
          course_id?: string | null;
          created_at?: string;
          id?: string;
          is_published?: boolean;
          position?: number;
          question?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "faqs_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
        ];
      };
      instructors: {
        Row: {
          bio_md: string | null;
          created_at: string;
          display_name: string;
          headline: string | null;
          id: string;
          is_demo: boolean;
          is_placeholder: boolean;
          is_published: boolean;
          photo_url: string | null;
          profile_id: string | null;
          slug: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          bio_md?: string | null;
          created_at?: string;
          display_name: string;
          headline?: string | null;
          id?: string;
          is_demo?: boolean;
          is_placeholder?: boolean;
          is_published?: boolean;
          photo_url?: string | null;
          profile_id?: string | null;
          slug: string;
          updated_at?: string;
        };
        Update: {
          bio_md?: string | null;
          created_at?: string;
          display_name?: string;
          headline?: string | null;
          id?: string;
          is_demo?: boolean;
          is_placeholder?: boolean;
          is_published?: boolean;
          photo_url?: string | null;
          profile_id?: string | null;
          slug?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "instructors_profile_id_fkey";
            columns: ["profile_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      lesson_contents: {
        Row: {
          body_md: string;
          course_id: string;
          file_path: string | null;
          lesson_id: string;
          updated_at: string;
          video_url: string | null;
        };
        ComputedFields: never;
        Insert: {
          body_md?: string;
          course_id: string;
          file_path?: string | null;
          lesson_id: string;
          updated_at?: string;
          video_url?: string | null;
        };
        Update: {
          body_md?: string;
          course_id?: string;
          file_path?: string | null;
          lesson_id?: string;
          updated_at?: string;
          video_url?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "lesson_contents_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "lesson_contents_lesson_id_fkey";
            columns: ["lesson_id"];
            isOneToOne: true;
            referencedRelation: "lessons";
            referencedColumns: ["id"];
          },
        ];
      };
      lesson_progress: {
        Row: {
          completed_at: string;
          course_id: string;
          lesson_id: string;
          source: string;
          user_id: string;
        };
        ComputedFields: never;
        Insert: {
          completed_at?: string;
          course_id: string;
          lesson_id: string;
          source?: string;
          user_id: string;
        };
        Update: {
          completed_at?: string;
          course_id?: string;
          lesson_id?: string;
          source?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "lesson_progress_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "lesson_progress_lesson_id_fkey";
            columns: ["lesson_id"];
            isOneToOne: false;
            referencedRelation: "lessons";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "lesson_progress_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      lessons: {
        Row: {
          course_id: string;
          created_at: string;
          duration_minutes: number | null;
          id: string;
          is_free_preview: boolean;
          position: number;
          section_id: string;
          summary: string | null;
          title: string;
          type: Database["public"]["Enums"]["lesson_type"];
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          course_id: string;
          created_at?: string;
          duration_minutes?: number | null;
          id?: string;
          is_free_preview?: boolean;
          position?: number;
          section_id: string;
          summary?: string | null;
          title: string;
          type?: Database["public"]["Enums"]["lesson_type"];
          updated_at?: string;
        };
        Update: {
          course_id?: string;
          created_at?: string;
          duration_minutes?: number | null;
          id?: string;
          is_free_preview?: boolean;
          position?: number;
          section_id?: string;
          summary?: string | null;
          title?: string;
          type?: Database["public"]["Enums"]["lesson_type"];
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "lessons_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "lessons_section_id_fkey";
            columns: ["section_id"];
            isOneToOne: false;
            referencedRelation: "sections";
            referencedColumns: ["id"];
          },
        ];
      };
      live_session_links: {
        Row: {
          join_url: string;
          session_id: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          join_url: string;
          session_id: string;
          updated_at?: string;
        };
        Update: {
          join_url?: string;
          session_id?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "live_session_links_session_id_fkey";
            columns: ["session_id"];
            isOneToOne: true;
            referencedRelation: "live_sessions";
            referencedColumns: ["id"];
          },
        ];
      };
      live_sessions: {
        Row: {
          cancel_reason: string | null;
          capacity: number;
          course_id: string | null;
          created_at: string;
          created_by: string | null;
          description_md: string;
          ends_at: string;
          id: string;
          instructor_id: string | null;
          is_demo: boolean;
          lesson_id: string | null;
          materials_md: string | null;
          recording_url: string | null;
          reminder_1h_sent_at: string | null;
          reminder_24h_sent_at: string | null;
          series_id: string | null;
          starts_at: string;
          status: Database["public"]["Enums"]["session_status"];
          timezone: string;
          title: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          cancel_reason?: string | null;
          capacity?: number;
          course_id?: string | null;
          created_at?: string;
          created_by?: string | null;
          description_md?: string;
          ends_at: string;
          id?: string;
          instructor_id?: string | null;
          is_demo?: boolean;
          lesson_id?: string | null;
          materials_md?: string | null;
          recording_url?: string | null;
          reminder_1h_sent_at?: string | null;
          reminder_24h_sent_at?: string | null;
          series_id?: string | null;
          starts_at: string;
          status?: Database["public"]["Enums"]["session_status"];
          timezone?: string;
          title: string;
          updated_at?: string;
        };
        Update: {
          cancel_reason?: string | null;
          capacity?: number;
          course_id?: string | null;
          created_at?: string;
          created_by?: string | null;
          description_md?: string;
          ends_at?: string;
          id?: string;
          instructor_id?: string | null;
          is_demo?: boolean;
          lesson_id?: string | null;
          materials_md?: string | null;
          recording_url?: string | null;
          reminder_1h_sent_at?: string | null;
          reminder_24h_sent_at?: string | null;
          series_id?: string | null;
          starts_at?: string;
          status?: Database["public"]["Enums"]["session_status"];
          timezone?: string;
          title?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "live_sessions_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "live_sessions_created_by_fkey";
            columns: ["created_by"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "live_sessions_instructor_id_fkey";
            columns: ["instructor_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "live_sessions_lesson_id_fkey";
            columns: ["lesson_id"];
            isOneToOne: false;
            referencedRelation: "lessons";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "live_sessions_series_id_fkey";
            columns: ["series_id"];
            isOneToOne: false;
            referencedRelation: "session_series";
            referencedColumns: ["id"];
          },
        ];
      };
      notifications: {
        Row: {
          body: string | null;
          created_at: string;
          id: string;
          link: string | null;
          read_at: string | null;
          title: string;
          type: string;
          user_id: string;
        };
        ComputedFields: never;
        Insert: {
          body?: string | null;
          created_at?: string;
          id?: string;
          link?: string | null;
          read_at?: string | null;
          title: string;
          type: string;
          user_id: string;
        };
        Update: {
          body?: string | null;
          created_at?: string;
          id?: string;
          link?: string | null;
          read_at?: string | null;
          title?: string;
          type?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      orders: {
        Row: {
          admin_note: string | null;
          billing_email: string;
          billing_name: string;
          cancelled_at: string | null;
          coupon_code: string | null;
          coupon_id: string | null;
          course_id: string;
          course_title: string;
          created_at: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor: number;
          id: string;
          invoice_number: string | null;
          paid_at: string | null;
          provider: string;
          provider_data: NonNullable<Json>;
          provider_ref: string | null;
          reference: string;
          refunded_at: string | null;
          status: Database["public"]["Enums"]["order_status"];
          subtotal_minor: number;
          total_minor: number;
          updated_at: string;
          user_id: string;
        };
        ComputedFields: never;
        Insert: {
          admin_note?: string | null;
          billing_email: string;
          billing_name: string;
          cancelled_at?: string | null;
          coupon_code?: string | null;
          coupon_id?: string | null;
          course_id: string;
          course_title: string;
          created_at?: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor?: number;
          id?: string;
          invoice_number?: string | null;
          paid_at?: string | null;
          provider: string;
          provider_data?: NonNullable<Json>;
          provider_ref?: string | null;
          reference: string;
          refunded_at?: string | null;
          status?: Database["public"]["Enums"]["order_status"];
          subtotal_minor: number;
          total_minor: number;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          admin_note?: string | null;
          billing_email?: string;
          billing_name?: string;
          cancelled_at?: string | null;
          coupon_code?: string | null;
          coupon_id?: string | null;
          course_id?: string;
          course_title?: string;
          created_at?: string;
          currency?: Database["public"]["Enums"]["currency_code"];
          discount_minor?: number;
          id?: string;
          invoice_number?: string | null;
          paid_at?: string | null;
          provider?: string;
          provider_data?: NonNullable<Json>;
          provider_ref?: string | null;
          reference?: string;
          refunded_at?: string | null;
          status?: Database["public"]["Enums"]["order_status"];
          subtotal_minor?: number;
          total_minor?: number;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "orders_coupon_id_fkey";
            columns: ["coupon_id"];
            isOneToOne: false;
            referencedRelation: "coupons";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "orders_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "orders_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      pages: {
        Row: {
          body_md: string;
          created_at: string;
          id: string;
          seo_description: string | null;
          seo_title: string | null;
          slug: string;
          status: Database["public"]["Enums"]["content_status"];
          title: string;
          updated_at: string;
          updated_by: string | null;
        };
        ComputedFields: never;
        Insert: {
          body_md?: string;
          created_at?: string;
          id?: string;
          seo_description?: string | null;
          seo_title?: string | null;
          slug: string;
          status?: Database["public"]["Enums"]["content_status"];
          title: string;
          updated_at?: string;
          updated_by?: string | null;
        };
        Update: {
          body_md?: string;
          created_at?: string;
          id?: string;
          seo_description?: string | null;
          seo_title?: string | null;
          slug?: string;
          status?: Database["public"]["Enums"]["content_status"];
          title?: string;
          updated_at?: string;
          updated_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "pages_updated_by_fkey";
            columns: ["updated_by"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      posts: {
        Row: {
          author_id: string | null;
          body_md: string;
          cover_alt: string | null;
          cover_url: string | null;
          created_at: string;
          excerpt: string | null;
          id: string;
          is_demo: boolean;
          published_at: string | null;
          seo_description: string | null;
          seo_title: string | null;
          slug: string;
          status: Database["public"]["Enums"]["content_status"];
          tags: string[];
          title: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          author_id?: string | null;
          body_md?: string;
          cover_alt?: string | null;
          cover_url?: string | null;
          created_at?: string;
          excerpt?: string | null;
          id?: string;
          is_demo?: boolean;
          published_at?: string | null;
          seo_description?: string | null;
          seo_title?: string | null;
          slug: string;
          status?: Database["public"]["Enums"]["content_status"];
          tags?: string[];
          title: string;
          updated_at?: string;
        };
        Update: {
          author_id?: string | null;
          body_md?: string;
          cover_alt?: string | null;
          cover_url?: string | null;
          created_at?: string;
          excerpt?: string | null;
          id?: string;
          is_demo?: boolean;
          published_at?: string | null;
          seo_description?: string | null;
          seo_title?: string | null;
          slug?: string;
          status?: Database["public"]["Enums"]["content_status"];
          tags?: string[];
          title?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "posts_author_id_fkey";
            columns: ["author_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          avatar_url: string | null;
          bio: string | null;
          created_at: string;
          email: string;
          full_name: string;
          id: string;
          is_demo: boolean;
          role: Database["public"]["Enums"]["user_role"];
          suspended_at: string | null;
          timezone: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          avatar_url?: string | null;
          bio?: string | null;
          created_at?: string;
          email: string;
          full_name?: string;
          id: string;
          is_demo?: boolean;
          role?: Database["public"]["Enums"]["user_role"];
          suspended_at?: string | null;
          timezone?: string;
          updated_at?: string;
        };
        Update: {
          avatar_url?: string | null;
          bio?: string | null;
          created_at?: string;
          email?: string;
          full_name?: string;
          id?: string;
          is_demo?: boolean;
          role?: Database["public"]["Enums"]["user_role"];
          suspended_at?: string | null;
          timezone?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      quiz_attempts: {
        Row: {
          answers: NonNullable<Json>;
          course_id: string;
          created_at: string;
          id: string;
          lesson_id: string;
          passed: boolean;
          quiz_id: string;
          score: number;
          user_id: string;
        };
        ComputedFields: never;
        Insert: {
          answers: NonNullable<Json>;
          course_id: string;
          created_at?: string;
          id?: string;
          lesson_id: string;
          passed: boolean;
          quiz_id: string;
          score: number;
          user_id: string;
        };
        Update: {
          answers?: NonNullable<Json>;
          course_id?: string;
          created_at?: string;
          id?: string;
          lesson_id?: string;
          passed?: boolean;
          quiz_id?: string;
          score?: number;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "quiz_attempts_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "quiz_attempts_lesson_id_fkey";
            columns: ["lesson_id"];
            isOneToOne: false;
            referencedRelation: "lessons";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "quiz_attempts_quiz_id_fkey";
            columns: ["quiz_id"];
            isOneToOne: false;
            referencedRelation: "quizzes";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "quiz_attempts_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      quiz_questions: {
        Row: {
          correct_index: number;
          created_at: string;
          explanation: string | null;
          id: string;
          options: NonNullable<Json>;
          position: number;
          prompt: string;
          quiz_id: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          correct_index: number;
          created_at?: string;
          explanation?: string | null;
          id?: string;
          options: NonNullable<Json>;
          position?: number;
          prompt: string;
          quiz_id: string;
          updated_at?: string;
        };
        Update: {
          correct_index?: number;
          created_at?: string;
          explanation?: string | null;
          id?: string;
          options?: NonNullable<Json>;
          position?: number;
          prompt?: string;
          quiz_id?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "quiz_questions_quiz_id_fkey";
            columns: ["quiz_id"];
            isOneToOne: false;
            referencedRelation: "quizzes";
            referencedColumns: ["id"];
          },
        ];
      };
      quizzes: {
        Row: {
          course_id: string;
          created_at: string;
          id: string;
          lesson_id: string;
          pass_mark: number;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          course_id: string;
          created_at?: string;
          id?: string;
          lesson_id: string;
          pass_mark?: number;
          updated_at?: string;
        };
        Update: {
          course_id?: string;
          created_at?: string;
          id?: string;
          lesson_id?: string;
          pass_mark?: number;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "quizzes_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "quizzes_lesson_id_fkey";
            columns: ["lesson_id"];
            isOneToOne: true;
            referencedRelation: "lessons";
            referencedColumns: ["id"];
          },
        ];
      };
      sections: {
        Row: {
          course_id: string;
          created_at: string;
          description: string | null;
          id: string;
          position: number;
          title: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          course_id: string;
          created_at?: string;
          description?: string | null;
          id?: string;
          position?: number;
          title: string;
          updated_at?: string;
        };
        Update: {
          course_id?: string;
          created_at?: string;
          description?: string | null;
          id?: string;
          position?: number;
          title?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "sections_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
        ];
      };
      session_registrations: {
        Row: {
          attended_at: string | null;
          created_at: string;
          id: string;
          session_id: string;
          status: Database["public"]["Enums"]["registration_status"];
          updated_at: string;
          user_id: string;
          waitlisted_at: string | null;
        };
        ComputedFields: never;
        Insert: {
          attended_at?: string | null;
          created_at?: string;
          id?: string;
          session_id: string;
          status: Database["public"]["Enums"]["registration_status"];
          updated_at?: string;
          user_id: string;
          waitlisted_at?: string | null;
        };
        Update: {
          attended_at?: string | null;
          created_at?: string;
          id?: string;
          session_id?: string;
          status?: Database["public"]["Enums"]["registration_status"];
          updated_at?: string;
          user_id?: string;
          waitlisted_at?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "session_registrations_session_id_fkey";
            columns: ["session_id"];
            isOneToOne: false;
            referencedRelation: "live_sessions";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "session_registrations_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      session_series: {
        Row: {
          course_id: string | null;
          created_at: string;
          created_by: string | null;
          id: string;
          interval_weeks: number;
          occurrences: number;
          timezone: string;
          title: string;
        };
        ComputedFields: never;
        Insert: {
          course_id?: string | null;
          created_at?: string;
          created_by?: string | null;
          id?: string;
          interval_weeks?: number;
          occurrences: number;
          timezone?: string;
          title: string;
        };
        Update: {
          course_id?: string | null;
          created_at?: string;
          created_by?: string | null;
          id?: string;
          interval_weeks?: number;
          occurrences?: number;
          timezone?: string;
          title?: string;
        };
        Relationships: [
          {
            foreignKeyName: "session_series_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "session_series_created_by_fkey";
            columns: ["created_by"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      site_settings: {
        Row: {
          address: string | null;
          bank_details: NonNullable<Json>;
          brand_name: string;
          contact_email: string;
          contact_phone: string | null;
          default_currency: Database["public"]["Enums"]["currency_code"];
          default_timezone: string;
          id: number;
          invoice_company_address: string;
          invoice_company_name: string;
          invoice_footer: string;
          invoice_tax_id: string | null;
          social_links: NonNullable<Json>;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          address?: string | null;
          bank_details?: NonNullable<Json>;
          brand_name?: string;
          contact_email?: string;
          contact_phone?: string | null;
          default_currency?: Database["public"]["Enums"]["currency_code"];
          default_timezone?: string;
          id?: number;
          invoice_company_address?: string;
          invoice_company_name?: string;
          invoice_footer?: string;
          invoice_tax_id?: string | null;
          social_links?: NonNullable<Json>;
          updated_at?: string;
        };
        Update: {
          address?: string | null;
          bank_details?: NonNullable<Json>;
          brand_name?: string;
          contact_email?: string;
          contact_phone?: string | null;
          default_currency?: Database["public"]["Enums"]["currency_code"];
          default_timezone?: string;
          id?: number;
          invoice_company_address?: string;
          invoice_company_name?: string;
          invoice_footer?: string;
          invoice_tax_id?: string | null;
          social_links?: NonNullable<Json>;
          updated_at?: string;
        };
        Relationships: [];
      };
      testimonials: {
        Row: {
          author_name: string;
          author_title: string | null;
          course_id: string | null;
          created_at: string;
          id: string;
          is_published: boolean;
          position: number;
          quote: string;
          updated_at: string;
        };
        ComputedFields: never;
        Insert: {
          author_name: string;
          author_title?: string | null;
          course_id?: string | null;
          created_at?: string;
          id?: string;
          is_published?: boolean;
          position?: number;
          quote: string;
          updated_at?: string;
        };
        Update: {
          author_name?: string;
          author_title?: string | null;
          course_id?: string | null;
          created_at?: string;
          id?: string;
          is_published?: boolean;
          position?: number;
          quote?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "testimonials_course_id_fkey";
            columns: ["course_id"];
            isOneToOne: false;
            referencedRelation: "courses";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      admin_analytics: { Args: { p_weeks?: number }; Returns: Json };
      can_manage_session_row: {
        Args: { p_course_id: string; p_instructor_id: string };
        Returns: boolean;
      };
      can_register: { Args: { p_session_id: string }; Returns: boolean };
      cancel_order: {
        Args: { p_order_id: string };
        Returns: {
          admin_note: string | null;
          billing_email: string;
          billing_name: string;
          cancelled_at: string | null;
          coupon_code: string | null;
          coupon_id: string | null;
          course_id: string;
          course_title: string;
          created_at: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor: number;
          id: string;
          invoice_number: string | null;
          paid_at: string | null;
          provider: string;
          provider_data: NonNullable<Json>;
          provider_ref: string | null;
          reference: string;
          refunded_at: string | null;
          status: Database["public"]["Enums"]["order_status"];
          subtotal_minor: number;
          total_minor: number;
          updated_at: string;
          user_id: string;
        };
        SetofOptions: {
          from: "*";
          to: "orders";
          isOneToOne: true;
          isSetofReturn: false;
        };
      };
      cancel_registration: { Args: { p_session_id: string }; Returns: string[] };
      check_rate_limit: {
        Args: { p_key: string; p_max: number; p_window_seconds: number };
        Returns: boolean;
      };
      complete_lesson: { Args: { p_completed?: boolean; p_lesson_id: string }; Returns: undefined };
      confirm_order_payment: {
        Args: { p_provider: string; p_provider_ref: string; p_reference: string };
        Returns: {
          admin_note: string | null;
          billing_email: string;
          billing_name: string;
          cancelled_at: string | null;
          coupon_code: string | null;
          coupon_id: string | null;
          course_id: string;
          course_title: string;
          created_at: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor: number;
          id: string;
          invoice_number: string | null;
          paid_at: string | null;
          provider: string;
          provider_data: NonNullable<Json>;
          provider_ref: string | null;
          reference: string;
          refunded_at: string | null;
          status: Database["public"]["Enums"]["order_status"];
          subtotal_minor: number;
          total_minor: number;
          updated_at: string;
          user_id: string;
        };
        SetofOptions: {
          from: "*";
          to: "orders";
          isOneToOne: true;
          isSetofReturn: false;
        };
      };
      coupon_discount: {
        Args: {
          p_coupon: Omit<
            Database["public"]["Tables"]["coupons"]["Row"],
            Database["public"]["Tables"]["coupons"]["ComputedFields"]
          >;
          p_course: Omit<
            Database["public"]["Tables"]["courses"]["Row"],
            Database["public"]["Tables"]["courses"]["ComputedFields"]
          >;
        };
        Returns: number;
      };
      course_progress: {
        Args: { p_course_id: string };
        Returns: {
          completed: number;
          percent: number;
          required_completed: number;
          required_total: number;
          total: number;
        }[];
      };
      create_order: {
        Args: { p_coupon?: string; p_course_id: string; p_provider: string };
        Returns: {
          admin_note: string | null;
          billing_email: string;
          billing_name: string;
          cancelled_at: string | null;
          coupon_code: string | null;
          coupon_id: string | null;
          course_id: string;
          course_title: string;
          created_at: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor: number;
          id: string;
          invoice_number: string | null;
          paid_at: string | null;
          provider: string;
          provider_data: NonNullable<Json>;
          provider_ref: string | null;
          reference: string;
          refunded_at: string | null;
          status: Database["public"]["Enums"]["order_status"];
          subtotal_minor: number;
          total_minor: number;
          updated_at: string;
          user_id: string;
        };
        SetofOptions: {
          from: "*";
          to: "orders";
          isOneToOne: true;
          isSetofReturn: false;
        };
      };
      current_user_role: {
        Args: Record<PropertyKey, never>;
        Returns: Database["public"]["Enums"]["user_role"];
      };
      enrol_free: {
        Args: { p_course_id: string };
        Returns: Database["public"]["Enums"]["enrolment_status"];
      };
      fill_from_waitlist: { Args: { p_session_id: string }; Returns: string[] };
      find_coupon: {
        Args: {
          p_code: string;
          p_course: Omit<
            Database["public"]["Tables"]["courses"]["Row"],
            Database["public"]["Tables"]["courses"]["ComputedFields"]
          >;
        };
        Returns: {
          amount: number;
          code: string;
          course_id: string | null;
          created_at: string;
          created_by: string | null;
          currency: Database["public"]["Enums"]["currency_code"] | null;
          expires_at: string | null;
          id: string;
          is_active: boolean;
          kind: Database["public"]["Enums"]["coupon_kind"];
          max_redemptions: number | null;
          redemptions: number;
          updated_at: string;
        };
        SetofOptions: {
          from: "*";
          to: "coupons";
          isOneToOne: true;
          isSetofReturn: false;
        };
      };
      get_join_url: { Args: { p_session_id: string }; Returns: string };
      get_student_quiz: {
        Args: { p_lesson_id: string };
        Returns: {
          options: Json;
          pass_mark: number;
          prompt: string;
          q_position: number;
          question_id: string;
          quiz_id: string;
        }[];
      };
      is_admin: { Args: Record<PropertyKey, never>; Returns: boolean };
      is_course_published: { Args: { p_course_id: string }; Returns: boolean };
      is_course_staff: { Args: { p_course_id: string }; Returns: boolean };
      is_enrolled: { Args: { p_course_id: string }; Returns: boolean };
      is_session_staff: { Args: { p_session_id: string }; Returns: boolean };
      is_session_visible: { Args: { p_session_id: string }; Returns: boolean };
      is_staff: { Args: Record<PropertyKey, never>; Returns: boolean };
      is_valid_timezone: { Args: { tz: string }; Returns: boolean };
      issue_certificate: { Args: { p_course_id: string }; Returns: string };
      mark_order_paid: {
        Args: { p_note?: string; p_order_id: string };
        Returns: {
          admin_note: string | null;
          billing_email: string;
          billing_name: string;
          cancelled_at: string | null;
          coupon_code: string | null;
          coupon_id: string | null;
          course_id: string;
          course_title: string;
          created_at: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor: number;
          id: string;
          invoice_number: string | null;
          paid_at: string | null;
          provider: string;
          provider_data: NonNullable<Json>;
          provider_ref: string | null;
          reference: string;
          refunded_at: string | null;
          status: Database["public"]["Enums"]["order_status"];
          subtotal_minor: number;
          total_minor: number;
          updated_at: string;
          user_id: string;
        };
        SetofOptions: {
          from: "*";
          to: "orders";
          isOneToOne: true;
          isSetofReturn: false;
        };
      };
      my_instructor_id: { Args: Record<PropertyKey, never>; Returns: string };
      new_order_reference: { Args: Record<PropertyKey, never>; Returns: string };
      promote_waitlist: { Args: { p_session_id: string }; Returns: string[] };
      quote_price: {
        Args: { p_coupon?: string; p_course_id: string };
        Returns: {
          coupon_code: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor: number;
          subtotal_minor: number;
          total_minor: number;
        }[];
      };
      refund_order: {
        Args: { p_note?: string; p_order_id: string };
        Returns: {
          admin_note: string | null;
          billing_email: string;
          billing_name: string;
          cancelled_at: string | null;
          coupon_code: string | null;
          coupon_id: string | null;
          course_id: string;
          course_title: string;
          created_at: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor: number;
          id: string;
          invoice_number: string | null;
          paid_at: string | null;
          provider: string;
          provider_data: NonNullable<Json>;
          provider_ref: string | null;
          reference: string;
          refunded_at: string | null;
          status: Database["public"]["Enums"]["order_status"];
          subtotal_minor: number;
          total_minor: number;
          updated_at: string;
          user_id: string;
        };
        SetofOptions: {
          from: "*";
          to: "orders";
          isOneToOne: true;
          isSetofReturn: false;
        };
      };
      register_for_session: {
        Args: { p_session_id: string };
        Returns: Database["public"]["Enums"]["registration_status"];
      };
      reorder_lessons: { Args: { p_ids: string[]; p_section_id: string }; Returns: undefined };
      reorder_sections: { Args: { p_course_id: string; p_ids: string[] }; Returns: undefined };
      session_availability: {
        Args: { p_session_ids: string[] };
        Returns: {
          registered: number;
          session_id: string;
          waitlisted: number;
        }[];
      };
      set_attendance: {
        Args: { p_attended: boolean; p_session_id: string; p_user_ids: string[] };
        Returns: number;
      };
      settle_order: {
        Args: { p_order_id: string; p_provider_ref?: string };
        Returns: {
          admin_note: string | null;
          billing_email: string;
          billing_name: string;
          cancelled_at: string | null;
          coupon_code: string | null;
          coupon_id: string | null;
          course_id: string;
          course_title: string;
          created_at: string;
          currency: Database["public"]["Enums"]["currency_code"];
          discount_minor: number;
          id: string;
          invoice_number: string | null;
          paid_at: string | null;
          provider: string;
          provider_data: NonNullable<Json>;
          provider_ref: string | null;
          reference: string;
          refunded_at: string | null;
          status: Database["public"]["Enums"]["order_status"];
          subtotal_minor: number;
          total_minor: number;
          updated_at: string;
          user_id: string;
        };
        SetofOptions: {
          from: "*";
          to: "orders";
          isOneToOne: true;
          isSetofReturn: false;
        };
      };
      submit_quiz: { Args: { p_answers: Json; p_lesson_id: string }; Returns: Json };
      verify_certificate: {
        Args: { p_serial: string };
        Returns: {
          course_title: string;
          holder_name: string;
          issued_at: string;
          serial: string;
        }[];
      };
      write_audit: {
        Args: { p_action: string; p_metadata?: Json; p_target_id?: string; p_target_type?: string };
        Returns: undefined;
      };
    };
    Enums: {
      content_status: "draft" | "published";
      coupon_kind: "percent" | "fixed";
      course_format: "self_paced" | "live_cohort" | "hybrid";
      course_level: "beginner" | "intermediate" | "advanced";
      course_status: "draft" | "published" | "archived";
      course_track: "ai" | "data_science" | "power_bi";
      currency_code: "GHS" | "USD";
      enquiry_kind: "contact" | "corporate";
      enquiry_status: "new" | "in_progress" | "closed";
      enrolment_source: "free" | "order" | "manual" | "coupon";
      enrolment_status: "active" | "revoked";
      lesson_type: "video" | "article" | "file" | "quiz" | "live_session";
      order_status: "pending" | "paid" | "cancelled" | "refunded";
      registration_status: "registered" | "waitlist" | "cancelled" | "attended";
      session_status: "scheduled" | "live" | "completed" | "cancelled";
      user_role: "student" | "instructor" | "admin";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    keyof DefaultSchema["Enums"] | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    keyof DefaultSchema["CompositeTypes"] | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof DatabaseWithoutInternals }
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  graphql_public: {
    Enums: {},
  },
  public: {
    Enums: {
      content_status: ["draft", "published"],
      coupon_kind: ["percent", "fixed"],
      course_format: ["self_paced", "live_cohort", "hybrid"],
      course_level: ["beginner", "intermediate", "advanced"],
      course_status: ["draft", "published", "archived"],
      course_track: ["ai", "data_science", "power_bi"],
      currency_code: ["GHS", "USD"],
      enquiry_kind: ["contact", "corporate"],
      enquiry_status: ["new", "in_progress", "closed"],
      enrolment_source: ["free", "order", "manual", "coupon"],
      enrolment_status: ["active", "revoked"],
      lesson_type: ["video", "article", "file", "quiz", "live_session"],
      order_status: ["pending", "paid", "cancelled", "refunded"],
      registration_status: ["registered", "waitlist", "cancelled", "attended"],
      session_status: ["scheduled", "live", "completed", "cancelled"],
      user_role: ["student", "instructor", "admin"],
    },
  },
} as const;
