import { createServerClient } from "@supabase/ssr";
import { type NextRequest, NextResponse } from "next/server";
import { SIGNED_IN_FLAG, authCookieOptions } from "./cookie-options";

const PROTECTED = [
  "/dashboard",
  "/account",
  "/admin",
  "/instructor",
  "/studio",
  "/learn",
  "/certificates",
  "/checkout",
  "/orders",
  "/my-courses",
];

/** Refreshes the auth session cookie and redirects anonymous users away from private areas. */
export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookieOptions: authCookieOptions,
      cookies: {
        getAll: () => request.cookies.getAll(),
        setAll: (toSet) => {
          toSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          toSet.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
        },
      },
    },
  );

  // Must be called to refresh the session; do not remove.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;
  if (!user && PROTECTED.some((p) => path === p || path.startsWith(`${p}/`))) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.search = `?next=${encodeURIComponent(path)}`;
    return NextResponse.redirect(url);
  }

  if (user && !request.cookies.has(SIGNED_IN_FLAG)) {
    response.cookies.set(SIGNED_IN_FLAG, "1", {
      sameSite: "lax",
      path: "/",
      secure: authCookieOptions.secure,
    });
  } else if (!user && request.cookies.has(SIGNED_IN_FLAG)) {
    response.cookies.delete(SIGNED_IN_FLAG);
  }

  return response;
}
