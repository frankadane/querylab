import "server-only";
import { cache } from "react";
import { createPublicClient } from "@/lib/supabase/public";

export const getPage = cache(async (slug: string) => {
  const { data } = await createPublicClient()
    .from("pages")
    .select("slug, title, body_md, seo_title, seo_description, updated_at")
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();
  return data;
});

export async function listPosts(tag?: string) {
  let q = createPublicClient()
    .from("posts")
    .select(
      "slug, title, excerpt, cover_url, cover_alt, tags, published_at, is_demo, author:profiles(full_name)",
    )
    .eq("status", "published")
    .order("published_at", { ascending: false });
  if (tag) q = q.contains("tags", [tag]);
  return (await q).data ?? [];
}

export const getPost = cache(async (slug: string) => {
  const { data } = await createPublicClient()
    .from("posts")
    .select("*, author:profiles(full_name)")
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();
  return data;
});
