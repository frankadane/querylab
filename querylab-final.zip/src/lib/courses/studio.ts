import "server-only";
import { notFound } from "next/navigation";
import { cache } from "react";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

/** Loads a course for the studio through RLS: 404 unless the user is staff on it. */
export const getStudioCourse = cache(async (id: string) => {
  if (!z.string().uuid().safeParse(id).success) notFound();
  const supabase = await createClient();
  const { data } = await supabase
    .from("courses")
    .select(
      "*, sections(id, title, description, position, lessons(id, title, type, duration_minutes, is_free_preview, position))",
    )
    .eq("id", id)
    .order("position", { referencedTable: "sections" })
    .order("position", { referencedTable: "sections.lessons" })
    .maybeSingle();
  if (!data) notFound();
  const { data: canEdit } = await supabase.rpc("is_course_staff", { p_course_id: id });
  if (!canEdit) notFound();
  return data;
});
