import type { Database } from "@/lib/supabase/types";

type E = Database["public"]["Enums"];
export type Track = E["course_track"];
export type Level = E["course_level"];
export type Format = E["course_format"];
export type Currency = E["currency_code"];
export type LessonType = E["lesson_type"];
export type CourseStatus = E["course_status"];

export const TRACKS: Record<Track, string> = {
  ai: "Applied AI",
  data_science: "Data Science",
  power_bi: "Power BI",
};
export const LEVELS: Record<Level, string> = {
  beginner: "Beginner",
  intermediate: "Intermediate",
  advanced: "Advanced",
};
export const FORMATS: Record<Format, string> = {
  self_paced: "Self-paced",
  live_cohort: "Live cohort",
  hybrid: "Hybrid",
};
export const LESSON_TYPES: Record<LessonType, string> = {
  video: "Video",
  article: "Article",
  file: "Download",
  quiz: "Quiz",
  live_session: "Live session",
};
export const STATUSES: Record<CourseStatus, string> = {
  draft: "Draft",
  published: "Published",
  archived: "Archived",
};
export const LEVEL_ORDER: Level[] = ["beginner", "intermediate", "advanced"];

export function levelLabel(min: Level, max: Level) {
  return min === max ? LEVELS[min] : `${LEVELS[min]} → ${LEVELS[max]}`;
}

/** True if `level` falls inside the course's min..max range. */
export function levelInRange(level: Level, min: Level, max: Level) {
  const i = LEVEL_ORDER.indexOf(level);
  return i >= LEVEL_ORDER.indexOf(min) && i <= LEVEL_ORDER.indexOf(max);
}

export function formatPrice(minor: number, currency: Currency) {
  if (minor === 0) return "Free";
  return new Intl.NumberFormat(currency === "GHS" ? "en-GH" : "en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: minor % 100 === 0 ? 0 : 2,
  }).format(minor / 100);
}

/** Parses a user-entered major-unit amount ("1,500.50") into minor units. */
export function toMinor(amount: string | number): number {
  const n = typeof amount === "number" ? amount : Number(String(amount).replace(/,/g, ""));
  if (!Number.isFinite(n) || n < 0) throw new Error("Invalid amount");
  return Math.round(n * 100);
}

export function formatDuration(minutes: number) {
  if (minutes < 60) return `${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m ? `${h} h ${m} min` : `${h} h`;
}

export function slugify(s: string) {
  return s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 100);
}
