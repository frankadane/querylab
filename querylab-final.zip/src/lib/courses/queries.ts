import "server-only";
import { cache } from "react";
import { createPublicClient } from "@/lib/supabase/public";
import { type Format, type Level, type Track, levelInRange } from "./format";

export type CatalogueFilters = {
  q?: string;
  track?: Track;
  level?: Level;
  format?: Format;
  price?: "free" | "paid";
};

const CARD_FIELDS =
  "id, slug, title, subtitle, track, level_min, level_max, format, duration_weeks, price_minor, currency, thumbnail_url, is_demo, lessons(count), instructor:instructors(display_name, slug, is_placeholder)";

export async function listPublishedCourses(filters: CatalogueFilters = {}) {
  const supabase = createPublicClient();
  let query = supabase.from("courses").select(CARD_FIELDS).eq("status", "published").order("title");

  if (filters.q)
    query = query.textSearch("search", filters.q, { type: "websearch", config: "english" });
  if (filters.track) query = query.eq("track", filters.track);
  if (filters.format) query = query.eq("format", filters.format);
  if (filters.price === "free") query = query.eq("price_minor", 0);
  if (filters.price === "paid") query = query.gt("price_minor", 0);

  const { data, error } = await query;
  if (error) throw error;
  return (data ?? [])
    .filter((c) => !filters.level || levelInRange(filters.level, c.level_min, c.level_max))
    .map((c) => ({
      ...c,
      lessonCount: (c.lessons as unknown as { count: number }[])[0]?.count ?? 0,
    }));
}

export type CourseCardData = Awaited<ReturnType<typeof listPublishedCourses>>[number];

export const getPublishedCourse = cache(async (slug: string) => {
  const supabase = createPublicClient();
  const { data: course } = await supabase
    .from("courses")
    .select(
      "*, instructor:instructors(id, slug, display_name, headline, bio_md, photo_url, is_placeholder), sections(id, title, description, position, lessons(id, title, summary, type, duration_minutes, is_free_preview, position))",
    )
    .eq("slug", slug)
    .eq("status", "published")
    .order("position", { referencedTable: "sections" })
    .order("position", { referencedTable: "sections.lessons" })
    .maybeSingle();
  if (!course) return null;

  const { data: faqs } = await supabase
    .from("faqs")
    .select("id, question, answer_md")
    .eq("course_id", course.id)
    .order("position");

  const lessons = course.sections.flatMap((s) => s.lessons);
  return {
    ...course,
    faqs: faqs ?? [],
    lessonCount: lessons.length,
    totalMinutes: lessons.reduce((n, l) => n + (l.duration_minutes ?? 0), 0),
  };
});

export async function listPublishedSlugs() {
  const { data } = await createPublicClient()
    .from("courses")
    .select("slug, updated_at")
    .eq("status", "published");
  return data ?? [];
}

export async function listInstructors() {
  const { data } = await createPublicClient()
    .from("instructors")
    .select(
      "id, slug, display_name, headline, bio_md, photo_url, is_placeholder, courses(slug, title, status)",
    )
    .order("display_name");
  return (data ?? []).map((i) => ({
    ...i,
    courses: i.courses.filter((c) => c.status === "published"),
  }));
}

export async function listSiteFaqs() {
  const { data } = await createPublicClient()
    .from("faqs")
    .select("id, question, answer_md")
    .is("course_id", null)
    .order("position");
  return data ?? [];
}
