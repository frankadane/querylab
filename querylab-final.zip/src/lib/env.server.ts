import "server-only";
import { z } from "zod";

/** Server-only env. Importing this from a client component fails the build. */
export const serverEnv = z
  .object({
    SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
    RESEND_API_KEY: z.string().optional(),
    EMAIL_FROM: z.string().default("QueryLab <onboarding@resend.dev>"),
    CRON_SECRET: z.string().optional(),
  })
  .parse(process.env);
