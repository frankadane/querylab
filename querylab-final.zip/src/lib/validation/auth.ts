import { z } from "zod";
import { isValidTimezone } from "@/lib/timezones";

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(1, "Enter your email address")
  .max(254, "Email is too long")
  .email("Enter a valid email address");

export const passwordSchema = z
  .string()
  .min(10, "Use at least 10 characters")
  .max(72, "Use 72 characters or fewer")
  .regex(/[A-Za-z]/, "Include at least one letter")
  .regex(/[0-9]/, "Include at least one number");

export const timezoneSchema = z.string().min(1).refine(isValidTimezone, "Choose a valid timezone");

export const signUpSchema = z.object({
  fullName: z.string().trim().min(1, "Enter your name").max(120, "Name is too long"),
  email: emailSchema,
  password: passwordSchema,
  timezone: timezoneSchema,
  acceptTerms: z.literal(true, { error: "You must accept the terms to continue" }),
});

export const signInSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Enter your password").max(72),
});

export const emailOnlySchema = z.object({ email: emailSchema });

export const resetPasswordSchema = z
  .object({ password: passwordSchema, confirm: z.string() })
  .refine((v) => v.password === v.confirm, {
    message: "Passwords do not match",
    path: ["confirm"],
  });

export const changePasswordSchema = z
  .object({
    current: z.string().min(1, "Enter your current password"),
    password: passwordSchema,
    confirm: z.string(),
  })
  .refine((v) => v.password === v.confirm, {
    message: "Passwords do not match",
    path: ["confirm"],
  });

export const profileSchema = z.object({
  fullName: z.string().trim().min(1, "Enter your name").max(120, "Name is too long"),
  bio: z.string().trim().max(2000, "Keep your bio under 2000 characters"),
  timezone: timezoneSchema,
});

export const deleteAccountSchema = z.object({ confirmEmail: emailSchema });

export type SignUpValues = z.infer<typeof signUpSchema>;
export type SignInValues = z.infer<typeof signInSchema>;
export type EmailOnlyValues = z.infer<typeof emailOnlySchema>;
export type ResetPasswordValues = z.infer<typeof resetPasswordSchema>;
export type ChangePasswordValues = z.infer<typeof changePasswordSchema>;
export type ProfileValues = z.infer<typeof profileSchema>;
