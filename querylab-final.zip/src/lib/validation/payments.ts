import { z } from "zod";

export const couponSchema = z
  .object({
    code: z
      .string()
      .trim()
      .toUpperCase()
      .regex(/^[A-Z0-9][A-Z0-9_-]{2,31}$/, "3–32 letters, numbers, - or _"),
    kind: z.enum(["percent", "fixed"]),
    amount: z
      .string()
      .trim()
      .regex(/^\d{1,7}(\.\d{1,2})?$/, "Enter a number"),
    currency: z.enum(["GHS", "USD", ""]),
    courseId: z.string().uuid().or(z.literal("")),
    expiresAt: z.string().regex(/^(\d{4}-\d{2}-\d{2})?$/, "Choose a date"),
    maxRedemptions: z.string().regex(/^\d{0,6}$/, "Whole number"),
    isActive: z.boolean(),
  })
  .refine(
    (v) =>
      v.kind !== "percent" ||
      (Number(v.amount) >= 1 && Number(v.amount) <= 100 && Number.isInteger(Number(v.amount))),
    { message: "Percent must be a whole number from 1 to 100", path: ["amount"] },
  )
  .refine((v) => v.kind !== "fixed" || v.currency !== "", {
    message: "Choose the currency for a fixed discount",
    path: ["currency"],
  });
