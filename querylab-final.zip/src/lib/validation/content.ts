import { z } from "zod";
import { slugSchema } from "./courses";

const opt = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((v) => (v === "" ? null : v));

export const contentSchema = z.object({
  title: z.string().trim().min(1, "Enter a title").max(200),
  slug: slugSchema,
  excerpt: opt(400),
  bodyMd: z.string().max(100000),
  tags: z
    .string()
    .max(300)
    .transform((v) =>
      [
        ...new Set(
          v
            .split(",")
            .map((t) =>
              t
                .trim()
                .toLowerCase()
                .replace(/[^a-z0-9-]/g, ""),
            )
            .filter(Boolean),
        ),
      ].slice(0, 10),
    ),
  status: z.enum(["draft", "published"]),
  seoTitle: opt(70),
  seoDescription: opt(200),
  coverAlt: opt(200),
});
export type ContentInput = z.input<typeof contentSchema>;
