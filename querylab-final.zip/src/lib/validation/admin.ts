import { z } from "zod";
import { isValidTimezone } from "@/lib/timezones";
import { slugSchema } from "./courses";

const optional = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((v) => (v === "" ? null : v));
const optionalUrl = z
  .string()
  .trim()
  .max(300)
  .refine((v) => v === "" || /^https:\/\/[^\s]+$/.test(v), "Use a full https:// link")
  .transform((v) => (v === "" ? null : v));

export const ROLE = z.enum(["student", "instructor", "admin"]);

export const instructorSchema = z.object({
  displayName: z.string().trim().min(1, "Enter a name").max(120),
  slug: slugSchema,
  headline: optional(200),
  bioMd: z.string().trim().max(5000),
  profileId: z
    .string()
    .uuid()
    .nullable()
    .or(z.literal("").transform(() => null)),
  isPublished: z.boolean(),
  isPlaceholder: z.boolean(),
});

export const testimonialSchema = z.object({
  quote: z.string().trim().min(1, "Enter the quote").max(1000),
  authorName: z.string().trim().min(1, "Enter the author's name").max(120),
  authorTitle: optional(160),
  courseId: z
    .string()
    .uuid()
    .nullable()
    .or(z.literal("").transform(() => null)),
  isPublished: z.boolean(),
  consent: z.literal(true, { error: "Confirm you have the author's permission to publish this" }),
});

export const settingsSchema = z.object({
  brandName: z.string().trim().min(1).max(80),
  contactEmail: z.string().trim().toLowerCase().email("Enter a valid email"),
  contactPhone: optional(40),
  address: optional(300),
  defaultCurrency: z.enum(["GHS", "USD"]),
  defaultTimezone: z.string().refine(isValidTimezone, "Choose a valid timezone"),
  bank: z.object({
    accountName: z.string().trim().max(120),
    bankName: z.string().trim().max(120),
    accountNumber: z.string().trim().max(60),
    branch: z.string().trim().max(120),
    swift: z.string().trim().max(20),
    iban: z.string().trim().max(50),
    instructions: z.string().trim().max(1000),
  }),
  invoice: z.object({
    companyName: z.string().trim().min(1, "Enter the company name").max(160),
    companyAddress: z.string().trim().max(500),
    taxId: z.string().trim().max(60),
    footer: z.string().trim().max(300),
  }),
  social: z.object({
    linkedin: optionalUrl,
    x: optionalUrl,
    youtube: optionalUrl,
    instagram: optionalUrl,
    facebook: optionalUrl,
  }),
});

export type InstructorInput = z.input<typeof instructorSchema>;
export type TestimonialInput = z.input<typeof testimonialSchema>;
export type SettingsInput = z.input<typeof settingsSchema>;
