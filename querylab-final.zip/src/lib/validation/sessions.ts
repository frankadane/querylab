import { z } from "zod";
import { isValidTimezone } from "@/lib/timezones";

const optionalUuid = z
  .string()
  .uuid()
  .nullable()
  .or(z.literal("").transform(() => null));
const httpsUrl = (msg: string) =>
  z
    .string()
    .trim()
    .max(1000)
    .refine((v) => /^https:\/\/[^\s]+$/.test(v), msg);

export const sessionSchema = z.object({
  courseId: optionalUuid, // null = open to all signed-in users
  title: z.string().trim().min(1, "Enter a title").max(200),
  descriptionMd: z.string().max(10000),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a date"),
  time: z.string().regex(/^\d{2}:\d{2}$/, "Choose a start time"),
  durationMinutes: z.coerce
    .number()
    .int()
    .min(15, "At least 15 minutes")
    .max(720, "At most 12 hours"),
  timezone: z.string().refine(isValidTimezone, "Choose a valid timezone"),
  joinUrl: httpsUrl("Paste the full https:// meeting link (Zoom, Google Meet or Teams)"),
  capacity: z.coerce.number().int().min(1, "At least 1").max(10000),
  instructorId: optionalUuid,
  lessonId: optionalUuid.optional(), // live-session lesson this session counts towards
});

export const newSessionSchema = sessionSchema.extend({
  repeatWeeks: z.coerce.number().int().min(1).max(26),
});

export const cancelSessionSchema = z.object({ reason: z.string().trim().max(500) });

export const afterSessionSchema = z.object({
  recordingUrl: z
    .string()
    .trim()
    .max(1000)
    .refine((v) => v === "" || /^https:\/\/[^\s]+$/.test(v), "Use an https:// link")
    .transform((v) => (v === "" ? null : v)),
  materialsMd: z
    .string()
    .max(20000)
    .transform((v) => (v.trim() === "" ? null : v)),
});

export const messageSchema = z.object({
  subject: z.string().trim().min(1, "Enter a subject").max(150),
  body: z.string().trim().min(1, "Write a message").max(5000),
  includeWaitlist: z.boolean(),
});

export type SessionInput = z.input<typeof sessionSchema>;
export type NewSessionInput = z.input<typeof newSessionSchema>;
