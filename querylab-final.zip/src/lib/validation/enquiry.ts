import { z } from "zod";
import { emailSchema } from "./auth";

export const enquirySchema = z.object({
  kind: z.enum(["contact", "corporate"]),
  name: z.string().trim().min(1, "Enter your name").max(120),
  email: emailSchema,
  company: z.string().trim().max(160).optional().default(""),
  teamSize: z.string().trim().max(40).optional().default(""),
  topic: z.string().trim().max(120).optional().default(""),
  message: z.string().trim().min(10, "Tell us a little more (at least 10 characters)").max(5000),
  website: z.string().max(500).optional().default(""), // honeypot: real people leave this empty; checked on the server
});
export type EnquiryInput = z.input<typeof enquirySchema>;
