import { z } from "zod";

const uuid = z.string().uuid();
const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((v) => (v === "" ? null : v));
/** Textarea "one per line" → string[] (input stays a string for the form). */
const lines = (maxItems: number, maxLen: number) =>
  z
    .string()
    .max(maxItems * (maxLen + 2))
    .transform((v) =>
      v
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean),
    )
    .refine((a) => a.length <= maxItems, `Up to ${maxItems} lines`)
    .refine(
      (a) => a.every((l) => l.length <= maxLen),
      `Each line must be under ${maxLen} characters`,
    );

export const TRACK = z.enum(["ai", "data_science", "power_bi"]);
export const LEVEL = z.enum(["beginner", "intermediate", "advanced"]);
export const FORMAT = z.enum(["self_paced", "live_cohort", "hybrid"]);
export const CURRENCY = z.enum(["GHS", "USD"]);
export const LESSON_TYPE = z.enum(["video", "article", "file", "quiz", "live_session"]);
export const STATUS = z.enum(["draft", "published", "archived"]);

export const slugSchema = z
  .string()
  .trim()
  .min(1, "Enter a URL slug")
  .max(100)
  .regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Use lowercase letters, numbers and single hyphens");

export const createCourseSchema = z.object({
  title: z.string().trim().min(1, "Enter a title").max(160),
  track: TRACK,
  instructorId: uuid.nullable().optional(),
});

const LEVEL_RANK = { beginner: 0, intermediate: 1, advanced: 2 } as const;

export const courseDetailsSchema = z
  .object({
    title: z.string().trim().min(1, "Enter a title").max(160),
    slug: slugSchema,
    subtitle: optionalText(300),
    descriptionMd: z.string().max(20000),
    outcomes: lines(20, 300),
    requirements: lines(20, 300),
    track: TRACK,
    levelMin: LEVEL,
    levelMax: LEVEL,
    format: FORMAT,
    durationWeeks: z.coerce
      .number()
      .int()
      .min(1)
      .max(104)
      .nullable()
      .or(z.literal("").transform(() => null)),
    price: z
      .string()
      .trim()
      .regex(/^\d{1,7}(\.\d{1,2})?$/, "Enter an amount like 1500 or 120.50"),
    currency: CURRENCY,
    instructorId: uuid.nullable().or(z.literal("").transform(() => null)),
  })
  .refine((v) => LEVEL_RANK[v.levelMin] <= LEVEL_RANK[v.levelMax], {
    message: "Maximum level must be the same as or above the minimum",
    path: ["levelMax"],
  });

export const sectionSchema = z.object({
  title: z.string().trim().min(1, "Enter a section title").max(200),
  description: optionalText(1000),
});

export const newLessonSchema = z.object({
  title: z.string().trim().min(1, "Enter a lesson title").max(200),
  type: LESSON_TYPE,
});

export const lessonSchema = z.object({
  title: z.string().trim().min(1, "Enter a lesson title").max(200),
  summary: optionalText(1000),
  type: LESSON_TYPE,
  sectionId: uuid,
  durationMinutes: z.coerce
    .number()
    .int()
    .min(0)
    .max(1440)
    .nullable()
    .or(z.literal("").transform(() => null)),
  isFreePreview: z.boolean(),
  videoUrl: z
    .string()
    .trim()
    .max(500)
    .refine(
      (v) => v === "" || /^https:\/\//.test(v),
      "Use an https:// link (Vimeo, YouTube or Mux)",
    )
    .transform((v) => (v === "" ? null : v)),
  bodyMd: z.string().max(100000),
});

export const quizSchema = z.object({
  passMark: z.coerce.number().int().min(0).max(100),
  questions: z
    .array(
      z
        .object({
          prompt: z.string().trim().min(1, "Enter the question").max(1000),
          options: z
            .array(z.string().trim().min(1, "Options can't be empty").max(300))
            .min(2, "Add at least 2 options")
            .max(6),
          correctIndex: z.coerce.number().int().min(0),
          explanation: optionalText(1000),
        })
        .refine((q) => q.correctIndex < q.options.length, {
          message: "Choose the correct option",
          path: ["correctIndex"],
        }),
    )
    .max(50),
});

export const faqSchema = z.object({
  question: z.string().trim().min(1, "Enter a question").max(300),
  answerMd: z.string().trim().min(1, "Enter an answer").max(5000),
  isPublished: z.boolean().default(true),
});

export const reorderSchema = z.object({ parentId: uuid, ids: z.array(uuid).max(500) });

export type CourseDetailsInput = z.input<typeof courseDetailsSchema>;
export type LessonInput = z.input<typeof lessonSchema>;
export type QuizInput = z.input<typeof quizSchema>;
