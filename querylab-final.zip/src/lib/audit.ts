import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database, Json } from "@/lib/supabase/types";

/** Records a staff action. Never throws: a failed audit write is logged, not fatal. */
export async function audit(
  supabase: SupabaseClient<Database>,
  action: string,
  target?: { type: string; id: string },
  metadata: Record<string, unknown> = {},
) {
  const { error } = await supabase.rpc("write_audit", {
    p_action: action,
    p_target_type: target?.type,
    p_target_id: target?.id,
    p_metadata: metadata as Json,
  });
  if (error) console.error("[audit] failed", action, error.message);
}
