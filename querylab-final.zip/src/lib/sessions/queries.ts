import "server-only";
import { cache } from "react";
import { createPublicClient } from "@/lib/supabase/public";
import { createClient } from "@/lib/supabase/server";

const FIELDS =
  "id, title, description_md, starts_at, ends_at, timezone, capacity, status, cancel_reason, course_id, recording_url, materials_md, is_demo, course:courses(id, title, slug, track), instructor:profiles!live_sessions_instructor_id_fkey(full_name)";

export type PublicSession = Awaited<ReturnType<typeof listUpcomingSessions>>[number];

async function withAvailability<T extends { id: string }>(sessions: T[]) {
  if (!sessions.length) return [] as (T & { registered: number; waitlisted: number })[];
  const { data } = await createPublicClient().rpc("session_availability", {
    p_session_ids: sessions.map((s) => s.id),
  });
  const byId = new Map((data ?? []).map((r) => [r.session_id, r]));
  return sessions.map((s) => ({
    ...s,
    registered: byId.get(s.id)?.registered ?? 0,
    waitlisted: byId.get(s.id)?.waitlisted ?? 0,
  }));
}

/** Upcoming (not yet ended) sessions visible to the public, soonest first. */
export async function listUpcomingSessions(
  opts: { courseId?: string; days?: number; limit?: number } = {},
) {
  const supabase = createPublicClient();
  const now = new Date();
  let q = supabase
    .from("live_sessions")
    .select(FIELDS)
    .gte("ends_at", now.toISOString())
    .lte("starts_at", new Date(now.getTime() + (opts.days ?? 120) * 86_400_000).toISOString())
    .order("starts_at");
  if (opts.courseId) q = q.eq("course_id", opts.courseId);
  if (opts.limit) q = q.limit(opts.limit);
  const { data, error } = await q;
  if (error) throw error;
  return withAvailability(data ?? []);
}

export const getPublicSession = cache(async (id: string) => {
  if (!/^[0-9a-f-]{36}$/.test(id)) return null;
  const { data } = await createPublicClient()
    .from("live_sessions")
    .select(FIELDS)
    .eq("id", id)
    .maybeSingle();
  if (!data) return null;
  return (await withAvailability([data]))[0];
});

/** The signed-in user's registration for each of the given sessions. */
export async function myRegistrations(sessionIds: string[]) {
  if (!sessionIds.length) return new Map<string, string>();
  const supabase = await createClient();
  const { data } = await supabase
    .from("session_registrations")
    .select("session_id, status")
    .in("session_id", sessionIds);
  return new Map((data ?? []).map((r) => [r.session_id, r.status as string]));
}

/** Upcoming sessions the user is registered or waitlisted for. */
export async function myUpcomingSessions(userId: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("session_registrations")
    .select(
      "status, session:live_sessions(id, title, starts_at, ends_at, status, course:courses(title, slug))",
    )
    .eq("user_id", userId)
    .in("status", ["registered", "waitlist"]);
  const now = Date.now();
  return (data ?? [])
    .filter((r) => r.session && new Date(r.session.ends_at).getTime() >= now)
    .sort((a, b) => a.session!.starts_at.localeCompare(b.session!.starts_at));
}
