/**
 * Calendar-day arithmetic on plain "YYYY-MM-DD" keys (timezone-free), so the
 * grid never shifts because of the browser's own timezone.
 */
const toDate = (key: string) => {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
};
const toKey = (d: Date) => d.toISOString().slice(0, 10);

export function addDaysKey(key: string, n: number) {
  const d = toDate(key);
  d.setUTCDate(d.getUTCDate() + n);
  return toKey(d);
}

export function addMonthsKey(key: string, n: number) {
  const d = toDate(key);
  const day = d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + n);
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, last));
  return toKey(d);
}

/** Monday-first week start. */
export function startOfWeekKey(key: string) {
  const dow = (toDate(key).getUTCDay() + 6) % 7;
  return addDaysKey(key, -dow);
}

/** 6×7 grid of day keys covering the month of `key`, Monday first. */
export function monthGrid(key: string): string[][] {
  const first = `${key.slice(0, 7)}-01`;
  const start = startOfWeekKey(first);
  return Array.from({ length: 6 }, (_, w) =>
    Array.from({ length: 7 }, (_, d) => addDaysKey(start, w * 7 + d)),
  );
}

export function sameMonth(a: string, b: string) {
  return a.slice(0, 7) === b.slice(0, 7);
}

export function labelDay(
  key: string,
  opts: Intl.DateTimeFormatOptions = {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  },
) {
  return new Intl.DateTimeFormat("en-GB", { ...opts, timeZone: "UTC" }).format(toDate(key));
}
