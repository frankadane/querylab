/**
 * Pure mirror of the database registration rules (see migration
 * 20261119000003). The database functions are authoritative; this module
 * documents the behaviour and powers UI copy and unit tests.
 */
export type RegStatus = "registered" | "waitlist" | "cancelled" | "attended";

export function decideRegistration(capacity: number, taken: number): "registered" | "waitlist" {
  return taken < capacity ? "registered" : "waitlist";
}

/** Waitlist entries (oldest first) promoted when places free up. */
export function promotions<T extends { waitlistedAt: Date }>(
  capacity: number,
  taken: number,
  waitlist: T[],
): T[] {
  const free = Math.max(0, capacity - taken);
  return [...waitlist]
    .sort((a, b) => a.waitlistedAt.getTime() - b.waitlistedAt.getTime())
    .slice(0, free);
}

export function placesLeft(capacity: number, taken: number) {
  return Math.max(0, capacity - taken);
}

export function availabilityLabel(capacity: number, taken: number, waitlisted: number) {
  const left = placesLeft(capacity, taken);
  if (left === 0)
    return waitlisted ? `Full · ${waitlisted} on the waitlist` : "Full · join the waitlist";
  if (left <= 5) return `${left} ${left === 1 ? "place" : "places"} left`;
  return `${left} of ${capacity} places available`;
}
