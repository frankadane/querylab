import "server-only";
import { createClient } from "@/lib/supabase/server";

/** Courses the current staff member may attach sessions to (RLS-scoped). */
export async function manageableCourses(isAdmin: boolean) {
  const supabase = await createClient();
  let q = supabase.from("courses").select("id, title").neq("status", "archived").order("title");
  if (!isAdmin) {
    const { data: me } = await supabase.rpc("my_instructor_id");
    q = me ? q.eq("instructor_id", me) : q.eq("id", "00000000-0000-0000-0000-000000000000");
  }
  return (await q).data ?? [];
}

export async function staffAccounts() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("profiles")
    .select("id, full_name, email")
    .in("role", ["instructor", "admin"])
    .order("full_name");
  return data ?? [];
}

/** Live-session lessons of the given courses, for linking sessions to course progress. */
export async function liveLessons(courseIds: string[]) {
  if (!courseIds.length) return [];
  const supabase = await createClient();
  const { data } = await supabase
    .from("lessons")
    .select("id, title, course_id")
    .eq("type", "live_session")
    .in("course_id", courseIds)
    .order("position");
  return data ?? [];
}
