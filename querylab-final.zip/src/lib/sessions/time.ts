import { addDays, format as formatDate, parseISO } from "date-fns";
import { formatInTimeZone, fromZonedTime } from "date-fns-tz";

export const JOIN_OPENS_MINUTES = 15;

/**
 * Builds weekly occurrences that keep the same LOCAL wall-clock time in
 * `timeZone` (so a 18:00 London class stays at 18:00 across DST changes).
 * Returns UTC instants.
 */
export function weeklyOccurrences(opts: {
  date: string; // YYYY-MM-DD in timeZone
  time: string; // HH:mm in timeZone
  timeZone: string;
  durationMinutes: number;
  count: number;
  intervalWeeks?: number;
}): { startsAt: Date; endsAt: Date }[] {
  const { date, time, timeZone, durationMinutes, count, intervalWeeks = 1 } = opts;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time))
    throw new Error("Invalid date or time");
  if (count < 1 || count > 52) throw new Error("Between 1 and 52 occurrences");
  const base = parseISO(date);
  return Array.from({ length: count }, (_, i) => {
    const localDate = formatDate(addDays(base, i * 7 * intervalWeeks), "yyyy-MM-dd");
    const startsAt = fromZonedTime(`${localDate}T${time}:00`, timeZone);
    return { startsAt, endsAt: new Date(startsAt.getTime() + durationMinutes * 60_000) };
  });
}

/** "Thu 4 Dec 2026, 18:00 – 19:30 GMT" in the viewer's timezone. */
export function formatSessionRange(
  startsAt: Date | string,
  endsAt: Date | string,
  timeZone: string,
) {
  const s = typeof startsAt === "string" ? new Date(startsAt) : startsAt;
  const e = typeof endsAt === "string" ? new Date(endsAt) : endsAt;
  const sameDay =
    formatInTimeZone(s, timeZone, "yyyy-MM-dd") === formatInTimeZone(e, timeZone, "yyyy-MM-dd");
  const start = formatInTimeZone(s, timeZone, "EEE d MMM yyyy, HH:mm");
  const end = formatInTimeZone(e, timeZone, sameDay ? "HH:mm" : "EEE d MMM, HH:mm");
  return `${start} – ${end} ${formatInTimeZone(s, timeZone, "zzz")}`;
}

export function localDateKey(d: Date | string, timeZone: string) {
  return formatInTimeZone(typeof d === "string" ? new Date(d) : d, timeZone, "yyyy-MM-dd");
}

export type JoinState = "cancelled" | "too_early" | "open" | "ended";

/** Join links open 15 minutes before the start and close at the end. */
export function joinState(now: Date, startsAt: Date, endsAt: Date, status: string): JoinState {
  if (status === "cancelled") return "cancelled";
  if (now.getTime() > endsAt.getTime() || status === "completed") return "ended";
  if (now.getTime() < startsAt.getTime() - JOIN_OPENS_MINUTES * 60_000) return "too_early";
  return "open";
}

export function meetingProvider(
  url: string | null | undefined,
): "Zoom" | "Google Meet" | "Microsoft Teams" | null {
  if (!url) return null;
  try {
    const host = new URL(url).hostname;
    if (host === "zoom.us" || host.endsWith(".zoom.us")) return "Zoom";
    if (host === "meet.google.com") return "Google Meet";
    if (host === "teams.microsoft.com" || host === "teams.live.com") return "Microsoft Teams";
  } catch {
    /* invalid URL */
  }
  return null;
}

const gcalStamp = (d: Date) =>
  d
    .toISOString()
    .replace(/[-:]/g, "")
    .replace(/\.\d{3}/, "");

export function googleCalendarUrl(opts: {
  title: string;
  startsAt: Date;
  endsAt: Date;
  details: string;
  location?: string;
}) {
  const p = new URLSearchParams({
    action: "TEMPLATE",
    text: opts.title,
    dates: `${gcalStamp(opts.startsAt)}/${gcalStamp(opts.endsAt)}`,
    details: opts.details,
    ...(opts.location ? { location: opts.location } : {}),
  });
  return `https://calendar.google.com/calendar/render?${p}`;
}
