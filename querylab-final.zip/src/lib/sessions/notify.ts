import "server-only";
import { sendEmail } from "@/lib/email";
import { publicEnv } from "@/lib/env";
import { createAdminClient } from "@/lib/supabase/admin";
import { formatSessionRange } from "./time";

type Session = { id: string; title: string; starts_at: string; ends_at: string };

/**
 * Sends a personalised email (times in each person's own timezone) and
 * records an in-app notification. Uses the service role: callers must have
 * already authorised the action.
 */
export async function notifySessionUsers(
  userIds: string[],
  session: Session,
  msg: { type: string; subject: string; intro: string; outro?: string },
) {
  if (!userIds.length) return;
  const admin = createAdminClient();
  const { data: people } = await admin
    .from("profiles")
    .select("id, email, full_name, timezone")
    .in("id", userIds);
  const link = `/schedule/${session.id}`;
  const url = `${publicEnv.NEXT_PUBLIC_SITE_URL}${link}`;

  await admin.from("notifications").insert(
    (people ?? []).map((p) => ({
      user_id: p.id,
      type: msg.type,
      title: msg.subject,
      body: msg.intro,
      link,
    })),
  );

  await Promise.all(
    (people ?? []).map((p) =>
      sendEmail({
        to: p.email,
        subject: msg.subject,
        text: [
          `Hi ${p.full_name.split(" ")[0] || "there"},`,
          "",
          msg.intro,
          "",
          `${session.title}`,
          formatSessionRange(session.starts_at, session.ends_at, p.timezone),
          "",
          `Details and calendar links: ${url}`,
          msg.outro ? `\n${msg.outro}` : "",
          "",
          "QueryLab",
        ].join("\n"),
      }),
    ),
  );
}
