import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { notifySessionUsers } from "./notify";

const HOUR = 3_600_000;

/**
 * Sends due reminders. Safe to run as often as you like: each session is
 * "claimed" by an UPDATE … WHERE reminder_x_sent_at IS NULL, so concurrent
 * or repeated runs never email anyone twice.
 *   24h reminder: sessions starting in (1h, 24h]
 *   1h  reminder: sessions starting in (0, 1h]
 */
export async function sendDueReminders(now = new Date()) {
  const admin = createAdminClient();
  const at = (ms: number) => new Date(now.getTime() + ms).toISOString();
  const result = { day: 0, hour: 0, emails: 0 };

  const kinds = [
    {
      col: "reminder_24h_sent_at",
      from: at(HOUR),
      to: at(24 * HOUR),
      key: "day",
      label: "tomorrow",
    },
    {
      col: "reminder_1h_sent_at",
      from: now.toISOString(),
      to: at(HOUR),
      key: "hour",
      label: "in about an hour",
    },
  ] as const;

  for (const k of kinds) {
    const { data: claimed, error } = await admin
      .from("live_sessions")
      .update(
        k.key === "day"
          ? { reminder_24h_sent_at: now.toISOString() }
          : { reminder_1h_sent_at: now.toISOString() },
      )
      .eq("status", "scheduled")
      .is(k.col, null)
      .gt("starts_at", k.from)
      .lte("starts_at", k.to)
      .select("id, title, starts_at, ends_at");
    if (error) throw error;

    for (const s of claimed ?? []) {
      const { data: regs } = await admin
        .from("session_registrations")
        .select("user_id")
        .eq("session_id", s.id)
        .in("status", ["registered", "attended"]);
      const ids = (regs ?? []).map((r) => r.user_id);
      await notifySessionUsers(ids, s, {
        type: `session_reminder_${k.key}`,
        subject: `Reminder: ${s.title} starts ${k.label}`,
        intro:
          k.key === "hour"
            ? "Your live session starts soon. The join link is on the session page from 15 minutes before the start."
            : "A reminder that you're registered for this live session.",
        outro:
          "Can't make it? Cancel on the session page so someone on the waitlist can take your place.",
      });
      result[k.key] += 1;
      result.emails += ids.length;
    }
  }
  return result;
}
