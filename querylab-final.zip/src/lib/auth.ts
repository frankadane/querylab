import "server-only";
import { redirect } from "next/navigation";
import { cache } from "react";
import { createClient } from "@/lib/supabase/server";
import type { Database } from "@/lib/supabase/types";

export type Profile = Database["public"]["Tables"]["profiles"]["Row"];
export type Role = Database["public"]["Enums"]["user_role"];

/**
 * Current user + profile, verified with the auth server (getUser, not
 * getSession) and deduplicated per request. Role comes from the database.
 */
export const getCurrentUser = cache(async () => {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  if (!profile) return null;

  return { user, profile };
});

export async function requireUser(next = "/dashboard") {
  const current = await getCurrentUser();
  if (!current) redirect(`/login?next=${encodeURIComponent(next)}`);
  if (current.profile.suspended_at) redirect("/suspended");
  return current;
}

export async function requireRole(roles: Role[], next = "/dashboard") {
  const current = await requireUser(next);
  if (!roles.includes(current.profile.role)) redirect("/dashboard?denied=1");
  return current;
}
