import "server-only";
import { serverEnv } from "@/lib/env.server";

export type EmailMessage = { to: string; subject: string; text: string; html?: string };

/**
 * Sends a transactional email through Resend. With no RESEND_API_KEY set
 * (local development) the message is printed to the server console.
 * Auth emails (confirm, magic link, reset) are sent by Supabase Auth and,
 * locally, appear in Mailpit at http://127.0.0.1:54324.
 */
export async function sendEmail(msg: EmailMessage): Promise<{ ok: boolean }> {
  if (!serverEnv.RESEND_API_KEY) {
    console.info(
      `\n[email:console] To: ${msg.to}\nSubject: ${msg.subject}\n\n${msg.text}\n[/email:console]\n`,
    );
    return { ok: true };
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${serverEnv.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: serverEnv.EMAIL_FROM,
        to: [msg.to],
        subject: msg.subject,
        text: msg.text,
        html: msg.html,
      }),
    });
    if (!res.ok) console.error("[email] Resend error", res.status, await res.text());
    return { ok: res.ok };
  } catch (err) {
    console.error("[email] send failed", err);
    return { ok: false };
  }
}
