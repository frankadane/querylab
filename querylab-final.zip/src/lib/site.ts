/**
 * Static site configuration. Values that staff should edit without code
 * (contact details, bank details, social links) move to the `site_settings`
 * table in Phase 3; these are fallbacks for build time.
 */
export const siteConfig = {
  name: "QueryLab",
  tagline: "Practical training in AI, Data Science and Power BI",
  description:
    "QueryLab is an online and live training academy for working professionals and teams. Learn AI, Python, SQL and Power BI through self-paced courses and live cohorts.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  contactEmail: "querylab@gmail.com",
  defaultTimezone: "Africa/Accra",
  currencies: ["GHS", "USD"] as const,
} as const;

export type NavItem = { href: string; label: string };

export const mainNav: NavItem[] = [
  { href: "/courses", label: "Courses" },
  { href: "/schedule", label: "Live schedule" },
  { href: "/corporate", label: "For teams" },
  { href: "/resources", label: "Resources" },
  { href: "/about", label: "About" },
];

export const footerNav: { title: string; items: NavItem[] }[] = [
  {
    title: "Learn",
    items: [
      { href: "/courses", label: "All courses" },
      { href: "/schedule", label: "Live schedule" },
      { href: "/resources", label: "Blog & resources" },
    ],
  },
  {
    title: "Company",
    items: [
      { href: "/about", label: "About" },
      { href: "/instructors", label: "Instructors" },
      { href: "/corporate", label: "Corporate training" },
      { href: "/contact", label: "Contact" },
    ],
  },
  {
    title: "Legal",
    items: [
      { href: "/privacy", label: "Privacy policy" },
      { href: "/terms", label: "Terms of service" },
      { href: "/cookies", label: "Cookie notice" },
    ],
  },
];

export const tracks = [
  {
    slug: "ai",
    name: "Applied AI",
    summary:
      "Use LLMs and machine learning in your day-to-day work: prompting, automation, evaluation and responsible use.",
    courseSlug: "applied-ai-for-professionals",
  },
  {
    slug: "data-science",
    name: "Data Science",
    summary:
      "Python, pandas and SQL for analysis, then statistics and scikit-learn models you can explain to stakeholders.",
    courseSlug: "data-science-with-python-and-sql",
  },
  {
    slug: "power-bi",
    name: "Power BI",
    summary:
      "From Power Query and star schemas to DAX, report design, sharing and row-level security.",
    courseSlug: "power-bi-mastery",
  },
] as const;
