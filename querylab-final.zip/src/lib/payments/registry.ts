import "server-only";
import { bankTransfer } from "./providers/bank-transfer";
import { coupon, free, manual } from "./providers/free";
import type { PaymentProvider } from "./types";

// Add new providers here (e.g. `stripe`). See types.ts for the steps.
const providers: PaymentProvider[] = [bankTransfer, free, coupon, manual];

export function getProvider(id: string): PaymentProvider | undefined {
  return providers.find((p) => p.id === id);
}

export function checkoutProviders(): PaymentProvider[] {
  return providers.filter((p) => p.checkout);
}

export function providerLabel(id: string) {
  return getProvider(id)?.label ?? id;
}
