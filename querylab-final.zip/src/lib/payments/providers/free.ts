import "server-only";
import type { PaymentProvider } from "../types";

/** Price 0 (or a 100% coupon): the database settles the order on creation. */
export const free: PaymentProvider = {
  id: "free",
  label: "Free",
  description: "No payment needed.",
  checkout: false,
  async begin() {
    return { type: "completed" };
  },
};

/** Orders fully paid by a coupon (settled on creation, like free). */
export const coupon: PaymentProvider = { ...free, id: "coupon", label: "Coupon" };

/** Payments recorded by an admin (cash, cheque, sponsor invoice…) via "Mark as paid". */
export const manual: PaymentProvider = {
  id: "manual",
  label: "Recorded manually",
  description: "Payment recorded by an administrator.",
  checkout: false,
  async begin() {
    return { type: "instructions" };
  },
};
