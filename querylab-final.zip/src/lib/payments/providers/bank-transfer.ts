import "server-only";
import { sendEmail } from "@/lib/email";
import { publicEnv } from "@/lib/env";
import { formatPrice } from "@/lib/courses/format";
import { getBillingSettings } from "../bank";
import type { PaymentProvider } from "../types";

export const bankTransfer: PaymentProvider = {
  id: "bank_transfer",
  label: "Bank transfer / invoice",
  description:
    "Pay by bank transfer using your order reference. Your place is confirmed once we record the payment (usually within 1–2 working days).",
  checkout: true,
  async begin(order) {
    const { bank } = await getBillingSettings();
    const lines = [
      ["Account name", bank.account_name],
      ["Bank", bank.bank_name],
      ["Account number", bank.account_number],
      ["Branch", bank.branch],
      ["SWIFT/BIC", bank.swift],
      ["IBAN", bank.iban],
    ]
      .filter(([, v]) => v)
      .map(([k, v]) => `${k}: ${v}`);
    await sendEmail({
      to: order.billing_email,
      subject: `Order ${order.reference}: payment instructions`,
      text: [
        `Thanks for your order for ${order.course_title}.`,
        "",
        `Amount: ${formatPrice(order.total_minor, order.currency)}`,
        `Reference (include it with your payment): ${order.reference}`,
        "",
        ...(lines.length ? lines : ["Bank details will be sent to you shortly."]),
        bank.instructions ? `\n${bank.instructions}` : "",
        "",
        `Order and pro-forma invoice: ${publicEnv.NEXT_PUBLIC_SITE_URL}/orders/${order.reference}`,
        "",
        "QueryLab",
      ].join("\n"),
    });
    return { type: "instructions" };
  },
};
