import "server-only";
import { createPublicClient } from "@/lib/supabase/public";

export type BankDetails = {
  account_name?: string;
  bank_name?: string;
  account_number?: string;
  branch?: string;
  swift?: string;
  iban?: string;
  instructions?: string;
};

export async function getBillingSettings() {
  const { data } = await createPublicClient()
    .from("site_settings")
    .select("*")
    .eq("id", 1)
    .single();
  const bank = (data?.bank_details ?? {}) as BankDetails;
  return {
    bank,
    bankConfigured: !!(bank.account_name && bank.account_number && bank.bank_name),
    company: {
      name: data?.invoice_company_name ?? "QueryLab",
      address: data?.invoice_company_address ?? "",
      taxId: data?.invoice_tax_id ?? null,
      footer: data?.invoice_footer ?? "",
      email: data?.contact_email ?? "",
    },
  };
}
