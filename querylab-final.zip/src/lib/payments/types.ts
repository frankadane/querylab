import type { Database } from "@/lib/supabase/types";

export type Order = Database["public"]["Tables"]["orders"]["Row"];

/** What the checkout should do after an order has been created. */
export type CheckoutOutcome =
  | { type: "completed" } // paid already (free / 100% coupon) → go to the course
  | { type: "instructions" } // show payment instructions on the order page (bank transfer)
  | { type: "redirect"; url: string }; // hosted checkout (e.g. Stripe Checkout)

export type WebhookResult = { reference: string; providerRef: string } | null;

/**
 * A way of paying for an order. To add Stripe/PayPal:
 *  1. Create src/lib/payments/providers/<id>.ts implementing this interface.
 *     `begin` creates the PSP session (put order.reference in its metadata) and
 *     returns { type: "redirect", url }.
 *  2. Implement `handleWebhook`: verify the PSP signature, and for a successful
 *     payment return { reference, providerRef }. The shared webhook route then
 *     calls confirm_order_payment() with the service role (idempotent).
 *  3. Register it in registry.ts and add its secrets to the environment.
 * No database changes are needed: orders.provider / provider_ref /
 * provider_data are generic.
 */
export interface PaymentProvider {
  id: string;
  label: string;
  description: string;
  /** Offered to students at checkout. */
  checkout: boolean;
  begin(order: Order): Promise<CheckoutOutcome>;
  handleWebhook?(request: Request): Promise<WebhookResult>;
}
