import "server-only";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { formatPrice } from "@/lib/courses/format";
import type { BankDetails } from "./bank";
import type { Order } from "./types";

const INK = rgb(11 / 255, 21 / 255, 48 / 255);
const INDIGO = rgb(67 / 255, 56 / 255, 202 / 255);
const MUTED = rgb(74 / 255, 84 / 255, 112 / 255);
const LINE = rgb(220 / 255, 225 / 255, 234 / 255);

const date = (iso: string) =>
  new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(iso));
// Standard PDF fonts only cover WinAnsi; replace characters they can't draw.
const safe = (s: string) => s.replace(/₵/g, "GHS ").replace(/[^\x20-\x7E\xA0-\xFF\n]/g, "?");

/** Pro-forma invoice while pending; tax invoice (with number) once paid; marked REFUNDED/CANCELLED otherwise. */
export async function renderInvoicePdf(
  order: Order,
  company: { name: string; address: string; taxId: string | null; footer: string; email: string },
  bank: BankDetails,
) {
  const pdf = await PDFDocument.create();
  const page = pdf.addPage([595.28, 841.89]);
  const { width, height } = page.getSize();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const isPaid = order.status === "paid" || order.status === "refunded";
  const title = isPaid ? "INVOICE" : "PRO-FORMA INVOICE";
  pdf.setTitle(`${title} ${order.invoice_number ?? order.reference}`);
  pdf.setAuthor(company.name);

  const text = (t: string, x: number, y: number, size = 10, f = font, color = INK) =>
    page.drawText(safe(t), { x, y, size, font: f, color });
  const right = (t: string, xRight: number, y: number, size = 10, f = font, color = INK) =>
    page.drawText(safe(t), {
      x: xRight - f.widthOfTextAtSize(safe(t), size),
      y,
      size,
      font: f,
      color,
    });

  page.drawRectangle({ x: 0, y: height - 8, width, height: 8, color: INDIGO });
  text("QueryLab", 48, height - 64, 20, bold);
  right(title, width - 48, height - 64, 16, bold, INDIGO);

  let y = height - 100;
  [
    company.name,
    ...company.address.split("\n"),
    company.taxId ? `Tax ID: ${company.taxId}` : "",
    company.email,
  ]
    .filter(Boolean)
    .forEach((l) => {
      text(l, 48, y, 10, font, MUTED);
      y -= 14;
    });

  y = height - 100;
  const meta: [string, string][] = [
    ["Invoice no.", order.invoice_number ?? "Issued on payment"],
    ["Order reference", order.reference],
    ["Date", date(order.created_at)],
    ...(order.paid_at ? ([["Paid", date(order.paid_at)]] as [string, string][]) : []),
  ];
  meta.forEach(([k, v]) => {
    right(k, width - 160, y, 10, font, MUTED);
    right(v, width - 48, y, 10, bold);
    y -= 14;
  });

  y = height - 210;
  text("Bill to", 48, y, 10, bold, MUTED);
  text(order.billing_name, 48, y - 16, 11, bold);
  text(order.billing_email, 48, y - 30, 10, font, MUTED);

  y = height - 290;
  page.drawLine({
    start: { x: 48, y: y + 14 },
    end: { x: width - 48, y: y + 14 },
    thickness: 1,
    color: LINE,
  });
  text("Description", 48, y, 10, bold, MUTED);
  right("Amount", width - 48, y, 10, bold, MUTED);
  page.drawLine({
    start: { x: 48, y: y - 8 },
    end: { x: width - 48, y: y - 8 },
    thickness: 1,
    color: LINE,
  });
  y -= 28;
  text(`Course: ${order.course_title}`, 48, y, 11);
  right(
    formatPrice(order.subtotal_minor, order.currency).replace("Free", "0.00"),
    width - 48,
    y,
    11,
  );
  if (order.discount_minor > 0) {
    y -= 18;
    text(`Discount${order.coupon_code ? ` (${order.coupon_code})` : ""}`, 48, y, 11, font, MUTED);
    right(`-${formatPrice(order.discount_minor, order.currency)}`, width - 48, y, 11, font, MUTED);
  }
  y -= 16;
  page.drawLine({
    start: { x: width - 248, y },
    end: { x: width - 48, y },
    thickness: 1,
    color: LINE,
  });
  y -= 20;
  text(`Total (${order.currency})`, width - 248, y, 12, bold);
  right(
    order.total_minor === 0 ? "0.00" : formatPrice(order.total_minor, order.currency),
    width - 48,
    y,
    12,
    bold,
  );

  y -= 50;
  if (order.status === "pending") {
    text("How to pay", 48, y, 12, bold);
    y -= 18;
    text(
      `Bank transfer. Use reference ${order.reference} so we can match your payment.`,
      48,
      y,
      10,
    );
    y -= 18;
    const rows: [string, string | undefined][] = [
      ["Account name", bank.account_name],
      ["Bank", bank.bank_name],
      ["Account number", bank.account_number],
      ["Branch", bank.branch],
      ["SWIFT/BIC", bank.swift],
      ["IBAN", bank.iban],
    ];
    const filled = rows.filter(([, v]) => v);
    if (!filled.length) text("Bank details to follow by email.", 48, y, 10, font, MUTED);
    filled.forEach(([k, v]) => {
      text(k, 48, y, 10, font, MUTED);
      text(v!, 160, y, 10, bold);
      y -= 14;
    });
  } else {
    const stamp = { paid: "PAID", refunded: "REFUNDED", cancelled: "CANCELLED" }[
      order.status as "paid" | "refunded" | "cancelled"
    ];
    text(stamp, 48, y, 22, bold, order.status === "paid" ? INDIGO : MUTED);
  }

  text(company.footer, 48, 56, 9, font, MUTED);
  return pdf.save();
}
