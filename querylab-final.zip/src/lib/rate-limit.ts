import "server-only";
import { createHash } from "node:crypto";
import { headers } from "next/headers";
import { createAdminClient } from "@/lib/supabase/admin";

export const LIMITS = {
  signIn: { max: 10, windowSeconds: 15 * 60 },
  signUp: { max: 5, windowSeconds: 60 * 60 },
  emailLink: { max: 5, windowSeconds: 60 * 60 },
  sensitive: { max: 10, windowSeconds: 60 * 60 },
} as const;

async function clientIp() {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || "unknown";
}

function hash(value: string) {
  return createHash("sha256").update(value).digest("hex").slice(0, 32);
}

/**
 * Fixed-window rate limit keyed on action + IP (+ optional identifier such
 * as an email). Returns true when the request is allowed. Fails open if
 * the database is unreachable, so an outage doesn't lock everyone out;
 * Supabase Auth's own rate limits still apply.
 */
export async function rateLimit(
  action: keyof typeof LIMITS,
  identifier?: string,
): Promise<boolean> {
  const { windowSeconds } = LIMITS[action];
  // Test-only escape hatch: end-to-end runs reuse a few demo accounts many times.
  // Never set RATE_LIMIT_MULTIPLIER in production.
  const max = LIMITS[action].max * Math.max(1, Number(process.env.RATE_LIMIT_MULTIPLIER ?? 1) || 1);
  const ip = await clientIp();
  const keys = [`${action}:ip:${hash(ip)}`];
  if (identifier) keys.push(`${action}:id:${hash(identifier.toLowerCase())}`);

  try {
    const admin = createAdminClient();
    const results = await Promise.all(
      keys.map((k) =>
        admin.rpc("check_rate_limit", { p_key: k, p_max: max, p_window_seconds: windowSeconds }),
      ),
    );
    return results.every((r) => r.data !== false);
  } catch (err) {
    console.error("[rate-limit] check failed, allowing request", err);
    return true;
  }
}
