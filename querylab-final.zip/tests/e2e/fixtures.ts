import { test as base, expect } from "@playwright/test";
import { createClient } from "@supabase/supabase-js";

/**
 * Each test gets its own fake client IP so the app's per-IP rate limits
 * don't make repeated local runs flaky. (In production the platform sets
 * x-forwarded-for; clients can't override it.)
 */
export const test = base.extend({
  context: async ({ context }, run) => {
    const ip = `10.${rand()}.${rand()}.${rand()}`;
    await context.setExtraHTTPHeaders({ "x-forwarded-for": ip });
    await run(context);
  },
});
export { expect };

function rand() {
  return Math.floor(Math.random() * 254) + 1;
}

export const DEMO = {
  admin: { email: "admin@querylab.test", password: "Demo-Admin-2026!" },
  student: { email: "student1@querylab.test", password: "Demo-Student-2026!" },
};

export function serviceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    {
      auth: { persistSession: false, autoRefreshToken: false },
    },
  );
}

/** Creates a confirmed throwaway user. */
export async function createUser(password = "E2e-Password-123") {
  const email = `e2e-${Date.now()}-${rand()}@querylab.test`;
  const { data, error } = await serviceClient().auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { full_name: "E2E Tester" },
  });
  if (error) throw error;
  return { id: data.user.id, email, password };
}

const MAILPIT = process.env.MAILPIT_URL ?? "http://127.0.0.1:54324";

/** Waits for the newest email to `to` and returns the /auth/confirm link, rewritten to baseURL. */
export async function emailLink(to: string, baseURL: string, subject?: RegExp): Promise<string> {
  for (let i = 0; i < 40; i++) {
    const res = await fetch(`${MAILPIT}/api/v1/search?query=${encodeURIComponent(`to:"${to}"`)}`);
    const { messages = [] } = (await res.json()) as { messages: { ID: string; Subject: string }[] };
    const msg = messages.find((m) => !subject || subject.test(m.Subject));
    if (msg) {
      const full = (await (await fetch(`${MAILPIT}/api/v1/message/${msg.ID}`)).json()) as {
        HTML: string;
      };
      const href = full.HTML.match(/href="([^"]*\/auth\/confirm[^"]*)"/)?.[1];
      if (href) {
        const u = new URL(href.replaceAll("&amp;", "&"));
        return `${baseURL}${u.pathname}${u.search}`;
      }
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  throw new Error(`No email for ${to}`);
}

export async function logIn(
  page: import("@playwright/test").Page,
  user: { email: string; password: string },
) {
  await page.goto("/login");
  await page.getByLabel("Email").fill(user.email);
  await page.getByLabel("Password", { exact: true }).fill(user.password);
  await page.getByRole("button", { name: "Log in", exact: true }).click();
  await page.waitForURL("**/dashboard**");
}

export const INSTRUCTOR = { email: "instructor@querylab.test", password: "Demo-Instructor-2026!" };
export const STUDENT2 = { email: "student2@querylab.test", password: "Demo-Student-2026!" };
