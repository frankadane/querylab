import AxeBuilder from "@axe-core/playwright";
import { DEMO, expect, logIn, test } from "./fixtures";

test("sitemap, robots, social image and structured data", async ({ request, page }) => {
  const sitemap = await (await request.get("/sitemap.xml")).text();
  for (const path of [
    "/courses/power-bi-mastery",
    "/resources/star-schemas-in-plain-english",
    "/schedule/",
    "/privacy",
  ]) {
    expect(sitemap).toContain(path);
  }
  expect(sitemap).not.toContain("/admin");

  const robots = await (await request.get("/robots.txt")).text();
  expect(robots).toContain("Disallow: /admin");
  expect(robots).toContain("Sitemap:");

  const og = await request.get("/opengraph-image");
  expect(og.headers()["content-type"]).toBe("image/png");

  await page.goto("/");
  await expect(page.locator('meta[property="og:image"]')).toHaveCount(1);
  const ld = await page.locator('script[type="application/ld+json"]').first().textContent();
  expect(JSON.parse(ld!)["@type"]).toBe("EducationalOrganization");

  // Private pages are not indexable
  await logIn(page, DEMO.student);
  await page.goto("/dashboard");
  await expect(page.locator('meta[name="robots"]')).toHaveAttribute("content", /noindex/);
});

test("admin analytics: stat tiles, accessible charts with table views", async ({ page }) => {
  await logIn(page, DEMO.admin);
  await page.goto("/admin/analytics");
  await expect(page.getByRole("heading", { level: 1, name: "Analytics" })).toBeVisible();
  await expect(page.getByText("New sign-ups")).toBeVisible();
  await expect(page.getByText("GHS and USD are reported separately")).toBeVisible();

  const chart = page.getByRole("figure", { name: "Sign-ups per week" });
  await expect(chart.getByRole("group", { name: /bar chart/ })).toBeVisible();
  // Keyboard: focusing a bar shows its tooltip
  await chart.getByRole("button").last().focus();
  await expect(chart.getByRole("status")).toContainText("sign-ups");
  await chart.getByText("Show data table").click();
  await expect(chart.getByRole("table")).toBeVisible();
  await expect(chart.getByRole("row")).toHaveCount(13);

  for (const scheme of ["light", "dark"] as const) {
    await page.emulateMedia({ colorScheme: scheme, reducedMotion: "reduce" });
    await page.reload();
    const r = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
      .analyze();
    expect(
      r.violations.map((v) => `${scheme} ${v.id}: ${v.nodes.map((n) => n.target).join(",")}`),
    ).toEqual([]);
  }
});
