import AxeBuilder from "@axe-core/playwright";
import { readFileSync } from "node:fs";
import { DEMO, STUDENT2, createUser, expect, logIn, serviceClient, test } from "./fixtures";

const axe = (page: import("@playwright/test").Page) =>
  new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();

async function sessionId(title: string) {
  const { data } = await serviceClient()
    .from("live_sessions")
    .select("id")
    .eq("title", title)
    .single();
  return data!.id as string;
}

/** Creates an open (course-less) session directly in the DB. */
async function openSession(opts: { title: string; inMinutes: number; capacity?: number }) {
  const s = serviceClient();
  const start = new Date(Date.now() + opts.inMinutes * 60_000);
  const { data } = await s
    .from("live_sessions")
    .insert({
      title: opts.title,
      starts_at: start.toISOString(),
      ends_at: new Date(start.getTime() + 90 * 60_000).toISOString(),
      capacity: opts.capacity ?? 25,
    })
    .select("id")
    .single();
  await s
    .from("live_session_links")
    .insert({ session_id: data!.id, join_url: "https://meet.google.com/abc-defg-hij" });
  return data!.id as string;
}

test.describe("public schedule", () => {
  test("list, month grid keyboard navigation and timezone switching", async ({ page }) => {
    await page.goto("/schedule");
    await expect(page.getByRole("link", { name: "Intro to Data & AI (free)" })).toBeVisible();
    await expect(
      page.getByRole("link", { name: "Power BI Mastery: live session 1" }),
    ).toBeVisible();

    // Timezone switch: the intro is at 17:00 Accra = 12:00 New York (EST)
    await page.getByLabel("Show times in").selectOption("Africa/Accra");
    const intro = page.getByRole("article").filter({ hasText: "Intro to Data & AI" });
    await expect(intro).toContainText("17:00 – 18:30 GMT");
    await page.getByLabel("Show times in").selectOption("America/New_York");
    await expect(intro).toContainText("12:00 – 13:30 EST");

    // Month grid
    await page.getByRole("button", { name: "Month" }).click();
    const grid = page.getByRole("grid");
    await expect(grid).toBeVisible();
    const today = grid.locator('button[tabindex="0"]');
    await today.focus();
    await page.keyboard.press("ArrowRight");
    await expect(grid.locator('button[tabindex="0"]')).toBeFocused();
    await page.keyboard.press("PageDown");
    await expect(page.getByRole("heading", { level: 2 }).first()).not.toHaveText(/^$/);

    // Week view renders seven days
    await page.getByRole("button", { name: "Week" }).click();
    await expect(page.getByRole("button", { name: "Next week" })).toBeVisible();
  });

  test("session page: anonymous visitors are asked to log in; .ics never contains the join link", async ({
    page,
  }) => {
    const id = await sessionId("Intro to Data & AI (free)");
    await page.goto(`/schedule/${id}`);
    await expect(page.getByRole("link", { name: "Log in to register" })).toBeVisible();
    const ld = JSON.parse(
      (await page.locator('script[type="application/ld+json"]').textContent())!,
    );
    expect(ld["@type"]).toBe("Event");

    const download = page.waitForEvent("download");
    await page.getByRole("link", { name: /Download .ics/ }).click();
    const ics = readFileSync((await (await download).path())!, "utf8");
    expect(ics).toContain("BEGIN:VCALENDAR");
    expect(ics).toContain("Intro to Data & AI");
    expect(ics).not.toContain("example.com/join");
    expect(await page.content()).not.toContain("example.com/join");
  });

  test("schedule and session pages pass axe", async ({ page }) => {
    await page.goto("/schedule");
    expect((await axe(page)).violations.map((v) => `list ${v.id}`)).toEqual([]);
    await page.getByRole("button", { name: "Month" }).click();
    expect(
      (await axe(page)).violations.map(
        (v) => `month ${v.id}: ${v.nodes.map((n) => n.target).join(",")}`,
      ),
    ).toEqual([]);
    await page.goto(`/schedule/${await sessionId("Intro to Data & AI (free)")}`);
    expect((await axe(page)).violations.map((v) => `session ${v.id}`)).toEqual([]);
  });
});

test.describe("registration", () => {
  test("course sessions are for enrolled students only", async ({ page }) => {
    await logIn(page, STUDENT2); // not enrolled in Power BI
    await page.goto(`/schedule/${await sessionId("Power BI Mastery: live session 2")}`);
    await expect(
      page.getByText("This session is for students enrolled in the course."),
    ).toBeVisible();
  });

  test("register → confirmation → cancel", async ({ page }) => {
    const user = await createUser();
    const id = await openSession({ title: `Open ${Date.now()}`, inMinutes: 3 * 24 * 60 });
    await logIn(page, user);
    await page.goto(`/schedule/${id}`);
    await page.getByRole("button", { name: "Register for this session" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("You're registered");
    await page.reload();
    await expect(page.getByText("You're registered.")).toBeVisible();
    await expect(page.getByText(/join link appears here 15 minutes before/)).toBeVisible();

    await page.goto("/dashboard");
    await expect(
      page.getByRole("region", { name: "Upcoming live sessions" }).getByRole("link"),
    ).toContainText([/Open \d+/]);
    await expect(page.getByRole("link", { name: /You're registered: Open/ })).toBeVisible();

    await page.goto(`/schedule/${id}`);
    await page.getByRole("button", { name: "Cancel my place" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("cancelled");
  });

  test("full sessions waitlist, and cancelling promotes the next person", async ({ browser }) => {
    const id = await openSession({
      title: `Tiny ${Date.now()}`,
      inMinutes: 2 * 24 * 60,
      capacity: 1,
    });
    const [a, b] = [await createUser(), await createUser()];
    const ctxA = await browser.newContext({ extraHTTPHeaders: { "x-forwarded-for": "10.1.1.1" } });
    const ctxB = await browser.newContext({ extraHTTPHeaders: { "x-forwarded-for": "10.2.2.2" } });
    const pa = await ctxA.newPage();
    const pb = await ctxB.newPage();

    await logIn(pa, a);
    await pa.goto(`/schedule/${id}`);
    await pa.getByRole("button", { name: "Register for this session" }).click();
    await expect(pa.getByRole("main").getByRole("status")).toContainText("You're registered");

    await logIn(pb, b);
    await pb.goto(`/schedule/${id}`);
    await expect(pb.getByText("Full · join the waitlist")).toBeVisible();
    await pb.getByRole("button", { name: "Register for this session" }).click();
    await expect(pb.getByRole("main").getByRole("status")).toContainText("waitlist");

    await pa.getByRole("button", { name: "Cancel my place" }).click();
    await expect(pa.getByRole("main").getByRole("status")).toContainText("cancelled");

    await pb.reload();
    await expect(pb.getByText("You're registered.")).toBeVisible();
    await pb.goto("/dashboard");
    await expect(pb.getByRole("link", { name: /A place opened up/ })).toBeVisible();
    await ctxA.close();
    await ctxB.close();
  });

  test("join button appears only within 15 minutes of the start", async ({ page }) => {
    const user = await createUser();
    const soon = await openSession({ title: `Soon ${Date.now()}`, inMinutes: 10 });
    const later = await openSession({ title: `Later ${Date.now()}`, inMinutes: 120 });
    await logIn(page, user);
    for (const id of [soon, later]) {
      await page.goto(`/schedule/${id}`);
      await page.getByRole("button", { name: "Register for this session" }).click();
      await expect(page.getByRole("main").getByRole("status")).toContainText("registered");
    }
    await page.goto(`/schedule/${soon}`);
    await expect(page.getByRole("link", { name: /Join on Google Meet/ })).toHaveAttribute(
      "href",
      "https://meet.google.com/abc-defg-hij",
    );
    await page.goto(`/schedule/${later}`);
    await expect(page.getByRole("link", { name: /Join on/ })).toHaveCount(0);
    expect(await page.content()).not.toContain("meet.google.com/abc-defg-hij");
  });
});

test.describe("studio: sessions", () => {
  test("create a weekly series, reschedule, attendance, CSV, cancel", async ({ page }) => {
    const title = `E2E Series ${Date.now()}`;
    await logIn(page, DEMO.admin);
    await page.goto("/studio/sessions/new");
    await page
      .getByLabel("Who can attend")
      .selectOption({ label: "Anyone with an account (open session)" });
    await page.getByLabel("Title").fill(title);
    await page.getByLabel("Repeat weekly").fill("3");
    await page.getByLabel("Meeting link").fill("https://zoom.us/j/1234567890");
    await expect(page.getByText("Detected: Zoom.")).toBeVisible();
    await page.getByLabel("Capacity").fill("2");
    await page.getByRole("button", { name: "Create 3 sessions" }).click();
    await expect(page.getByText("3 weekly sessions created")).toBeVisible();
    const firstUrl = page.url().split("?")[0];
    const id = firstUrl.split("/").pop()!;

    const { data: series } = await serviceClient()
      .from("live_sessions")
      .select("starts_at")
      .like("title", `${title}%`)
      .order("starts_at");
    expect(series).toHaveLength(3);
    expect(
      new Date(series![1].starts_at).getTime() - new Date(series![0].starts_at).getTime(),
    ).toBe(7 * 86_400_000);

    // Two registrations (one via service role helper user + student via UI)
    const u1 = await createUser();
    const s = serviceClient();
    await s
      .from("session_registrations")
      .insert({ session_id: id, user_id: u1.id, status: "registered" });
    await s.from("session_registrations").insert({
      session_id: id,
      user_id: "a0000000-0000-4000-8000-000000000004",
      status: "registered",
    });
    await page.reload();
    await expect(page.getByText("2 of 2 places taken")).toBeVisible();

    // Attendance
    await page.getByLabel("Demo Student Two attended").check();
    await page.getByRole("button", { name: "Save attendance" }).click();
    await expect(page.getByText("Attendance saved: 1 present.")).toBeVisible();

    // CSV export
    const dl = page.waitForEvent("download");
    await page.getByRole("link", { name: "Export CSV" }).click();
    const csv = readFileSync((await (await dl).path())!, "utf8");
    expect(csv).toContain("student2@querylab.test");
    expect(csv).toMatch(/"student2@querylab.test","attended","yes"/);

    // CSV import (mark the other person present, unknown email reported)
    await page.locator('input[type="file"][accept=".csv,text/csv"]').setInputFiles({
      name: "zoom.csv",
      mimeType: "text/csv",
      buffer: Buffer.from(`Email,Attended\n${u1.email},yes\nstranger@example.com,yes\n`),
    });
    await expect(
      page.getByText(/Imported 1 row: 1 present, 0 absent\. 1 not registered/),
    ).toBeVisible();

    // Message attendees
    await page.getByLabel("Subject", { exact: true }).fill("Slides for this week");
    await page.getByLabel("Message", { exact: true }).fill("Here are the slides.");
    await page.getByRole("button", { name: "Send email" }).click();
    await expect(page.getByText("Message sent to 2 people.")).toBeVisible();

    // Reschedule (move start time) → attendees notified
    await page.getByLabel("Start time").fill("19:00");
    await page.getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByText("Session rescheduled and attendees notified.")).toBeVisible();

    // Cancel the rest of the series
    await page.goto(firstUrl);
    await page.getByRole("button", { name: "Cancel session" }).click();
    await page.getByLabel("Reason (included in the email, optional)").fill("Instructor unwell.");
    await page.getByLabel("Also cancel all later sessions in this series").check();
    await page.getByRole("button", { name: "Cancel and notify" }).click();
    await expect(page.getByText("3 sessions cancelled and attendees notified.")).toBeVisible();

    const { data: n } = await s.from("notifications").select("type").eq("user_id", u1.id);
    expect(n!.map((x) => x.type).sort()).toEqual(["session_cancelled", "session_rescheduled"]);
  });

  test("studio session pages pass axe", async ({ page }) => {
    await logIn(page, DEMO.admin);
    for (const p of [
      "/studio/sessions",
      "/studio/sessions/new",
      `/studio/sessions/${await sessionId("Intro to Data & AI (free)")}`,
    ]) {
      await page.goto(p);
      expect(
        (await axe(page)).violations.map(
          (v) => `${p} ${v.id}: ${v.nodes.map((n) => n.target).join(",")}`,
        ),
      ).toEqual([]);
    }
  });

  test("students and other instructors can't manage sessions", async ({ page }) => {
    await logIn(page, DEMO.student);
    await page.goto("/studio/sessions");
    await expect(page).toHaveURL(/denied=1/);
    await page.context().clearCookies();
    await logIn(page, { email: "instructor@querylab.test", password: "Demo-Instructor-2026!" });
    const res = await page.goto(
      `/studio/sessions/${await sessionId("Power BI Mastery: live session 1")}`,
    );
    expect(res?.status()).toBe(404);
  });
});
