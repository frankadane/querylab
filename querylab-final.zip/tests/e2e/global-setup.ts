import { execFileSync } from "node:child_process";

/**
 * Local test runs reuse the same demo accounts, so clear the app's
 * rate-limit counters first. Only ever touches the local Supabase DB.
 */
export default function globalSetup() {
  const db = process.env.E2E_DB_URL ?? "postgresql://postgres:postgres@127.0.0.1:54322/postgres";
  if (!/127\.0\.0\.1|localhost/.test(db))
    throw new Error("Refusing to reset rate limits on a non-local database");
  execFileSync("psql", [db, "-qc", "delete from private.rate_limits"], { stdio: "inherit" });
}
