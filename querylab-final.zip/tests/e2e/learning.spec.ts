import AxeBuilder from "@axe-core/playwright";
import { DEMO, createUser, expect, logIn, serviceClient, test } from "./fixtures";

const axe = (page: import("@playwright/test").Page) =>
  new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();

/** A small free, published course: video, article (with file), quiz (2 questions, pass 50%), live lesson. */
async function tinyCourse() {
  const s = serviceClient();
  const tag = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
  const { data: course } = await s
    .from("courses")
    .insert({
      slug: `tiny-${tag}`,
      title: `Tiny Course ${tag}`,
      track: "ai",
      status: "published",
      price_minor: 0,
    })
    .select("id, slug, title")
    .single();
  const { data: section } = await s
    .from("sections")
    .insert({ course_id: course!.id, title: "Only section", position: 1 })
    .select("id")
    .single();
  const { data: lessons } = await s
    .from("lessons")
    .insert([
      {
        section_id: section!.id,
        course_id: course!.id,
        title: "Watch this",
        type: "video",
        position: 1,
      },
      {
        section_id: section!.id,
        course_id: course!.id,
        title: "Read this",
        type: "article",
        position: 2,
      },
      {
        section_id: section!.id,
        course_id: course!.id,
        title: "Check yourself",
        type: "quiz",
        position: 3,
      },
      {
        section_id: section!.id,
        course_id: course!.id,
        title: "Live workshop",
        type: "live_session",
        position: 4,
      },
    ])
    .select("id, title");
  const id = (t: string) => lessons!.find((l) => l.title === t)!.id;
  await s.from("lesson_contents").insert([
    {
      lesson_id: id("Watch this"),
      course_id: course!.id,
      body_md: "Notes for the video.",
      video_url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    },
    {
      lesson_id: id("Read this"),
      course_id: course!.id,
      body_md: "## Article\n\nSome **reading**.",
      file_path: `${course!.id}/${id("Read this")}/1-worksheet.txt`,
    },
  ]);
  await s.storage
    .from("lesson-files")
    .upload(
      `${course!.id}/${id("Read this")}/1-worksheet.txt`,
      new Blob(["worksheet"], { type: "text/plain" }),
    );
  const { data: quiz } = await s
    .from("quizzes")
    .insert({ lesson_id: id("Check yourself"), course_id: course!.id, pass_mark: 50 })
    .select("id")
    .single();
  await s.from("quiz_questions").insert([
    {
      quiz_id: quiz!.id,
      prompt: "Which is a fact table?",
      options: ["Customers", "Sales"],
      correct_index: 1,
      explanation: "Sales records events.",
      position: 1,
    },
    {
      quiz_id: quiz!.id,
      prompt: "CALCULATE changes…",
      options: ["filter context", "font size"],
      correct_index: 0,
      explanation: "It modifies filter context.",
      position: 2,
    },
  ]);
  return { ...course!, lessonId: id };
}

test("learner journey: enrol → learn → quiz → certificate → verify", async ({ page, request }) => {
  const course = await tinyCourse();
  const user = await createUser();

  // Not enrolled → bounced to the course page
  await logIn(page, user);
  await page.goto(`/learn/${course.slug}`);
  await expect(page).toHaveURL(new RegExp(`/courses/${course.slug}\\?enrol=1`));

  // Enrol for free
  await page.getByRole("button", { name: "Enrol for free" }).click();
  await expect(page).toHaveURL(new RegExp(`/learn/${course.slug}/`));
  await expect(page.getByRole("heading", { level: 1, name: "Watch this" })).toBeVisible();
  await expect(
    page.locator('iframe[src^="https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ"]'),
  ).toBeVisible();
  await expect(page.getByRole("progressbar", { name: "Course progress" })).toHaveAttribute(
    "aria-valuenow",
    "0",
  );

  // Mark complete → continues to the next lesson; progress 25%
  await page.getByRole("button", { name: "Mark complete and continue" }).click();
  await expect(page.getByRole("heading", { level: 1, name: "Read this" })).toBeVisible();
  await expect(page.getByRole("progressbar", { name: "Course progress" })).toHaveAttribute(
    "aria-valuenow",
    "25",
  );
  await expect(page.getByRole("link", { name: "Watch this (completed)" })).toBeVisible();

  // Private file download through a short-lived signed URL
  const dl = page.waitForEvent("download");
  await page.getByRole("button", { name: "Download" }).click();
  expect((await dl).suggestedFilename()).toContain("worksheet");

  await page.getByRole("button", { name: "Mark complete and continue" }).click();
  await expect(page.getByRole("heading", { level: 1, name: "Check yourself" })).toBeVisible();

  // Quiz: submitting incomplete is blocked, a wrong attempt reveals nothing
  await page.getByRole("button", { name: "Submit answers" }).click();
  await expect(page.getByText("Answer all questions first (2 left).")).toBeVisible();
  await page
    .getByRole("group", { name: /Which is a fact table/ })
    .getByLabel("Customers")
    .check();
  await page
    .getByRole("group", { name: /CALCULATE changes/ })
    .getByLabel("font size")
    .check();
  await page.getByRole("button", { name: "Submit answers" }).click();
  await expect(page.getByRole("status").filter({ hasText: "Not passed yet: 0%" })).toBeVisible();
  await expect(page.getByText("Correct answer", { exact: true })).toHaveCount(0);
  await expect(page.getByText("Sales records events.")).toHaveCount(0);

  // Retry and pass → explanations + certificate (live lesson not required)
  await page.getByRole("button", { name: "Try again" }).click();
  await page
    .getByRole("group", { name: /Which is a fact table/ })
    .getByLabel("Sales")
    .check();
  await page
    .getByRole("group", { name: /CALCULATE changes/ })
    .getByLabel("filter context")
    .check();
  await page.getByRole("button", { name: "Submit answers" }).click();
  await expect(page.getByRole("status").filter({ hasText: "Passed: 100%" })).toBeVisible();
  await expect(page.getByText("Sales records events.")).toBeVisible();
  const certLink = page.getByRole("link", { name: /download your certificate/ });
  await expect(certLink).toBeVisible();
  const href = (await certLink.getAttribute("href"))!;
  const serial = href.split("/")[2];
  expect(serial).toMatch(/^QL-\d{4}-[A-Z0-9]{8}$/);

  // PDF (owner only) + public verification
  const pdf = await page.request.get(href);
  expect(pdf.headers()["content-type"]).toBe("application/pdf");
  expect((await pdf.body()).subarray(0, 4).toString()).toBe("%PDF");
  const anonPdf = await request.get(href, { maxRedirects: 0 });
  expect([302, 307, 404]).toContain(anonPdf.status());

  await page.goto(`/verify/${serial}`);
  await expect(page.getByText("Valid certificate")).toBeVisible();
  await expect(page.getByRole("heading", { name: "E2E Tester" })).toBeVisible();
  await expect(page.getByText(course.title)).toBeVisible();

  // Dashboard shows progress and the certificate
  await page.goto("/dashboard");
  await expect(page.getByRole("region", { name: "Certificates" })).toContainText(course.title);
  await expect(
    page
      .getByRole("region", { name: "Continue learning" })
      .getByRole("link", { name: course.title }),
  ).toBeVisible();

  // Email confirmation was sent (console mailer → no assertion), and a bogus serial is rejected
  await page.goto("/verify/QL-2026-NOTREAL1");
  await expect(page.getByRole("heading", { name: "Certificate not found" })).toBeVisible();
});

test("quiz answers never reach the browser before submission", async ({ page }) => {
  const course = await tinyCourse();
  const user = await createUser();
  await serviceClient()
    .from("enrolments")
    .insert({ user_id: user.id, course_id: course.id, source: "manual" });
  await logIn(page, user);
  await page.goto(`/learn/${course.slug}/${course.lessonId("Check yourself")}`);
  const html = await page.content();
  expect(html).not.toContain("Sales records events.");
  expect(html).not.toContain("correct_index");
});

test("enrolled student sees the seeded progress; staff can preview", async ({ page }) => {
  await logIn(page, DEMO.student); // enrolled in Power BI with 3 lessons done
  await page.goto("/my-courses");
  await expect(page.getByRole("progressbar", { name: "3 of 27 lessons" })).toBeVisible();
  await page.getByRole("link", { name: "Power BI Mastery" }).click();
  await expect(
    page.getByRole("heading", { level: 1, name: "Cleaning columns and data types" }),
  ).toBeVisible(); // next unfinished lesson

  await page.context().clearCookies();
  await logIn(page, DEMO.admin);
  await page.goto("/learn/data-science-with-python-and-sql");
  await expect(page.getByText("Staff preview")).toBeVisible();
});

test("learning pages pass axe", async ({ page }) => {
  await logIn(page, DEMO.student);
  const { data } = await serviceClient()
    .from("lessons")
    .select("id, course:courses!inner(slug)")
    .eq("type", "quiz")
    .eq("courses.slug", "power-bi-mastery")
    .single();
  for (const p of [
    "/my-courses",
    "/dashboard",
    "/learn/power-bi-mastery",
    `/learn/power-bi-mastery/${data!.id}`,
  ]) {
    await page.goto(p);
    expect(
      (await axe(page)).violations.map(
        (v) => `${p} ${v.id}: ${v.nodes.map((n) => n.target).join(",")}`,
      ),
    ).toEqual([]);
  }
});
