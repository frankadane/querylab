import AxeBuilder from "@axe-core/playwright";
import { DEMO, expect, logIn, serviceClient, test } from "./fixtures";

const axe = (page: import("@playwright/test").Page) =>
  new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();

test("legal pages, about and blog render from the CMS", async ({ page }) => {
  for (const [path, heading] of [
    ["/privacy", "Privacy policy"],
    ["/terms", "Terms of service"],
    ["/cookies", "Cookie notice"],
    ["/about", "About QueryLab"],
  ]) {
    await page.goto(path);
    await expect(page.getByRole("heading", { level: 1, name: heading })).toBeVisible();
  }
  await expect(page.getByText("Placeholder page.")).toBeVisible();
  await page.goto("/privacy");
  await expect(page.getByText("Template, not legal advice.")).toBeVisible();

  await page.goto("/resources");
  await page.getByRole("link", { name: "Star schemas in plain English" }).click();
  await expect(
    page.getByRole("heading", { level: 1, name: "Star schemas in plain English" }),
  ).toBeVisible();
  const ld = JSON.parse((await page.locator('script[type="application/ld+json"]').textContent())!);
  expect(ld["@type"]).toBe("Article");
  await page.getByRole("link", { name: "power-bi" }).click();
  await expect(page).toHaveURL(/tag=power-bi/);
});

test("contact and corporate enquiries reach the admin inbox", async ({ page, browser }) => {
  const stamp = Date.now();
  await page.goto("/corporate");
  await page.getByRole("button", { name: "Send enquiry" }).click();
  await expect(page.getByText("Enter your name")).toBeVisible();
  await page.getByLabel("Your name").fill("Kwame Mensah");
  await page.getByLabel("Work email").fill(`kwame-${stamp}@example.com`);
  await page.getByRole("textbox", { name: "Company" }).fill(`Acme Analytics ${stamp}`);
  await page.getByLabel("Team size").selectOption("6-15");
  await page.getByLabel("Main interest").selectOption("Power BI");
  await page
    .getByLabel("What does your team need?")
    .fill("We need Power BI training for 10 analysts in Q1.");
  await page.getByRole("button", { name: "Send enquiry" }).click();
  await expect(page.getByRole("status")).toContainText("We've received your message");

  const adminCtx = await browser.newContext({
    extraHTTPHeaders: { "x-forwarded-for": "10.6.6.6" },
  });
  const admin = await adminCtx.newPage();
  await logIn(admin, DEMO.admin);
  await admin.goto("/admin/enquiries");
  const card = admin.getByRole("listitem").filter({ hasText: `Acme Analytics ${stamp}` });
  await expect(card).toContainText("Team: 6-15");
  await card.getByLabel("Status").selectOption("closed");
  await expect(card.getByText("Saved")).toBeVisible();
  await adminCtx.close();
});

test("honeypot submissions are dropped silently", async ({ page }) => {
  await page.goto("/contact");
  await page.getByLabel("Your name").fill("Bot");
  await page.getByLabel("Work email").fill("bot@example.com");
  await page.getByLabel("Message").fill("Buy cheap things now!!!");
  await page.locator('input[name="website"]').fill("http://spam.example", { force: true });
  await page.getByRole("button", { name: "Send message" }).click();
  await expect(page.getByRole("status")).toBeVisible();
  const { count } = await serviceClient()
    .from("enquiries")
    .select("id", { count: "exact", head: true })
    .eq("email", "bot@example.com");
  expect(count).toBe(0);
});

test("admin writes and publishes a blog post; drafts stay hidden", async ({ page }) => {
  const title = `E2E post ${Date.now()}`;
  await logIn(page, DEMO.admin);
  await page.goto("/admin/posts");
  await page.getByLabel("New post title").fill(title);
  await page.getByRole("button", { name: "Create draft" }).click();
  await expect(page.getByRole("heading", { level: 1, name: title })).toBeVisible();
  const slug = await page.getByLabel("URL slug").inputValue();

  await page.getByLabel("Excerpt").fill("Testing the blog editor.");
  await page.getByLabel("Tags").fill("Testing, QA");
  await page.getByLabel("Content", { exact: true }).fill("## Hello\n\nThis is **published**.");
  await page.getByRole("button", { name: "Save" }).click();
  await expect(page.getByText("Draft saved.")).toBeVisible();
  expect((await page.request.get(`/resources/${slug}`)).status()).toBe(404);

  await page.getByLabel("Status").selectOption("published");
  await page.getByRole("button", { name: "Save" }).click();
  await expect(page.getByText("Saved and published.")).toBeVisible();
  await page.goto(`/resources/${slug}`);
  await expect(page.locator("main strong", { hasText: "published" })).toBeVisible();
  await expect(page.getByRole("link", { name: "testing" })).toBeVisible();
});

test("content pages pass axe", async ({ page }) => {
  for (const p of [
    "/about",
    "/privacy",
    "/cookies",
    "/resources",
    "/resources/star-schemas-in-plain-english",
    "/contact",
    "/corporate",
  ]) {
    await page.goto(p);
    expect(
      (await axe(page)).violations.map(
        (v) => `${p} ${v.id}: ${v.nodes.map((n) => n.target).join(",")}`,
      ),
    ).toEqual([]);
  }
  await logIn(page, DEMO.admin);
  for (const p of ["/admin/posts", "/admin/pages", "/admin/enquiries"]) {
    await page.goto(p);
    expect(
      (await axe(page)).violations.map(
        (v) => `${p} ${v.id}: ${v.nodes.map((n) => n.target).join(",")}`,
      ),
    ).toEqual([]);
  }
});
