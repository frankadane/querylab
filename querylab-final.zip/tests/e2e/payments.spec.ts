import AxeBuilder from "@axe-core/playwright";
import { DEMO, createUser, emailLink, expect, logIn, serviceClient, test } from "./fixtures";

/** A paid course (GHS 1,500) with one section, two lessons and an upcoming live session. */
async function paidCourse() {
  const s = serviceClient();
  const tag = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
  const { data: c } = await s
    .from("courses")
    .insert({
      slug: `paid-${tag}`,
      title: `Paid Course ${tag}`,
      track: "data_science",
      status: "published",
      price_minor: 150000,
      currency: "GHS",
    })
    .select("id, slug, title")
    .single();
  const { data: sec } = await s
    .from("sections")
    .insert({ course_id: c!.id, title: "Week 1", position: 1 })
    .select("id")
    .single();
  const { data: ls } = await s
    .from("lessons")
    .insert([
      { section_id: sec!.id, course_id: c!.id, title: "Welcome", type: "article", position: 1 },
      { section_id: sec!.id, course_id: c!.id, title: "Second", type: "article", position: 2 },
    ])
    .select("id");
  await s
    .from("lesson_contents")
    .insert(ls!.map((l) => ({ lesson_id: l.id, course_id: c!.id, body_md: "Content." })));
  const start = new Date(Date.now() + 3 * 86_400_000);
  const { data: sess } = await s
    .from("live_sessions")
    .insert({
      course_id: c!.id,
      title: `Live for ${tag}`,
      starts_at: start.toISOString(),
      ends_at: new Date(start.getTime() + 90 * 60_000).toISOString(),
    })
    .select("id")
    .single();
  await s
    .from("live_session_links")
    .insert({ session_id: sess!.id, join_url: "https://zoom.us/j/1" });
  return { ...c!, sessionId: sess!.id };
}

test("required journey: register → enrol (bank transfer) → mark paid → register for session → complete lesson", async ({
  page,
  browser,
  baseURL,
}) => {
  const course = await paidCourse();

  // 1. Register + confirm email
  const email = `buyer-${Date.now()}@querylab.test`;
  await page.goto("/register");
  await page.getByLabel("Full name").fill("Yaa Asantewaa");
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill("Buyer-Password-1");
  await page.getByLabel(/I agree to the/).check();
  await page.getByRole("button", { name: "Create account" }).click();
  await expect(page.getByRole("main").getByRole("status")).toContainText("Check your email");
  await page.goto(await emailLink(email, baseURL!, /Confirm/));
  await expect(page).toHaveURL(/\/dashboard/);

  // 2. Enrol in a paid course → checkout → bank transfer order
  await page.goto(`/courses/${course.slug}`);
  await page.getByRole("link", { name: /Enrol · / }).click();
  await expect(page.getByRole("heading", { name: "Checkout" })).toBeVisible();
  await page.getByLabel("Coupon code (optional)").fill("NOTACODE");
  await page.getByRole("button", { name: "Apply" }).click();
  await expect(
    page.getByRole("alert").filter({ hasText: "That coupon code isn't valid" }),
  ).toBeVisible();
  await page.getByRole("button", { name: /Place order · GH/ }).click();
  await expect(page).toHaveURL(/\/orders\/QL-[A-Z0-9]{8}\?placed=1/);
  const reference = page.url().match(/QL-[A-Z0-9]{8}/)![0];
  await expect(page.getByRole("heading", { name: `Order ${reference}` })).toBeVisible();
  await expect(page.getByText("Awaiting payment")).toBeVisible();

  // Pro-forma invoice PDF
  const proforma = await page.request.get(`/orders/${reference}/invoice`);
  expect(proforma.headers()["content-type"]).toBe("application/pdf");

  // Not enrolled yet: course is locked
  await page.goto(`/learn/${course.slug}`);
  await expect(page).toHaveURL(new RegExp(`/courses/${course.slug}\\?enrol=1`));
  await expect(page.getByRole("link", { name: "Complete your payment" })).toBeVisible();

  // 3. Admin marks the order as paid
  const adminCtx = await browser.newContext({
    extraHTTPHeaders: { "x-forwarded-for": "10.7.7.7" },
  });
  const admin = await adminCtx.newPage();
  await logIn(admin, DEMO.admin);
  await admin.goto(`/admin/orders?q=${reference}`);
  await admin.getByRole("button", { name: `Mark paid ${reference}` }).click();
  await admin.getByLabel(/Note/).fill("GCB transfer 12345");
  await admin.getByRole("button", { name: "Confirm payment received" }).click();
  await expect(
    admin.getByText(new RegExp(`${reference} marked as paid\\. Invoice INV-\\d{4}-\\d{6}`)),
  ).toBeVisible();
  await adminCtx.close();

  // 4. Student: register for the course's live session
  await page.goto(`/schedule/${course.sessionId}`);
  await page.getByRole("button", { name: "Register for this session" }).click();
  await expect(page.getByRole("main").getByRole("status")).toContainText("You're registered");

  // 5. Complete a lesson
  await page.goto(`/learn/${course.slug}`);
  await expect(page.getByRole("heading", { level: 1, name: "Welcome" })).toBeVisible();
  await page.getByRole("button", { name: "Mark complete and continue" }).click();
  await expect(page.getByRole("progressbar", { name: "Course progress" })).toHaveAttribute(
    "aria-valuenow",
    "50",
  );

  // Paid invoice now carries an invoice number
  await page.goto(`/orders/${reference}`);
  await expect(page.getByText(/INV-\d{4}-\d{6}/)).toBeVisible();
  const invoice = await page.request.get(`/orders/${reference}/invoice`);
  expect((await invoice.body()).subarray(0, 4).toString()).toBe("%PDF");
});

test("100% coupon enrols immediately; refunds remove access", async ({ page, browser }) => {
  const course = await paidCourse();
  const code = `FREE${Date.now().toString().slice(-6)}`;
  await serviceClient()
    .from("coupons")
    .insert({ code, kind: "percent", amount: 100, course_id: course.id, max_redemptions: 1 });
  const user = await createUser();
  await logIn(page, user);
  await page.goto(`/checkout/${course.slug}`);
  await page.getByLabel("Coupon code (optional)").fill(code.toLowerCase());
  await page.getByRole("button", { name: "Apply" }).click();
  await expect(
    page.getByRole("status").filter({ hasText: `Coupon ${code} applied` }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Enrol now" }).click();
  await expect(page).toHaveURL(new RegExp(`/learn/${course.slug}/`));

  const { data: order } = await serviceClient()
    .from("orders")
    .select("id, reference, status, provider")
    .eq("user_id", user.id)
    .single();
  expect(order).toMatchObject({ status: "paid", provider: "coupon" });

  const adminCtx = await browser.newContext({
    extraHTTPHeaders: { "x-forwarded-for": "10.8.8.8" },
  });
  const admin = await adminCtx.newPage();
  await logIn(admin, DEMO.admin);
  await admin.goto(`/admin/orders?q=${order!.reference}`);
  admin.once("dialog", (d) => d.accept("Customer request"));
  await admin.getByRole("button", { name: `Refund ${order!.reference}` }).click();
  await expect(admin.getByText(`${order!.reference} refunded and access removed.`)).toBeVisible();
  await adminCtx.close();

  await page.goto(`/learn/${course.slug}`);
  await expect(page).toHaveURL(new RegExp(`/courses/${course.slug}\\?enrol=1`));
});

test("admin creates a coupon; payment pages pass axe", async ({ page }) => {
  await logIn(page, DEMO.admin);
  await page.goto("/admin/coupons");
  await page.getByRole("button", { name: "New coupon" }).click();
  const code = `SAVE${Date.now().toString().slice(-5)}`;
  await page.getByLabel("Code").fill(code);
  await page.getByLabel("Type").selectOption("fixed");
  await page.getByLabel("Amount").fill("200");
  await page.getByRole("button", { name: "Save coupon" }).click();
  await expect(page.getByText("Choose the currency for a fixed discount")).toBeVisible();
  await page.getByLabel("Currency").selectOption("GHS");
  await page.getByRole("button", { name: "Save coupon" }).click();
  await expect(page.getByText(`Coupon ${code} saved.`)).toBeVisible();
  await expect(page.getByRole("cell", { name: code, exact: true })).toBeVisible();

  const course = await paidCourse();
  for (const p of ["/admin/orders", "/admin/coupons", `/checkout/${course.slug}`, "/orders"]) {
    await page.goto(p);
    const r = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
      .analyze();
    expect(
      r.violations.map((v) => `${p} ${v.id}: ${v.nodes.map((n) => n.target).join(",")}`),
    ).toEqual([]);
  }
});
