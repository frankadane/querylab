import AxeBuilder from "@axe-core/playwright";
import { DEMO, expect, logIn, serviceClient, test } from "./fixtures";

/** Every route, light + dark, phone + desktop width: no axe violations and no horizontal scrolling. */
const PUBLIC = [
  "/",
  "/courses",
  "/courses/power-bi-mastery",
  "/schedule",
  "/resources",
  "/resources/writing-better-prompts-at-work",
  "/instructors",
  "/about",
  "/corporate",
  "/contact",
  "/privacy",
  "/terms",
  "/cookies",
  "/login",
  "/register",
  "/forgot-password",
  "/verify-email",
];
const STUDENT = [
  "/dashboard",
  "/my-courses",
  "/learn/power-bi-mastery",
  "/orders",
  "/account",
  "/account/security",
];
const ADMIN = [
  "/admin",
  "/admin/analytics",
  "/admin/orders",
  "/admin/coupons",
  "/admin/users",
  "/admin/enquiries",
  "/admin/posts",
  "/admin/pages",
  "/admin/instructors",
  "/admin/testimonials",
  "/admin/faqs",
  "/admin/settings",
  "/admin/audit",
  "/studio/courses",
  "/studio/sessions",
  "/studio/sessions/new",
];

for (const width of [375, 1440]) {
  for (const scheme of ["light", "dark"] as const) {
    test(`all pages at ${width}px, ${scheme}`, async ({ page }) => {
      test.setTimeout(180_000);
      await page.setViewportSize({ width, height: 900 });
      await page.emulateMedia({ colorScheme: scheme, reducedMotion: "reduce" });
      const { data: session } = await serviceClient()
        .from("live_sessions")
        .select("id")
        .is("course_id", null)
        .limit(1)
        .single();
      const problems: string[] = [];
      const check = async (path: string) => {
        await page.goto(path);
        await page.waitForLoadState("networkidle");
        const r = await new AxeBuilder({ page })
          .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
          .analyze();
        r.violations.forEach((v) =>
          problems.push(
            `${path} ${v.id}: ${v.nodes
              .slice(0, 3)
              .map((n) => n.target)
              .join(" | ")}`,
          ),
        );
        const overflow = await page.evaluate(
          () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
        );
        if (overflow > 0) problems.push(`${path} horizontal overflow ${overflow}px`);
      };
      for (const p of [...PUBLIC, `/schedule/${session!.id}`]) await check(p);
      await logIn(page, DEMO.student);
      for (const p of STUDENT) await check(p);
      await page.context().clearCookies();
      await logIn(page, DEMO.admin);
      for (const p of ADMIN) await check(p);
      expect(problems).toEqual([]);
    });
  }
}
