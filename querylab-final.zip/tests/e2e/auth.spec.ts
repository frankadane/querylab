import { readFileSync } from "node:fs";
import AxeBuilder from "@axe-core/playwright";
import { DEMO, createUser, emailLink, expect, logIn, serviceClient, test } from "./fixtures";

test.describe("registration and verification", () => {
  test("register → confirm email → dashboard", async ({ page, baseURL }) => {
    const email = `signup-${Date.now()}@querylab.test`;
    await page.goto("/register");
    await page.getByLabel("Full name").fill("Kofi Boateng");
    await page.getByLabel("Email").fill(email);
    await page.getByLabel("Password").fill("Signup-Password-1");
    await page.getByLabel(/I agree to the/).check();
    await page.getByRole("button", { name: "Create account" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("Check your email");

    await page.goto(await emailLink(email, baseURL!, /Confirm/));
    await expect(page).toHaveURL(/\/dashboard/);
    await expect(page.getByRole("heading", { name: "Welcome, Kofi" })).toBeVisible();
  });

  test("client-side validation lists problems before submitting", async ({ page }) => {
    await page.goto("/register");
    await page.getByRole("button", { name: "Create account" }).click();
    await expect(page.getByText("Enter your name")).toBeVisible();
    await expect(page.getByText("You must accept the terms")).toBeVisible();
    await expect(page.getByLabel("Full name")).toHaveAttribute("aria-invalid", "true");
  });
});

test.describe("login and roles", () => {
  test("wrong password shows a generic error", async ({ page }) => {
    await page.goto("/login");
    await page.getByLabel("Email").fill(DEMO.student.email);
    await page.getByLabel("Password", { exact: true }).fill("not-the-password-1");
    await page.getByRole("button", { name: "Log in", exact: true }).click();
    await expect(page.getByRole("main").getByRole("alert")).toHaveText(
      "Email or password is incorrect.",
    );
  });

  test("anonymous users are sent to login and returned afterwards", async ({ page }) => {
    await page.goto("/account");
    await expect(page).toHaveURL(/\/login\?next=%2Faccount/);
    await page.getByLabel("Email").fill(DEMO.student.email);
    await page.getByLabel("Password", { exact: true }).fill(DEMO.student.password);
    await page.getByRole("button", { name: "Log in", exact: true }).click();
    await expect(page).toHaveURL(/\/account$/);
  });

  test("students cannot open admin or teaching pages", async ({ page }) => {
    await logIn(page, DEMO.student);
    await expect(page.getByRole("link", { name: "Admin" })).toHaveCount(0);
    await page.goto("/admin");
    await expect(page).toHaveURL(/\/dashboard\?denied=1/);
    await expect(page.getByRole("main").getByRole("alert")).toContainText("don't have access");
    await page.goto("/instructor");
    await expect(page).toHaveURL(/denied=1/);
  });

  test("admins see the admin area", async ({ page }) => {
    await logIn(page, DEMO.admin);
    await page.getByRole("link", { name: "Admin" }).click();
    await expect(page.getByRole("heading", { name: "Admin", level: 1 })).toBeVisible();
  });

  test("log out clears the session", async ({ page }) => {
    await logIn(page, DEMO.student);
    await page.getByRole("button", { name: "Account menu" }).click();
    await page.getByRole("menuitem", { name: "Log out" }).click();
    await expect(page).toHaveURL("/");
    await page.goto("/dashboard");
    await expect(page).toHaveURL(/\/login/);
  });

  test("auth cookies are httpOnly", async ({ page, context }) => {
    await logIn(page, DEMO.student);
    const cookies = await context.cookies();
    const auth = cookies.filter((c) => c.name.startsWith("sb-"));
    expect(auth.length).toBeGreaterThan(0);
    auth.forEach((c) => expect(c.httpOnly).toBe(true));
  });
});

test.describe("email links", () => {
  test("magic link signs in", async ({ page, baseURL }) => {
    const user = await createUser();
    await page.goto("/login");
    await page.getByRole("button", { name: "Email me a sign-in link instead" }).click();
    await page.getByLabel("Email").fill(user.email);
    await page.getByRole("button", { name: "Send sign-in link" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("Check your inbox");
    await page.goto(await emailLink(user.email, baseURL!, /sign-in link/));
    await expect(page).toHaveURL(/\/dashboard/);
  });

  test("magic link for an unknown email gives the same response", async ({ page }) => {
    await page.goto("/login");
    await page.getByRole("button", { name: "Email me a sign-in link instead" }).click();
    await page.getByLabel("Email").fill(`nobody-${Date.now()}@querylab.test`);
    await page.getByRole("button", { name: "Send sign-in link" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("Check your inbox");
  });

  test("forgot password → reset → log in with new password", async ({ page, baseURL }) => {
    const user = await createUser();
    await page.goto("/forgot-password");
    await page.getByLabel("Email").fill(user.email);
    await page.getByRole("button", { name: "Send reset link" }).click();
    await expect(page.getByRole("main").getByRole("status")).toBeVisible();

    await page.goto(await emailLink(user.email, baseURL!, /Reset/));
    await expect(page).toHaveURL(/\/reset-password/);
    await page.getByLabel("New password", { exact: true }).fill("Brand-New-Pass-9");
    await page.getByLabel("Confirm new password").fill("Brand-New-Pass-9");
    await page.getByRole("button", { name: "Save new password" }).click();
    await expect(page).toHaveURL(/passwordReset=1/);

    await page.context().clearCookies();
    await logIn(page, { email: user.email, password: "Brand-New-Pass-9" });
  });

  test("expired or tampered links show a friendly error", async ({ page }) => {
    await page.goto("/auth/confirm?token_hash=bogus&type=recovery&next=/reset-password");
    await expect(page.getByRole("heading", { name: "This link doesn't work" })).toBeVisible();
  });

  test("open redirects are blocked", async ({ page }) => {
    await page.goto("/login?next=https://evil.example");
    await page.getByLabel("Email").fill(DEMO.student.email);
    await page.getByLabel("Password", { exact: true }).fill(DEMO.student.password);
    await page.getByRole("button", { name: "Log in", exact: true }).click();
    await expect(page).toHaveURL(/localhost:\d+\/dashboard/);
  });
});

test.describe("account", () => {
  test("edit profile and timezone", async ({ page }) => {
    const user = await createUser();
    await logIn(page, user);
    await page.goto("/account");
    await page.getByLabel("Full name").fill("Efua Owusu");
    await page.getByLabel("Bio").fill("Analyst learning Power BI.");
    await page.getByLabel("Timezone").selectOption("Europe/London");
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page.getByRole("main").getByRole("status")).toHaveText("Profile saved.");
    await page.goto("/dashboard");
    await expect(page.getByText("Europe/London")).toBeVisible();
  });

  test("change password requires the current one", async ({ page }) => {
    const user = await createUser();
    await logIn(page, user);
    await page.goto("/account/security");
    await page.getByLabel("Current password").fill("wrong-password-1");
    await page.getByLabel("New password", { exact: true }).fill("Changed-Pass-77");
    await page.getByLabel("Confirm new password").fill("Changed-Pass-77");
    await page.getByRole("button", { name: "Change password" }).click();
    await expect(page.getByRole("main").getByRole("alert")).toContainText(
      "Current password is incorrect",
    );

    await page.getByLabel("Current password").fill(user.password);
    await page.getByRole("button", { name: "Change password" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("Password changed");
  });

  test("export my data, then delete my account", async ({ page }) => {
    const user = await createUser();
    await logIn(page, user);
    await page.goto("/account/security");

    const download = page.waitForEvent("download");
    await page.getByRole("link", { name: "Download my data" }).click();
    const file = await (await download).path();
    const json = JSON.parse(readFileSync(file, "utf8"));
    expect(json.account.email).toBe(user.email);
    expect(json.profile.id).toBe(user.id);

    await page.getByLabel(`Type ${user.email} to confirm`).fill(user.email);
    await page.getByRole("button", { name: "Delete my account permanently" }).click();
    await expect(page).toHaveURL(/accountDeleted=1/);

    const { data } = await serviceClient().auth.admin.getUserById(user.id);
    expect(data.user).toBeNull();
  });
});

test.describe("accessibility of auth pages", () => {
  for (const path of ["/login", "/register", "/forgot-password"]) {
    for (const scheme of ["light", "dark"] as const) {
      test(`${path} has no axe violations (${scheme})`, async ({ page }) => {
        await page.emulateMedia({ colorScheme: scheme, reducedMotion: "reduce" });
        await page.goto(path);
        const r = await new AxeBuilder({ page })
          .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
          .analyze();
        expect(
          r.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target).join(",")}`),
        ).toEqual([]);
      });
    }
  }

  test("account pages have no axe violations", async ({ page }) => {
    await logIn(page, DEMO.student);
    for (const path of ["/dashboard", "/account", "/account/security"]) {
      await page.goto(path);
      const r = await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
        .analyze();
      expect(r.violations.map((v) => `${path} ${v.id}`)).toEqual([]);
    }
  });
});
