import AxeBuilder from "@axe-core/playwright";
import { DEMO, INSTRUCTOR, STUDENT2, expect, logIn, serviceClient, test } from "./fixtures";

const axe = (page: import("@playwright/test").Page) =>
  new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();

test.describe("public catalogue", () => {
  test("lists, searches and filters courses", async ({ page }) => {
    await page.goto("/courses");
    for (const t of [
      "Applied AI for Professionals",
      "Data Science with Python & SQL",
      "Power BI Mastery",
    ]) {
      await expect(page.getByRole("link", { name: t, exact: true })).toBeVisible();
    }

    await page.getByLabel("Search").fill("DAX");
    await page.getByRole("button", { name: "Apply" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("1 course");
    await expect(page.getByRole("link", { name: "Power BI Mastery" })).toBeVisible();

    await page.goto("/courses?level=advanced");
    await expect(page.getByRole("link", { name: "Power BI Mastery" })).toBeVisible();
    await expect(page.getByRole("link", { name: "Applied AI for Professionals" })).toHaveCount(0);

    await page.goto("/courses?track=data_science");
    await expect(
      page.getByRole("link", { name: "Data Science with Python & SQL", exact: true }),
    ).toBeVisible();
    await expect(page.getByRole("link", { name: "Power BI Mastery", exact: true })).toHaveCount(0);

    await page.goto("/courses?q=zzzznotacourse");
    await expect(page.getByRole("heading", { name: "No courses match" })).toBeVisible();
  });

  test("course page shows syllabus, JSON-LD and a working free preview", async ({ page }) => {
    await page.goto("/courses/power-bi-mastery");
    await expect(page.getByRole("heading", { level: 1, name: "Power BI Mastery" })).toBeVisible();
    await expect(page.getByRole("heading", { name: "Syllabus" })).toBeVisible();
    await expect(page.getByText("DAX fundamentals")).toBeVisible();
    const ld = JSON.parse(
      (await page.locator('script[type="application/ld+json"]').textContent())!,
    );
    expect(ld["@type"]).toBe("Course");
    expect(ld.offers.priceCurrency).toBe("GHS");

    await page.getByRole("link", { name: "Tour of Power BI Desktop" }).click();
    await expect(
      page.getByRole("heading", { level: 1, name: "Tour of Power BI Desktop" }),
    ).toBeVisible();
    await expect(page.getByText("Video coming soon (placeholder)")).toBeVisible();
  });

  test("non-preview lessons can't be opened via the preview URL", async ({ page }) => {
    const { data } = await serviceClient()
      .from("lessons")
      .select("id, course:courses(slug)")
      .eq("is_free_preview", false)
      .limit(1)
      .single();
    const res = await page.goto(
      `/courses/${(data!.course as unknown as { slug: string }).slug}/preview/${data!.id}`,
    );
    expect(res?.status()).toBe(404);
  });

  test("public course pages pass axe", async ({ page }) => {
    for (const path of ["/courses", "/courses/applied-ai-for-professionals", "/instructors"]) {
      await page.goto(path);
      expect((await axe(page)).violations.map((v) => `${path} ${v.id}`)).toEqual([]);
    }
  });
});

test.describe("studio (instructor)", () => {
  test("instructor sees and edits only their own course", async ({ page }) => {
    await logIn(page, INSTRUCTOR);
    await page.getByRole("link", { name: "Studio" }).click();
    await expect(page.getByRole("link", { name: "Applied AI for Professionals" })).toBeVisible();
    await expect(page.getByRole("link", { name: "Power BI Mastery" })).toHaveCount(0);

    const { data: other } = await serviceClient()
      .from("courses")
      .select("id")
      .eq("slug", "power-bi-mastery")
      .single();
    const res = await page.goto(`/studio/courses/${other!.id}`);
    expect(res?.status()).toBe(404);
  });

  test("students can't open the studio", async ({ page }) => {
    await logIn(page, DEMO.student);
    await page.goto("/studio/courses");
    await expect(page).toHaveURL(/denied=1/);
  });
});

test.describe("studio (admin): build and publish a course", () => {
  test("create → add sections/lessons → reorder → quiz → publish → archive", async ({ page }) => {
    const title = `E2E Course ${Date.now()}`;
    await logIn(page, DEMO.admin);
    await page.goto("/studio/courses");
    await page.getByRole("button", { name: "New course" }).click();
    await page.getByRole("dialog").getByLabel("Title").fill(title);
    await page.getByRole("dialog").getByLabel("Track").selectOption("power_bi");
    await page.getByRole("button", { name: "Create draft" }).click();
    await expect(page.getByRole("heading", { level: 1, name: title })).toBeVisible();

    // Publishing an empty course is refused
    await page.getByRole("button", { name: "Publish" }).click();
    await expect(page.getByRole("main").getByRole("alert")).toContainText(
      "Add at least one lesson",
    );

    // Details
    await page.getByLabel("Subtitle").fill("Built by the end-to-end test.");
    await page.getByLabel("Price", { exact: true }).fill("120.50");
    await page.getByLabel("Currency").selectOption("USD");
    await page.getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("main").getByRole("status")).toHaveText("Course saved.");

    // Thumbnail upload (Supabase Storage → next/image)
    await page.locator('input[type="file"]').setInputFiles("tests/e2e/assets/thumb.png");
    await expect(page.getByText("Thumbnail updated.")).toBeVisible();

    // Curriculum
    await page.getByRole("link", { name: "Curriculum" }).click();
    await page.getByLabel("New section").fill("Week 1");
    await page.getByRole("button", { name: "Add section" }).click();
    const week1 = page
      .getByRole("listitem")
      .filter({ has: page.getByRole("heading", { name: "Week 1" }) });
    for (const t of ["Lesson A", "Lesson B"]) {
      await week1.getByLabel(/New lesson in/).fill(t);
      await week1.getByRole("button", { name: "Add lesson" }).click();
      await expect(week1.getByRole("link", { name: t })).toBeVisible();
    }
    await week1.getByLabel(/New lesson in/).fill("Check your understanding");
    await week1.getByLabel("Type").selectOption("quiz");
    await week1.getByRole("button", { name: "Add lesson" }).click();
    await expect(week1.getByRole("link", { name: "Check your understanding" })).toBeVisible();

    // Reorder with the button alternative
    await week1.getByRole("button", { name: "Move lesson down: Lesson A" }).click();
    await expect(page.getByText("Moved “Lesson A” to position 2")).toBeVisible();
    await page.reload();
    const titles = await page
      .getByRole("listitem")
      .filter({ has: page.getByRole("heading", { name: "Week 1" }) })
      .getByRole("link")
      .allTextContents();
    expect(titles.slice(0, 2)).toEqual(["Lesson B", "Lesson A"]);

    // Reorder with keyboard drag-and-drop (Space, ArrowDown, Space). Wait for hydration first.
    await page.waitForLoadState("networkidle");
    const handle = page.getByRole("button", { name: "Drag to reorder lesson: Lesson A" });
    await expect(handle).toHaveAttribute("aria-roledescription", "sortable");
    await handle.focus();
    await page.keyboard.press("Space");
    await expect(page.getByText(/Lesson “Lesson A” is over position 2 of 3/)).toBeAttached();
    await page.waitForTimeout(300); // dnd-kit animates each step (~250 ms); pace keys like a person would
    await page.keyboard.press("ArrowDown");
    await expect(page.getByText(/Lesson “Lesson A” is over position 3 of 3/)).toBeAttached();
    await page.waitForTimeout(300);
    await page.keyboard.press("Space");
    await expect(page.getByText("Moved “Lesson A” to position 3")).toBeVisible();

    // Quiz editor
    await page.getByRole("link", { name: "Check your understanding" }).click();
    await page.getByRole("button", { name: "Add question" }).click();
    await page.getByLabel("Question", { exact: true }).fill("2 + 2 = ?");
    await page.getByLabel("Option 1", { exact: true }).fill("3");
    await page.getByLabel("Option 2", { exact: true }).fill("4");
    await page.getByLabel("Option 2 is correct").check();
    await page.getByRole("button", { name: "Save quiz" }).click();
    await expect(page.getByRole("main").getByRole("status").last()).toContainText(
      "Quiz saved (1 questions)",
    );

    // Lesson content + free preview
    await page.goto(page.url().replace(/lessons\/.*/, "curriculum"));
    await page.getByRole("link", { name: "Lesson B" }).click();
    await page.getByLabel("Free preview").check();
    await page.getByLabel("Video URL").fill("http://insecure.example");
    await page.getByRole("button", { name: "Save lesson" }).click();
    await expect(page.getByText("Use an https:// link")).toBeVisible();
    await page.getByLabel("Video URL").fill("https://vimeo.com/123");
    await page
      .getByLabel("Lesson notes", { exact: true })
      .fill("## Hello\n\n<script>alert(1)</script>\n\nSome **bold** text.");
    await page.getByRole("button", { name: "Save lesson" }).click();
    await expect(page.getByRole("main").getByRole("status")).toHaveText("Lesson saved.");

    // Publish → public
    await page.getByRole("button", { name: "Publish" }).click();
    await expect(page.getByRole("main").getByRole("status").first()).toContainText(
      "Course published",
    );
    await page.getByRole("link", { name: "View public page" }).click();
    await expect(page.getByRole("heading", { level: 1, name: title })).toBeVisible();
    await expect(page.getByText("$120.50").first()).toBeVisible();
    const thumb = page.locator('aside[aria-label="Enrolment"] img');
    await expect(thumb).toHaveJSProperty("complete", true);
    expect(await thumb.evaluate((img: HTMLImageElement) => img.naturalWidth)).toBeGreaterThan(0);
    await page.getByRole("link", { name: "Lesson B" }).click();
    await expect(page.locator("main strong", { hasText: "bold" })).toBeVisible();
    expect(await page.locator("main script").count()).toBe(0);

    // Archive → gone from catalogue
    await page.goBack();
    await page.goBack();
    await page.getByRole("button", { name: "Archive" }).click();
    await expect(page.getByRole("main").getByRole("status").first()).toContainText(
      "Course archived",
    );
    await page.goto("/courses");
    await expect(page.getByRole("link", { name: title })).toHaveCount(0);

    // Every action was audited
    await page.goto("/admin/audit");
    await expect(page.getByRole("cell", { name: "course.archived" }).first()).toBeVisible();
    await expect(page.getByRole("cell", { name: "quiz.saved" }).first()).toBeVisible();
  });

  test("studio pages pass axe", async ({ page }) => {
    await logIn(page, DEMO.admin);
    const { data } = await serviceClient()
      .from("courses")
      .select("id")
      .eq("slug", "power-bi-mastery")
      .single();
    for (const p of [
      "/studio/courses",
      `/studio/courses/${data!.id}`,
      `/studio/courses/${data!.id}/curriculum`,
      `/studio/courses/${data!.id}/faqs`,
    ]) {
      await page.goto(p);
      expect(
        (await axe(page)).violations.map(
          (v) => `${p} ${v.id}: ${v.nodes.map((n) => n.target).join(", ")}`,
        ),
      ).toEqual([]);
    }
  });
});

test.describe("admin", () => {
  test("search users, change role, suspend and enrol", async ({ page, browser }) => {
    await logIn(page, DEMO.admin);
    await page.goto("/admin/users");
    await page.getByLabel("Search name or email").fill("student2");
    await page.getByRole("button", { name: "Search" }).click();
    await page.getByRole("link", { name: "Demo Student Two" }).click();
    await expect(page.getByRole("heading", { level: 1, name: "Demo Student Two" })).toBeVisible();

    await page.getByLabel("Role", { exact: true }).selectOption("instructor");
    await page.getByRole("button", { name: "Save role" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText(
      "Role changed to instructor",
    );
    await page.getByLabel("Role", { exact: true }).selectOption("student");
    await page.getByRole("button", { name: "Save role" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText(
      "Role changed to student",
    );

    page.once("dialog", (d) => d.accept());
    await page.getByRole("button", { name: "Suspend user" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("User suspended");

    const other = await browser.newContext({ extraHTTPHeaders: { "x-forwarded-for": "10.9.9.9" } });
    const p2 = await other.newPage();
    await p2.goto("/login");
    await p2.getByLabel("Email").fill(STUDENT2.email);
    await p2.getByLabel("Password", { exact: true }).fill(STUDENT2.password);
    await p2.getByRole("button", { name: "Log in", exact: true }).click();
    await expect(p2.getByRole("main").getByRole("alert")).toBeVisible();
    await expect(p2).toHaveURL(/\/login/);
    await other.close();

    await page.getByRole("button", { name: "Lift suspension" }).click();
    await expect(page.getByRole("main").getByRole("status")).toContainText("Suspension lifted");

    await page
      .getByLabel("Enrol in a course (manual)")
      .selectOption({ label: "Data Science with Python & SQL" });
    await page.getByRole("button", { name: "Enrol user" }).click();
    await expect(page.getByText("via manual")).toBeVisible();
    await page.getByRole("button", { name: /Remove access to Data Science/ }).click();
    await expect(page.getByText(/Revoked · via manual/)).toBeVisible();
  });

  test("testimonials require consent; settings save bank details", async ({ page }) => {
    await logIn(page, DEMO.admin);
    await page.goto("/admin/testimonials");
    await page.getByRole("button", { name: "Add testimonial" }).click();
    await page.getByLabel("Quote", { exact: true }).fill("Clear and practical.");
    await page.getByLabel("Author name").fill("Test Person");
    await page.getByRole("button", { name: "Save testimonial" }).click();
    await expect(page.getByText("Confirm you have the author's permission")).toBeVisible();

    await page.goto("/admin/settings");
    await page.getByLabel("Account name").fill("QueryLab Training Ltd (test)");
    await page.getByLabel("Bank name").fill("Test Bank Ghana");
    await page.getByRole("button", { name: "Save settings" }).click();
    await expect(page.getByRole("main").getByRole("status")).toHaveText("Settings saved.");
    const { data } = await serviceClient().from("site_settings").select("bank_details").single();
    expect((data!.bank_details as { bank_name: string }).bank_name).toBe("Test Bank Ghana");
  });

  test("admin pages pass axe", async ({ page }) => {
    await logIn(page, DEMO.admin);
    for (const p of [
      "/admin",
      "/admin/users",
      "/admin/instructors",
      "/admin/faqs",
      "/admin/testimonials",
      "/admin/settings",
      "/admin/audit",
    ]) {
      await page.goto(p);
      expect(
        (await axe(page)).violations.map(
          (v) => `${p} ${v.id}: ${v.nodes.map((n) => n.target).join(", ")}`,
        ),
      ).toEqual([]);
    }
  });
});
