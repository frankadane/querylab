import { describe, expect, it } from "vitest";
import {
  addDaysKey,
  addMonthsKey,
  labelDay,
  monthGrid,
  startOfWeekKey,
} from "@/lib/sessions/calendar";

describe("calendar keys", () => {
  it("adds days across month and year ends", () => {
    expect(addDaysKey("2026-12-31", 1)).toBe("2027-01-01");
    expect(addDaysKey("2026-03-01", -1)).toBe("2026-02-28");
  });
  it("adds months clamping the day", () => {
    expect(addMonthsKey("2026-01-31", 1)).toBe("2026-02-28");
    expect(addMonthsKey("2026-12-15", 1)).toBe("2027-01-15");
  });
  it("starts weeks on Monday", () => {
    expect(startOfWeekKey("2026-11-19")).toBe("2026-11-16"); // Thursday → Monday
    expect(startOfWeekKey("2026-11-22")).toBe("2026-11-16"); // Sunday → Monday
  });
  it("builds a 6x7 month grid starting on Monday", () => {
    const g = monthGrid("2026-11-19");
    expect(g).toHaveLength(6);
    expect(g[0][0]).toBe("2026-10-26");
    expect(g.flat()).toContain("2026-11-30");
  });
  it("labels days without browser timezone drift", () => {
    expect(labelDay("2026-11-19")).toBe("Thursday, 19 November 2026");
  });
});
