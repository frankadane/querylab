import { describe, expect, it } from "vitest";
import { footerNav, mainNav, siteConfig, tracks } from "@/lib/site";

describe("site config", () => {
  it("uses Africa/Accra as the default timezone", () => {
    expect(siteConfig.defaultTimezone).toBe("Africa/Accra");
  });
  it("supports GHS and USD", () => {
    expect(siteConfig.currencies).toEqual(["GHS", "USD"]);
  });
  it("has unique, absolute nav links", () => {
    const hrefs = [...mainNav, ...footerNav.flatMap((g) => g.items)].map((i) => i.href);
    hrefs.forEach((h) => expect(h.startsWith("/")).toBe(true));
    expect(new Set(mainNav.map((i) => i.href)).size).toBe(mainNav.length);
  });
  it("defines the three tracks", () => {
    expect(tracks.map((t) => t.slug)).toEqual(["ai", "data-science", "power-bi"]);
  });
});
