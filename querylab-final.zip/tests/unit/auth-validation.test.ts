import { describe, expect, it } from "vitest";
import {
  changePasswordSchema,
  profileSchema,
  resetPasswordSchema,
  signUpSchema,
} from "@/lib/validation/auth";

const valid = {
  fullName: "Ama Mensah",
  email: "  Ama@Example.COM ",
  password: "correcthorse9",
  timezone: "Africa/Accra",
  acceptTerms: true,
};

describe("signUpSchema", () => {
  it("normalises email", () => {
    expect(signUpSchema.parse(valid).email).toBe("ama@example.com");
  });
  it.each([
    ["short", "abc123"],
    ["no digit", "onlyletters"],
    ["no letter", "1234567890"],
    ["too long", `a1${"x".repeat(80)}`],
  ])("rejects password: %s", (_, password) => {
    expect(signUpSchema.safeParse({ ...valid, password }).success).toBe(false);
  });
  it("requires accepting terms", () => {
    expect(signUpSchema.safeParse({ ...valid, acceptTerms: false }).success).toBe(false);
  });
  it("rejects unknown timezones", () => {
    expect(signUpSchema.safeParse({ ...valid, timezone: "Mars/Base" }).success).toBe(false);
  });
  it("rejects bad emails", () => {
    expect(signUpSchema.safeParse({ ...valid, email: "not-an-email" }).success).toBe(false);
  });
});

describe("password confirmation", () => {
  it("must match on reset", () => {
    const r = resetPasswordSchema.safeParse({ password: "newpassword1", confirm: "different1" });
    expect(r.success).toBe(false);
    expect(r.error?.issues[0]?.path).toEqual(["confirm"]);
  });
  it("change requires current password", () => {
    expect(
      changePasswordSchema.safeParse({
        current: "",
        password: "newpassword1",
        confirm: "newpassword1",
      }).success,
    ).toBe(false);
  });
});

describe("profileSchema", () => {
  it("caps bio length", () => {
    expect(
      profileSchema.safeParse({ fullName: "A", bio: "x".repeat(2001), timezone: "UTC" }).success,
    ).toBe(false);
  });
});
