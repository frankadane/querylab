import { describe, expect, it } from "vitest";
import {
  availabilityLabel,
  decideRegistration,
  placesLeft,
  promotions,
} from "@/lib/sessions/capacity";

describe("capacity and waitlist", () => {
  it("registers until full, then waitlists", () => {
    expect(decideRegistration(25, 0)).toBe("registered");
    expect(decideRegistration(25, 24)).toBe("registered");
    expect(decideRegistration(25, 25)).toBe("waitlist");
    expect(decideRegistration(25, 30)).toBe("waitlist");
  });

  it("promotes the oldest waitlisted people into freed places", () => {
    const w = [
      { id: "c", waitlistedAt: new Date("2026-01-03") },
      { id: "a", waitlistedAt: new Date("2026-01-01") },
      { id: "b", waitlistedAt: new Date("2026-01-02") },
    ];
    expect(promotions(25, 24, w).map((x) => x.id)).toEqual(["a"]);
    expect(promotions(25, 23, w).map((x) => x.id)).toEqual(["a", "b"]);
    expect(promotions(25, 25, w)).toEqual([]);
    expect(promotions(30, 25, w).map((x) => x.id)).toEqual(["a", "b", "c"]);
  });

  it("never reports negative places", () => {
    expect(placesLeft(25, 26)).toBe(0);
  });

  it("labels availability", () => {
    expect(availabilityLabel(25, 3, 0)).toBe("22 of 25 places available");
    expect(availabilityLabel(25, 24, 0)).toBe("1 place left");
    expect(availabilityLabel(25, 25, 0)).toBe("Full · join the waitlist");
    expect(availabilityLabel(25, 25, 4)).toBe("Full · 4 on the waitlist");
  });
});
