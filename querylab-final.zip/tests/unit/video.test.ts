import { describe, expect, it } from "vitest";
import { toVideoEmbed } from "@/lib/learning/video";

describe("toVideoEmbed", () => {
  it.each([
    [
      "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
      "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0",
    ],
    ["https://youtu.be/dQw4w9WgXcQ", "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0"],
    [
      "https://m.youtube.com/shorts/dQw4w9WgXcQ",
      "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0",
    ],
    ["https://vimeo.com/76979871", "https://player.vimeo.com/video/76979871?dnt=1"],
    [
      "https://vimeo.com/123456789/abcdef1234",
      "https://player.vimeo.com/video/123456789?dnt=1&h=abcdef1234",
    ],
    [
      "https://stream.mux.com/EcHgOK9coz5K4rjSwOkoE7Y7O01201YMIC200RI6lNxnhs.m3u8",
      "https://player.mux.com/EcHgOK9coz5K4rjSwOkoE7Y7O01201YMIC200RI6lNxnhs",
    ],
  ])("%s", (input, src) => {
    expect(toVideoEmbed(input)).toMatchObject({ src });
  });

  it("recognises the demo placeholder", () => {
    expect(toVideoEmbed("https://example.com/placeholder-video")).toEqual({
      provider: "placeholder",
    });
  });

  it.each([
    "http://youtube.com/watch?v=dQw4w9WgXcQ",
    "https://evil.com/watch?v=dQw4w9WgXcQ",
    "javascript:alert(1)",
    "https://youtube.com/watch?v=<script>",
    "",
  ])("rejects %s", (input) => expect(toVideoEmbed(input)).toBeNull());
});
