import { describe, expect, it } from "vitest";
import {
  formatSessionRange,
  googleCalendarUrl,
  joinState,
  localDateKey,
  meetingProvider,
  weeklyOccurrences,
} from "@/lib/sessions/time";

describe("weeklyOccurrences", () => {
  it("Africa/Accra (no DST): 18:00 local is 18:00 UTC every week", () => {
    const occ = weeklyOccurrences({
      date: "2026-12-03",
      time: "18:00",
      timeZone: "Africa/Accra",
      durationMinutes: 90,
      count: 3,
    });
    expect(occ.map((o) => o.startsAt.toISOString())).toEqual([
      "2026-12-03T18:00:00.000Z",
      "2026-12-10T18:00:00.000Z",
      "2026-12-17T18:00:00.000Z",
    ]);
    expect(occ[0].endsAt.toISOString()).toBe("2026-12-03T19:30:00.000Z");
  });

  it("keeps local wall time across a DST change (Europe/London, March 2027)", () => {
    const occ = weeklyOccurrences({
      date: "2027-03-21",
      time: "18:00",
      timeZone: "Europe/London",
      durationMinutes: 60,
      count: 2,
    });
    // 21 Mar = GMT (UTC+0); 28 Mar = BST (UTC+1) after the clocks go forward
    expect(occ[0].startsAt.toISOString()).toBe("2027-03-21T18:00:00.000Z");
    expect(occ[1].startsAt.toISOString()).toBe("2027-03-28T17:00:00.000Z");
  });

  it("supports fortnightly series", () => {
    const occ = weeklyOccurrences({
      date: "2026-12-01",
      time: "09:30",
      timeZone: "UTC",
      durationMinutes: 30,
      count: 2,
      intervalWeeks: 2,
    });
    expect(occ[1].startsAt.toISOString()).toBe("2026-12-15T09:30:00.000Z");
  });

  it("rejects bad input", () => {
    expect(() =>
      weeklyOccurrences({
        date: "3 Dec",
        time: "18:00",
        timeZone: "UTC",
        durationMinutes: 60,
        count: 1,
      }),
    ).toThrow();
    expect(() =>
      weeklyOccurrences({
        date: "2026-12-03",
        time: "18:00",
        timeZone: "UTC",
        durationMinutes: 60,
        count: 53,
      }),
    ).toThrow();
  });
});

describe("display in the viewer's timezone", () => {
  const start = new Date("2026-12-03T18:00:00Z");
  const end = new Date("2026-12-03T19:30:00Z");
  it("formats for Accra", () => {
    expect(formatSessionRange(start, end, "Africa/Accra")).toBe(
      "Thu 3 Dec 2026, 18:00 – 19:30 GMT",
    );
  });
  it("formats for New York (previous offset)", () => {
    expect(formatSessionRange(start, end, "America/New_York")).toBe(
      "Thu 3 Dec 2026, 13:00 – 14:30 EST",
    );
  });
  it("shows the end date when the session crosses midnight locally", () => {
    expect(formatSessionRange(start, end, "Asia/Tokyo")).toBe(
      "Fri 4 Dec 2026, 03:00 – 04:30 GMT+9",
    );
  });
  it("buckets sessions by local calendar day", () => {
    expect(localDateKey(start, "Africa/Accra")).toBe("2026-12-03");
    expect(localDateKey(start, "Asia/Tokyo")).toBe("2026-12-04");
  });
});

describe("joinState", () => {
  const s = new Date("2026-12-03T18:00:00Z");
  const e = new Date("2026-12-03T19:30:00Z");
  it.each([
    ["2026-12-03T17:44:59Z", "too_early"],
    ["2026-12-03T17:45:00Z", "open"],
    ["2026-12-03T19:30:00Z", "open"],
    ["2026-12-03T19:30:01Z", "ended"],
  ])("at %s → %s", (now, expected) =>
    expect(joinState(new Date(now), s, e, "scheduled")).toBe(expected),
  );
  it("cancelled sessions never open", () =>
    expect(joinState(new Date("2026-12-03T18:10:00Z"), s, e, "cancelled")).toBe("cancelled"));
});

describe("links", () => {
  it("detects the meeting provider", () => {
    expect(meetingProvider("https://us02web.zoom.us/j/123")).toBe("Zoom");
    expect(meetingProvider("https://meet.google.com/abc-defg-hij")).toBe("Google Meet");
    expect(meetingProvider("https://teams.microsoft.com/l/meetup-join/x")).toBe("Microsoft Teams");
    expect(meetingProvider("https://evil.com/zoom.us")).toBeNull();
    expect(meetingProvider("not a url")).toBeNull();
  });
  it("builds a Google Calendar link in UTC", () => {
    const url = new URL(
      googleCalendarUrl({
        title: "DAX",
        startsAt: new Date("2026-12-03T18:00:00Z"),
        endsAt: new Date("2026-12-03T19:30:00Z"),
        details: "x",
      }),
    );
    expect(url.searchParams.get("dates")).toBe("20261203T180000Z/20261203T193000Z");
    expect(url.searchParams.get("text")).toBe("DAX");
  });
});
