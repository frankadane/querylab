import { describe, expect, it, vi } from "vitest";
vi.mock("server-only", () => ({}));
vi.mock("@/lib/email", () => ({ sendEmail: vi.fn(async () => ({ ok: true })) }));
vi.mock("@/lib/payments/bank", () => ({
  getBillingSettings: async () => ({ bank: {}, bankConfigured: false, company: {} }),
}));
vi.mock("@/lib/env", () => ({ publicEnv: { NEXT_PUBLIC_SITE_URL: "https://querylab.test" } }));

describe("payment providers", () => {
  it("offers only bank transfer at checkout; free/coupon/manual are internal", async () => {
    const { checkoutProviders, getProvider, providerLabel } =
      await import("@/lib/payments/registry");
    expect(checkoutProviders().map((p) => p.id)).toEqual(["bank_transfer"]);
    expect(getProvider("free")?.checkout).toBe(false);
    expect(providerLabel("stripe")).toBe("stripe");
  });

  it("bank transfer emails instructions and shows them on the order page", async () => {
    const { bankTransfer } = await import("@/lib/payments/providers/bank-transfer");
    const { sendEmail } = await import("@/lib/email");
    const outcome = await bankTransfer.begin({
      reference: "QL-ABCDEFGH",
      billing_email: "a@b.c",
      course_title: "X",
      total_minor: 150000,
      currency: "GHS",
    } as never);
    expect(outcome).toEqual({ type: "instructions" });
    expect(vi.mocked(sendEmail).mock.calls[0][0].text).toContain("QL-ABCDEFGH");
  });
});
