import { describe, expect, it } from "vitest";
import {
  formatDuration,
  formatPrice,
  levelInRange,
  levelLabel,
  slugify,
  toMinor,
} from "@/lib/courses/format";

describe("course formatting", () => {
  it("formats prices", () => {
    expect(formatPrice(0, "GHS")).toBe("Free");
    expect(formatPrice(150000, "GHS")).toMatch(/1,500/);
    expect(formatPrice(12050, "USD")).toBe("$120.50");
  });
  it("converts to minor units without float drift", () => {
    expect(toMinor("1,500.50")).toBe(150050);
    expect(toMinor(19.99)).toBe(1999);
    expect(() => toMinor("-1")).toThrow();
    expect(() => toMinor("abc")).toThrow();
  });
  it("labels and filters level ranges", () => {
    expect(levelLabel("beginner", "advanced")).toBe("Beginner → Advanced");
    expect(levelLabel("intermediate", "intermediate")).toBe("Intermediate");
    expect(levelInRange("intermediate", "beginner", "advanced")).toBe(true);
    expect(levelInRange("advanced", "beginner", "intermediate")).toBe(false);
  });
  it("formats durations", () => {
    expect(formatDuration(45)).toBe("45 min");
    expect(formatDuration(90)).toBe("1 h 30 min");
    expect(formatDuration(120)).toBe("2 h");
  });
  it("slugifies titles", () => {
    expect(slugify("Data Science with Python & SQL")).toBe("data-science-with-python-and-sql");
    expect(slugify("  Café — Énergie!! ")).toBe("cafe-energie");
  });
});
