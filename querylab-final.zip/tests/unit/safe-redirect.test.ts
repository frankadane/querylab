import { describe, expect, it } from "vitest";
import { safeNext } from "@/lib/safe-redirect";

describe("safeNext", () => {
  it.each([
    ["/dashboard", "/dashboard"],
    ["/account/security?x=1", "/account/security?x=1"],
    ["/courses#faq", "/courses#faq"],
  ])("allows %s", (input, expected) => expect(safeNext(input)).toBe(expected));

  it.each([
    "https://evil.example",
    "//evil.example",
    "/\\evil.example",
    "javascript:alert(1)",
    "dashboard",
    "",
    null,
    undefined,
  ])("rejects %s", (input) => expect(safeNext(input as string)).toBe("/dashboard"));
});
