import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { DEMO, service } from "./helpers";

vi.mock("server-only", () => ({}));
const sent: { to: string; subject: string }[] = [];
vi.mock("@/lib/email", () => ({
  sendEmail: async (m: { to: string; subject: string }) => {
    sent.push(m);
    return { ok: true };
  },
}));

const ids: string[] = [];
beforeAll(async () => {
  const s = service();
  const { data: course } = await s
    .from("courses")
    .select("id")
    .eq("slug", "power-bi-mastery")
    .single();
  const now = Date.now();
  const mk = (title: string, inMs: number) => ({
    course_id: course!.id,
    title,
    starts_at: new Date(now + inMs).toISOString(),
    ends_at: new Date(now + inMs + 90 * 60_000).toISOString(),
  });
  const { data } = await s
    .from("live_sessions")
    .insert([
      mk("R-in-20h", 20 * 3_600_000),
      mk("R-in-30m", 30 * 60_000),
      mk("R-in-3d", 72 * 3_600_000),
    ])
    .select("id, title");
  ids.push(...data!.map((d) => d.id));
  await s.from("session_registrations").insert(
    data!.map((d) => ({
      session_id: d.id,
      user_id: DEMO.student1.id,
      status: "registered" as const,
    })),
  );
});
afterAll(async () => {
  await service().from("live_sessions").delete().in("id", ids);
});

describe("reminder job", () => {
  it("sends 24h and 1h reminders once, and never twice", async () => {
    const { sendDueReminders } = await import("@/lib/sessions/reminders");
    await sendDueReminders();
    const mine = sent.filter((m) => m.to === DEMO.student1.email && m.subject.includes("R-in-"));
    expect(mine.map((m) => m.subject).sort()).toEqual([
      "Reminder: R-in-20h starts tomorrow",
      "Reminder: R-in-30m starts in about an hour",
    ]);

    sent.length = 0;
    await sendDueReminders();
    expect(sent.filter((m) => m.subject.includes("R-in-"))).toEqual([]);
  });
});
