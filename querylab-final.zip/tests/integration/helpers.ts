import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/lib/supabase/types";

export const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
export const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
export const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

export const DEMO = {
  admin: {
    id: "a0000000-0000-4000-8000-000000000001",
    email: "admin@querylab.test",
    password: "Demo-Admin-2026!",
  },
  instructor: {
    id: "a0000000-0000-4000-8000-000000000002",
    email: "instructor@querylab.test",
    password: "Demo-Instructor-2026!",
  },
  student1: {
    id: "a0000000-0000-4000-8000-000000000003",
    email: "student1@querylab.test",
    password: "Demo-Student-2026!",
  },
  student2: {
    id: "a0000000-0000-4000-8000-000000000004",
    email: "student2@querylab.test",
    password: "Demo-Student-2026!",
  },
} as const;

const opts = { auth: { persistSession: false, autoRefreshToken: false } };

export const anon = () => createClient<Database>(url, anonKey, opts);
export const service = () => createClient<Database>(url, serviceKey, opts);

export async function signedIn(user: { email: string; password: string }) {
  const client = anon();
  const { error } = await client.auth.signInWithPassword(user);
  if (error) throw error;
  return client;
}
