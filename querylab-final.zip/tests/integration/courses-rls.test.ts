import { describe, expect, it } from "vitest";
import { DEMO, anon, signedIn } from "./helpers";

describe("course content access through the API", () => {
  it("anonymous visitors see the syllabus but only free-preview bodies", async () => {
    const c = anon();
    const { data: lessons } = await c.from("lessons").select("id");
    const { data: bodies } = await c.from("lesson_contents").select("lesson_id");
    expect(lessons!.length).toBeGreaterThan(80);
    expect(bodies!.length).toBe(3);
  });

  it("quiz answers are never readable by students, even when enrolled", async () => {
    const c = await signedIn(DEMO.student1); // enrolled in Power BI Mastery
    const { data } = await c.from("quiz_questions").select("correct_index");
    expect(data).toEqual([]);
  });

  it("students cannot enrol themselves", async () => {
    const c = await signedIn(DEMO.student2);
    const { data: course } = await c
      .from("courses")
      .select("id")
      .eq("slug", "power-bi-mastery")
      .single();
    const { error } = await c
      .from("enrolments")
      .insert({ user_id: DEMO.student2.id, course_id: course!.id, source: "free" });
    expect(error?.code).toBe("42501");
  });

  it("anonymous users can't write site settings", async () => {
    const { data } = await anon()
      .from("site_settings")
      .update({ brand_name: "Hacked" })
      .eq("id", 1)
      .select();
    expect(data ?? []).toEqual([]);
  });
});
