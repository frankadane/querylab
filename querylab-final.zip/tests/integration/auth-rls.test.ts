import { afterAll, describe, expect, it } from "vitest";
import { DEMO, anon, service, signedIn } from "./helpers";

const created: string[] = [];
afterAll(async () => {
  const admin = service();
  for (const id of created) await admin.auth.admin.deleteUser(id);
});

describe("sign up", () => {
  it("creates a student profile and ignores a role in metadata", async () => {
    const email = `it-${Date.now()}@querylab.test`;
    const { data, error } = await anon().auth.signUp({
      email,
      password: "Integration-Test-1",
      options: {
        data: { full_name: "Integration User", role: "admin", timezone: "Europe/London" },
      },
    });
    expect(error).toBeNull();
    created.push(data.user!.id);

    const { data: profile } = await service()
      .from("profiles")
      .select("*")
      .eq("id", data.user!.id)
      .single();
    expect(profile).toMatchObject({
      role: "student",
      full_name: "Integration User",
      timezone: "Europe/London",
    });
  });

  it("requires email confirmation before password sign-in", async () => {
    const email = `unconfirmed-${Date.now()}@querylab.test`;
    const { data } = await anon().auth.signUp({ email, password: "Integration-Test-1" });
    created.push(data.user!.id);
    const { error } = await anon().auth.signInWithPassword({
      email,
      password: "Integration-Test-1",
    });
    expect(error?.code).toBe("email_not_confirmed");
  });

  it("enforces the server-side password policy", async () => {
    const { error } = await anon().auth.signUp({
      email: `weak-${Date.now()}@querylab.test`,
      password: "short",
    });
    expect(error?.code).toBe("weak_password");
  });
});

describe("profiles RLS through the API", () => {
  it("anonymous users read nothing", async () => {
    const { data } = await anon().from("profiles").select("id");
    expect(data).toEqual([]);
  });

  it("a student reads and edits only their own profile", async () => {
    const c = await signedIn(DEMO.student1);
    const { data } = await c.from("profiles").select("id");
    expect(data?.map((r) => r.id)).toEqual([DEMO.student1.id]);

    const { error } = await c.from("profiles").update({ bio: "Hello" }).eq("id", DEMO.student1.id);
    expect(error).toBeNull();

    const { data: other } = await c
      .from("profiles")
      .update({ bio: "x" })
      .eq("id", DEMO.student2.id)
      .select();
    expect(other).toEqual([]);
  });

  it("a student cannot escalate their role", async () => {
    const c = await signedIn(DEMO.student1);
    const { error } = await c.from("profiles").update({ role: "admin" }).eq("id", DEMO.student1.id);
    expect(error?.code).toBe("42501");
  });

  it("an instructor cannot change roles either", async () => {
    const c = await signedIn(DEMO.instructor);
    const { error } = await c
      .from("profiles")
      .update({ role: "admin" })
      .eq("id", DEMO.instructor.id);
    expect(error?.code).toBe("42501");
  });

  it("an admin can change another user's role, and it is audited", async () => {
    const c = await signedIn(DEMO.admin);
    const { error } = await c
      .from("profiles")
      .update({ role: "instructor" })
      .eq("id", DEMO.student2.id);
    expect(error).toBeNull();
    await c.rpc("write_audit", {
      p_action: "user.role_changed",
      p_target_type: "profile",
      p_target_id: DEMO.student2.id,
    });
    const { data: log } = await c
      .from("audit_log")
      .select("action, actor_id")
      .eq("target_id", DEMO.student2.id);
    expect(log?.at(-1)).toMatchObject({ action: "user.role_changed", actor_id: DEMO.admin.id });
    // restore
    await c.from("profiles").update({ role: "student" }).eq("id", DEMO.student2.id);
  });
});

describe("rate limiter", () => {
  it("is not callable by signed-in users", async () => {
    const c = await signedIn(DEMO.student1);
    const { error } = await c.rpc("check_rate_limit", {
      p_key: "x",
      p_max: 1,
      p_window_seconds: 60,
    });
    expect(error).not.toBeNull();
  });

  it("blocks after the limit with the service role", async () => {
    const s = service();
    const key = `test:${Date.now()}`;
    const results = [];
    for (let i = 0; i < 4; i++) {
      const { data } = await s.rpc("check_rate_limit", {
        p_key: key,
        p_max: 3,
        p_window_seconds: 600,
      });
      results.push(data);
    }
    expect(results).toEqual([true, true, true, false]);
  });
});

describe("avatars storage", () => {
  it("lets users write only inside their own folder", async () => {
    const c = await signedIn(DEMO.student1);
    const png = new Blob([new Uint8Array([137, 80, 78, 71])], { type: "image/png" });
    const own = await c.storage
      .from("avatars")
      .upload(`${DEMO.student1.id}/t-${Date.now()}.png`, png);
    expect(own.error).toBeNull();
    const other = await c.storage
      .from("avatars")
      .upload(`${DEMO.student2.id}/t-${Date.now()}.png`, png);
    expect(other.error).not.toBeNull();
    await c.storage.from("avatars").remove([own.data!.path]);
  });
});
