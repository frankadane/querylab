-- Fix: instructors creating a course got a permission error on
-- INSERT … RETURNING because "courses: staff read" re-looks the row up by id
-- (invisible within the same statement). Add a column-based read policy.
create policy "courses: instructor read own" on public.courses for select to authenticated
  using (instructor_id is not null and instructor_id = (select public.my_instructor_id()));
