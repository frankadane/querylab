-- Phase 6: blog/resources, editable pages, contact + corporate enquiries.

create type public.content_status as enum ('draft', 'published');
create type public.enquiry_kind as enum ('contact', 'corporate');
create type public.enquiry_status as enum ('new', 'in_progress', 'closed');

create table public.posts (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$' and char_length(slug) <= 100),
  title           text not null check (char_length(title) between 1 and 200),
  excerpt         text check (char_length(excerpt) <= 400),
  body_md         text not null default '' check (char_length(body_md) <= 100000),
  cover_url       text,
  cover_alt       text check (char_length(cover_alt) <= 200),
  tags            text[] not null default '{}',
  status          public.content_status not null default 'draft',
  published_at    timestamptz,
  author_id       uuid references public.profiles (id) on delete set null,
  seo_title       text check (char_length(seo_title) <= 70),
  seo_description text check (char_length(seo_description) <= 200),
  is_demo         boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index posts_published_idx on public.posts (status, published_at desc);

create table public.pages (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$' and char_length(slug) <= 100),
  title           text not null check (char_length(title) between 1 and 200),
  body_md         text not null default '' check (char_length(body_md) <= 100000),
  status          public.content_status not null default 'draft',
  seo_title       text check (char_length(seo_title) <= 70),
  seo_description text check (char_length(seo_description) <= 200),
  updated_by      uuid references public.profiles (id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create or replace function public.posts_before_write()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.status = 'published' and new.published_at is null then
    new.published_at := now();
  end if;
  new.updated_at := now();
  return new;
end;
$$;
create trigger posts_before_write before insert or update on public.posts for each row execute function public.posts_before_write();
create trigger pages_set_updated_at before update on public.pages for each row execute function public.set_updated_at();

create table public.enquiries (
  id         uuid primary key default gen_random_uuid(),
  kind       public.enquiry_kind not null,
  name       text not null check (char_length(name) between 1 and 120),
  email      text not null check (char_length(email) <= 254),
  company    text check (char_length(company) <= 160),
  team_size  text check (char_length(team_size) <= 40),
  topic      text check (char_length(topic) <= 120),
  message    text not null check (char_length(message) between 1 and 5000),
  status     public.enquiry_status not null default 'new',
  user_id    uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index enquiries_status_idx on public.enquiries (status, created_at desc);
create trigger enquiries_set_updated_at before update on public.enquiries for each row execute function public.set_updated_at();

alter table public.posts enable row level security;
alter table public.pages enable row level security;
alter table public.enquiries enable row level security;

create policy "posts: public read published" on public.posts for select to anon, authenticated using (status = 'published');
create policy "posts: staff read" on public.posts for select to authenticated using ((select public.is_staff()));
create policy "posts: admin write" on public.posts for all to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
-- Instructors may write and edit their own posts.
create policy "posts: author insert" on public.posts for insert to authenticated
  with check ((select public.is_staff()) and author_id = (select auth.uid()));
create policy "posts: author update" on public.posts for update to authenticated
  using ((select public.is_staff()) and author_id = (select auth.uid()))
  with check ((select public.is_staff()) and author_id = (select auth.uid()));

create policy "pages: public read published" on public.pages for select to anon, authenticated using (status = 'published');
create policy "pages: admin all" on public.pages for all to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));

-- Enquiries are inserted by the server (service role) after validation and
-- rate limiting; only admins can read or update them.
create policy "enquiries: admin read" on public.enquiries for select to authenticated using ((select public.is_admin()));
create policy "enquiries: admin update" on public.enquiries for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
revoke all on public.enquiries from anon;
