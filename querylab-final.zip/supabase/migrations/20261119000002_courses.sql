-- Phase 3: courses, curriculum, quizzes, enrolments, instructors, FAQs,
-- testimonials, site settings, course media storage.
--
-- Access model
--   anon/students : published course metadata + syllabus titles; lesson
--                   CONTENT only for free-preview lessons or active enrolments
--   instructors   : full access to courses where they are the instructor
--   admins        : everything
-- Quiz answers are never readable by students (graded server-side in Phase 5).

-- ---------------------------------------------------------------------------
-- Types
-- ---------------------------------------------------------------------------
create type public.course_status as enum ('draft', 'published', 'archived');
create type public.course_track as enum ('ai', 'data_science', 'power_bi');
create type public.course_level as enum ('beginner', 'intermediate', 'advanced');
create type public.course_format as enum ('self_paced', 'live_cohort', 'hybrid');
create type public.currency_code as enum ('GHS', 'USD');
create type public.lesson_type as enum ('video', 'article', 'file', 'quiz', 'live_session');
create type public.enrolment_status as enum ('active', 'revoked');
create type public.enrolment_source as enum ('free', 'order', 'manual', 'coupon');

-- ---------------------------------------------------------------------------
-- Instructors (public-facing profiles, optionally linked to a user account)
-- ---------------------------------------------------------------------------
create table public.instructors (
  id             uuid primary key default gen_random_uuid(),
  profile_id     uuid unique references public.profiles (id) on delete set null,
  slug           text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  display_name   text not null check (char_length(display_name) between 1 and 120),
  headline       text check (char_length(headline) <= 200),
  bio_md         text check (char_length(bio_md) <= 5000),
  photo_url      text,
  is_published   boolean not null default true,
  is_placeholder boolean not null default false,
  is_demo        boolean not null default false,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create trigger instructors_set_updated_at before update on public.instructors
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Courses
-- ---------------------------------------------------------------------------
create table public.courses (
  id             uuid primary key default gen_random_uuid(),
  slug           text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$' and char_length(slug) <= 100),
  title          text not null check (char_length(title) between 1 and 160),
  subtitle       text check (char_length(subtitle) <= 300),
  description_md text not null default '' check (char_length(description_md) <= 20000),
  outcomes       text[] not null default '{}',
  requirements   text[] not null default '{}',
  track          public.course_track not null,
  level_min      public.course_level not null default 'beginner',
  level_max      public.course_level not null default 'beginner',
  format         public.course_format not null default 'self_paced',
  duration_weeks smallint check (duration_weeks between 1 and 104),
  price_minor    integer not null default 0 check (price_minor >= 0),
  currency       public.currency_code not null default 'GHS',
  thumbnail_url  text,
  instructor_id  uuid references public.instructors (id) on delete set null,
  status         public.course_status not null default 'draft',
  published_at   timestamptz,
  is_demo        boolean not null default false,
  created_by     uuid references public.profiles (id) on delete set null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  search         tsvector generated always as (
    setweight(to_tsvector('english', coalesce(title, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(subtitle, '')), 'B') ||
    setweight(to_tsvector('english', coalesce(description_md, '')), 'C')
  ) stored,
  constraint courses_level_range check (level_min <= level_max)
);
comment on column public.courses.price_minor is 'Price in minor units (pesewas / cents). 0 = free.';

create index courses_status_idx on public.courses (status);
create index courses_track_idx on public.courses (track);
create index courses_instructor_idx on public.courses (instructor_id);
create index courses_search_idx on public.courses using gin (search);

create or replace function public.courses_before_write()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.status = 'published' and (tg_op = 'INSERT' or old.status is distinct from 'published') then
    new.published_at := coalesce(new.published_at, now());
  end if;
  new.updated_at := now();
  return new;
end;
$$;
create trigger courses_before_write before insert or update on public.courses
  for each row execute function public.courses_before_write();

-- ---------------------------------------------------------------------------
-- Curriculum
-- ---------------------------------------------------------------------------
create table public.sections (
  id          uuid primary key default gen_random_uuid(),
  course_id   uuid not null references public.courses (id) on delete cascade,
  title       text not null check (char_length(title) between 1 and 200),
  description text check (char_length(description) <= 1000),
  position    integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index sections_course_idx on public.sections (course_id, position);
create trigger sections_set_updated_at before update on public.sections
  for each row execute function public.set_updated_at();

-- Lesson metadata (titles, type, duration) is public for published courses
-- so the syllabus can be shown. The body lives in lesson_contents.
create table public.lessons (
  id               uuid primary key default gen_random_uuid(),
  section_id       uuid not null references public.sections (id) on delete cascade,
  course_id        uuid not null references public.courses (id) on delete cascade,
  title            text not null check (char_length(title) between 1 and 200),
  summary          text check (char_length(summary) <= 1000),
  type             public.lesson_type not null default 'video',
  duration_minutes smallint check (duration_minutes between 0 and 1440),
  is_free_preview  boolean not null default false,
  position         integer not null default 0,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index lessons_section_idx on public.lessons (section_id, position);
create index lessons_course_idx on public.lessons (course_id);
create trigger lessons_set_updated_at before update on public.lessons
  for each row execute function public.set_updated_at();

-- Keep lessons.course_id consistent with its section.
create or replace function public.lessons_sync_course()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  select s.course_id into new.course_id from public.sections s where s.id = new.section_id;
  return new;
end;
$$;
create trigger lessons_sync_course before insert or update of section_id on public.lessons
  for each row execute function public.lessons_sync_course();

create table public.lesson_contents (
  lesson_id  uuid primary key references public.lessons (id) on delete cascade,
  course_id  uuid not null references public.courses (id) on delete cascade,
  body_md    text not null default '' check (char_length(body_md) <= 100000),
  video_url  text check (video_url is null or video_url ~ '^https://'),
  file_path  text check (char_length(file_path) <= 500),
  updated_at timestamptz not null default now()
);
create index lesson_contents_course_idx on public.lesson_contents (course_id);
create trigger lesson_contents_set_updated_at before update on public.lesson_contents
  for each row execute function public.set_updated_at();

create or replace function public.lesson_contents_sync_course()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  select l.course_id into new.course_id from public.lessons l where l.id = new.lesson_id;
  return new;
end;
$$;
create trigger lesson_contents_sync_course before insert or update of lesson_id on public.lesson_contents
  for each row execute function public.lesson_contents_sync_course();

-- ---------------------------------------------------------------------------
-- Quizzes (answers hidden from students)
-- ---------------------------------------------------------------------------
create table public.quizzes (
  id         uuid primary key default gen_random_uuid(),
  lesson_id  uuid not null unique references public.lessons (id) on delete cascade,
  course_id  uuid not null references public.courses (id) on delete cascade,
  pass_mark  smallint not null default 70 check (pass_mark between 0 and 100),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index quizzes_course_idx on public.quizzes (course_id);
create trigger quizzes_set_updated_at before update on public.quizzes
  for each row execute function public.set_updated_at();

create or replace function public.quizzes_sync_course()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  select l.course_id into new.course_id from public.lessons l where l.id = new.lesson_id;
  return new;
end;
$$;
create trigger quizzes_sync_course before insert or update of lesson_id on public.quizzes
  for each row execute function public.quizzes_sync_course();

create table public.quiz_questions (
  id            uuid primary key default gen_random_uuid(),
  quiz_id       uuid not null references public.quizzes (id) on delete cascade,
  prompt        text not null check (char_length(prompt) between 1 and 1000),
  options       jsonb not null check (jsonb_typeof(options) = 'array' and jsonb_array_length(options) between 2 and 6),
  correct_index smallint not null check (correct_index >= 0),
  explanation   text check (char_length(explanation) <= 1000),
  position      integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  constraint quiz_questions_correct_in_range check (correct_index < jsonb_array_length(options))
);
create index quiz_questions_quiz_idx on public.quiz_questions (quiz_id, position);
create trigger quiz_questions_set_updated_at before update on public.quiz_questions
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Enrolments (written by trusted server code: payments, admin, free enrol)
-- ---------------------------------------------------------------------------
create table public.enrolments (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  course_id  uuid not null references public.courses (id) on delete cascade,
  status     public.enrolment_status not null default 'active',
  source     public.enrolment_source not null,
  order_id   uuid,  -- FK added in Phase 6 (orders)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, course_id)
);
create index enrolments_course_idx on public.enrolments (course_id);
create trigger enrolments_set_updated_at before update on public.enrolments
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- FAQs, testimonials, site settings
-- ---------------------------------------------------------------------------
create table public.faqs (
  id           uuid primary key default gen_random_uuid(),
  course_id    uuid references public.courses (id) on delete cascade, -- null = site-wide FAQ
  question     text not null check (char_length(question) between 1 and 300),
  answer_md    text not null check (char_length(answer_md) between 1 and 5000),
  position     integer not null default 0,
  is_published boolean not null default true,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index faqs_course_idx on public.faqs (course_id, position);
create trigger faqs_set_updated_at before update on public.faqs
  for each row execute function public.set_updated_at();

create table public.testimonials (
  id             uuid primary key default gen_random_uuid(),
  course_id      uuid references public.courses (id) on delete set null,
  quote          text not null check (char_length(quote) between 1 and 1000),
  author_name    text not null check (char_length(author_name) between 1 and 120),
  author_title   text check (char_length(author_title) <= 160),
  is_published   boolean not null default false,
  position       integer not null default 0,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
comment on table public.testimonials is 'Real testimonials only. Publish only with the author''s consent.';
create trigger testimonials_set_updated_at before update on public.testimonials
  for each row execute function public.set_updated_at();

create table public.site_settings (
  id               smallint primary key default 1 check (id = 1),
  brand_name       text not null default 'QueryLab',
  contact_email    text not null default 'querylab@gmail.com',
  contact_phone    text,
  address          text,
  default_currency public.currency_code not null default 'GHS',
  default_timezone text not null default 'Africa/Accra' check (public.is_valid_timezone(default_timezone)),
  bank_details     jsonb not null default '{}'::jsonb,
  social_links     jsonb not null default '{}'::jsonb,
  updated_at       timestamptz not null default now()
);
comment on column public.site_settings.bank_details is
  'Shown to buyers at bank-transfer checkout: {account_name, bank_name, account_number, branch, swift, iban, instructions}.';
create trigger site_settings_set_updated_at before update on public.site_settings
  for each row execute function public.set_updated_at();
insert into public.site_settings (id) values (1);

-- ---------------------------------------------------------------------------
-- Access helpers
-- ---------------------------------------------------------------------------
create or replace function public.is_course_staff(p_course_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.is_admin() or exists (
    select 1
    from public.courses c
    join public.instructors i on i.id = c.instructor_id
    join public.profiles p on p.id = i.profile_id
    where c.id = p_course_id and p.id = auth.uid() and p.suspended_at is null and p.role in ('instructor', 'admin')
  );
$$;

create or replace function public.is_course_published(p_course_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (select 1 from public.courses where id = p_course_id and status = 'published');
$$;

create or replace function public.is_enrolled(p_course_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.enrolments e
    join public.profiles p on p.id = e.user_id
    where e.course_id = p_course_id and e.user_id = auth.uid()
      and e.status = 'active' and p.suspended_at is null
  );
$$;

-- The instructor row (if any) linked to the current user.
create or replace function public.my_instructor_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select i.id from public.instructors i
  join public.profiles p on p.id = i.profile_id
  where p.id = auth.uid() and p.role in ('instructor', 'admin') and p.suspended_at is null;
$$;

grant execute on function public.is_course_published(uuid) to anon, authenticated;
revoke execute on function public.is_course_staff(uuid) from public, anon;
revoke execute on function public.is_enrolled(uuid) from public, anon;
revoke execute on function public.my_instructor_id() from public, anon;
grant execute on function public.is_course_staff(uuid) to authenticated;
grant execute on function public.is_enrolled(uuid) to authenticated;
grant execute on function public.my_instructor_id() to authenticated;

-- ---------------------------------------------------------------------------
-- RLS
-- ---------------------------------------------------------------------------
alter table public.instructors enable row level security;
alter table public.courses enable row level security;
alter table public.sections enable row level security;
alter table public.lessons enable row level security;
alter table public.lesson_contents enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.enrolments enable row level security;
alter table public.faqs enable row level security;
alter table public.testimonials enable row level security;
alter table public.site_settings enable row level security;

-- instructors
create policy "instructors: public read published" on public.instructors for select
  to anon, authenticated using (is_published);
create policy "instructors: admin + self read" on public.instructors for select
  to authenticated using ((select public.is_admin()) or profile_id = (select auth.uid()));
create policy "instructors: admin write" on public.instructors for all
  to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
create policy "instructors: self update" on public.instructors for update
  to authenticated using (profile_id = (select auth.uid())) with check (profile_id = (select auth.uid()));

-- Instructors may edit their own bio/photo but not relink or (un)publish themselves.
create or replace function public.instructors_guard()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if current_user = 'authenticated' and not public.is_admin() then
    if new.profile_id is distinct from old.profile_id or new.slug is distinct from old.slug
       or new.is_published is distinct from old.is_published
       or new.is_placeholder is distinct from old.is_placeholder or new.is_demo is distinct from old.is_demo then
      raise exception 'Not allowed to change protected instructor fields' using errcode = '42501';
    end if;
  end if;
  return new;
end;
$$;
create trigger instructors_guard before update on public.instructors
  for each row execute function public.instructors_guard();

-- courses
create policy "courses: public read published" on public.courses for select
  to anon, authenticated using (status = 'published');
create policy "courses: staff read" on public.courses for select
  to authenticated using ((select public.is_course_staff(id)));
create policy "courses: enrolled read" on public.courses for select
  to authenticated using ((select public.is_enrolled(id)));
create policy "courses: admin insert" on public.courses for insert
  to authenticated with check ((select public.is_admin()));
create policy "courses: instructor insert own" on public.courses for insert
  to authenticated with check (
    (select public.is_staff()) and instructor_id = (select public.my_instructor_id())
  );
create policy "courses: staff update" on public.courses for update
  to authenticated using ((select public.is_course_staff(id))) with check ((select public.is_course_staff(id)));
create policy "courses: admin delete" on public.courses for delete
  to authenticated using ((select public.is_admin()));

-- Only admins may reassign a course to another instructor.
create or replace function public.courses_guard()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if current_user = 'authenticated' and not public.is_admin()
     and (new.instructor_id is distinct from old.instructor_id or new.is_demo is distinct from old.is_demo) then
    raise exception 'Only admins can change the course instructor' using errcode = '42501';
  end if;
  return new;
end;
$$;
create trigger courses_guard before update on public.courses
  for each row execute function public.courses_guard();

-- sections + lessons: readable with the course; writable by course staff
create policy "sections: read with course" on public.sections for select
  to anon, authenticated using ((select public.is_course_published(course_id)));
create policy "sections: staff/enrolled read" on public.sections for select
  to authenticated using ((select public.is_course_staff(course_id)) or (select public.is_enrolled(course_id)));
create policy "sections: staff write" on public.sections for all
  to authenticated using ((select public.is_course_staff(course_id))) with check ((select public.is_course_staff(course_id)));

create policy "lessons: read with course" on public.lessons for select
  to anon, authenticated using ((select public.is_course_published(course_id)));
create policy "lessons: staff/enrolled read" on public.lessons for select
  to authenticated using ((select public.is_course_staff(course_id)) or (select public.is_enrolled(course_id)));
create policy "lessons: staff write" on public.lessons for all
  to authenticated using ((select public.is_course_staff(course_id))) with check ((select public.is_course_staff(course_id)));

-- lesson content: free previews of published courses, enrolled students, staff
create policy "lesson_contents: free preview" on public.lesson_contents for select
  to anon, authenticated using (
    (select public.is_course_published(course_id))
    and exists (select 1 from public.lessons l where l.id = lesson_id and l.is_free_preview)
  );
create policy "lesson_contents: enrolled read" on public.lesson_contents for select
  to authenticated using ((select public.is_enrolled(course_id)) and (select public.is_course_published(course_id)));
create policy "lesson_contents: staff all" on public.lesson_contents for all
  to authenticated using ((select public.is_course_staff(course_id))) with check ((select public.is_course_staff(course_id)));

-- quizzes: staff only (students get questions without answers via server code)
create policy "quizzes: staff all" on public.quizzes for all
  to authenticated using ((select public.is_course_staff(course_id))) with check ((select public.is_course_staff(course_id)));
create policy "quiz_questions: staff all" on public.quiz_questions for all
  to authenticated
  using (exists (select 1 from public.quizzes q where q.id = quiz_id and public.is_course_staff(q.course_id)))
  with check (exists (select 1 from public.quizzes q where q.id = quiz_id and public.is_course_staff(q.course_id)));

-- enrolments: students read their own; staff read their course's; admins write
create policy "enrolments: own read" on public.enrolments for select
  to authenticated using (user_id = (select auth.uid()));
create policy "enrolments: staff read" on public.enrolments for select
  to authenticated using ((select public.is_course_staff(course_id)));
create policy "enrolments: admin write" on public.enrolments for all
  to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));

-- faqs
create policy "faqs: public read" on public.faqs for select
  to anon, authenticated using (
    is_published and (course_id is null or (select public.is_course_published(course_id)))
  );
create policy "faqs: staff read" on public.faqs for select
  to authenticated using ((select public.is_admin()) or (course_id is not null and (select public.is_course_staff(course_id))));
create policy "faqs: admin write site faqs" on public.faqs for all
  to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
create policy "faqs: staff write course faqs" on public.faqs for all
  to authenticated
  using (course_id is not null and (select public.is_course_staff(course_id)))
  with check (course_id is not null and (select public.is_course_staff(course_id)));

-- testimonials
create policy "testimonials: public read published" on public.testimonials for select
  to anon, authenticated using (is_published);
create policy "testimonials: admin all" on public.testimonials for all
  to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));

-- site settings: public read (bank details are shown to every buyer anyway), admin update
create policy "site_settings: public read" on public.site_settings for select
  to anon, authenticated using (true);
create policy "site_settings: admin update" on public.site_settings for update
  to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));

-- ---------------------------------------------------------------------------
-- Profiles: instructors can see the students enrolled in their courses
-- ---------------------------------------------------------------------------
create policy "profiles: course staff read students" on public.profiles for select
  to authenticated using (
    exists (
      select 1 from public.enrolments e
      where e.user_id = profiles.id and public.is_course_staff(e.course_id)
    )
  );

-- ---------------------------------------------------------------------------
-- Course media bucket (thumbnails, instructor photos): public read, staff write
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('course-media', 'course-media', true, 5242880, array['image/png', 'image/jpeg', 'image/webp'])
on conflict (id) do nothing;

create policy "course-media: staff insert" on storage.objects for insert
  to authenticated with check (bucket_id = 'course-media' and (select public.is_staff()));
create policy "course-media: staff update" on storage.objects for update
  to authenticated using (bucket_id = 'course-media' and (select public.is_staff()));
create policy "course-media: admin delete" on storage.objects for delete
  to authenticated using (bucket_id = 'course-media' and (select public.is_admin()));

-- ---------------------------------------------------------------------------
-- Reordering helpers (atomic, staff-checked)
-- ---------------------------------------------------------------------------
create or replace function public.reorder_sections(p_course_id uuid, p_ids uuid[])
returns void
language plpgsql
security invoker
set search_path = ''
as $$
begin
  update public.sections s
     set position = x.ord
    from unnest(p_ids) with ordinality as x(id, ord)
   where s.id = x.id and s.course_id = p_course_id;
end;
$$;

-- Moves lessons between sections too: p_ids is the full ordered list for p_section_id.
create or replace function public.reorder_lessons(p_section_id uuid, p_ids uuid[])
returns void
language plpgsql
security invoker
set search_path = ''
as $$
declare
  target_course uuid;
begin
  select course_id into target_course from public.sections where id = p_section_id;
  update public.lessons l
     set section_id = p_section_id, position = x.ord
    from unnest(p_ids) with ordinality as x(id, ord)
   where l.id = x.id and l.course_id = target_course;
end;
$$;

revoke execute on function public.reorder_sections(uuid, uuid[]) from public, anon;
revoke execute on function public.reorder_lessons(uuid, uuid[]) from public, anon;
grant execute on function public.reorder_sections(uuid, uuid[]) to authenticated;
grant execute on function public.reorder_lessons(uuid, uuid[]) to authenticated;

-- ---------------------------------------------------------------------------
-- Lesson files (private). Path convention: {course_id}/{lesson_id}/{filename}
-- Staff of the course upload; students get short-lived signed URLs from the
-- server after an enrolment check (Phase 5).
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit)
values ('lesson-files', 'lesson-files', false, 52428800)
on conflict (id) do nothing;

create policy "lesson-files: course staff read" on storage.objects for select
  to authenticated using (bucket_id = 'lesson-files' and (select public.is_course_staff(((storage.foldername(name))[1])::uuid)));
create policy "lesson-files: course staff insert" on storage.objects for insert
  to authenticated with check (bucket_id = 'lesson-files' and (select public.is_course_staff(((storage.foldername(name))[1])::uuid)));
create policy "lesson-files: course staff update" on storage.objects for update
  to authenticated using (bucket_id = 'lesson-files' and (select public.is_course_staff(((storage.foldername(name))[1])::uuid)));
create policy "lesson-files: course staff delete" on storage.objects for delete
  to authenticated using (bucket_id = 'lesson-files' and (select public.is_course_staff(((storage.foldername(name))[1])::uuid)));
