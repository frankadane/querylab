-- Phase 4: live classes. Sessions, weekly series, registrations with a
-- waitlist, private join links, attendance, reminders and notifications.
--
-- Times are stored in UTC (timestamptz). `timezone` records the zone the
-- session was planned in (used for recurrence and for staff display).
-- Registration, cancellation and waitlist promotion happen in SECURITY
-- DEFINER functions that lock the session row, so concurrent sign-ups can
-- never exceed capacity.

create type public.session_status as enum ('scheduled', 'live', 'completed', 'cancelled');
create type public.registration_status as enum ('registered', 'waitlist', 'cancelled', 'attended');

-- ---------------------------------------------------------------------------
-- Series (weekly recurrence template)
-- ---------------------------------------------------------------------------
create table public.session_series (
  id               uuid primary key default gen_random_uuid(),
  course_id        uuid references public.courses (id) on delete cascade,
  title            text not null check (char_length(title) between 1 and 200),
  timezone         text not null default 'Africa/Accra' check (public.is_valid_timezone(timezone)),
  interval_weeks   smallint not null default 1 check (interval_weeks between 1 and 4),
  occurrences      smallint not null check (occurrences between 1 and 52),
  created_by       uuid references public.profiles (id) on delete set null,
  created_at       timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Sessions
-- ---------------------------------------------------------------------------
create table public.live_sessions (
  id                   uuid primary key default gen_random_uuid(),
  course_id            uuid references public.courses (id) on delete cascade, -- null = open to every signed-in user
  series_id            uuid references public.session_series (id) on delete set null,
  lesson_id            uuid references public.lessons (id) on delete set null, -- optional "live session" lesson it belongs to
  title                text not null check (char_length(title) between 1 and 200),
  description_md       text not null default '' check (char_length(description_md) <= 10000),
  starts_at            timestamptz not null,
  ends_at              timestamptz not null,
  timezone             text not null default 'Africa/Accra' check (public.is_valid_timezone(timezone)),
  capacity             integer not null default 25 check (capacity between 1 and 10000),
  instructor_id        uuid references public.profiles (id) on delete set null,
  status               public.session_status not null default 'scheduled',
  cancel_reason        text check (char_length(cancel_reason) <= 500),
  recording_url        text check (recording_url is null or recording_url ~ '^https://'),
  materials_md         text check (char_length(materials_md) <= 20000),
  reminder_24h_sent_at timestamptz,
  reminder_1h_sent_at  timestamptz,
  is_demo              boolean not null default false,
  created_by           uuid references public.profiles (id) on delete set null,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  constraint live_sessions_time_order check (ends_at > starts_at),
  constraint live_sessions_max_length check (ends_at - starts_at <= interval '12 hours')
);
create index live_sessions_starts_idx on public.live_sessions (starts_at);
create index live_sessions_course_idx on public.live_sessions (course_id, starts_at);
create index live_sessions_series_idx on public.live_sessions (series_id);
create index live_sessions_reminders_idx on public.live_sessions (starts_at)
  where status = 'scheduled' and (reminder_24h_sent_at is null or reminder_1h_sent_at is null);
create trigger live_sessions_set_updated_at before update on public.live_sessions
  for each row execute function public.set_updated_at();

-- Rescheduling clears reminder flags so new reminders go out.
create or replace function public.live_sessions_reschedule()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.starts_at is distinct from old.starts_at then
    new.reminder_24h_sent_at := null;
    new.reminder_1h_sent_at := null;
  end if;
  return new;
end;
$$;
create trigger live_sessions_reschedule before update on public.live_sessions
  for each row execute function public.live_sessions_reschedule();

-- Join links live in their own table so they can never leak through a
-- public SELECT on live_sessions. Students get them via get_join_url().
create table public.live_session_links (
  session_id uuid primary key references public.live_sessions (id) on delete cascade,
  join_url   text not null check (join_url ~ '^https://' and char_length(join_url) <= 1000),
  updated_at timestamptz not null default now()
);
create trigger live_session_links_set_updated_at before update on public.live_session_links
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Registrations
-- ---------------------------------------------------------------------------
create table public.session_registrations (
  id            uuid primary key default gen_random_uuid(),
  session_id    uuid not null references public.live_sessions (id) on delete cascade,
  user_id       uuid not null references public.profiles (id) on delete cascade,
  status        public.registration_status not null,
  waitlisted_at timestamptz,
  attended_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (session_id, user_id)
);
create index session_registrations_session_idx on public.session_registrations (session_id, status);
create index session_registrations_user_idx on public.session_registrations (user_id, status);
create index session_registrations_waitlist_idx on public.session_registrations (session_id, waitlisted_at)
  where status = 'waitlist';
create trigger session_registrations_set_updated_at before update on public.session_registrations
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Notifications (in-app inbox; emails are sent by the server)
-- ---------------------------------------------------------------------------
create table public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  type       text not null check (char_length(type) <= 60),
  title      text not null check (char_length(title) <= 200),
  body       text check (char_length(body) <= 2000),
  link       text check (link is null or link ~ '^/'),
  read_at    timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
create or replace function public.is_session_staff(p_session_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.live_sessions s
    where s.id = p_session_id
      and (
        public.is_admin()
        or (s.course_id is not null and public.is_course_staff(s.course_id))
        or (s.instructor_id = auth.uid() and public.is_staff())
      )
  );
$$;

-- Who may sign up: active enrolment in the course, any signed-in user for
-- open sessions (course_id null), or staff.
create or replace function public.can_register(p_session_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.live_sessions s
    join public.profiles p on p.id = auth.uid() and p.suspended_at is null
    where s.id = p_session_id
      and (s.course_id is null or public.is_enrolled(s.course_id) or public.is_session_staff(s.id))
  );
$$;

create or replace function public.is_session_visible(p_session_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.live_sessions s
    left join public.courses c on c.id = s.course_id
    where s.id = p_session_id and (s.course_id is null or c.status = 'published')
  );
$$;

revoke execute on function public.is_session_staff(uuid) from public, anon;
revoke execute on function public.can_register(uuid) from public, anon;
grant execute on function public.is_session_staff(uuid) to authenticated;
grant execute on function public.can_register(uuid) to authenticated;
grant execute on function public.is_session_visible(uuid) to anon, authenticated;

-- Places taken / waitlist length for any visible sessions (no personal data).
create or replace function public.session_availability(p_session_ids uuid[])
returns table (session_id uuid, registered integer, waitlisted integer)
language sql
stable
security definer
set search_path = ''
as $$
  select s.id,
         count(r.id) filter (where r.status in ('registered', 'attended'))::int,
         count(r.id) filter (where r.status = 'waitlist')::int
  from public.live_sessions s
  left join public.session_registrations r on r.session_id = s.id
  where s.id = any (p_session_ids) and public.is_session_visible(s.id)
  group by s.id;
$$;
grant execute on function public.session_availability(uuid[]) to anon, authenticated;

-- Join link: staff any time; registered attendees from 15 minutes before
-- the start until the end. Returns null otherwise.
create or replace function public.get_join_url(p_session_id uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select l.join_url
  from public.live_sessions s
  join public.live_session_links l on l.session_id = s.id
  where s.id = p_session_id
    and (
      public.is_session_staff(s.id)
      or (
        s.status in ('scheduled', 'live')
        and now() >= s.starts_at - interval '15 minutes'
        and now() <= s.ends_at
        and exists (
          select 1 from public.session_registrations r
          join public.profiles p on p.id = r.user_id and p.suspended_at is null
          where r.session_id = s.id and r.user_id = auth.uid() and r.status in ('registered', 'attended')
        )
      )
    );
$$;
revoke execute on function public.get_join_url(uuid) from public, anon;
grant execute on function public.get_join_url(uuid) to authenticated;

-- ---------------------------------------------------------------------------
-- Registration state machine
-- ---------------------------------------------------------------------------

-- Returns the resulting status: 'registered' or 'waitlist'.
create or replace function public.register_for_session(p_session_id uuid)
returns public.registration_status
language plpgsql
security definer
set search_path = ''
as $$
declare
  s public.live_sessions;
  taken integer;
  existing public.session_registrations;
  result public.registration_status;
begin
  if auth.uid() is null then
    raise exception 'Sign in to register' using errcode = '42501';
  end if;

  -- Serialise sign-ups for this session.
  select * into s from public.live_sessions where id = p_session_id for update;
  if not found or not public.is_session_visible(p_session_id) then
    raise exception 'Session not found' using errcode = 'P0002';
  end if;
  if s.status <> 'scheduled' or s.starts_at <= now() then
    raise exception 'Registration is closed for this session' using errcode = 'P0001';
  end if;
  if not public.can_register(p_session_id) then
    raise exception 'Enrol in the course to register for this session' using errcode = '42501';
  end if;

  select * into existing from public.session_registrations
   where session_id = p_session_id and user_id = auth.uid();
  if found and existing.status in ('registered', 'waitlist', 'attended') then
    return existing.status;
  end if;

  select count(*) into taken from public.session_registrations
   where session_id = p_session_id and status in ('registered', 'attended');
  result := case when taken < s.capacity then 'registered' else 'waitlist' end;

  insert into public.session_registrations (session_id, user_id, status, waitlisted_at)
  values (p_session_id, auth.uid(), result, case when result = 'waitlist' then now() end)
  on conflict (session_id, user_id) do update
    set status = excluded.status, waitlisted_at = excluded.waitlisted_at, attended_at = null;

  return result;
end;
$$;

-- Fills free places from the waitlist (oldest first). Returns promoted
-- registration ids. Caller must already hold the session row lock.
create or replace function public.fill_from_waitlist(p_session_id uuid)
returns setof uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  s public.live_sessions;
  free integer;
  next_id uuid;
begin
  select * into s from public.live_sessions where id = p_session_id;
  if s.status <> 'scheduled' then
    return;
  end if;
  select s.capacity - count(*) into free from public.session_registrations
   where session_id = p_session_id and status in ('registered', 'attended');

  for next_id in
    select id from public.session_registrations
     where session_id = p_session_id and status = 'waitlist'
     order by waitlisted_at, created_at
     limit greatest(free, 0)
  loop
    update public.session_registrations set status = 'registered', waitlisted_at = null where id = next_id;
    return next next_id;
  end loop;
end;
$$;
revoke execute on function public.fill_from_waitlist(uuid) from public, anon, authenticated;

-- Cancels the caller's registration. Returns ids of anyone promoted from the waitlist.
create or replace function public.cancel_registration(p_session_id uuid)
returns setof uuid
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'Sign in first' using errcode = '42501';
  end if;
  perform 1 from public.live_sessions where id = p_session_id for update;

  update public.session_registrations
     set status = 'cancelled', waitlisted_at = null
   where session_id = p_session_id and user_id = auth.uid() and status in ('registered', 'waitlist');

  return query select * from public.fill_from_waitlist(p_session_id);
end;
$$;

-- Staff: re-run promotion after raising capacity.
create or replace function public.promote_waitlist(p_session_id uuid)
returns setof uuid
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_session_staff(p_session_id) then
    raise exception 'Not allowed' using errcode = '42501';
  end if;
  perform 1 from public.live_sessions where id = p_session_id for update;
  return query select * from public.fill_from_waitlist(p_session_id);
end;
$$;

-- Staff: mark attendance for registrations of one session.
create or replace function public.set_attendance(p_session_id uuid, p_user_ids uuid[], p_attended boolean)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  n integer;
begin
  if not public.is_session_staff(p_session_id) then
    raise exception 'Not allowed' using errcode = '42501';
  end if;
  update public.session_registrations
     set status = case when p_attended then 'attended' else 'registered' end::public.registration_status,
         attended_at = case when p_attended then coalesce(attended_at, now()) end
   where session_id = p_session_id and user_id = any (p_user_ids)
     and status in ('registered', 'attended');
  get diagnostics n = row_count;
  return n;
end;
$$;

revoke execute on function public.register_for_session(uuid) from public, anon;
revoke execute on function public.cancel_registration(uuid) from public, anon;
revoke execute on function public.promote_waitlist(uuid) from public, anon;
revoke execute on function public.set_attendance(uuid, uuid[], boolean) from public, anon;
grant execute on function public.register_for_session(uuid) to authenticated;
grant execute on function public.cancel_registration(uuid) to authenticated;
grant execute on function public.promote_waitlist(uuid) to authenticated;
grant execute on function public.set_attendance(uuid, uuid[], boolean) to authenticated;

-- ---------------------------------------------------------------------------
-- RLS
-- ---------------------------------------------------------------------------
alter table public.session_series enable row level security;
alter table public.live_sessions enable row level security;
alter table public.live_session_links enable row level security;
alter table public.session_registrations enable row level security;
alter table public.notifications enable row level security;

-- Who may create/edit a session row (used by several policies).
create or replace function public.can_manage_session_row(p_course_id uuid, p_instructor_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.is_admin()
      or (p_course_id is not null and public.is_course_staff(p_course_id))
      or (p_course_id is null and p_instructor_id = auth.uid() and public.is_staff());
$$;
revoke execute on function public.can_manage_session_row(uuid, uuid) from public, anon;
grant execute on function public.can_manage_session_row(uuid, uuid) to authenticated;

create policy "session_series: staff" on public.session_series for all to authenticated
  using ((select public.is_admin()) or (course_id is not null and (select public.is_course_staff(course_id))) or created_by = (select auth.uid()))
  with check ((select public.is_staff()) and ((select public.is_admin()) or (course_id is not null and (select public.is_course_staff(course_id))) or course_id is null));

-- Read policies use the row's own columns (not a re-lookup by id), so the
-- creator can see a row in INSERT … RETURNING within the same statement.
create policy "live_sessions: public read" on public.live_sessions for select to anon, authenticated
  using (course_id is null or (select public.is_course_published(course_id)));
create policy "live_sessions: staff read" on public.live_sessions for select to authenticated
  using ((select public.can_manage_session_row(course_id, instructor_id)));
create policy "live_sessions: staff insert" on public.live_sessions for insert to authenticated
  with check ((select public.can_manage_session_row(course_id, instructor_id)));
create policy "live_sessions: staff update" on public.live_sessions for update to authenticated
  using ((select public.can_manage_session_row(course_id, instructor_id)))
  with check ((select public.can_manage_session_row(course_id, instructor_id)));
create policy "live_sessions: admin delete" on public.live_sessions for delete to authenticated
  using ((select public.is_admin()));

create policy "live_session_links: staff" on public.live_session_links for all to authenticated
  using ((select public.is_session_staff(session_id)))
  with check ((select public.is_session_staff(session_id)));

-- Registrations: read own; staff read their sessions'. All writes go through
-- the functions above (or the service role).
create policy "registrations: own read" on public.session_registrations for select to authenticated
  using (user_id = (select auth.uid()));
create policy "registrations: staff read" on public.session_registrations for select to authenticated
  using ((select public.is_session_staff(session_id)));

-- Session staff can see the profiles of people registered for their sessions.
create policy "profiles: session staff read attendees" on public.profiles for select to authenticated
  using (exists (
    select 1 from public.session_registrations r
    where r.user_id = profiles.id and public.is_session_staff(r.session_id)
  ));

create policy "notifications: own read" on public.notifications for select to authenticated
  using (user_id = (select auth.uid()));
create policy "notifications: own mark read" on public.notifications for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Users may only flip read_at on their notifications.
create or replace function public.notifications_guard()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if current_user = 'authenticated' and (
       new.user_id is distinct from old.user_id or new.type is distinct from old.type
       or new.title is distinct from old.title or new.body is distinct from old.body
       or new.link is distinct from old.link) then
    raise exception 'Only read status can be changed' using errcode = '42501';
  end if;
  return new;
end;
$$;
create trigger notifications_guard before update on public.notifications
  for each row execute function public.notifications_guard();

-- Belt and braces: anonymous users have no access at all to join links.
revoke all on public.live_session_links from anon;
