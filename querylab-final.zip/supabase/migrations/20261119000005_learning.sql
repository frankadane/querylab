-- Phase 5: learning experience. Free enrolment, lesson progress, quizzes
-- (graded in the database; answers never sent before submission),
-- attendance → progress, certificates with public verification.
--
-- Certificate rule: every lesson that is NOT a live session is complete
-- (quiz lessons complete only by passing). Live-session lessons count
-- towards progress when attended but are not required.

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
create table public.lesson_progress (
  user_id      uuid not null references public.profiles (id) on delete cascade,
  lesson_id    uuid not null references public.lessons (id) on delete cascade,
  course_id    uuid not null references public.courses (id) on delete cascade,
  completed_at timestamptz not null default now(),
  source       text not null default 'manual' check (source in ('manual', 'quiz', 'attendance')),
  primary key (user_id, lesson_id)
);
create index lesson_progress_course_idx on public.lesson_progress (user_id, course_id);

create table public.quiz_attempts (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  quiz_id    uuid not null references public.quizzes (id) on delete cascade,
  lesson_id  uuid not null references public.lessons (id) on delete cascade,
  course_id  uuid not null references public.courses (id) on delete cascade,
  answers    jsonb not null,
  score      smallint not null check (score between 0 and 100),
  passed     boolean not null,
  created_at timestamptz not null default now()
);
create index quiz_attempts_user_idx on public.quiz_attempts (user_id, lesson_id, created_at desc);

create table public.certificates (
  id          uuid primary key default gen_random_uuid(),
  serial      text not null unique check (serial ~ '^QL-[0-9]{4}-[A-Z0-9]{8}$'),
  user_id     uuid not null references public.profiles (id) on delete cascade,
  course_id   uuid not null references public.courses (id) on delete cascade,
  -- Snapshot so the certificate stays accurate if names/titles change later.
  holder_name text not null,
  course_title text not null,
  issued_at   timestamptz not null default now(),
  unique (user_id, course_id)
);

alter table public.lesson_progress enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.certificates enable row level security;

-- Own data, plus course staff for their courses. All writes go through functions.
create policy "lesson_progress: own read" on public.lesson_progress for select to authenticated
  using (user_id = (select auth.uid()));
create policy "lesson_progress: staff read" on public.lesson_progress for select to authenticated
  using ((select public.is_course_staff(course_id)));
create policy "quiz_attempts: own read" on public.quiz_attempts for select to authenticated
  using (user_id = (select auth.uid()));
create policy "quiz_attempts: staff read" on public.quiz_attempts for select to authenticated
  using ((select public.is_course_staff(course_id)));
create policy "certificates: own read" on public.certificates for select to authenticated
  using (user_id = (select auth.uid()));
create policy "certificates: admin read" on public.certificates for select to authenticated
  using ((select public.is_admin()));

-- ---------------------------------------------------------------------------
-- Enrolment (free courses)
-- ---------------------------------------------------------------------------
create or replace function public.enrol_free(p_course_id uuid)
returns public.enrolment_status
language plpgsql
security definer
set search_path = ''
as $$
declare
  c public.courses;
  e public.enrolments;
begin
  if auth.uid() is null then
    raise exception 'Sign in to enrol' using errcode = '42501';
  end if;
  if exists (select 1 from public.profiles where id = auth.uid() and suspended_at is not null) then
    raise exception 'Account suspended' using errcode = '42501';
  end if;
  select * into c from public.courses where id = p_course_id;
  if not found or c.status <> 'published' then
    raise exception 'Course not found' using errcode = 'P0002';
  end if;
  if c.price_minor > 0 then
    raise exception 'This course is not free' using errcode = 'P0001';
  end if;

  select * into e from public.enrolments where user_id = auth.uid() and course_id = p_course_id;
  if found then
    if e.status = 'revoked' then
      raise exception 'Your access to this course was removed. Contact us.' using errcode = '42501';
    end if;
    return e.status;
  end if;

  insert into public.enrolments (user_id, course_id, source) values (auth.uid(), p_course_id, 'free');
  return 'active';
end;
$$;

-- ---------------------------------------------------------------------------
-- Progress
-- ---------------------------------------------------------------------------
create or replace function public.course_progress(p_course_id uuid)
returns table (completed integer, total integer, percent integer, required_completed integer, required_total integer)
language sql
stable
security definer
set search_path = ''
as $$
  with l as (
    select l.id, l.type, exists (
      select 1 from public.lesson_progress p where p.user_id = auth.uid() and p.lesson_id = l.id
    ) as done
    from public.lessons l where l.course_id = p_course_id
  )
  select count(*) filter (where done)::int,
         count(*)::int,
         case when count(*) = 0 then 0 else floor(100.0 * count(*) filter (where done) / count(*))::int end,
         count(*) filter (where done and type <> 'live_session')::int,
         count(*) filter (where type <> 'live_session')::int
  from l;
$$;

-- Marks a video / article / file lesson complete. Quiz lessons complete by
-- passing; live-session lessons by attendance.
create or replace function public.complete_lesson(p_lesson_id uuid, p_completed boolean default true)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  l public.lessons;
begin
  select * into l from public.lessons where id = p_lesson_id;
  if not found or not public.is_course_published(l.course_id) or not public.is_enrolled(l.course_id) then
    raise exception 'Enrol in this course first' using errcode = '42501';
  end if;
  if l.type not in ('video', 'article', 'file') then
    raise exception 'This lesson is completed automatically' using errcode = 'P0001';
  end if;
  if p_completed then
    insert into public.lesson_progress (user_id, lesson_id, course_id, source)
    values (auth.uid(), p_lesson_id, l.course_id, 'manual')
    on conflict (user_id, lesson_id) do nothing;
  else
    delete from public.lesson_progress where user_id = auth.uid() and lesson_id = p_lesson_id and source = 'manual';
  end if;
end;
$$;

-- Attendance → progress for the lesson a session is linked to.
create or replace function public.attendance_to_progress()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  s public.live_sessions;
begin
  if new.status = 'attended' and old.status is distinct from 'attended' then
    select * into s from public.live_sessions where id = new.session_id;
    if s.lesson_id is not null and s.course_id is not null then
      insert into public.lesson_progress (user_id, lesson_id, course_id, source)
      values (new.user_id, s.lesson_id, s.course_id, 'attendance')
      on conflict (user_id, lesson_id) do nothing;
    end if;
  elsif old.status = 'attended' and new.status <> 'attended' then
    select * into s from public.live_sessions where id = new.session_id;
    if s.lesson_id is not null then
      -- Only undo if no other attended session covers the same lesson.
      if not exists (
        select 1 from public.session_registrations r join public.live_sessions o on o.id = r.session_id
        where r.user_id = new.user_id and r.status = 'attended' and o.lesson_id = s.lesson_id and r.id <> new.id
      ) then
        delete from public.lesson_progress where user_id = new.user_id and lesson_id = s.lesson_id and source = 'attendance';
      end if;
    end if;
  end if;
  return new;
end;
$$;
create trigger session_registrations_progress after update of status on public.session_registrations
  for each row execute function public.attendance_to_progress();

-- Sessions may only be linked to a live-session lesson of the same course.
create or replace function public.live_sessions_lesson_check()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.lesson_id is not null and not exists (
    select 1 from public.lessons where id = new.lesson_id and course_id = new.course_id and type = 'live_session'
  ) then
    raise exception 'Link the session to a live-session lesson of the same course' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger live_sessions_lesson_check before insert or update of lesson_id, course_id on public.live_sessions
  for each row execute function public.live_sessions_lesson_check();

-- ---------------------------------------------------------------------------
-- Quizzes
-- ---------------------------------------------------------------------------

-- Questions WITHOUT answers, for enrolled students (and staff previewing).
create or replace function public.get_student_quiz(p_lesson_id uuid)
returns table (quiz_id uuid, pass_mark smallint, question_id uuid, prompt text, options jsonb, q_position integer)
language sql
stable
security definer
set search_path = ''
as $$
  select q.id, q.pass_mark, qq.id, qq.prompt, qq.options, qq.position
  from public.quizzes q
  join public.quiz_questions qq on qq.quiz_id = q.id
  where q.lesson_id = p_lesson_id
    and ((public.is_enrolled(q.course_id) and public.is_course_published(q.course_id)) or public.is_course_staff(q.course_id))
  order by qq.position;
$$;

-- Grades a submission. p_answers: {"<question_id>": <option index>, …}.
-- Correct answers and explanations are only revealed once the quiz is passed.
create or replace function public.submit_quiz(p_lesson_id uuid, p_answers jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  q public.quizzes;
  total integer;
  correct integer;
  pct integer;
  ok boolean;
  results jsonb;
begin
  select * into q from public.quizzes where lesson_id = p_lesson_id;
  if not found or not public.is_course_published(q.course_id) or not public.is_enrolled(q.course_id) then
    raise exception 'Enrol in this course first' using errcode = '42501';
  end if;
  if jsonb_typeof(p_answers) <> 'object' then
    raise exception 'Invalid answers' using errcode = '22023';
  end if;

  select count(*), count(*) filter (where (p_answers ->> qq.id::text) ~ '^[0-9]+$' and (p_answers ->> qq.id::text)::int = qq.correct_index)
    into total, correct
  from public.quiz_questions qq where qq.quiz_id = q.id;
  if total = 0 then
    raise exception 'This quiz has no questions yet' using errcode = 'P0001';
  end if;

  pct := floor(100.0 * correct / total);
  ok := pct >= q.pass_mark;

  select jsonb_agg(jsonb_build_object(
           'question_id', qq.id,
           'correct', (p_answers ->> qq.id::text) ~ '^[0-9]+$' and (p_answers ->> qq.id::text)::int = qq.correct_index,
           'correct_index', case when ok then qq.correct_index end,
           'explanation', case when ok then qq.explanation end
         ) order by qq.position)
    into results
  from public.quiz_questions qq where qq.quiz_id = q.id;

  insert into public.quiz_attempts (user_id, quiz_id, lesson_id, course_id, answers, score, passed)
  values (auth.uid(), q.id, p_lesson_id, q.course_id, p_answers, pct, ok);

  if ok then
    insert into public.lesson_progress (user_id, lesson_id, course_id, source)
    values (auth.uid(), p_lesson_id, q.course_id, 'quiz')
    on conflict (user_id, lesson_id) do nothing;
  end if;

  return jsonb_build_object('score', pct, 'passed', ok, 'pass_mark', q.pass_mark, 'correct', correct, 'total', total, 'results', results);
end;
$$;

-- ---------------------------------------------------------------------------
-- Certificates
-- ---------------------------------------------------------------------------
create or replace function public.issue_certificate(p_course_id uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  existing text;
  prog record;
  new_serial text;
  name text;
  title text;
begin
  if not public.is_enrolled(p_course_id) then
    return null;
  end if;
  select serial into existing from public.certificates where user_id = auth.uid() and course_id = p_course_id;
  if existing is not null then
    return existing;
  end if;

  select * into prog from public.course_progress(p_course_id);
  if prog.required_total = 0 or prog.required_completed < prog.required_total then
    return null;
  end if;

  select coalesce(nullif(full_name, ''), email::text) into name from public.profiles where id = auth.uid();
  select c.title into title from public.courses c where c.id = p_course_id;
  loop
    new_serial := 'QL-' || to_char(now(), 'YYYY') || '-' ||
                  upper(substr(translate(encode(extensions.gen_random_bytes(8), 'base64'), '+/=0O1Il', ''), 1, 8));
    exit when length(new_serial) = 16 and not exists (select 1 from public.certificates where serial = new_serial);
  end loop;

  insert into public.certificates (serial, user_id, course_id, holder_name, course_title)
  values (new_serial, auth.uid(), p_course_id, name, title);
  return new_serial;
end;
$$;

-- Public verification (no personal data beyond what is printed on the certificate).
create or replace function public.verify_certificate(p_serial text)
returns table (serial text, holder_name text, course_title text, issued_at timestamptz)
language sql
stable
security definer
set search_path = ''
as $$
  select serial, holder_name, course_title, issued_at from public.certificates where serial = upper(p_serial);
$$;

revoke execute on function public.enrol_free(uuid) from public, anon;
revoke execute on function public.course_progress(uuid) from public, anon;
revoke execute on function public.complete_lesson(uuid, boolean) from public, anon;
revoke execute on function public.get_student_quiz(uuid) from public, anon;
revoke execute on function public.submit_quiz(uuid, jsonb) from public, anon;
revoke execute on function public.issue_certificate(uuid) from public, anon;
grant execute on function public.enrol_free(uuid) to authenticated;
grant execute on function public.course_progress(uuid) to authenticated;
grant execute on function public.complete_lesson(uuid, boolean) to authenticated;
grant execute on function public.get_student_quiz(uuid) to authenticated;
grant execute on function public.submit_quiz(uuid, jsonb) to authenticated;
grant execute on function public.issue_certificate(uuid) to authenticated;
grant execute on function public.verify_certificate(text) to anon, authenticated;
