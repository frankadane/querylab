-- Phase 6: admin analytics, computed in the database. Admin only.
create or replace function public.admin_analytics(p_weeks integer default 12)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  weeks integer := least(greatest(coalesce(p_weeks, 12), 4), 52);
  start_week timestamptz := date_trunc('week', now()) - make_interval(weeks => weeks - 1);
  result jsonb;
begin
  if not public.is_admin() then
    raise exception 'Not allowed' using errcode = '42501';
  end if;

  with w as (
    select generate_series(start_week, date_trunc('week', now()), interval '1 week') as week
  )
  select jsonb_build_object(
    'weeks', weeks,
    'signups', (select jsonb_agg(jsonb_build_object('week', w.week::date, 'value',
                  (select count(*) from public.profiles p where date_trunc('week', p.created_at) = w.week)) order by w.week) from w),
    'enrolments', (select jsonb_agg(jsonb_build_object('week', w.week::date, 'value',
                  (select count(*) from public.enrolments e where date_trunc('week', e.created_at) = w.week)) order by w.week) from w),
    'totals', jsonb_build_object(
      'users', (select count(*) from public.profiles),
      'signups_period', (select count(*) from public.profiles where created_at >= start_week),
      'active_enrolments', (select count(*) from public.enrolments where status = 'active'),
      'enrolments_period', (select count(*) from public.enrolments where created_at >= start_week),
      'pending_orders', (select count(*) from public.orders where status = 'pending'),
      'certificates', (select count(*) from public.certificates)
    ),
    'revenue', coalesce((
      select jsonb_agg(jsonb_build_object('currency', currency, 'period_minor', period_minor, 'all_minor', all_minor, 'orders', n) order by currency)
      from (
        select currency,
               sum(total_minor) filter (where paid_at >= start_week) as period_minor,
               sum(total_minor) as all_minor,
               count(*) as n
        from public.orders where status = 'paid' group by currency
      ) r), '[]'::jsonb),
    'attendance', (
      select jsonb_build_object(
        'sessions', count(distinct s.id),
        'registered', count(r.id) filter (where r.status in ('registered', 'attended')),
        'attended', count(r.id) filter (where r.status = 'attended'))
      from public.live_sessions s
      left join public.session_registrations r on r.session_id = s.id
      where s.ends_at < now() and s.ends_at >= start_week and s.status <> 'cancelled'),
    'courses', coalesce((
      select jsonb_agg(jsonb_build_object(
               'title', c.title,
               'enrolled', (select count(*) from public.enrolments e where e.course_id = c.id and e.status = 'active'),
               'completed', (select count(*) from public.certificates ce where ce.course_id = c.id)) order by c.title)
      from public.courses c where c.status = 'published'), '[]'::jsonb)
  ) into result;
  return result;
end;
$$;
revoke execute on function public.admin_analytics(integer) from public, anon;
grant execute on function public.admin_analytics(integer) to authenticated;
