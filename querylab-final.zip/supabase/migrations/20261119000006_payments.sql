-- Phase 6: provider-agnostic payments.
--
-- Orders record what was bought, the price breakdown (computed here, never
-- trusted from the client) and which PaymentProvider handles it. Adding
-- Stripe/PayPal later needs no schema change: use provider = 'stripe',
-- store the PSP id in provider_ref / provider_data, and call
-- confirm_order_payment() from the webhook (service role).

create type public.order_status as enum ('pending', 'paid', 'cancelled', 'refunded');
create type public.coupon_kind as enum ('percent', 'fixed');

-- ---------------------------------------------------------------------------
-- Coupons
-- ---------------------------------------------------------------------------
create table public.coupons (
  id              uuid primary key default gen_random_uuid(),
  code            extensions.citext not null unique check (code ~* '^[A-Z0-9][A-Z0-9_-]{2,31}$'),
  kind            public.coupon_kind not null,
  amount          integer not null check (amount > 0), -- percent 1–100, or minor units for fixed
  currency        public.currency_code,                 -- required for fixed
  course_id       uuid references public.courses (id) on delete cascade, -- null = any course
  expires_at      timestamptz,
  max_redemptions integer check (max_redemptions is null or max_redemptions > 0),
  redemptions     integer not null default 0,
  is_active       boolean not null default true,
  created_by      uuid references public.profiles (id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint coupons_percent_range check (kind <> 'percent' or amount between 1 and 100),
  constraint coupons_fixed_currency check (kind <> 'fixed' or currency is not null)
);
create index coupons_code_lower_idx on public.coupons (lower(code::text));
create trigger coupons_set_updated_at before update on public.coupons
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Orders
-- ---------------------------------------------------------------------------
create sequence public.invoice_number_seq;

create table public.orders (
  id             uuid primary key default gen_random_uuid(),
  reference      text not null unique check (reference ~ '^QL-[A-Z0-9]{8}$'),
  user_id        uuid not null references public.profiles (id) on delete cascade,
  course_id      uuid not null references public.courses (id) on delete restrict,
  course_title   text not null,       -- snapshot for invoices
  provider       text not null check (provider ~ '^[a-z_]{2,30}$'),
  status         public.order_status not null default 'pending',
  currency       public.currency_code not null,
  subtotal_minor integer not null check (subtotal_minor >= 0),
  discount_minor integer not null default 0 check (discount_minor >= 0),
  total_minor    integer not null check (total_minor >= 0),
  coupon_id      uuid references public.coupons (id) on delete set null,
  coupon_code    text,
  provider_ref   text,                -- e.g. a Stripe PaymentIntent id
  provider_data  jsonb not null default '{}'::jsonb,
  invoice_number text unique,
  billing_name   text not null,
  billing_email  text not null,
  admin_note     text check (char_length(admin_note) <= 1000),
  paid_at        timestamptz,
  cancelled_at   timestamptz,
  refunded_at    timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  constraint orders_total check (total_minor = subtotal_minor - discount_minor)
);
create index orders_user_idx on public.orders (user_id, created_at desc);
create index orders_status_idx on public.orders (status, created_at desc);
create index orders_course_idx on public.orders (course_id);
-- At most one open order per person and course.
create unique index orders_one_pending on public.orders (user_id, course_id) where status = 'pending';
create trigger orders_set_updated_at before update on public.orders
  for each row execute function public.set_updated_at();

alter table public.enrolments
  add constraint enrolments_order_id_fkey foreign key (order_id) references public.orders (id) on delete set null;

-- Invoice details (placeholders until set in Admin → Settings)
alter table public.site_settings
  add column invoice_company_name text not null default '[Your company name]',
  add column invoice_company_address text not null default E'[Street address]\n[City], Ghana',
  add column invoice_tax_id text,
  add column invoice_footer text not null default 'Thank you for learning with QueryLab.';

alter table public.coupons enable row level security;
alter table public.orders enable row level security;

create policy "coupons: admin all" on public.coupons for all to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy "orders: own read" on public.orders for select to authenticated
  using (user_id = (select auth.uid()));
create policy "orders: admin read" on public.orders for select to authenticated
  using ((select public.is_admin()));
-- No write policies: all changes go through the functions below.

-- ---------------------------------------------------------------------------
-- Pricing
-- ---------------------------------------------------------------------------
create or replace function public.coupon_discount(p_coupon public.coupons, p_course public.courses)
returns integer
language sql
immutable
as $$
  select case
    when p_coupon.kind = 'percent' then least(p_course.price_minor, (p_course.price_minor * p_coupon.amount) / 100)
    else least(p_course.price_minor, p_coupon.amount)
  end;
$$;

-- Validates a coupon for a course; raises a friendly error if unusable.
create or replace function public.find_coupon(p_code text, p_course public.courses)
returns public.coupons
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  c public.coupons;
begin
  -- Explicit lower(): with an empty search_path the citext operator isn't visible.
  select * into c from public.coupons where lower(code::text) = lower(p_code);
  if not found or not c.is_active then
    raise exception 'That coupon code isn''t valid' using errcode = 'P0001';
  end if;
  if c.expires_at is not null and c.expires_at < now() then
    raise exception 'That coupon has expired' using errcode = 'P0001';
  end if;
  if c.max_redemptions is not null and c.redemptions >= c.max_redemptions then
    raise exception 'That coupon has been fully used' using errcode = 'P0001';
  end if;
  if c.course_id is not null and c.course_id <> p_course.id then
    raise exception 'That coupon is for a different course' using errcode = 'P0001';
  end if;
  if c.kind = 'fixed' and c.currency <> p_course.currency then
    raise exception 'That coupon is in a different currency' using errcode = 'P0001';
  end if;
  return c;
end;
$$;
revoke execute on function public.find_coupon(text, public.courses) from public, anon, authenticated;

-- Price preview for the checkout page.
create or replace function public.quote_price(p_course_id uuid, p_coupon text default null)
returns table (currency public.currency_code, subtotal_minor integer, discount_minor integer, total_minor integer, coupon_code text)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  crs public.courses;
  cpn public.coupons;
  d integer := 0;
begin
  select * into crs from public.courses where id = p_course_id and status = 'published';
  if not found then
    raise exception 'Course not found' using errcode = 'P0002';
  end if;
  if coalesce(trim(p_coupon), '') <> '' then
    cpn := public.find_coupon(trim(p_coupon), crs);
    d := public.coupon_discount(cpn, crs);
  end if;
  return query select crs.currency, crs.price_minor, d, crs.price_minor - d, cpn.code::text;
end;
$$;

-- ---------------------------------------------------------------------------
-- Order lifecycle
-- ---------------------------------------------------------------------------
create or replace function public.new_order_reference()
returns text
language plpgsql
volatile
set search_path = ''
as $$
declare
  r text;
begin
  loop
    r := 'QL-' || upper(substr(translate(encode(extensions.gen_random_bytes(9), 'base64'), '+/=0O1Il', ''), 1, 8));
    exit when length(r) = 11 and not exists (select 1 from public.orders where reference = r);
  end loop;
  return r;
end;
$$;

-- Internal: marks paid, numbers the invoice, enrols. Idempotent.
create or replace function public.settle_order(p_order_id uuid, p_provider_ref text default null)
returns public.orders
language plpgsql
security definer
set search_path = ''
as $$
declare
  o public.orders;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then
    raise exception 'Order not found' using errcode = 'P0002';
  end if;
  if o.status = 'paid' then
    return o;
  end if;
  if o.status <> 'pending' then
    raise exception 'Only pending orders can be marked as paid' using errcode = 'P0001';
  end if;

  update public.orders
     set status = 'paid',
         paid_at = now(),
         provider_ref = coalesce(p_provider_ref, provider_ref),
         invoice_number = 'INV-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.invoice_number_seq')::text, 6, '0')
   where id = p_order_id
  returning * into o;

  insert into public.enrolments (user_id, course_id, source, order_id, status)
  values (o.user_id, o.course_id, (case when o.total_minor = 0 and o.coupon_id is not null then 'coupon' else 'order' end)::public.enrolment_source, o.id, 'active')
  on conflict (user_id, course_id) do update set status = 'active', source = excluded.source, order_id = excluded.order_id;

  if o.coupon_id is not null then
    update public.coupons set redemptions = redemptions + 1 where id = o.coupon_id;
  end if;
  return o;
end;
$$;
revoke execute on function public.settle_order(uuid, text) from public, anon, authenticated;

-- Student checkout. Price is computed here. A zero total settles at once.
create or replace function public.create_order(p_course_id uuid, p_provider text, p_coupon text default null)
returns public.orders
language plpgsql
security definer
set search_path = ''
as $$
declare
  crs public.courses;
  cpn public.coupons;
  prof public.profiles;
  d integer := 0;
  o public.orders;
begin
  select * into prof from public.profiles where id = auth.uid();
  if not found or prof.suspended_at is not null then
    raise exception 'Sign in to buy a course' using errcode = '42501';
  end if;
  select * into crs from public.courses where id = p_course_id and status = 'published' for share;
  if not found then
    raise exception 'Course not found' using errcode = 'P0002';
  end if;
  if exists (select 1 from public.enrolments where user_id = prof.id and course_id = crs.id and status = 'active') then
    raise exception 'You''re already enrolled in this course' using errcode = 'P0001';
  end if;
  if p_provider !~ '^[a-z_]{2,30}$' then
    raise exception 'Unknown payment method' using errcode = '22023';
  end if;

  if coalesce(trim(p_coupon), '') <> '' then
    select * into cpn from public.coupons where id = (public.find_coupon(trim(p_coupon), crs)).id for update;
    d := public.coupon_discount(cpn, crs);
  end if;

  -- Replace any earlier unpaid order for the same course.
  update public.orders set status = 'cancelled', cancelled_at = now()
   where user_id = prof.id and course_id = crs.id and status = 'pending';

  insert into public.orders (reference, user_id, course_id, course_title, provider, currency, subtotal_minor, discount_minor,
                             total_minor, coupon_id, coupon_code, billing_name, billing_email)
  values (public.new_order_reference(), prof.id, crs.id, crs.title,
          case when crs.price_minor - d = 0 then (case when cpn.id is null then 'free' else 'coupon' end) else p_provider end,
          crs.currency, crs.price_minor, d, crs.price_minor - d, cpn.id, cpn.code::text,
          coalesce(nullif(prof.full_name, ''), prof.email::text), prof.email::text)
  returning * into o;

  if o.total_minor = 0 then
    o := public.settle_order(o.id);
  end if;
  return o;
end;
$$;

-- Admin: record a bank transfer / invoice payment.
create or replace function public.mark_order_paid(p_order_id uuid, p_note text default null)
returns public.orders
language plpgsql
security definer
set search_path = ''
as $$
declare
  o public.orders;
begin
  if not public.is_admin() then
    raise exception 'Not allowed' using errcode = '42501';
  end if;
  o := public.settle_order(p_order_id);
  if p_note is not null then
    update public.orders set admin_note = left(p_note, 1000) where id = p_order_id returning * into o;
  end if;
  return o;
end;
$$;

-- Service role (payment webhooks): confirm a provider payment.
create or replace function public.confirm_order_payment(p_reference text, p_provider text, p_provider_ref text)
returns public.orders
language plpgsql
security definer
set search_path = ''
as $$
declare
  o public.orders;
begin
  select * into o from public.orders where reference = p_reference and provider = p_provider;
  if not found then
    raise exception 'Order not found' using errcode = 'P0002';
  end if;
  return public.settle_order(o.id, p_provider_ref);
end;
$$;
revoke execute on function public.confirm_order_payment(text, text, text) from public, anon, authenticated;
grant execute on function public.confirm_order_payment(text, text, text) to service_role;

-- Owner (pending only) or admin can cancel.
create or replace function public.cancel_order(p_order_id uuid)
returns public.orders
language plpgsql
security definer
set search_path = ''
as $$
declare
  o public.orders;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found or (o.user_id <> auth.uid() and not public.is_admin()) then
    raise exception 'Order not found' using errcode = 'P0002';
  end if;
  if o.status <> 'pending' then
    raise exception 'Only unpaid orders can be cancelled' using errcode = 'P0001';
  end if;
  update public.orders set status = 'cancelled', cancelled_at = now() where id = p_order_id returning * into o;
  return o;
end;
$$;

-- Admin: refund a paid order and remove access.
create or replace function public.refund_order(p_order_id uuid, p_note text default null)
returns public.orders
language plpgsql
security definer
set search_path = ''
as $$
declare
  o public.orders;
begin
  if not public.is_admin() then
    raise exception 'Not allowed' using errcode = '42501';
  end if;
  select * into o from public.orders where id = p_order_id for update;
  if not found then
    raise exception 'Order not found' using errcode = 'P0002';
  end if;
  if o.status <> 'paid' then
    raise exception 'Only paid orders can be refunded' using errcode = 'P0001';
  end if;
  update public.orders set status = 'refunded', refunded_at = now(), admin_note = coalesce(left(p_note, 1000), admin_note)
   where id = p_order_id returning * into o;
  update public.enrolments set status = 'revoked' where order_id = o.id;
  return o;
end;
$$;

revoke execute on function public.quote_price(uuid, text) from public, anon;
revoke execute on function public.create_order(uuid, text, text) from public, anon;
revoke execute on function public.mark_order_paid(uuid, text) from public, anon;
revoke execute on function public.cancel_order(uuid) from public, anon;
revoke execute on function public.refund_order(uuid, text) from public, anon;
grant execute on function public.quote_price(uuid, text) to authenticated;
grant execute on function public.create_order(uuid, text, text) to authenticated;
grant execute on function public.mark_order_paid(uuid, text) to authenticated;
grant execute on function public.cancel_order(uuid) to authenticated;
grant execute on function public.refund_order(uuid, text) to authenticated;

-- Anonymous users have no access to coupons or orders at all.
revoke all on public.coupons from anon;
revoke all on public.orders from anon;
-- Signed-in users can only read orders; every change goes through the functions above.
revoke insert, update, delete on public.orders from authenticated;
