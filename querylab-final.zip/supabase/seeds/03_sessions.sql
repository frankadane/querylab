-- DEMO live sessions, generated relative to the seed date (never hard-coded).
-- Weekly, 90 minutes, capacity 25, 18:00 Africa/Accra (= 18:00 UTC, no DST).
-- Join links are placeholders on example.com; replace them in the studio.

do $$
declare
  crs record;
  sid uuid;
  first_day date := (now() at time zone 'Africa/Accra')::date + 7;  -- one week from the seed date
  wk int;
begin
  for crs in
    select id, title, slug from public.courses where is_demo order by title
  loop
    for wk in 0..2 loop
      insert into public.live_sessions (course_id, title, description_md, starts_at, ends_at, timezone, capacity,
                                        instructor_id, is_demo)
      values (crs.id,
              format('%s: live session %s', crs.title, wk + 1),
              'Weekly live session: questions, worked examples and project help. Bring your questions.',
              ((first_day + wk * 7)::timestamp + time '18:00') at time zone 'Africa/Accra',
              ((first_day + wk * 7)::timestamp + time '19:30') at time zone 'Africa/Accra',
              'Africa/Accra', 25,
              case when crs.slug = 'applied-ai-for-professionals' then 'a0000000-0000-4000-8000-000000000002'::uuid end,
              true)
      returning id into sid;
      insert into public.live_session_links (session_id, join_url)
      values (sid, format('https://example.com/join/%s-week-%s', crs.slug, wk + 1));
    end loop;
  end loop;

  -- Free intro session open to every registered user (course_id null), in 3 days.
  insert into public.live_sessions (course_id, title, description_md, starts_at, ends_at, timezone, capacity,
                                    instructor_id, is_demo)
  values (null, 'Intro to Data & AI (free)',
          E'A free 90-minute introduction for anyone with a QueryLab account.\n\n- What AI, data science and BI each do\n- Which course fits your goals\n- Live Q&A',
          (((now() at time zone 'Africa/Accra')::date + 3)::timestamp + time '17:00') at time zone 'Africa/Accra',
          (((now() at time zone 'Africa/Accra')::date + 3)::timestamp + time '18:30') at time zone 'Africa/Accra',
          'Africa/Accra', 25, 'a0000000-0000-4000-8000-000000000002', true)
  returning id into sid;
  insert into public.live_session_links (session_id, join_url) values (sid, 'https://example.com/join/intro-to-data-and-ai');

  -- student1 (enrolled in Power BI) is registered for the first Power BI session and the intro.
  insert into public.session_registrations (session_id, user_id, status)
  select s.id, 'a0000000-0000-4000-8000-000000000003', 'registered'
  from public.live_sessions s left join public.courses c on c.id = s.course_id
  where (c.slug = 'power-bi-mastery' and s.title like '%session 1') or s.course_id is null;
end $$;

-- Demo progress for student1 in Power BI Mastery (first three lessons done).
insert into public.lesson_progress (user_id, lesson_id, course_id, source)
select 'a0000000-0000-4000-8000-000000000003', l.id, l.course_id, 'manual'
from public.lessons l
join public.sections s on s.id = l.section_id
join public.courses c on c.id = l.course_id
where c.slug = 'power-bi-mastery' and s.position = 1;
