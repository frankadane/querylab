-- Local development seed. DEMO DATA ONLY: never run against production.
-- Credentials are documented in README.md ("Demo accounts").

create or replace function pg_temp.seed_user(p_id uuid, p_email text, p_password text, p_name text)
returns void language plpgsql as $$
begin
  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change_token_new, email_change,
    email_change_token_current, phone_change, phone_change_token, reauthentication_token
  ) values (
    '00000000-0000-0000-0000-000000000000', p_id, 'authenticated', 'authenticated', p_email,
    extensions.crypt(p_password, extensions.gen_salt('bf')), now(),
    '{"provider":"email","providers":["email"]}', jsonb_build_object('full_name', p_name),
    now(), now(), '', '', '', '', '', '', '', ''
  );
  insert into auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
  values (gen_random_uuid(), p_id, p_id::text,
          jsonb_build_object('sub', p_id::text, 'email', p_email, 'email_verified', true),
          'email', now(), now(), now());
end $$;

select pg_temp.seed_user('a0000000-0000-4000-8000-000000000001', 'admin@querylab.test',      'Demo-Admin-2026!',      'Demo Admin');
select pg_temp.seed_user('a0000000-0000-4000-8000-000000000002', 'instructor@querylab.test', 'Demo-Instructor-2026!', 'Demo Instructor');
select pg_temp.seed_user('a0000000-0000-4000-8000-000000000003', 'student1@querylab.test',   'Demo-Student-2026!',    'Demo Student One');
select pg_temp.seed_user('a0000000-0000-4000-8000-000000000004', 'student2@querylab.test',   'Demo-Student-2026!',    'Demo Student Two');

update public.profiles set is_demo = true
 where id in ('a0000000-0000-4000-8000-000000000001','a0000000-0000-4000-8000-000000000002',
              'a0000000-0000-4000-8000-000000000003','a0000000-0000-4000-8000-000000000004');
update public.profiles set role = 'admin'      where id = 'a0000000-0000-4000-8000-000000000001';
update public.profiles set role = 'instructor' where id = 'a0000000-0000-4000-8000-000000000002';
