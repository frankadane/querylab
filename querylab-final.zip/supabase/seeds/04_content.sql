-- Editable pages. Legal pages are TEMPLATES: have them reviewed by a lawyer
-- before launch. The About page uses placeholders; no claims are invented.

insert into public.pages (slug, title, status, seo_description, body_md) values
('about', 'About QueryLab', 'published', 'QueryLab is an online and live training academy for AI, Data Science and Power BI.',
$md$> **Placeholder page.** Replace this text in Admin → Pages before launch.

QueryLab is an online and live training academy for **AI, Data Science (Python & SQL) and Power BI**, built for working professionals, analysts and corporate teams.

## How we teach

- **Practical first.** Every course ends with a capstone built on a problem from your own job.
- **Self-paced and live.** Short lessons you can take any time, plus weekly live sessions with an instructor.
- **Clear outcomes.** Each course lists exactly what you will be able to do by the end.

## Who we are

[Add your story: who founded QueryLab, why, and the experience of the team.]

## Get in touch

Questions about a course or training for your team? [Contact us](/contact) or see [training for teams](/corporate).
$md$),
('privacy', 'Privacy policy', 'published', 'How QueryLab collects, uses and protects your personal data.',
$md$> **Template, not legal advice.** Review with a qualified lawyer (including for Ghana's Data Protection Act, 2012 (Act 843) and, if you serve EU/UK learners, the GDPR) before launch. Replace every [bracketed] item.

_Last updated: [date]_

## Who we are

[Company legal name], trading as QueryLab ("we"), [address]. Contact: [querylab@gmail.com]. [Registration with the Data Protection Commission: number.]

## What we collect

- **Account data:** name, email address, password (stored only as a secure hash), timezone, optional photo and bio.
- **Learning data:** enrolments, lesson progress, quiz attempts, live-session registrations and attendance, certificates.
- **Orders:** what you bought, amounts, payment references and invoices. We do not store card numbers.
- **Messages:** what you send through our contact or corporate enquiry forms.
- **Technical data:** essential cookies needed to keep you signed in (see the [cookie notice](/cookies)) and server logs.

## Why we use it (and our legal basis)

- To provide the courses and live sessions you sign up for (contract).
- To send service emails such as confirmations, reminders and receipts (contract / legitimate interest).
- To keep the platform secure and prevent abuse, including rate limiting (legitimate interest).
- To meet accounting and tax obligations for orders (legal obligation).

We do not sell your data or use it for advertising.

## Who we share it with

Service providers that process data on our behalf: [Supabase (database, authentication and file storage; region: …)], [Vercel (hosting)], [Resend (email)], [video hosting provider], and the meeting tool used for live sessions (Zoom, Google Meet or Microsoft Teams) when you join one. [List international transfers and safeguards.]

## How long we keep it

Account and learning data while your account is open. Order and invoice records for [X] years for tax purposes. Enquiries for [X] months.

## Your rights

You can access, correct, export and delete your data. Download a copy and delete your account any time under **Account → Login & security**. For anything else, email [querylab@gmail.com]. You can also complain to [the Data Protection Commission of Ghana / your local regulator].

## Changes

We will post changes here and, if significant, tell you by email.
$md$),
('terms', 'Terms of service', 'published', 'The terms that apply when you use QueryLab.',
$md$> **Template, not legal advice.** Review with a qualified lawyer before launch. Replace every [bracketed] item.

_Last updated: [date]_

## 1. About these terms
These terms are an agreement between you and [Company legal name] ("QueryLab"). By creating an account you accept them.

## 2. Your account
Keep your password secure and your details accurate. Accounts are personal; don't share access. We may suspend accounts that break these terms.

## 3. Courses and live sessions
- Course content is for your personal, non-commercial learning. Don't redistribute videos, materials or quiz answers.
- Live sessions have limited places. Join links are personal. Sessions may be rescheduled or cancelled; we will tell you by email.
- Certificates confirm completion of the course requirements; they are not an accredited qualification [unless stated].

## 4. Prices and payment
Prices are shown in GHS or USD. For bank transfers, access starts once we record your payment. Invoices are issued by [Company legal name].

## 5. Cancellations and refunds
[Describe your refund policy, e.g. full refund within 14 days of purchase if you have completed less than 20% of the course.] Refunds end access to the course.

## 6. Acceptable use
No abuse, harassment, attempts to access other people's data, or interference with the platform.

## 7. Liability
[Limitation of liability clause appropriate to your jurisdiction.]

## 8. Changes and contact
We may update these terms and will tell you about material changes. Questions: [querylab@gmail.com]. These terms are governed by the laws of [Ghana].
$md$),
('cookies', 'Cookie notice', 'published', 'Which cookies QueryLab uses and why.',
$md$> **Template, not legal advice.** Review before launch.

QueryLab uses only **essential** cookies and browser storage that are needed for the site to work. We do not use advertising or tracking cookies, so we don't show a cookie consent banner. If we add analytics or marketing tools later, we will ask for your consent first and update this page.

| Name | Purpose | Duration |
| --- | --- | --- |
| `sb-…-auth-token` | Keeps you signed in securely (HttpOnly) | Until you sign out or the session expires |
| `ql-signed-in` | Lets public pages show "Dashboard" instead of "Log in"; contains no personal data | Same as your session |
| `theme` (local storage) | Remembers light/dark mode | Until you clear it |
| `ql-viewer-tz` (local storage) | Remembers the timezone you chose on the schedule | Until you clear it |

Embedded videos from YouTube (privacy-enhanced mode) or Vimeo (do-not-track) may set their own cookies when you play them.
$md$);

-- Demo blog posts (educational; flagged is_demo).
insert into public.posts (slug, title, excerpt, tags, status, is_demo, author_id, body_md) values
('star-schemas-in-plain-english', 'Star schemas in plain English', 'Why Power BI models built from facts and dimensions are faster, simpler and easier to trust.', '{power-bi,modelling}', 'published', true, (select id from public.profiles where role = 'admin' order by created_at limit 1),
$md$A **star schema** splits your data into two kinds of tables:

- **Fact tables** record events: sales, website visits, support tickets. They are long and narrow.
- **Dimension tables** describe those events: customers, products, dates, regions.

Each fact row points to one row in each dimension, which is why the diagram looks like a star.

## Why it matters in Power BI

1. **Simpler DAX.** Filters flow from dimensions to facts in one direction, so measures behave predictably.
2. **Better performance.** The engine compresses narrow fact tables well.
3. **Fewer surprises.** One date table, marked as a date table, makes time intelligence reliable.

## A quick checklist

- One fact table per business process.
- Dimensions have a unique key and descriptive columns.
- Relationships are one-to-many, single direction, from dimension to fact.
- A dedicated, continuous date table.

> Demo post. Replace or delete it in Admin → Blog.
$md$),
('writing-better-prompts-at-work', 'Writing better prompts at work', 'A simple structure for prompts that produce reliable, reviewable results.', '{ai,prompting}', 'published', true, (select id from public.profiles where role = 'admin' order by created_at limit 1),
$md$Good prompts are less about magic words and more about **giving the model what a capable colleague would need**.

## A structure that works

1. **Role:** who should the model act as? ("You are a financial analyst…")
2. **Task:** what exactly do you want?
3. **Context:** the facts, data or document it should use.
4. **Constraints:** length, tone, what to avoid.
5. **Format:** a table, bullet points, JSON…

## Always check the output

- Ask for sources or the reasoning behind numbers.
- Spot-check facts against the original material.
- Never paste confidential data into tools your organisation hasn't approved.

> Demo post. Replace or delete it in Admin → Blog.
$md$);
