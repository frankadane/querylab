-- DEMO course catalogue (local/dev). All rows flagged is_demo / is_placeholder.
-- Instructors are placeholders: replace names, bios and photos in Admin → Instructors.
-- Video URLs point at example.com and render as "video coming soon" in the player.

insert into public.instructors (id, profile_id, slug, display_name, headline, bio_md, is_placeholder, is_demo) values
  ('c1000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000002', 'placeholder-ai-instructor',
   'Placeholder: AI Instructor', 'Placeholder headline. Replace in Admin → Instructors.',
   'Placeholder bio. Replace with the real instructor''s background before launch.', true, true),
  ('c1000000-0000-4000-8000-000000000002', null, 'placeholder-data-science-instructor',
   'Placeholder: Data Science Instructor', 'Placeholder headline. Replace in Admin → Instructors.',
   'Placeholder bio. Replace with the real instructor''s background before launch.', true, true),
  ('c1000000-0000-4000-8000-000000000003', null, 'placeholder-power-bi-instructor',
   'Placeholder: Power BI Instructor', 'Placeholder headline. Replace in Admin → Instructors.',
   'Placeholder bio. Replace with the real instructor''s background before launch.', true, true);

create or replace function pg_temp.seed_course(d jsonb) returns uuid language plpgsql as $$
declare
  cid uuid;
  sid uuid;
  lid uuid;
  qid uuid;
  sec jsonb;
  les jsonb;
  q jsonb;
  si int := 0;
  li int;
  first_lesson boolean := true;
begin
  insert into public.courses (slug, title, subtitle, description_md, outcomes, requirements, track, level_min, level_max,
                              format, duration_weeks, price_minor, currency, instructor_id, status, is_demo)
  values (d->>'slug', d->>'title', d->>'subtitle', d->>'description',
          array(select jsonb_array_elements_text(d->'outcomes')),
          array(select jsonb_array_elements_text(d->'requirements')),
          (d->>'track')::public.course_track, (d->>'level_min')::public.course_level, (d->>'level_max')::public.course_level,
          (d->>'format')::public.course_format, (d->>'weeks')::smallint, 0, 'GHS',
          (d->>'instructor_id')::uuid, 'published', true)
  returning id into cid;

  for sec in select * from jsonb_array_elements(d->'sections') loop
    si := si + 1;
    insert into public.sections (course_id, title, position) values (cid, sec->>'title', si) returning id into sid;
    li := 0;
    for les in select * from jsonb_array_elements(sec->'lessons') loop
      li := li + 1;
      insert into public.lessons (section_id, course_id, title, summary, type, duration_minutes, is_free_preview, position)
      values (sid, cid, les->>'t', les->>'s', coalesce(les->>'type', 'video')::public.lesson_type,
              coalesce((les->>'min')::smallint, 12), first_lesson, li)
      returning id into lid;
      insert into public.lesson_contents (lesson_id, course_id, body_md, video_url)
      values (lid, cid,
              format(E'## %s\n\n%s\n\n> Placeholder lesson content (demo). Replace in the course builder.', les->>'t', les->>'s'),
              case when coalesce(les->>'type', 'video') = 'video' then 'https://example.com/placeholder-video' end);
      first_lesson := false;

      if les->>'type' = 'quiz' then
        insert into public.quizzes (lesson_id, course_id, pass_mark) values (lid, cid, 70) returning id into qid;
        for q in select * from jsonb_array_elements(d->'quiz') loop
          insert into public.quiz_questions (quiz_id, prompt, options, correct_index, explanation, position)
          values (qid, q->>'q', q->'o', (q->>'c')::smallint, q->>'e',
                  (select count(*) from public.quiz_questions where quiz_id = qid) + 1);
        end loop;
      end if;
    end loop;
  end loop;

  insert into public.faqs (course_id, question, answer_md, position)
  select cid, f->>'q', f->>'a', ord from jsonb_array_elements(d->'faqs') with ordinality as x(f, ord);

  return cid;
end $$;

-- 1. Applied AI for Professionals -------------------------------------------
select pg_temp.seed_course($json${
  "slug": "applied-ai-for-professionals",
  "title": "Applied AI for Professionals",
  "subtitle": "Use AI tools and machine learning confidently and responsibly in your everyday work.",
  "description": "An 8-week practical course for professionals who want to use AI well, not just talk about it. You will learn the core vocabulary, write prompts that produce reliable results, use large language models for analysis and writing, understand how machine learning models are built and evaluated, and automate routine tasks with no-code tools. The course closes with a capstone where you design an AI-assisted workflow for your own job.\n\nTaught as a live cohort with weekly sessions, with all material also available self-paced.",
  "outcomes": [
    "Explain key AI and machine learning concepts in plain language",
    "Write structured prompts and evaluate the quality of AI output",
    "Use LLMs to summarise, analyse and draft documents faster",
    "Describe how classification and regression models are trained and evaluated",
    "Automate a repetitive task with no-code / low-code AI tools",
    "Identify bias, privacy and governance risks and apply safeguards"
  ],
  "requirements": ["No coding experience needed", "A laptop and access to at least one AI assistant (free tiers are fine)"],
  "track": "ai", "level_min": "beginner", "level_max": "intermediate", "format": "hybrid", "weeks": 8,
  "instructor_id": "c1000000-0000-4000-8000-000000000001",
  "sections": [
    {"title": "AI fundamentals & vocabulary", "lessons": [
      {"t": "Welcome and how this course works", "s": "Course structure, live sessions, the capstone and how to get help.", "min": 8},
      {"t": "What AI is (and isn't)", "s": "AI, machine learning, deep learning and generative AI, and how they relate."},
      {"t": "How large language models work", "s": "Tokens, training data, context windows and why models make mistakes."},
      {"t": "A working AI glossary", "s": "The 30 terms you will hear in meetings, explained with examples.", "type": "article", "min": 10}
    ]},
    {"title": "Prompting and AI workflows", "lessons": [
      {"t": "Anatomy of a good prompt", "s": "Role, task, context, constraints and output format."},
      {"t": "Iterating and evaluating output", "s": "Checking accuracy, asking for sources and refining step by step."},
      {"t": "Reusable prompt templates", "s": "Build a personal library of prompts for recurring work.", "type": "file", "min": 10},
      {"t": "Chaining steps into a workflow", "s": "Break larger tasks into reliable, reviewable steps."}
    ]},
    {"title": "Using LLMs for analysis and writing", "lessons": [
      {"t": "Summarising long documents", "s": "Reports, transcripts and email threads, with verification habits."},
      {"t": "Analysing tables and spreadsheets with AI", "s": "Asking good questions of data and spotting wrong answers."},
      {"t": "Drafting and editing professional writing", "s": "Briefs, emails and reports in your organisation's voice."},
      {"t": "Fact-checking and citing", "s": "Reduce hallucinations and keep an audit trail.", "type": "article", "min": 10}
    ]},
    {"title": "Machine learning basics", "lessons": [
      {"t": "Supervised learning in one picture", "s": "Features, labels, training and prediction."},
      {"t": "Classification", "s": "Predicting categories: churn, fraud, spam, with worked examples."},
      {"t": "Regression", "s": "Predicting numbers: demand, price and time to complete."},
      {"t": "Evaluating models", "s": "Accuracy, precision, recall, error metrics and overfitting."},
      {"t": "Knowledge check: AI and ML basics", "s": "Ten questions on the first four sections.", "type": "quiz", "min": 15}
    ]},
    {"title": "Automating tasks with no-code / low-code AI", "lessons": [
      {"t": "Choosing what to automate", "s": "Find tasks with high volume, clear rules and low risk."},
      {"t": "Building an automation step by step", "s": "Triggers, AI steps and human review points."},
      {"t": "Testing and monitoring automations", "s": "Edge cases, failure alerts and measuring time saved."}
    ]},
    {"title": "Responsible AI: bias, privacy, governance", "lessons": [
      {"t": "Where bias comes from", "s": "Data, design and deployment, and how to detect it."},
      {"t": "Privacy and confidential data", "s": "What not to paste into AI tools and safer alternatives."},
      {"t": "AI governance at work", "s": "Policies, approvals, documentation and accountability.", "type": "article", "min": 15}
    ]},
    {"title": "Capstone: an AI-assisted workflow for your job", "lessons": [
      {"t": "Capstone brief", "s": "Requirements, timeline and how it is assessed.", "type": "article", "min": 10},
      {"t": "Designing your workflow", "s": "Map the current process and where AI helps.", "type": "live_session", "min": 90},
      {"t": "Presenting your results", "s": "Show time saved, quality checks and risks managed.", "type": "live_session", "min": 90}
    ]}
  ],
  "quiz": [
    {"q": "Which of these is an example of a classification task?", "o": ["Forecasting next month's revenue", "Deciding whether an email is spam", "Estimating delivery time in minutes", "Calculating average order value"], "c": 1, "e": "Classification predicts a category; the others predict numbers."},
    {"q": "What does a context window limit?", "o": ["How fast a model responds", "How much text the model can consider at once", "How many users can use the model", "The model's training date"], "c": 1, "e": "The context window is the amount of text (tokens) the model can attend to in one request."},
    {"q": "A model scores 99% accuracy on training data and 60% on new data. This suggests:", "o": ["Underfitting", "Overfitting", "Perfect generalisation", "Data leakage is impossible"], "c": 1, "e": "Large gaps between training and test performance indicate overfitting."},
    {"q": "Which is the safest practice with confidential client data?", "o": ["Paste it into any free AI tool", "Remove identifying details or use an approved tool", "Share it only in the evening", "Email it to the AI vendor"], "c": 1, "e": "Anonymise data or use tools approved by your organisation."}
  ],
  "faqs": [
    {"q": "Do I need to know how to code?", "a": "No. Every exercise can be completed without code. Optional extensions use simple spreadsheets."},
    {"q": "Which AI tools will we use?", "a": "We teach transferable skills that work with common AI assistants. Free tiers are enough to complete the course."},
    {"q": "How much time should I plan each week?", "a": "About 3–4 hours: one 90-minute live session plus self-paced lessons and practice."}
  ]
}$json$::jsonb);

-- 2. Data Science with Python & SQL ------------------------------------------
select pg_temp.seed_course($json${
  "slug": "data-science-with-python-and-sql",
  "title": "Data Science with Python & SQL",
  "subtitle": "Clean, query, analyse and model data end to end, and explain the results to people who make decisions.",
  "description": "A 10-week intermediate programme for analysts who want to move from spreadsheets to code. You will write Python and pandas to clean real-world data, query databases with SQL, explore and visualise patterns, test hypotheses, and build and evaluate supervised learning models with scikit-learn. The final capstone is an end-to-end analysis with a written report.",
  "outcomes": [
    "Write clean, readable Python for data work",
    "Load, clean and reshape messy datasets with pandas",
    "Query relational databases with joins, aggregates and window functions",
    "Explore data visually and communicate findings with clear charts",
    "Apply hypothesis tests and interpret p-values and confidence intervals correctly",
    "Train, evaluate and improve scikit-learn models"
  ],
  "requirements": ["Comfortable with spreadsheets (formulas, filters, pivot tables)", "No prior Python required; we start from the essentials", "A laptop that can run Python (setup guide provided)"],
  "track": "data_science", "level_min": "intermediate", "level_max": "intermediate", "format": "hybrid", "weeks": 10,
  "instructor_id": "c1000000-0000-4000-8000-000000000002",
  "sections": [
    {"title": "Python essentials", "lessons": [
      {"t": "Setting up your environment", "s": "Install Python, Jupyter and the course notebooks.", "min": 15},
      {"t": "Variables, types and collections", "s": "Numbers, strings, lists and dictionaries for data work."},
      {"t": "Control flow and functions", "s": "Loops, conditions and writing reusable functions."},
      {"t": "Working with files", "s": "Reading CSV, Excel and JSON files safely."}
    ]},
    {"title": "pandas and data cleaning", "lessons": [
      {"t": "DataFrames and Series", "s": "Selecting, filtering and sorting data."},
      {"t": "Handling missing and inconsistent data", "s": "Nulls, duplicates, types and messy categories."},
      {"t": "Reshaping and joining", "s": "groupby, pivot, melt and merge."},
      {"t": "Dates and times", "s": "Parsing, time zones and resampling."}
    ]},
    {"title": "SQL for analysts", "lessons": [
      {"t": "SELECT, WHERE and ORDER BY", "s": "Reading data from a relational database."},
      {"t": "Joins", "s": "Inner, left and anti joins, and avoiding duplicate rows."},
      {"t": "Aggregation and GROUP BY", "s": "Summaries, HAVING and common pitfalls."},
      {"t": "Window functions", "s": "Running totals, rankings and period-over-period change."},
      {"t": "SQL from Python", "s": "Querying a database into pandas."}
    ]},
    {"title": "Exploratory analysis and visualisation", "lessons": [
      {"t": "An EDA checklist", "s": "Questions to ask of any new dataset.", "type": "article", "min": 10},
      {"t": "Distributions and relationships", "s": "Histograms, box plots and scatter plots."},
      {"t": "Charts that communicate", "s": "Choosing chart types and removing clutter."}
    ]},
    {"title": "Statistics and hypothesis testing", "lessons": [
      {"t": "Sampling and uncertainty", "s": "Why samples vary and what that means for decisions."},
      {"t": "Confidence intervals", "s": "Estimating ranges, not just single numbers."},
      {"t": "Hypothesis tests", "s": "t-tests, chi-square and interpreting p-values responsibly."},
      {"t": "A/B testing in practice", "s": "Designing and reading experiments."}
    ]},
    {"title": "Supervised learning with scikit-learn", "lessons": [
      {"t": "The scikit-learn workflow", "s": "Fit, predict, score and pipelines."},
      {"t": "Linear and logistic regression", "s": "Interpretable baselines for numbers and categories."},
      {"t": "Decision trees and random forests", "s": "Non-linear models and feature importance."}
    ]},
    {"title": "Model evaluation and feature engineering", "lessons": [
      {"t": "Train/test splits and cross-validation", "s": "Honest estimates of model performance."},
      {"t": "Metrics that matter", "s": "Precision, recall, ROC AUC, MAE and RMSE."},
      {"t": "Feature engineering", "s": "Encoding, scaling and creating useful features."},
      {"t": "Knowledge check: modelling", "s": "Questions on statistics, modelling and evaluation.", "type": "quiz", "min": 15}
    ]},
    {"title": "Communicating results", "lessons": [
      {"t": "Writing for decision-makers", "s": "Lead with the answer, then the evidence."},
      {"t": "Presenting uncertainty", "s": "Ranges, caveats and recommendations."},
      {"t": "Reproducible notebooks and reports", "s": "Structure work so others can rerun it.", "type": "article", "min": 10}
    ]},
    {"title": "Capstone: end-to-end analysis and report", "lessons": [
      {"t": "Capstone brief and datasets", "s": "Choose a dataset and frame a business question.", "type": "file", "min": 10},
      {"t": "Capstone clinic", "s": "Live help with analysis and modelling.", "type": "live_session", "min": 90},
      {"t": "Final presentations", "s": "Present your findings and get feedback.", "type": "live_session", "min": 90}
    ]}
  ],
  "quiz": [
    {"q": "Which SQL clause filters groups after aggregation?", "o": ["WHERE", "HAVING", "ORDER BY", "LIMIT"], "c": 1, "e": "WHERE filters rows before grouping; HAVING filters groups after."},
    {"q": "In pandas, which method combines two DataFrames on a key column?", "o": ["concat", "merge", "pivot", "melt"], "c": 1, "e": "merge performs SQL-style joins on keys."},
    {"q": "Why use cross-validation?", "o": ["To make training faster", "To get a more reliable estimate of performance on unseen data", "To remove missing values", "To increase the number of features"], "c": 1, "e": "Cross-validation averages performance across several train/test splits."},
    {"q": "A fraud model must catch as many frauds as possible. Which metric matters most?", "o": ["Precision", "Recall", "R-squared", "Mean absolute error"], "c": 1, "e": "Recall measures the share of actual frauds the model catches."}
  ],
  "faqs": [
    {"q": "Is this course suitable if I've never coded?", "a": "Yes, if you are comfortable with spreadsheets. The first two weeks cover Python from the beginning; expect to practise between sessions."},
    {"q": "Which database do we use for SQL?", "a": "PostgreSQL-compatible SQL. The skills transfer to SQL Server, MySQL and BigQuery with minor syntax differences."},
    {"q": "Do I keep access to the materials?", "a": "Yes. Notebooks, datasets and recordings stay available in your dashboard after the course ends."}
  ]
}$json$::jsonb);

-- 3. Power BI Mastery --------------------------------------------------------
select pg_temp.seed_course($json${
  "slug": "power-bi-mastery",
  "title": "Power BI Mastery",
  "subtitle": "Go from raw data to trusted, well-designed executive dashboards, including DAX, modelling and governance.",
  "description": "A 6-week course that takes you from first connection to production-ready reports. You will shape data in Power Query, design star-schema models, write DAX measures with CALCULATE and time intelligence, design reports that tell a clear story, publish and refresh in the Power BI Service, and secure data with row-level security. You will finish by building an executive sales dashboard.",
  "outcomes": [
    "Connect to common data sources and shape data with Power Query",
    "Design star-schema models with correct relationships",
    "Write DAX measures including CALCULATE and time intelligence",
    "Design clear, accessible report pages that answer business questions",
    "Publish, share and schedule refresh in the Power BI Service",
    "Implement row-level security and basic governance"
  ],
  "requirements": ["Power BI Desktop (free, Windows) or access to a Windows machine", "Basic Excel skills", "A free Power BI account is helpful for the Service section"],
  "track": "power_bi", "level_min": "beginner", "level_max": "advanced", "format": "live_cohort", "weeks": 6,
  "instructor_id": "c1000000-0000-4000-8000-000000000003",
  "sections": [
    {"title": "Power BI interface and data sources", "lessons": [
      {"t": "Tour of Power BI Desktop", "s": "Report, data and model views, and the build workflow.", "min": 10},
      {"t": "Connecting to Excel, CSV and databases", "s": "Import vs DirectQuery and when to use each."},
      {"t": "Your first report in 20 minutes", "s": "An end-to-end walkthrough to see the whole picture.", "min": 20}
    ]},
    {"title": "Power Query transformations", "lessons": [
      {"t": "Cleaning columns and data types", "s": "Split, trim, replace and type detection."},
      {"t": "Merging and appending queries", "s": "Combine tables and files reliably."},
      {"t": "Unpivoting and reshaping", "s": "Turn report-style sheets into analysis-ready tables."},
      {"t": "Parameters and reusable steps", "s": "Make refreshes robust to changing sources."}
    ]},
    {"title": "Data modelling and star schemas", "lessons": [
      {"t": "Facts and dimensions", "s": "Why star schemas make DAX simpler and faster."},
      {"t": "Relationships and cardinality", "s": "One-to-many, filter direction and common mistakes."},
      {"t": "Date tables", "s": "Build and mark a proper date table."}
    ]},
    {"title": "DAX fundamentals", "lessons": [
      {"t": "Measures vs calculated columns", "s": "Row context, filter context and when to use each."},
      {"t": "CALCULATE", "s": "Changing filter context: the most important DAX function."},
      {"t": "Time intelligence", "s": "YTD, previous period and rolling averages."},
      {"t": "Iterators and variables", "s": "SUMX, AVERAGEX and readable DAX with VAR."},
      {"t": "Knowledge check: modelling and DAX", "s": "Questions on star schemas and DAX.", "type": "quiz", "min": 15}
    ]},
    {"title": "Report design and storytelling", "lessons": [
      {"t": "Designing for the question", "s": "Start from decisions, not visuals."},
      {"t": "Layout, colour and accessibility", "s": "Hierarchy, contrast and colour-blind-safe palettes."},
      {"t": "Interactivity", "s": "Slicers, drill-through, bookmarks and tooltips."}
    ]},
    {"title": "Power BI Service, sharing and refresh", "lessons": [
      {"t": "Workspaces and apps", "s": "Organising content for teams."},
      {"t": "Scheduled refresh and gateways", "s": "Keep data current safely."},
      {"t": "Sharing and permissions", "s": "Who can see and edit what."}
    ]},
    {"title": "Row-level security and governance", "lessons": [
      {"t": "Static and dynamic RLS", "s": "Restrict rows by role or by user."},
      {"t": "Testing RLS", "s": "View as role and avoid common leaks."},
      {"t": "Governance basics", "s": "Certified datasets, naming and documentation.", "type": "article", "min": 10}
    ]},
    {"title": "Capstone: executive sales dashboard", "lessons": [
      {"t": "Capstone brief and dataset", "s": "Requirements for a one-page executive dashboard.", "type": "file", "min": 10},
      {"t": "Build clinic", "s": "Live help with modelling and DAX.", "type": "live_session", "min": 90},
      {"t": "Dashboard reviews", "s": "Present and get structured feedback.", "type": "live_session", "min": 90}
    ]}
  ],
  "quiz": [
    {"q": "In a star schema, a Sales table that records each transaction is a:", "o": ["Dimension table", "Fact table", "Bridge table", "Calculated table"], "c": 1, "e": "Fact tables store events/measurements; dimensions describe them."},
    {"q": "What does CALCULATE primarily do?", "o": ["Creates a new table", "Evaluates an expression in a modified filter context", "Refreshes the dataset", "Sorts a column"], "c": 1, "e": "CALCULATE changes the filter context in which an expression is evaluated."},
    {"q": "Time intelligence functions work most reliably when you:", "o": ["Use the auto date/time only", "Have a marked date table with a continuous range of dates", "Store dates as text", "Avoid relationships"], "c": 1, "e": "A contiguous, marked date table is required for reliable time intelligence."},
    {"q": "Dynamic row-level security usually filters on:", "o": ["The report theme", "USERPRINCIPALNAME() matched to a user table", "The refresh schedule", "The visual type"], "c": 1, "e": "Dynamic RLS uses the signed-in user's identity to filter rows."}
  ],
  "faqs": [
    {"q": "Can I take this course on a Mac?", "a": "Power BI Desktop runs on Windows only. Mac users can use a Windows virtual machine or a cloud PC; we share options in week 1."},
    {"q": "Do I need a paid Power BI licence?", "a": "No. Power BI Desktop is free. A free account covers most of the Service section; we explain where Pro features differ."},
    {"q": "Is this course right for complete beginners?", "a": "Yes. It starts with the basics and progresses to advanced DAX and governance, so experienced users also benefit from the later weeks."}
  ]
}$json$::jsonb);

-- Site-wide FAQs (shown on the home page)
insert into public.faqs (course_id, question, answer_md, position) values
  (null, 'Do I need a technical background?', 'No. Applied AI and Power BI Mastery start from the basics. Data Science with Python & SQL expects comfort with spreadsheets; we cover Python from the beginning.', 1),
  (null, 'What happens if I miss a live session?', 'Recordings and materials are attached to each session after it ends, so you can catch up from your dashboard.', 2),
  (null, 'How do I pay?', 'At launch you can pay by bank transfer or invoice. Your place is confirmed once the payment is recorded. Some courses and sessions are free.', 3),
  (null, 'Do you train whole teams?', 'Yes. We run private cohorts for companies, with content adapted to your data and tools. Send us an enquiry and we will reply by email.', 4);

-- Demo enrolment so student1 can see enrolled-only content in tests.
insert into public.enrolments (user_id, course_id, source)
select 'a0000000-0000-4000-8000-000000000003', id, 'manual' from public.courses where slug = 'power-bi-mastery';
