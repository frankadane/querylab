begin;
create extension if not exists pgtap with schema extensions;
select plan(20);

-- Fixtures (seed users exist: admin ...01, instructor ...02, students ...03/...04)
create or replace function pg_temp.as_user(uid uuid) returns void language sql as $$
  select set_config('role', 'authenticated', true),
         set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
$$;

-- RLS is on for every public table
select is(
  (select count(*)::int from pg_tables where schemaname = 'public' and not rowsecurity),
  0, 'RLS enabled on every public table');

-- New auth users get a student profile; metadata cannot grant a role
insert into auth.users (instance_id, id, aud, role, email, raw_user_meta_data, created_at, updated_at)
values ('00000000-0000-0000-0000-000000000000', 'b0000000-0000-4000-8000-000000000009',
        'authenticated', 'authenticated', 'sneaky@querylab.test',
        '{"full_name":"Sneaky","role":"admin","timezone":"Not/AZone"}', now(), now());
select is((select role::text from public.profiles where id = 'b0000000-0000-4000-8000-000000000009'),
          'student', 'signup metadata cannot set role');
select is((select timezone from public.profiles where id = 'b0000000-0000-4000-8000-000000000009'),
          'Africa/Accra', 'invalid signup timezone falls back to Africa/Accra');

-- Anonymous: nothing
set local role anon;
select is((select count(*)::int from public.profiles), 0, 'anon sees no profiles');
select throws_ok($$ select public.is_admin() $$, '42501', null, 'anon cannot call is_admin');
reset role;

-- Student
select pg_temp.as_user('a0000000-0000-4000-8000-000000000003');
select is((select count(*)::int from public.profiles), 1, 'student sees only own profile');
select lives_ok($$ update public.profiles set full_name = 'Renamed', bio = 'hi', timezone = 'Europe/London'
                   where id = 'a0000000-0000-4000-8000-000000000003' $$, 'student can edit own profile');
select throws_ok($$ update public.profiles set role = 'admin' where id = 'a0000000-0000-4000-8000-000000000003' $$,
                 '42501', null, 'student cannot change own role');
select throws_ok($$ update public.profiles set email = 'x@y.z' where id = 'a0000000-0000-4000-8000-000000000003' $$,
                 '42501', null, 'student cannot change email directly');
select throws_ok($$ update public.profiles set timezone = 'Mars/Base' where id = 'a0000000-0000-4000-8000-000000000003' $$,
                 '22023', null, 'invalid timezone rejected');
update public.profiles set full_name = 'Hacked' where id = 'a0000000-0000-4000-8000-000000000004';
select is((select count(*)::int from public.profiles where full_name = 'Hacked'), 0,
          'student cannot update another profile (0 rows)');
select is((select count(*)::int from public.audit_log), 0, 'student cannot read audit log');
select throws_ok($$ select public.write_audit('fake') $$, '42501', null, 'student cannot write audit log');
select throws_ok($$ select public.check_rate_limit('k', 1, 60) $$, '42501', null,
                 'authenticated users cannot call rate limiter');
select throws_ok($$ insert into public.profiles (id, email) values (gen_random_uuid(), 'a@b.c') $$,
                 '42501', null, 'cannot insert profiles directly');
reset role;

-- Instructor: own profile + people registered for sessions they teach (seed: student1 on the intro session)
select pg_temp.as_user('a0000000-0000-4000-8000-000000000002');
select is((select array_agg(id order by id) from public.profiles),
          array['a0000000-0000-4000-8000-000000000002', 'a0000000-0000-4000-8000-000000000003']::uuid[],
          'instructor sees own profile and their attendees only');
reset role;

-- Admin
select pg_temp.as_user('a0000000-0000-4000-8000-000000000001');
select ok((select count(*) from public.profiles) >= 5, 'admin sees all profiles');
select lives_ok($$ update public.profiles set role = 'instructor' where id = 'a0000000-0000-4000-8000-000000000004' $$,
                'admin can change another user''s role');
select throws_ok($$ update public.profiles set role = 'student' where id = 'a0000000-0000-4000-8000-000000000001' $$,
                 '42501', null, 'admin cannot demote themselves');
select lives_ok($$ select public.write_audit('user.role_changed', 'profile', 'a0000000-0000-4000-8000-000000000004') $$,
                'admin can write audit log');
reset role;

select * from finish();
rollback;
