begin;
create extension if not exists pgtap with schema extensions;
select plan(30);

create or replace function pg_temp.as_user(uid uuid) returns void language sql as $$
  select set_config('role', 'authenticated', true),
         set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
$$;

-- Small fixture course: 2 video lessons, 1 quiz (2 questions, pass 50), 1 live-session lesson
insert into public.courses (id, slug, title, track, status, instructor_id) values
  ('d1000000-0000-4000-8000-000000000001', 'tiny-course', 'Tiny course', 'ai', 'published', 'c1000000-0000-4000-8000-000000000001');
insert into public.sections (id, course_id, title) values ('d1000000-0000-4000-8000-000000000002', 'd1000000-0000-4000-8000-000000000001', 'S');
insert into public.lessons (id, section_id, course_id, title, type, position) values
  ('d1000000-0000-4000-8000-000000000011', 'd1000000-0000-4000-8000-000000000002', 'd1000000-0000-4000-8000-000000000001', 'V1', 'video', 1),
  ('d1000000-0000-4000-8000-000000000012', 'd1000000-0000-4000-8000-000000000002', 'd1000000-0000-4000-8000-000000000001', 'V2', 'article', 2),
  ('d1000000-0000-4000-8000-000000000013', 'd1000000-0000-4000-8000-000000000002', 'd1000000-0000-4000-8000-000000000001', 'Q', 'quiz', 3),
  ('d1000000-0000-4000-8000-000000000014', 'd1000000-0000-4000-8000-000000000002', 'd1000000-0000-4000-8000-000000000001', 'Live', 'live_session', 4);
insert into public.quizzes (id, lesson_id, course_id, pass_mark) values ('d1000000-0000-4000-8000-000000000020', 'd1000000-0000-4000-8000-000000000013', 'd1000000-0000-4000-8000-000000000001', 50);
insert into public.quiz_questions (id, quiz_id, prompt, options, correct_index, explanation, position) values
  ('d1000000-0000-4000-8000-000000000021', 'd1000000-0000-4000-8000-000000000020', '1+1', '["1","2"]', 1, 'Two.', 1),
  ('d1000000-0000-4000-8000-000000000022', 'd1000000-0000-4000-8000-000000000020', '2+2', '["4","5"]', 0, 'Four.', 2);
insert into public.live_sessions (id, course_id, lesson_id, title, starts_at, ends_at)
values ('d1000000-0000-4000-8000-000000000030', 'd1000000-0000-4000-8000-000000000001', 'd1000000-0000-4000-8000-000000000014', 'Live 1', now() + interval '1 day', now() + interval '1 day 1 hour');
-- A paid course
insert into public.courses (id, slug, title, track, status, price_minor) values ('d1000000-0000-4000-8000-000000000099', 'paid', 'Paid', 'ai', 'published', 10000);

select is((select count(*)::int from pg_tables where schemaname = 'public' and not rowsecurity), 0, 'RLS enabled on every public table');

-- ---------- enrolment ----------
select pg_temp.as_user('a0000000-0000-4000-8000-000000000004'); -- student2
select throws_ok($$ select public.complete_lesson('d1000000-0000-4000-8000-000000000011') $$, '42501', null, 'cannot complete lessons before enrolling');
select is((select count(*)::int from public.get_student_quiz('d1000000-0000-4000-8000-000000000013')), 0, 'cannot see quiz before enrolling');
select is(public.enrol_free('d1000000-0000-4000-8000-000000000001')::text, 'active', 'free course enrols immediately');
select is(public.enrol_free('d1000000-0000-4000-8000-000000000001')::text, 'active', 'enrolling twice is idempotent');
select throws_ok($$ select public.enrol_free('d1000000-0000-4000-8000-000000000099') $$, 'P0001', null, 'paid course cannot be enrolled for free');

-- ---------- progress ----------
select lives_ok($$ select public.complete_lesson('d1000000-0000-4000-8000-000000000011') $$, 'complete a video lesson');
select lives_ok($$ select public.complete_lesson('d1000000-0000-4000-8000-000000000011') $$, 'completing twice is harmless');
select throws_ok($$ select public.complete_lesson('d1000000-0000-4000-8000-000000000013') $$, 'P0001', null, 'quiz lessons cannot be ticked manually');
select throws_ok($$ select public.complete_lesson('d1000000-0000-4000-8000-000000000014') $$, 'P0001', null, 'live lessons cannot be ticked manually');
select is((select percent from public.course_progress('d1000000-0000-4000-8000-000000000001')), 25, 'progress 1/4 = 25%');
select is(public.issue_certificate('d1000000-0000-4000-8000-000000000001'), null, 'no certificate yet');
select throws_ok($$ insert into public.lesson_progress (user_id, lesson_id, course_id) values ('a0000000-0000-4000-8000-000000000004', 'd1000000-0000-4000-8000-000000000012', 'd1000000-0000-4000-8000-000000000001') $$,
                 '42501', null, 'cannot write progress directly');

-- ---------- quiz ----------
select is((select count(*)::int from public.get_student_quiz('d1000000-0000-4000-8000-000000000013')), 2, 'enrolled student gets the questions');
select is((select count(*)::int from public.quiz_questions), 0, 'but never the quiz_questions table (answers)');
select is((public.submit_quiz('d1000000-0000-4000-8000-000000000013', '{"d1000000-0000-4000-8000-000000000021": 0, "d1000000-0000-4000-8000-000000000022": 1}') ->> 'passed'), 'false', '0/2 fails');
select is((public.submit_quiz('d1000000-0000-4000-8000-000000000013', '{"d1000000-0000-4000-8000-000000000021": 0}') -> 'results' -> 0 ->> 'correct_index'), null, 'failed attempts do not reveal correct answers');
select is((public.submit_quiz('d1000000-0000-4000-8000-000000000013', '{"d1000000-0000-4000-8000-000000000021": 1, "d1000000-0000-4000-8000-000000000022": 1}') ->> 'score'), '50', '1/2 = 50%');
select is((select count(*)::int from public.lesson_progress where lesson_id = 'd1000000-0000-4000-8000-000000000013'), 1, 'passing (50 ≥ 50) completes the quiz lesson');
select is((public.submit_quiz('d1000000-0000-4000-8000-000000000013', '{"d1000000-0000-4000-8000-000000000021": 1, "d1000000-0000-4000-8000-000000000022": 0}') -> 'results' -> 1 ->> 'explanation'), 'Four.', 'passed attempts reveal explanations');
select is((select count(*)::int from public.quiz_attempts), 4, 'attempts are recorded');
select throws_ok($$ select public.submit_quiz('d1000000-0000-4000-8000-000000000013', '"x"') $$, '22023', null, 'malformed answers rejected');

-- ---------- certificate ----------
select lives_ok($$ select public.complete_lesson('d1000000-0000-4000-8000-000000000012') $$, 'complete the article');
select ok(public.issue_certificate('d1000000-0000-4000-8000-000000000001') ~ '^QL-[0-9]{4}-[A-Z0-9]{8}$', 'certificate issued without attending the live session');
select is((select count(*)::int from public.certificates), 1, 'one certificate, visible to its owner');
reset role;
select is((select holder_name from public.verify_certificate((select serial from public.certificates where course_id = 'd1000000-0000-4000-8000-000000000001'))), 'Demo Student Two', 'public verification works');

-- ---------- attendance → progress ----------
insert into public.session_registrations (session_id, user_id, status) values ('d1000000-0000-4000-8000-000000000030', 'a0000000-0000-4000-8000-000000000004', 'registered');
update public.session_registrations set status = 'attended' where session_id = 'd1000000-0000-4000-8000-000000000030';
select is((select source from public.lesson_progress where lesson_id = 'd1000000-0000-4000-8000-000000000014'), 'attendance', 'attending completes the linked live lesson');
update public.session_registrations set status = 'registered' where session_id = 'd1000000-0000-4000-8000-000000000030';
select is((select count(*)::int from public.lesson_progress where lesson_id = 'd1000000-0000-4000-8000-000000000014'), 0, 'un-marking attendance removes it');
select throws_ok($$ update public.live_sessions set lesson_id = 'd1000000-0000-4000-8000-000000000011' where id = 'd1000000-0000-4000-8000-000000000030' $$,
                 '23514', null, 'sessions can only link to live-session lessons');

-- ---------- isolation ----------
select pg_temp.as_user('a0000000-0000-4000-8000-000000000003'); -- student1
select is((select count(*)::int from public.certificates), 0, 'others cannot see someone else''s certificate');
reset role;

select * from finish();
rollback;
