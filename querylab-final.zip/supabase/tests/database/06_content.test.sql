begin;
create extension if not exists pgtap with schema extensions;
select plan(14);

create or replace function pg_temp.as_user(uid uuid) returns void language sql as $$
  select set_config('role', 'authenticated', true),
         set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
$$;

insert into public.posts (slug, title, status) values ('secret-draft', 'Draft', 'draft');
insert into public.pages (slug, title, status) values ('hidden-page', 'Hidden', 'draft');
insert into public.enquiries (kind, name, email, message) values ('contact', 'A', 'a@b.c', 'Hello there');

select is((select count(*)::int from pg_tables where schemaname = 'public' and not rowsecurity), 0, 'RLS enabled on every public table');

set local role anon;
select is((select count(*)::int from public.posts where slug = 'secret-draft'), 0, 'anon cannot see draft posts');
select is((select count(*)::int from public.posts), 2, 'anon sees published posts');
select is((select count(*)::int from public.pages where slug = 'hidden-page'), 0, 'anon cannot see draft pages');
select throws_ok($$ select * from public.enquiries $$, '42501', null, 'anon cannot read enquiries');
select throws_ok($$ insert into public.enquiries (kind, name, email, message) values ('contact', 'x', 'x@y.z', 'spam spam') $$, '42501', null, 'anon cannot insert enquiries directly');
reset role;

select pg_temp.as_user('a0000000-0000-4000-8000-000000000003'); -- student
select is((select count(*)::int from public.enquiries), 0, 'students cannot read enquiries');
select throws_ok($$ select public.admin_analytics() $$, '42501', null, 'students cannot read analytics');
select throws_ok($$ insert into public.posts (slug, title) values ('x', 'x') $$, '42501', null, 'students cannot write posts');
reset role;

select pg_temp.as_user('a0000000-0000-4000-8000-000000000002'); -- instructor
select lives_ok($$ insert into public.posts (slug, title, author_id) values ('instructor-post', 'Mine', 'a0000000-0000-4000-8000-000000000002') returning id $$, 'instructors can draft their own posts');
update public.pages set title = 'Hacked' where slug = 'about';
select isnt((select title from public.pages where slug = 'about'), 'Hacked', 'instructors cannot edit pages (0 rows changed)');
reset role;

select pg_temp.as_user('a0000000-0000-4000-8000-000000000001'); -- admin
select is((select count(*)::int from public.enquiries), 1, 'admin reads enquiries');
select lives_ok($$ update public.pages set title = 'About us' where slug = 'about' $$, 'admin edits pages');
select is(jsonb_array_length(public.admin_analytics(12) -> 'signups'), 12, 'admin analytics returns 12 weeks');
reset role;

select * from finish();
rollback;
