begin;
create extension if not exists pgtap with schema extensions;
select plan(33);

create or replace function pg_temp.as_user(uid uuid) returns void language sql as $$
  select set_config('role', 'authenticated', true),
         set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
$$;

-- Extra students enrolled in Power BI
insert into auth.users (instance_id, id, aud, role, email, created_at, updated_at) values
  ('00000000-0000-0000-0000-000000000000', 'e0000000-0000-4000-8000-000000000001', 'authenticated', 'authenticated', 's3@t.test', now(), now()),
  ('00000000-0000-0000-0000-000000000000', 'e0000000-0000-4000-8000-000000000002', 'authenticated', 'authenticated', 's4@t.test', now(), now());
insert into public.enrolments (user_id, course_id, source)
select u, c.id, 'manual' from public.courses c,
  unnest(array['e0000000-0000-4000-8000-000000000001','e0000000-0000-4000-8000-000000000002']::uuid[]) u
where c.slug = 'power-bi-mastery';

-- A capacity-1 Power BI session tomorrow, and one starting in 10 minutes
insert into public.live_sessions (id, course_id, title, starts_at, ends_at, capacity)
select 'f0000000-0000-4000-8000-000000000001', id, 'Tiny', now() + interval '1 day', now() + interval '1 day 90 minutes', 1
from public.courses where slug = 'power-bi-mastery';
insert into public.live_session_links values ('f0000000-0000-4000-8000-000000000001', 'https://example.com/join/tiny', now());
insert into public.live_sessions (id, course_id, title, starts_at, ends_at, capacity)
select 'f0000000-0000-4000-8000-000000000002', id, 'Soon', now() + interval '10 minutes', now() + interval '100 minutes', 25
from public.courses where slug = 'power-bi-mastery';
insert into public.live_session_links values ('f0000000-0000-4000-8000-000000000002', 'https://example.com/join/soon', now());

select is((select count(*)::int from pg_tables where schemaname = 'public' and not rowsecurity), 0, 'RLS enabled on every public table');

-- ---------- anon ----------
set local role anon;
select ok((select count(*) from public.live_sessions) >= 10, 'anon sees public sessions');
select throws_ok($$ select * from public.live_session_links $$, '42501', null, 'anon cannot read join links table');
select is((select count(*)::int from public.session_registrations), 0, 'anon sees no registrations');
select is((select registered from public.session_availability(array['f0000000-0000-4000-8000-000000000001'::uuid])), 0, 'anon can read availability counts');
select throws_ok($$ select public.register_for_session('f0000000-0000-4000-8000-000000000001') $$, '42501', null, 'anon cannot register');
reset role;

-- ---------- registration + waitlist ----------
select pg_temp.as_user('e0000000-0000-4000-8000-000000000001');
select is(public.register_for_session('f0000000-0000-4000-8000-000000000001')::text, 'registered', 'first student gets the only place');
select is(public.register_for_session('f0000000-0000-4000-8000-000000000001')::text, 'registered', 'registering twice is idempotent');
select is((select count(*)::int from public.live_session_links), 0, 'registered student still cannot read links table');
select is(public.get_join_url('f0000000-0000-4000-8000-000000000001'), null, 'join link hidden more than 15 minutes before start');
reset role;

select pg_temp.as_user('e0000000-0000-4000-8000-000000000002');
select is(public.register_for_session('f0000000-0000-4000-8000-000000000001')::text, 'waitlist', 'second student is waitlisted when full');
select is((select count(*)::int from public.session_registrations), 1, 'student sees only own registration');
reset role;

select pg_temp.as_user('a0000000-0000-4000-8000-000000000003'); -- student1, also enrolled in Power BI
select is(public.register_for_session('f0000000-0000-4000-8000-000000000001')::text, 'waitlist', 'third student is waitlisted');
reset role;

-- First student cancels → oldest waitlisted (s4) is promoted
select pg_temp.as_user('e0000000-0000-4000-8000-000000000001');
select is((select count(*)::int from public.cancel_registration('f0000000-0000-4000-8000-000000000001')), 1, 'cancelling promotes one person');
reset role;
select is((select status::text from public.session_registrations where session_id = 'f0000000-0000-4000-8000-000000000001' and user_id = 'e0000000-0000-4000-8000-000000000002'),
          'registered', 'oldest waitlisted student promoted');
select is((select status::text from public.session_registrations where session_id = 'f0000000-0000-4000-8000-000000000001' and user_id = 'a0000000-0000-4000-8000-000000000003'),
          'waitlist', 'next student still waiting');
select is((select count(*)::int from public.session_registrations where session_id = 'f0000000-0000-4000-8000-000000000001' and status = 'registered'),
          1, 'capacity never exceeded');

-- Not enrolled → cannot register for a course session; can register for the open intro
select pg_temp.as_user('a0000000-0000-4000-8000-000000000004'); -- student2, not enrolled in Power BI
select throws_ok($$ select public.register_for_session('f0000000-0000-4000-8000-000000000001') $$, '42501', null, 'non-enrolled student cannot register');
select is(public.register_for_session((select id from public.live_sessions where course_id is null limit 1))::text, 'registered', 'any user can register for the open intro session');
reset role;

-- Join window
select pg_temp.as_user('e0000000-0000-4000-8000-000000000001');
select is(public.register_for_session('f0000000-0000-4000-8000-000000000002')::text, 'registered', 'register for the session starting soon');
select is(public.get_join_url('f0000000-0000-4000-8000-000000000002'), 'https://example.com/join/soon', 'join link visible within 15 minutes of start');
reset role;
select pg_temp.as_user('e0000000-0000-4000-8000-000000000002');
select is(public.get_join_url('f0000000-0000-4000-8000-000000000002'), null, 'join link hidden from people not registered');
reset role;

-- Closed registration for past/cancelled sessions
update public.live_sessions set status = 'cancelled' where id = 'f0000000-0000-4000-8000-000000000001';
select pg_temp.as_user('a0000000-0000-4000-8000-000000000003');
select throws_ok($$ select public.register_for_session('f0000000-0000-4000-8000-000000000001') $$, 'P0001', null, 'cannot register for a cancelled session');
reset role;
update public.live_sessions set status = 'scheduled' where id = 'f0000000-0000-4000-8000-000000000001';

-- ---------- attendance + staff ----------
select pg_temp.as_user('e0000000-0000-4000-8000-000000000002');
select throws_ok($$ select public.set_attendance('f0000000-0000-4000-8000-000000000001', array['e0000000-0000-4000-8000-000000000002'::uuid], true) $$,
                 '42501', null, 'students cannot mark attendance');
reset role;

select pg_temp.as_user('a0000000-0000-4000-8000-000000000002'); -- demo instructor: Applied AI only
select is(public.get_join_url('f0000000-0000-4000-8000-000000000001'), null, 'instructor of another course gets no link');
select is((select count(*)::int from public.session_registrations where session_id = 'f0000000-0000-4000-8000-000000000001'), 0, 'instructor cannot see another course''s roster');
reset role;

-- Staff can create sessions through the API path (INSERT … RETURNING), not just via the seed
select pg_temp.as_user('a0000000-0000-4000-8000-000000000002'); -- demo instructor (Applied AI)
select lives_ok($$ insert into public.live_sessions (course_id, title, starts_at, ends_at, instructor_id)
                   select id, 'Instructor-created', now() + interval '2 days', now() + interval '2 days 1 hour', 'a0000000-0000-4000-8000-000000000002'
                   from public.courses where slug = 'applied-ai-for-professionals' returning id $$, 'instructor creates a session for own course (with RETURNING)');
select throws_ok($$ insert into public.live_sessions (course_id, title, starts_at, ends_at)
                   select id, 'Nope', now() + interval '2 days', now() + interval '2 days 1 hour'
                   from public.courses where slug = 'power-bi-mastery' $$, '42501', null, 'instructor cannot create sessions for another course');
reset role;

select pg_temp.as_user('a0000000-0000-4000-8000-000000000001'); -- admin
select lives_ok($$ insert into public.live_sessions (title, starts_at, ends_at, instructor_id)
                   values ('Admin open', now() + interval '3 days', now() + interval '3 days 1 hour', 'a0000000-0000-4000-8000-000000000001') returning id $$,
                'admin creates an open session (with RETURNING)');
select is(public.get_join_url('f0000000-0000-4000-8000-000000000001'), 'https://example.com/join/tiny', 'staff can always see the link');
select is(public.set_attendance('f0000000-0000-4000-8000-000000000001', array['e0000000-0000-4000-8000-000000000002'::uuid], true), 1, 'admin marks attendance');
update public.live_sessions set capacity = 5 where id = 'f0000000-0000-4000-8000-000000000001';
select is((select count(*)::int from public.promote_waitlist('f0000000-0000-4000-8000-000000000001')), 1, 'raising capacity promotes the waitlist');
select ok((select count(*) from public.session_registrations where session_id = 'f0000000-0000-4000-8000-000000000001') = 3, 'admin sees full roster');
reset role;

select * from finish();
rollback;
