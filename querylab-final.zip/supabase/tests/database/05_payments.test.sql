begin;
create extension if not exists pgtap with schema extensions;
select plan(30);

create or replace function pg_temp.as_user(uid uuid) returns void language sql as $$
  select set_config('role', 'authenticated', true),
         set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
$$;

insert into public.courses (id, slug, title, track, status, price_minor, currency) values
  ('e1000000-0000-4000-8000-000000000001', 'paid-ghs', 'Paid GHS', 'ai', 'published', 150000, 'GHS'),
  ('e1000000-0000-4000-8000-000000000002', 'paid-usd', 'Paid USD', 'ai', 'published', 12000, 'USD');
insert into public.coupons (code, kind, amount, currency, max_redemptions) values
  ('HALF', 'percent', 50, null, null),
  ('FREE100', 'percent', 100, null, 1),
  ('GHS200', 'fixed', 20000, 'GHS', null),
  ('OLD', 'percent', 10, null, null);
update public.coupons set expires_at = now() - interval '1 day' where code = 'OLD';

select is((select count(*)::int from pg_tables where schemaname = 'public' and not rowsecurity), 0, 'RLS enabled on every public table');

-- anon
set local role anon;
select throws_ok($$ select * from public.orders $$, '42501', null, 'anon cannot read orders');
select throws_ok($$ select * from public.coupons $$, '42501', null, 'anon cannot read coupons');
select throws_ok($$ select public.create_order('e1000000-0000-4000-8000-000000000001', 'bank_transfer') $$, '42501', null, 'anon cannot order');
reset role;

-- student2
select pg_temp.as_user('a0000000-0000-4000-8000-000000000004');
select is((select count(*)::int from public.coupons), 0, 'students cannot list coupons');
select is((select total_minor from public.quote_price('e1000000-0000-4000-8000-000000000001', 'half')), 75000, 'coupon codes are case-insensitive; 50% off');
select is((select total_minor from public.quote_price('e1000000-0000-4000-8000-000000000001', 'GHS200')), 130000, 'fixed GHS discount');
select throws_ok($$ select * from public.quote_price('e1000000-0000-4000-8000-000000000002', 'GHS200') $$, 'P0001', 'That coupon is in a different currency', 'currency mismatch rejected');
select throws_ok($$ select * from public.quote_price('e1000000-0000-4000-8000-000000000001', 'OLD') $$, 'P0001', 'That coupon has expired', 'expired coupon rejected');
select throws_ok($$ select * from public.quote_price('e1000000-0000-4000-8000-000000000001', 'NOPE') $$, 'P0001', 'That coupon code isn''t valid', 'unknown coupon rejected');

select is((select status::text from public.create_order('e1000000-0000-4000-8000-000000000001', 'bank_transfer')), 'pending', 'bank transfer order is pending');
select ok((select reference ~ '^QL-[A-Z0-9]{8}$' from public.orders limit 1), 'order gets a reference');
select is((select total_minor from public.orders where status = 'pending'), 150000, 'price computed on the server');
select is((select count(*)::int from public.enrolments where course_id = 'e1000000-0000-4000-8000-000000000001'), 0, 'no access until paid');
select is((select status::text from public.create_order('e1000000-0000-4000-8000-000000000001', 'bank_transfer', 'half')), 'pending', 'ordering again replaces the open order');
select is((select count(*)::int from public.orders where status = 'pending'), 1, 'only one open order per course');
select throws_ok($$ select public.mark_order_paid((select id from public.orders where status = 'pending')) $$, '42501', null, 'students cannot mark paid');
select throws_ok($$ update public.orders set status = 'paid' $$, '42501', null, 'orders cannot be written directly');
select lives_ok($$ select public.cancel_order((select id from public.orders where status = 'pending')) $$, 'owner can cancel a pending order');
select is((select status::text from public.create_order('e1000000-0000-4000-8000-000000000002', 'bank_transfer', 'free100')), 'paid', '100% coupon settles immediately');
select is((select source::text from public.enrolments where course_id = 'e1000000-0000-4000-8000-000000000002'), 'coupon', 'enrolled via coupon');
select throws_ok($$ select public.create_order('e1000000-0000-4000-8000-000000000002', 'bank_transfer') $$, 'P0001', 'You''re already enrolled in this course', 'cannot buy twice');
reset role;
select is((select redemptions from public.coupons where code = 'FREE100'), 1, 'redemption counted');

select pg_temp.as_user('a0000000-0000-4000-8000-000000000003'); -- student1
select throws_ok($$ select public.create_order('e1000000-0000-4000-8000-000000000002', 'bank_transfer', 'FREE100') $$, 'P0001', 'That coupon has been fully used', 'max redemptions enforced');
select is((select count(*)::int from public.orders), 0, 'students see only their own orders');
select lives_ok($$ select public.create_order('e1000000-0000-4000-8000-000000000001', 'bank_transfer') $$, 'student1 places an order');
reset role;

-- admin
select pg_temp.as_user('a0000000-0000-4000-8000-000000000001');
select ok((select invoice_number ~ '^INV-[0-9]{4}-[0-9]{6}$' from public.mark_order_paid((select id from public.orders where user_id = 'a0000000-0000-4000-8000-000000000003' and status = 'pending'), 'Received')), 'admin marks paid; invoice numbered');
select is((select status::text from public.enrolments where user_id = 'a0000000-0000-4000-8000-000000000003' and course_id = 'e1000000-0000-4000-8000-000000000001'), 'active', 'paid order grants access');
select lives_ok($$ select public.refund_order((select id from public.orders where user_id = 'a0000000-0000-4000-8000-000000000003' and status = 'paid')) $$, 'admin refunds');
select is((select status::text from public.enrolments where user_id = 'a0000000-0000-4000-8000-000000000003' and course_id = 'e1000000-0000-4000-8000-000000000001'), 'revoked', 'refund revokes access');
reset role;

select * from finish();
rollback;
