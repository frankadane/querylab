begin;
create extension if not exists pgtap with schema extensions;
select plan(29);

create or replace function pg_temp.as_user(uid uuid) returns void language sql as $$
  select set_config('role', 'authenticated', true),
         set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, true);
$$;

-- Fixture: a draft course owned by the placeholder DS instructor (not the demo instructor)
insert into public.courses (id, slug, title, track, status, instructor_id)
values ('d0000000-0000-4000-8000-000000000001', 'draft-course', 'Draft course', 'ai', 'draft', 'c1000000-0000-4000-8000-000000000002');
insert into public.sections (id, course_id, title) values ('d0000000-0000-4000-8000-000000000002', 'd0000000-0000-4000-8000-000000000001', 'S1');

select is((select count(*)::int from pg_tables where schemaname = 'public' and not rowsecurity), 0, 'RLS enabled on every public table');

-- ---------- anon ----------
set local role anon;
select is((select count(*)::int from public.courses), 3, 'anon sees only the 3 published courses');
select ok((select count(*) from public.lessons) > 80, 'anon sees published syllabus (lesson titles)');
select is((select count(*)::int from public.lesson_contents), 3, 'anon reads only the 3 free-preview lesson bodies');
select is((select count(*)::int from public.quiz_questions), 0, 'anon cannot read quiz questions/answers');
select is((select count(*)::int from public.quizzes), 0, 'anon cannot read quizzes');
select is((select count(*)::int from public.enrolments), 0, 'anon sees no enrolments');
select ok((select count(*) from public.faqs where course_id is null) = 4, 'anon reads site FAQs');
select is((select count(*)::int from public.instructors), 3, 'anon reads published instructors');
select is((select count(*)::int from public.site_settings), 1, 'anon reads site settings');
select throws_ok($$ insert into public.courses (slug, title, track) values ('x', 'x', 'ai') $$, '42501', null, 'anon cannot create courses');
reset role;

-- ---------- student1 (enrolled in Power BI only) ----------
select pg_temp.as_user('a0000000-0000-4000-8000-000000000003');
select is((select count(*)::int from public.courses where status = 'draft'), 0, 'student cannot see drafts');
select is(
  (select count(*)::int from public.lesson_contents lc join public.courses c on c.id = lc.course_id where c.slug = 'power-bi-mastery'),
  27, 'enrolled student reads all lesson bodies of their course');
select is(
  (select count(*)::int from public.lesson_contents lc join public.courses c on c.id = lc.course_id where c.slug = 'applied-ai-for-professionals'),
  1, 'non-enrolled course: free preview only');
select is((select count(*)::int from public.quiz_questions), 0, 'enrolled student still cannot read quiz answers');
select is((select count(*)::int from public.enrolments), 1, 'student sees only own enrolment');
select throws_ok($$ insert into public.enrolments (user_id, course_id, source)
                   select 'a0000000-0000-4000-8000-000000000003', id, 'manual' from public.courses where slug = 'applied-ai-for-professionals' $$,
                 '42501', null, 'student cannot self-enrol directly');
update public.courses set title = 'Hacked' where slug = 'power-bi-mastery';
select is((select count(*)::int from public.courses where title = 'Hacked'), 0, 'student cannot edit courses');
reset role;

-- ---------- demo instructor (linked to AI course only) ----------
select pg_temp.as_user('a0000000-0000-4000-8000-000000000002');
select lives_ok($$ update public.courses set subtitle = 'Edited by instructor' where slug = 'applied-ai-for-professionals' $$, 'instructor edits own course');
select is((select subtitle from public.courses where slug = 'applied-ai-for-professionals'), 'Edited by instructor', 'edit persisted');
update public.courses set subtitle = 'Nope' where slug = 'power-bi-mastery';
select isnt((select subtitle from public.courses where slug = 'power-bi-mastery'), 'Nope', 'instructor cannot edit another instructor''s course');
select is((select count(*)::int from public.courses where slug = 'draft-course'), 0, 'instructor cannot see other instructors'' drafts');
select ok((select count(*) from public.quiz_questions qq join public.quizzes q on q.id = qq.quiz_id
           join public.courses c on c.id = q.course_id where c.slug = 'applied-ai-for-professionals') = 4, 'instructor reads own quiz answers');
select throws_ok($$ update public.courses set instructor_id = 'c1000000-0000-4000-8000-000000000003' where slug = 'applied-ai-for-professionals' $$,
                 '42501', null, 'instructor cannot reassign course');
select lives_ok($$ insert into public.courses (slug, title, track, instructor_id) values ('instructor-new', 'New', 'ai', 'c1000000-0000-4000-8000-000000000001') $$,
                'instructor can create a course for themselves');
select lives_ok($$ insert into public.courses (slug, title, track, instructor_id) values ('instructor-new-2', 'New 2', 'ai', 'c1000000-0000-4000-8000-000000000001') returning id $$,
                'instructor course creation works with RETURNING (as the app does)');
select throws_ok($$ insert into public.courses (slug, title, track, instructor_id) values ('instructor-other', 'Other', 'ai', 'c1000000-0000-4000-8000-000000000002') $$,
                 '42501', null, 'instructor cannot create a course for someone else');
reset role;

-- ---------- admin ----------
select pg_temp.as_user('a0000000-0000-4000-8000-000000000001');
select ok((select count(*) from public.courses) >= 4, 'admin sees drafts too');
select lives_ok($$ insert into public.enrolments (user_id, course_id, source)
                   select 'a0000000-0000-4000-8000-000000000004', id, 'manual' from public.courses where slug = 'applied-ai-for-professionals' $$,
                'admin can enrol a user manually');
reset role;

select * from finish();
rollback;
