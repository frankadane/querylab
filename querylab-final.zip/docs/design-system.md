# QueryLab design system

Generated with the **ui-ux-pro-max** skill (`--design-system`, query
`"professional adult education data analytics AI"`), then adjusted to the brief.

## What the generator suggested vs. what we use

| Area    | Generator                                                        | QueryLab                                                                                                           | Why                                                                                                                                   |
| ------- | ---------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------- |
| Pattern | Enterprise Gateway (path selection, client logos, contact sales) | Kept path selection ("For myself / For my team") and the sales enquiry CTA. **Dropped client logos.**              | We have no real clients to show yet; the brief forbids invented logos.                                                                |
| Style   | Data-Dense Dashboard                                             | Dashboard motifs (grid, KPI tiles, mono labels) in the hero only; marketing pages use generous whitespace.         | Dense layouts suit the student/admin app, not a page meant for first-time visitors.                                                   |
| Primary | `#1E40AF` blue                                                   | `#4338CA` indigo (light) / `#818CF8` (dark)                                                                        | Brief asks for indigo; contrast is still 7.9:1.                                                                                       |
| Accent  | `#D97706` amber                                                  | `#F59E0B` amber fill with ink text, `#92400E` when amber is used as text (passes on white and on the grey surface) | Brighter amber reads as a highlight; text variant passes 4.5:1.                                                                       |
| Fonts   | Fira Sans + Fira Code                                            | **IBM Plex Sans + IBM Plex Mono**                                                                                  | Brief preference. Plex has a matching mono, tabular figures and a neutral, credible voice; Fira was a fine alternative but no better. |

Nothing playful or child-oriented was suggested, so no style override was needed on tone.

## Tokens

Defined as CSS variables in `src/app/globals.css` (light under `:root`, dark under `.dark`) and
mapped to Tailwind via `@theme inline`. Key names:

- `background`, `foreground`, `card`, `surface` (alternate section band), `ink` (navy)
- `primary` (indigo), `secondary` (indigo tint), `muted`, `muted-foreground`
- `highlight` / `highlight-foreground` / `highlight-text` (amber; shadcn's `accent` stays the subtle hover surface)
- `chart-1..5` for data visualisation

## Verified contrast (WCAG AA ≥ 4.5:1)

| Pair                          | Light | Dark  |
| ----------------------------- | ----- | ----- |
| foreground / background       | 16.99 | 15.99 |
| muted-foreground / background | 7.08  | 8.53  |
| primary text / background     | 7.44  | 6.34  |
| primary-foreground / primary  | 7.90  | 6.34  |
| ink / amber                   | 8.40  | 11.33 |
| amber text / background       | 4.73  | 11.33 |

## Rules

- Lucide SVG icons only, `aria-hidden` when decorative. No emoji.
- Visible 2px focus ring (`--ring`) on every interactive element; `cursor: pointer` on clickables.
- Touch targets ≥ 44px on mobile.
- All animation is CSS and disabled under `prefers-reduced-motion`.
- Checked at 375 / 768 / 1024 / 1440 (Playwright + axe, see `tests/e2e`).
