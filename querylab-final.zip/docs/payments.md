# Payments

QueryLab launches without card payments. Orders, invoices and coupons are **provider-agnostic**, so
Stripe or PayPal can be added later **without any database changes**.

## How an order flows

```
Course page → /checkout/:slug → create_order()  (price + coupon computed in Postgres)
   ├─ total 0 (free course or 100% coupon) → settle_order() → enrolled → /learn/:slug
   └─ total > 0 → provider.begin(order)
        ├─ bank_transfer → email with reference + bank details → /orders/:reference
        └─ (future) stripe → redirect to Stripe Checkout → webhook → confirm_order_payment()
Admin → Orders → "Mark paid" → mark_order_paid() → settle_order() → enrolment + invoice number + receipt email
Admin → Orders → "Refund"    → refund_order()    → order refunded + enrolment revoked + email
```

| Status      | Meaning                                                                              |
| ----------- | ------------------------------------------------------------------------------------ |
| `pending`   | Waiting for payment. At most one per student and course; a new checkout replaces it. |
| `paid`      | Settled; invoice number assigned (`INV-YYYY-000001`); access granted.                |
| `cancelled` | Abandoned by the student or cancelled by an admin.                                   |
| `refunded`  | Money returned; access revoked.                                                      |

All state changes happen in `SECURITY DEFINER` functions in
`supabase/migrations/20261119000006_payments.sql`. Students can read only their own orders and can't
write to the table at all.

## Providers available now

| id              | Shown at checkout | What it does                                                                      |
| --------------- | ----------------- | --------------------------------------------------------------------------------- |
| `bank_transfer` | yes               | Pending order + emailed instructions + pro-forma invoice; an admin marks it paid. |
| `free`          | no                | Price 0: settled immediately.                                                     |
| `coupon`        | no                | Fully discounted by a coupon: settled immediately.                                |
| `manual`        | no                | Label for payments an admin records (cash, sponsor invoice…).                     |

Coupons (**Admin → Coupons**) support percent or fixed amounts, an optional single course, an expiry
date and a usage limit. Codes are case-insensitive. A coupon's redemption count increases when the
order is paid.

## Adding Stripe (or PayPal) later

1. `pnpm add stripe` and add `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` to the environment.
2. Create `src/lib/payments/providers/stripe.ts`:

   ```ts
   import Stripe from "stripe";
   import type { PaymentProvider } from "../types";

   const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

   export const stripeProvider: PaymentProvider = {
     id: "stripe",
     label: "Card (Stripe)",
     description: "Pay securely by card. Access starts immediately.",
     checkout: true,
     async begin(order) {
       const session = await stripe.checkout.sessions.create({
         mode: "payment",
         customer_email: order.billing_email,
         line_items: [
           {
             quantity: 1,
             price_data: {
               currency: order.currency.toLowerCase(),
               unit_amount: order.total_minor,
               product_data: { name: order.course_title },
             },
           },
         ],
         metadata: { reference: order.reference },
         success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/orders/${order.reference}`,
         cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/orders/${order.reference}`,
       });
       return { type: "redirect", url: session.url! };
     },
     async handleWebhook(request) {
       const event = stripe.webhooks.constructEvent(
         await request.text(),
         request.headers.get("stripe-signature")!,
         process.env.STRIPE_WEBHOOK_SECRET!,
       );
       if (event.type !== "checkout.session.completed") return null;
       const s = event.data.object;
       return { reference: s.metadata!.reference, providerRef: s.payment_intent as string };
     },
   };
   ```

3. Register it in `src/lib/payments/registry.ts`.
4. In the Stripe dashboard, add the webhook endpoint `https://YOUR-DOMAIN/api/payments/stripe/webhook`
   for `checkout.session.completed`.

The shared webhook route calls `confirm_order_payment(reference, 'stripe', payment_intent)` with the
service role. It is idempotent, so Stripe's retries are safe. Note: Stripe doesn't support GHS for
all account countries; check before offering GHS card payments, or use a local PSP (Paystack,
Flutterwave, Hubtel) with the same pattern.
