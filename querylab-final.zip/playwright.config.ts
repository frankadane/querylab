import { existsSync } from "node:fs";
import { defineConfig, devices } from "@playwright/test";

if (existsSync(".env.local")) process.loadEnvFile(".env.local");

const PORT = Number(process.env.PORT ?? 3100);
const chrome = devices["Desktop Chrome"];

export default defineConfig({
  testDir: "./tests/e2e",
  globalSetup: "./tests/e2e/global-setup.ts",
  fullyParallel: true,
  retries: process.env.CI ? 2 : 0,
  use: { baseURL: `http://localhost:${PORT}`, trace: "off" },
  webServer: {
    command: `pnpm start -p ${PORT}`,
    url: `http://localhost:${PORT}`,
    reuseExistingServer: !process.env.CI,
    // Tests log in to the same demo accounts many times; production limits are unchanged.
    env: { RATE_LIMIT_MULTIPLIER: "50" },
    timeout: 120_000,
  },
  projects: [
    // Layout + accessibility checks at every breakpoint.
    {
      name: "mobile-375",
      testMatch: /landing\.spec/,
      use: { ...chrome, viewport: { width: 375, height: 812 } },
    },
    {
      name: "tablet-768",
      testMatch: /landing\.spec/,
      use: { ...chrome, viewport: { width: 768, height: 1024 } },
    },
    {
      name: "laptop-1024",
      testMatch: /landing\.spec/,
      use: { ...chrome, viewport: { width: 1024, height: 768 } },
    },
    // Functional flows run once, at desktop size.
    { name: "desktop-1440", use: { ...chrome, viewport: { width: 1440, height: 900 } } },
  ],
});
